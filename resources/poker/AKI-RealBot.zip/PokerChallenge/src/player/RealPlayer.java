package player;

import java.net.InetAddress;

import simulation.real.RealSimulator;

/**
 *
 * Created on 05.05.2008
 * @author Kami II
 */
public class RealPlayer extends PokerPlayer {

	public RealPlayer() {
		super();
    	simulator = new RealSimulator();
	}
    
    /**
     * A function for startme.bat to call
     */
    public static void main(String[] args) throws Exception{
        PokerPlayer pp = new RealPlayer();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        pp.run();

    }
}
