package player;

import java.net.InetAddress;

import simulation.UCT.UCTSimulator;

/**
 *
 * Created on 24.04.2008
 * @author Kami II
 */
public class UCTPlayer extends PokerPlayer {

	public UCTPlayer() {
		super();
    	simulator = new UCTSimulator();
	}
    
    /**
     * A function for startme.bat to call
     */
    public static void main(String[] args) throws Exception{
        PokerPlayer pp = new UCTPlayer();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        pp.run();

    }
}
