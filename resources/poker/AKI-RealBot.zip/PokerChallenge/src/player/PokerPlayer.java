package player;

/*
 * TestPlayer.java
 *
 * Created on April 21, 2006, 11:54 AM
 */

import java.net.InetAddress;

import ca.ualberta.cs.poker.free.dynamics.Card;

import ringclient.ActionFunction;
import ringclient.AdvancedRingClient;
import ringclient.interfaces.ITimerFunction;
import simulation.interfaces.ISimulator;
import simulation.montecarlo.Simulator;
import data.Action;
import data.CONSTANT;


/**
 * The main class of our PokerPlayer AKI-Bot :)
 * 
 * @author Alex, Immi, Kami
 */
public class PokerPlayer extends AdvancedRingClient {
	/** 
	 * the simulator Interface
	 */
    protected ISimulator simulator;
    
    /**
     * the function that should be called from within the timer
     */
    private ITimerFunction function;

    /**
     * Initialize this player.
     */
    public PokerPlayer() {
    	simulator = new Simulator();
    	function = new ActionFunction(this);
    }

    /**
     * starts the simulation and the timer
     */
    public synchronized void startTakeAction() {
    	simulator.startSimulation(state);
    	timerManager.waitForDecision(function);
    }
    
    /**
     * sends the decided action to the server
     */
    public void sendAction() {
        try {
        	Action a = simulator.getDecision();
        	if (CONSTANT.DEBUG_IMMI) {
        		System.out.println("Our decision: " + a + " Our Amount in: " + this.state.inPot[this.state.seatTaken]);
        		System.out.print("Hole|Board:");
        		for (Card c: this.state.hole[this.state.seatTaken]) {
        			if (c!=null)
        				System.out.print(c);
        		}
        		System.out.print("|");
        		for (Card c: this.state.board) {
        			if (c!=null)
        				System.out.print(c + "|");
        		}
        		System.out.println();
        	}
        	if (a == Action.RAISE && state.canRaise(state.seatTaken))
        		sendRaise();
            else if (a == Action.RAISE || a == Action.CALL)
            	sendCall();
            else
            	sendFold();
        } catch(Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void afterTakeAction() {
    	simulator.killTree();
    }
    
    /**
     * A function for startme.bat to call
     */
    public static void main(String[] args) throws Exception{
        PokerPlayer pp = new PokerPlayer();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        pp.run();

    }
}
