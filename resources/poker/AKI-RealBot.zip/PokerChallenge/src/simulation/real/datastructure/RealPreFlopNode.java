package simulation.real.datastructure;

import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class RealPreFlopNode extends RealRandomNode implements INode {

	public RealPreFlopNode(IArc parentArc, long id) {
		super(parentArc, id);
	}

	public RealPreFlopNode(long id) {
		super(id);
	}
}
