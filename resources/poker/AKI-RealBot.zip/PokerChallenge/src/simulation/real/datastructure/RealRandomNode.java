package simulation.real.datastructure;

import simulation.datastructure.AbstractNode;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class RealRandomNode extends AbstractNode implements INode {
	private Card random;
	
	public RealRandomNode(IArc parentArc, long id) {
		super(parentArc, id);
	}
	
	public RealRandomNode(long id) {
		super(id);
	}

	public void setCard(Card c) {
		random = c;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((random == null) ? 0 : random.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (!(obj instanceof RealRandomNode))
			return false;
		final RealRandomNode other = (RealRandomNode) obj;
		if (random == null) {
			if (other.random != null)
				return false;
		} else if (!random.equals(other.random))
			return false;
		return true;
	}
	
	

}
