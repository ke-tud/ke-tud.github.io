package simulation.datastructure;

import java.util.Arrays;
import java.util.Random;
import java.util.Vector;

import simulation.game.PlayerState;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class RandomRiverNode extends RandomNode implements INode {

	public RandomRiverNode(long id) {
		super(id);
	}

	@Override
	public RandomArc setValue(PlayerState player) {
		Random random = new Random();
		double r = random.nextDouble();
		// if o or oh
		if(player.getFlop()%3==1) {
			if(r<0.125) {
				// flush
				randomValues = new int[]{-1, 0, 0, 13};
			}
			else if(r<0.25) {
				// straight
				randomValues = new int[]{-1, 0, 0, 12};
			}
			//hit
			else if(r<0.30) {
					int i = player.getFlop();
					int e = i + (int)Math.pow(3.0, ((i/3)+1)) -1;
					randomValues = new int[]{-1, e , 0, 0};
			}
			// nh
			else randomValues = new int[]{-1, 0, 0, 0};
			
		}
		else {
			double bh = 0.12 * (player.getBucket()/4.0) + 0.88;
			//nh
			if(r < 0.88) randomValues = new int[]{-1, -1, -1, 0};
			// bh
			else if(r<bh) randomValues = new int[]{-1, -1, -1, 3};
			// sh
			else randomValues = new int[]{-1, -1, -1, 2};
		}
		
		player.setRandomBuckets(randomValues);
		Vector<IArc> childArcs = getChildArcs();
		for(IArc arc: childArcs) {
			if(arc instanceof RandomArc) {
				RandomArc rArc = (RandomArc) arc;
				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
					return rArc;
				}
			}	
		}
		return null;
		
		
		
		
		
		
		
		
//		int river = 0;
//		Random random = new Random();
//		double r = random.nextDouble();
//		if(r < 0.8) river = 0;
//		else if(r<0.87) river = 3;
//		else if(r<0.94) river = 4;
//		else {
//			river = 20;
//			player.setFlop(0);
//			player.setTurn(0);
//		}
//		randomValues = new int[]{-1, -1, -1, river};
//		player.setRiver(river);
//		Vector<IArc> childArcs = getChildArcs();
//		for(IArc arc: childArcs) {
//			if(arc instanceof RandomArc) {
//				RandomArc rArc = (RandomArc) arc;
//				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
//					return rArc;
//				}
//			}
//				
//		}
//		return null;
		
	}

}
