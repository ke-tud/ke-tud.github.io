package simulation.datastructure;

import java.util.Arrays;

import simulation.game.PlayerState;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public abstract class RandomNode extends AbstractNode implements INode {
	
	protected int[] randomValues;
	
	public RandomNode(IArc parentArc, long id) {
		super(parentArc, id);
	}

	public RandomNode(long id) {
		super(id);
	}

	public abstract RandomArc setValue(PlayerState player);
	
	public int[] getRandomValues() {
		return randomValues;
	}
	
	public String toString() {
		return randomValues.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(randomValues);
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof RandomNode))
			return false;
		final RandomNode other = (RandomNode) obj;
		if (!Arrays.equals(randomValues, other.randomValues))
			return false;
		return true;
	}

}
