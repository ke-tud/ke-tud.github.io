package simulation.datastructure;

import java.util.Arrays;
import java.util.Random;
import java.util.Vector;

import simulation.game.PlayerState;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class RandomFlopNode extends RandomNode implements INode {

	public RandomFlopNode(long id) {
		super(id);
	}

	@Override
	public RandomArc setValue(PlayerState player) {
		Random random = new Random();
		double r = random.nextDouble();
		// no hit
		if(r < 0.7) randomValues =  new int[]{-1, 0, -1, -1};
		// outs
		else if(r < 0.78) randomValues = new int[] {-1, 1, -1, -1};
		// hit
		else {
			r = random.nextDouble();
			double bh = 0.9 * (player.getBucket()/4.0);
			double sh = bh + 0.9 * (4-player.getBucket()/4.0);
			
			// out hit
			if(r < 0.1) randomValues =  new int[]{-1, 4, -1, -1};
			// bh
			else if(r<bh) randomValues =  new int[]{-1, 3, -1, -1};
			// sh
			else if(r<sh) randomValues =  new int[]{-1, 2, -1, -1};
			// more hits
			else {
				r = random.nextDouble();
				// quads
				if(r<0.05) randomValues =  new int[]{-1, 3, 3, 3};
				// trips
				else  randomValues =  new int[]{-1, 3, 3, -1};
			}
			
		}
		player.setRandomBuckets(randomValues);
		Vector<IArc> childArcs = getChildArcs();
		for(IArc arc: childArcs) {
			if(arc instanceof RandomArc) {
				RandomArc rArc = (RandomArc) arc;
				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
					return rArc;
				}
			}	
		}
		return null;
		
		
		
		
//		if(r < 0.55) flop = 0;
//		else if(r<0.65) flop = 1;
//		else if(r<0.8) flop = 3;
//		else if(r< 0.95) flop = 4;
//		else {
//			randomValues = new int[]{-1, 4, 4, -1};
//			player.setFlop(4);
//			player.setTurn(4);
//			Vector<IArc> childArcs = getChildArcs();
//			for(IArc arc: childArcs) {
//				if(arc instanceof RandomArc) {
//					RandomArc rArc = (RandomArc) arc;
//					if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
//						return rArc;
//					}
//				}	
//			}
//		}
//		randomValues = new int[]{-1, flop, -1, -1};
//		player.setFlop(flop);
//		Vector<IArc> childArcs = getChildArcs();
//		for(IArc arc: childArcs) {
//			if(arc instanceof RandomArc) {
//				RandomArc rArc = (RandomArc) arc;
//				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
//					return rArc;
//				}
//			}
//				
//		}
//		return null;
	}

}
