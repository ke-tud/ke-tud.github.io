package simulation.datastructure;

import simulation.interfaces.IArc;
import simulation.interfaces.INode;
import data.Action;

public class RandomArc extends AbstractArc implements IArc {

	private int[] randomValues;


	
	public RandomArc(INode parent, INode child, int[] randomValues) {
		super(parent, child);
		this.randomValues = randomValues;
	}

	public RandomArc(INode parent, INode child) {
		super(parent, child);
	}

	@Override
	public Action getDecision() {
		return null;
	}

	public boolean isDeterministic() {
		return false;
	}

	public int[] getRandomBucket() {
		return randomValues;
	}
}
