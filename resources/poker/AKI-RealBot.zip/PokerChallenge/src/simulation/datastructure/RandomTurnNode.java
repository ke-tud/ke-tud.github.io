package simulation.datastructure;

import java.util.Arrays;
import java.util.Random;
import java.util.Vector;

import simulation.game.PlayerState;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class RandomTurnNode extends RandomNode implements INode {
	public RandomTurnNode(long id) {
		super(id);
	}

	@Override
	public RandomArc setValue(PlayerState player) {
		Random random = new Random();
		double r = random.nextDouble();
		// if o or oh
		if(player.getFlop()%3==1) {
			if(r<0.125) {
				// flush
				randomValues = new int[]{-1, 0, 0, 13};
			}
			else if(r<0.25) {
				// straight
				randomValues = new int[]{-1, 0, 0, 12};
			}
			//hit
			else if(r<0.32) {
					int i = player.getFlop();
					int e = i + (int)Math.pow(3.0, ((i/3)+1));
					randomValues = new int[]{-1, e , 0, -1};
			}
			// nh
			else randomValues = new int[]{-1, -1, 0, -1};
			
		}
		else {
			double bh = 0.16 * (player.getBucket()/4.0) + 0.84;
			//nh
			if(r < 0.84) randomValues = new int[]{-1, -1, 0, -1};
			// bh
			else if(r<bh) randomValues = new int[]{-1, -1, 3, -1};
			// sh
			else randomValues = new int[]{-1, -1, 2, -1};
		}
		
		player.setRandomBuckets(randomValues);
		Vector<IArc> childArcs = getChildArcs();
		for(IArc arc: childArcs) {
			if(arc instanceof RandomArc) {
				RandomArc rArc = (RandomArc) arc;
				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
					return rArc;
				}
			}	
		}
		return null;
		
		
		
		
//		if(r < 0.8) turn = 0;
//		else if(r<0.87) turn = 3;
//		else if(r<0.94) turn = 4;
//		else {
//			randomValues = new int[]{-1, -1, 5, 15};
//			player.setTurn(5);
//			player.setRiver(15);
//			player.setTurn(0);
//			Vector<IArc> childArcs = getChildArcs();
//			for(IArc arc: childArcs) {
//				if(arc instanceof RandomArc) {
//					RandomArc rArc = (RandomArc) arc;
//					if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
//						return rArc;
//					}
//				}
//					
//			}
//		}
//		randomValues = new int[]{-1, -1, turn, -1};
//		player.setTurn(turn);
//		Vector<IArc> childArcs = getChildArcs();
//		for(IArc arc: childArcs) {
//			if(arc instanceof RandomArc) {
//				RandomArc rArc = (RandomArc) arc;
//				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
//					return rArc;
//				}
//			}
//				
//		}
//		return null;
	}

}
