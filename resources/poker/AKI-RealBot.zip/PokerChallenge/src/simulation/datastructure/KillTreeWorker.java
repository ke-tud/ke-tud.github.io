package simulation.datastructure;

import java.util.Vector;

import simulation.interfaces.IArc;
import simulation.interfaces.INode;

/**
 *
 * Created on 30.04.2008
 * @author Kami II
 */
public class KillTreeWorker implements Runnable {

	private INode tree;
	private Thread killTree;
	
	public KillTreeWorker(INode tree) {
		this.tree = tree;
	}
	
	public void run() {
		Vector<INode> nodes = new Vector<INode>();
		nodes.add(tree);
		while(nodes.size()>0) {
			Vector<INode> level_nodes = new Vector<INode>();
			for(INode node: nodes) {
				Vector<IArc> childArcs = node.getChildArcs();
				if (childArcs.size() == 0)
					break;
				for(IArc arc: childArcs) {
					INode child = arc.getChild();
					arc.setParent(null);
					arc.setChild(null);
					if(child!=null)
						level_nodes.add(child);
				}
			}
			nodes = level_nodes;
		}
	}


	public void startKilling() {
		killTree = new Thread(this);
		killTree.start();
	}
}
