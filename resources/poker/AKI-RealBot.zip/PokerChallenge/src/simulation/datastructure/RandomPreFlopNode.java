package simulation.datastructure;

import history.History;

import java.util.Arrays;
import java.util.Random;
import java.util.Vector;

import simulation.game.PlayerState;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class RandomPreFlopNode extends RandomNode implements INode {

	public RandomPreFlopNode(long id) {
		super(id);
	}

	@Override
	public RandomArc setValue(PlayerState player) {
		double[] probs = History.getHistory().getCurrentBucketProbabilities()[player.getPlayerSeat()];
		int bucket = 0;
		Random random = new Random();
		double r = random.nextDouble();
		if(r < probs[0]) bucket = 0;
		else if(r< probs[1]) bucket = 1;
		else if(r< probs[2]) bucket = 2;
		else if(r< probs[3]) bucket = 3;
		else bucket = 4;
		randomValues = new int[]{bucket, -1, -1, -1};
		player.setBucket(bucket);
		Vector<IArc> childArcs = getChildArcs();
		for(IArc arc: childArcs) {
			if(arc instanceof RandomArc) {
				RandomArc rArc = (RandomArc) arc;
				if(Arrays.equals(randomValues, rArc.getRandomBucket())) {
					return rArc;
				}
			}
				
		}
		return null;
	}

}
