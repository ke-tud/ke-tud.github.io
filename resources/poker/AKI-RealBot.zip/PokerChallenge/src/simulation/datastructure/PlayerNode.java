package simulation.datastructure;

import simulation.game.PlayerState;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class PlayerNode extends AbstractNode implements INode {
	
	private String playerName;
	private int bucket;
	private int flop;
	private int turn;
	private int river;
	private int seat;

	public PlayerNode(IArc parentArc, String playerName, int bucket, int[] flopturnriver, int seat, long id) {
		super(parentArc, id);
		this.playerName = playerName;
		this.bucket = bucket;
		this.flop = flopturnriver[0];
		this.turn = flopturnriver[1];
		this.river = flopturnriver[2]; 
		this.seat = seat;
	}

	public PlayerNode(String playerName, int bucket, int[] flopturnriver, int seat, long id) {
		super(id);
		this.playerName = playerName;
		this.bucket = bucket;
		this.flop = flopturnriver[0];
		this.turn = flopturnriver[1];
		this.river = flopturnriver[2];
		this.seat = seat;
	}

	public PlayerNode(PlayerState player, long id) {
		super(id);
		this.playerName = player.getName();
		this.bucket = player.getBucket();
		this.flop = player.getFlop();
		this.turn = player.getTurn();
		this.river = player.getRiver();
		this.seat = player.getSeat();
	}

	public String getName() {
		return this.playerName;
	}

	public int getBucket() {
		return this.bucket;
	}

	public int getFlop() {
		return flop;
	}

	public int getTurn() {
		return turn;
	}

	public int getRiver() {
		return river;
	}
	public String toString() {
		return "Name:" + playerName + " Bucket: " + getBucket() + " Flop: " + getFlop() + " Turn: " + getTurn() + " River: " + getRiver() + " Seat: " + seat;
	}

}
