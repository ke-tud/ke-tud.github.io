package simulation.game;

import simulation.datastructure.PlayerNode;

public class PlayerState {
	private String name;
	private boolean active;
	private boolean canAct;
	private int[] randomBucket;
	private int amountIn;
	private int amountBet;
	private int seat;
	private int playerSeat;

	public PlayerState(boolean active, boolean canRaiseNextRound, int inPot, int seat, int playerSeat) {
		
		name = "test";
		this.active = active;
		this.randomBucket = new int[]{-1,-1,-1,-1};
		this.amountIn = inPot;
		this.amountBet = this.amountIn;
		this.canAct = canRaiseNextRound;
		this.seat = seat;
		this.playerSeat = playerSeat;
	}
	
	public PlayerState(PlayerState player) {
		this.name = player.name;
		this.active = player.active;
		this.randomBucket = new int[]{player.getBucket(),player.getFlop(),player.getTurn(),player.getRiver()};
		this.amountIn = player.amountIn;
		this.amountBet = this.amountIn;
		this.canAct = player.canAct;
		this.seat = player.seat;
		this.playerSeat = player.playerSeat;
	}

	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}

	/**
	 * @param active the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}

	/**
	 * @return the bucket
	 */
	public int getBucket() {
		return randomBucket[0];
	}

	/**
	 * @param bucket the bucket to set
	 */
	public void setBucket(int bucket) {
		this.randomBucket[0] = bucket;
	}

	/**
	 * @return the flop
	 */
	public int getFlop() {
		return randomBucket[1];
	}

	/**
	 * @param flop the flop to set
	 */
	public void setFlop(int flop) {
		this.randomBucket[1] = flop;
	}

	/**
	 * @return the turn
	 */
	public int getTurn() {
		return randomBucket[2];
	}

	/**
	 * @param turn the turn to set
	 */
	public void setTurn(int turn) {
		this.randomBucket[2] = turn;
	}

	/**
	 * @return the river
	 */
	public int getRiver() {
		return randomBucket[3];
	}

	/**
	 * @param river the river to set
	 */
	public void setRiver(int river) {
		this.randomBucket[3] = river;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	public int handValue() {
		int result = 0;
		int flop = getFlop();
		int turn = getTurn();
		int river = getRiver();
		result +=flop;
		// turn
		if(flop == turn) result += turn*turn;
		else result += turn;
		// river
		if(river == turn && river == flop) {
			result += river*river*river;
			// underestimated quads
			if(result < 39) result = 39;
		}	
		else if(river == turn || river == flop) result +=river*river;
		else result += river;
		//underestimated full house
		if(result == 9) result = 14;
		return result;
		
	}

	/**
	 * @return the amountIn
	 */
	public int getAmountIn() {
		return amountIn;
	}

	/**
	 * @param amountIn the amountIn to set
	 */
	public void setAmountIn(int amountIn) {
		this.amountIn = amountIn;
	}

	public int getHighest() {
		if(getFlop() < 0) return getBucket();
		else if(getTurn() < 0) return getFlop();
		else if(getRiver() < 0) return getTurn();
		else return getRiver();
	}

	/**
	 * @return the amountBet
	 */
	public int getAmountBet() {
		return amountBet;
	}

	/**
	 * @param amountBet the amountBet to set
	 */
	public void setAmountBet(int amountBet) {
		this.amountBet = amountBet;
	}

	/**
	 * @return the canRaiseNextRound
	 */
	public boolean isCanRaiseNextRound() {
		return canAct;
	}

	/**
	 * @param canRaiseNextRound the canRaiseNextRound to set
	 */
	public void setCanRaiseNextRound(boolean canRaiseNextRound) {
		this.canAct = canRaiseNextRound;
	}

	public boolean canAct(int maxAmount) {
		return isActive() && (canAct || amountIn<maxAmount);
	}

	public void addPlayerNode(PlayerNode player) {
		this.randomBucket = new int[]{player.getBucket(),player.getFlop(),player.getTurn(),player.getRiver()};
	}

	/**
	 * @return the seat
	 */
	public int getSeat() {
		return seat;
	}
	
	public String toString() {
		return " Name: " + name + "Active: " + active + " canAct: " + canAct + "bucket: " + getBucket() + " flop: " + getFlop() + " turn: " + getTurn() + " river: " + getRiver() + " Seat: " + seat; 
	}

	public void setRandomBuckets(int[] randomBucket) {
		for(int i = 0; i < randomBucket.length; i++) {
			int rBucket = randomBucket[i];
			if(rBucket>=0) {
				this.randomBucket[i] = rBucket;
			}
		}
		
	}

	public int getPlayerSeat() {
		return this.playerSeat;
	}
	

}
