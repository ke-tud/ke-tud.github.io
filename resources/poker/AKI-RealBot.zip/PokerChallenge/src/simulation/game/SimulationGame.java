package simulation.game;

import java.util.Random;
import java.util.Vector;

import ringclient.ClientRingDynamics;
import simulation.datastructure.DecisionArc;
import simulation.datastructure.LeafNode;
import simulation.datastructure.PlayerNode;
import simulation.datastructure.RandomArc;
import simulation.datastructure.RandomFlopNode;
import simulation.datastructure.RandomNode;
import simulation.datastructure.RandomPreFlopNode;
import simulation.datastructure.RandomRiverNode;
import simulation.datastructure.RandomTurnNode;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;
import data.Action;
import data.CONSTANT;
import data.SimulationGuide;

public class SimulationGame {
	private SimulationGuide simulationGuides;
	private Random random;
	private PlayerState[] playerStates;
	private int actualSeat;
	private int bettingRound;
	private int round;
	private int ownSeat;
	private int maxInPot;
	private ClientRingDynamics crd;

	public SimulationGame(ClientRingDynamics crd, INode root) {
		this.crd = crd;
		this.random = new Random();
		this.playerStates = new PlayerState[CONSTANT.PLAYER_COUNT];
		this.simulationGuides = new SimulationGuide(crd);
		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
			this.playerStates[i] = new PlayerState(crd.active[i],
					crd.canRaiseNextTurn[i], crd.inPot[i], i, crd.seatToPlayer(i));
		}
		this.actualSeat = crd.seatTaken;
		this.ownSeat = this.actualSeat;
		bettingRound = crd.roundBets;
		round = crd.roundIndex;
		maxInPot = crd.getMaxInPot();
		if (root instanceof PlayerNode) {
			PlayerNode pNode = (PlayerNode) root;
			PlayerState player = playerStates[ownSeat];
			player.addPlayerNode(pNode);
		}
	}

	public SimulationGame(SimulationGame game) {
		this.crd = game.crd;
		this.random = new Random();
		this.playerStates = new PlayerState[CONSTANT.PLAYER_COUNT];
		this.simulationGuides = new SimulationGuide(crd);
		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
			this.playerStates[i] = new PlayerState(game.playerStates[i]);
		}
		this.actualSeat = game.actualSeat;
		this.bettingRound = game.bettingRound;
		this.round = game.round;
		this.ownSeat = game.ownSeat;
		this.maxInPot = game.maxInPot;
		
	}

	public INode getNextNode() {
		PlayerState player;
		// Game ends
		if (getNumActivePlayer() <= 1)
			return actualLeafNode();
		// new Round starts
		if (getNumPlayerToAct() == 0) {
			startNewRound();
		}

		player = getNextPlayerCanAct();
		if (player.getBucket() < 0)
			return new RandomPreFlopNode(CONSTANT.getNodeId());
		if (round == 0) {
			actualSeat = player.getSeat();
			return new PlayerNode(player,CONSTANT.getNodeId());
		} else {
			if (player.getFlop() < 0)
				return new RandomFlopNode(CONSTANT.getNodeId());
			if (round == 1) {
				actualSeat = player.getSeat();
				return new PlayerNode(player, CONSTANT.getNodeId());
			} else {
				if (player.getTurn() < 0)
					return new RandomTurnNode(CONSTANT.getNodeId());
				if (round == 2) {
					actualSeat = player.getSeat();
					return new PlayerNode(player,CONSTANT.getNodeId());
				} else {
					if (player.getRiver() < 0)
						return new RandomRiverNode(CONSTANT.getNodeId());
					if (round == 3) {
						actualSeat = player.getSeat();
						return new PlayerNode(player,CONSTANT.getNodeId());
					} else
						return actualLeafNode();
				}
			}
		}

	}

	private void startNewRound() {
		round++;
		bettingRound = 0;
		maxInPot += getBetSize();
		for (PlayerState p : playerStates) {
			if (p.isActive())
				p.setCanRaiseNextRound(true);
		}
		actualSeat = getNextSeatCanAct();
	}

	private int getNextSeatCanAct() {
		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
			PlayerState p = playerStates[i];
			if (p.canAct(maxInPot))
				return i;
		}
		return 0;
	}

	private int getBetSize() {
		if (round < 2)
			return 2;
		else
			return 4;
	}

	private int getNumPlayerToAct() {
		int actPlayers = 0;
		for (PlayerState player : playerStates) {
			if (player.canAct(maxInPot))
				actPlayers++;
		}
		return actPlayers;
	}

	private int getNumActivePlayer() {
		int activePlayers = 0;
		for (PlayerState player : playerStates) {
			if (player.isActive())
				activePlayers++;
		}
		return activePlayers;
	}

	private INode actualLeafNode() {
		LeafNode leaf = new LeafNode(CONSTANT.getNodeId());
		double[] value = new double[CONSTANT.PLAYER_COUNT];
		if(!playerStates[ownSeat].isActive()) {
			value[ownSeat] = -playerStates[ownSeat].getAmountIn();
			leaf.setValue(value[ownSeat]);
			return leaf;
		}
		int winner = 0;
		int pot = 0;
		int handvalue = -1;
		int bucket = -1;
		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
			PlayerState player = playerStates[i];
			int tempValue = player.handValue();
			if (player.isActive() && tempValue > handvalue || (tempValue == handvalue && player.getBucket() > bucket)) {
				winner = i;
				handvalue = tempValue;
				bucket = player.getBucket();
			}
			
			pot += player.getAmountIn();
			value[i] = -player.getAmountIn();
		}
		value[winner] = pot;
		leaf.setValue(value[ownSeat]);
		return leaf;
	}

	private PlayerState getNextPlayerCanAct() {
		for (int i = 1; i <= CONSTANT.PLAYER_COUNT; i++) {
			PlayerState player = playerStates[(i + actualSeat) % CONSTANT.PLAYER_COUNT];
			if (player.canAct(maxInPot))
				return player;
		}
		return null;
	}

	public DecisionArc getDecision(PlayerNode pNode) {
		double fold = simulationGuides.getValue(actualSeat, round, pNode.getBucket(), 2);
		double raise = simulationGuides.getValue(actualSeat, round, pNode.getBucket(),0);
		double ran = random.nextDouble();
		Action a = Action.FOLD;
		if (ran < fold) {
			foldAction();
			a = Action.FOLD;
		} else if (ran < raise + fold) {
			if (bettingRound == 3) {
				callAction();
				a = Action.CALL;
			} else {
				raiseAction();
				a = Action.RAISE;
			}
		} else {
			callAction();
			a = Action.CALL;
		}
		DecisionArc arc = new DecisionArc(pNode, a);
		Vector<IArc> childArcs = pNode.getChildArcs();
		if (childArcs.contains(arc)) {
			DecisionArc dArc = (DecisionArc) childArcs.get(childArcs
					.indexOf(arc));
			INode n = dArc.getChild();
			// new Round starts
			if (getNumPlayerToAct() == 0) {
				startNewRound();
			}
			if (n instanceof PlayerNode)
				actualSeat = getNextPlayerCanAct().getSeat();
			return dArc;
		} else {
			INode nextNode = getNextNode();
			arc.setChild(nextNode);
			nextNode.initParent(arc);
			pNode.addArc(arc);
			return arc;
		}
	}

	public DecisionArc getDecision(PlayerNode pNode, int i) {
		Action a = Action.FOLD;
		if (i == 0) {
			foldAction();
			a = Action.FOLD;
		} else if (i == 1) {
			if (bettingRound == 3) {
				callAction();
				a = Action.CALL;
			} else {
				raiseAction();
				a = Action.RAISE;
			}
		} else {
			callAction();
			a = Action.CALL;
		}
		DecisionArc arc = new DecisionArc(pNode, a);
		Vector<IArc> childArcs = pNode.getChildArcs();
		if (childArcs.contains(arc)) {
			DecisionArc dArc = (DecisionArc) childArcs.get(childArcs
					.indexOf(arc));
			INode n = dArc.getChild();
			// new Round starts
			if (getNumPlayerToAct() == 0) {
				startNewRound();
			}
			if (n instanceof PlayerNode)
				actualSeat = getNextPlayerCanAct().getSeat();
			return dArc;
		} else {
			INode nextNode = getNextNode();
			arc.setChild(nextNode);
			nextNode.initParent(arc);
			pNode.addArc(arc);
			return arc;
		}
	}

	/**
	 * If someone raises
	 */
	private void raiseAction() {
		bettingRound++;
		maxInPot += getBetSize();
		PlayerState player = playerStates[actualSeat];
		player.setAmountIn(maxInPot);
		for (PlayerState p : playerStates) {
			if (p.isActive())
				p.setCanRaiseNextRound(true);
		}
		player.setCanRaiseNextRound(false);
	}

	private void callAction() {
		PlayerState player = playerStates[actualSeat];
		player.setAmountIn(maxInPot);
		player.setCanRaiseNextRound(false);

	}

	/**
	 * If we fold the game will be set inactive No need to process this path
	 * anymore
	 */
	private void foldAction() {
		if(actualSeat== ownSeat) {
			for(PlayerState p: playerStates) {
				p.setActive(false);
			}
		}
		else 
			playerStates[actualSeat].setActive(false);
	}

	public INode getNextNode(RandomNode randomNode) {
		PlayerState player = getNextPlayerCanAct();
		RandomArc arc = randomNode.setValue(player);
		if (arc != null) {
			INode n = arc.getChild();
			// new Round starts
			if (getNumPlayerToAct() == 0) {
				startNewRound();
			}
			if (n instanceof PlayerNode)
				actualSeat = player.getSeat();
		} else {
			INode node = getNextNode();
			arc = new RandomArc(randomNode, node, randomNode.getRandomValues());
			node.initParent(arc);
		}
		return arc.getChild();
	}

	
	public void incrementGame(IArc arc) {
		if(arc instanceof RandomArc) {
			incrementGame((RandomArc) arc);
		}
		else if(arc instanceof DecisionArc) {
			incrementGame((DecisionArc) arc);
		}
	}
	
	private void incrementGame(RandomArc arc) {
		PlayerState player = getNextPlayerCanAct();
		player.setRandomBuckets(arc.getRandomBucket());
		getNextNode();
	}
	private void incrementGame(DecisionArc arc) {
		Action a = arc.getDecision();
		switch(a) {
		case FOLD: foldAction(); break;
		case CALL: callAction(); break;
		case RAISE: raiseAction(); break;
		}
		getNextNode();
	}
}
