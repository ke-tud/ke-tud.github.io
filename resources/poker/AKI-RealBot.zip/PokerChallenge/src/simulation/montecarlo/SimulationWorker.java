package simulation.montecarlo;

import simulation.game.SimulationGame;
import simulation.interfaces.INode;

public class SimulationWorker implements Runnable {

	private INode root;
	private SimulationGame game;
	private Thread simWorker;
	private INode startNode;
	private int runs;
	private boolean stopped;

	public SimulationWorker(INode root, SimulationGame game, INode startNode) {
		this(root, game, startNode, -1);
	}
	
	public SimulationWorker(INode root, SimulationGame game, INode startNode, int runs) {
		this.root = root;
		this.game = game;
		this.startNode = startNode;
		this.runs = runs;
		this.stopped = false;
		startWork();
	}


	public void run() {
		Thread currentThread = Thread.currentThread();
		int actualRun = 0;
		while(currentThread == simWorker) {
			PathSimulator ps = new PathSimulator(root, new SimulationGame(game));
			ps.startPath(startNode);
			if(this.runs > 0) {
				actualRun++;
				if(actualRun >= runs)
					stopWork();
			}
		}
		synchronized (this) {
			setStopped(true);
			try {
				notifyAll();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void startWork() {
		simWorker = new Thread(this);
		simWorker.start();
	}
	
	public void stopWork() {
		simWorker = null;
	}
	
	public synchronized void setStopped(boolean stopped) {
		this.stopped = stopped;
	}
	
	public synchronized boolean isStopped() {
		return stopped;
	}
}
