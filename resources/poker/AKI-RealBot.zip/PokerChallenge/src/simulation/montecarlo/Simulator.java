package simulation.montecarlo;

import java.util.Vector;

import ringclient.ClientRingDynamics;
import simulation.datastructure.DecisionArc;
import simulation.datastructure.KillTreeWorker;
import simulation.datastructure.LeafNode;
import simulation.datastructure.PlayerNode;
import simulation.game.SimulationGame;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;
import simulation.interfaces.ISimulator;
import data.Action;
import data.Bucket;
import data.CONSTANT;

public class Simulator implements ISimulator {
	private INode root;
	private int ownSeat;
	private ClientRingDynamics crd;
	private Vector<SimulationWorker> workerThreads;
	private boolean started = false;
	private long start;
	private long stop;
	private INode oldRoot;

	public Action getDecision() {
		oldRoot = root;
		if (started) {
			// Stop simulationThreads
			for (SimulationWorker simW : workerThreads)
				simW.stopWork();
			// getBestChild
			this.stop = System.currentTimeMillis();
			Vector<IArc> childArcs = root.getChildArcs();
			int simCount = 0;
			Action actualDecision = Action.FOLD;
			if (CONSTANT.DEBUG_IMMI) 
				System.out.println("Decisions: ");

//			double actualValue = new double[CONSTANT.PLAYER_COUNT];
			double actualValue = Double.NEGATIVE_INFINITY;
			for (IArc child : childArcs) {

				Action decision = child.getDecision();
				
				simCount += child.getSimulationCount();
				double tempValue = child.getValue();
				if (CONSTANT.DEBUG_IMMI)
					System.out.println("Dec: " + decision + " Value: " + tempValue);
				if (tempValue > actualValue) {
					actualValue = tempValue;
					actualDecision = decision;
				}
			}
			started = false;
			if (CONSTANT.DEBUG_IMMI) {
				System.out.println("SimCount: " + simCount + " Time (in ms): " + (stop - start));
			}
			return actualDecision;
		}
		return Action.FOLD;
	}

	public void startSimulation(ClientRingDynamics crd) {
		this.start = System.currentTimeMillis();
		if (CONSTANT.DEBUG_IMMI) {
			System.out
					.println("We use Monte Carlo Simulation and we are player: "
							+ crd.seatToPlayer(crd.seatTaken));
		}
		workerThreads = new Vector<SimulationWorker>();
		CONSTANT.NODE_ID = 0;
		this.ownSeat = crd.seatTaken;
		this.crd = crd;
		this.root = getRootNode();
		started = true;
		// Expand one step
		// make fold decision
		SimulationGame fold = new SimulationGame(crd, root);
		DecisionArc foldArc = fold.getDecision((PlayerNode) root, 0);
		// make no simulation, value doesn't change here
		foldArc.addValue(((LeafNode)foldArc.getChild()).getValue());
		// make raise decision
		SimulationGame raise = new SimulationGame(crd, root);
		DecisionArc raiseArc = raise.getDecision((PlayerNode) root, 1);
		SimulationWorker raiseW = new SimulationWorker(root, raise, raiseArc
				.getChild());
		workerThreads.add(raiseW);
		if (raiseArc.getDecision() == Action.RAISE) {
			// make call decision
			SimulationGame call = new SimulationGame(crd, root);
			DecisionArc callArc = call.getDecision((PlayerNode) root, 2);
			SimulationWorker callW = new SimulationWorker(root, call, callArc
					.getChild());	
			workerThreads.add(callW);
		}

	}

	private INode getRootNode() {
		PlayerNode node = new PlayerNode("SimBot", getOwnBucket(),
				getOwnFlopTurnRiver(), ownSeat,CONSTANT.getNodeId());
		return node;
	}

	private int[] getOwnFlopTurnRiver() {
		if (crd.roundIndex < 1)
			return new int[] { -1, -1, -1 };
		else
			return Bucket.getFlopTurnRiver(crd.board, crd.hole[ownSeat]);
	}

	private int getOwnBucket() {
		return Bucket.getBucket(crd.hole[ownSeat]);
	}

	public void killTree() {
    	synchronized (this) {
            try {
            	boolean allStopped = false;
            	while (!allStopped) {
            		allStopped = true;
            		synchronized (workerThreads) {
            			for (SimulationWorker simW : workerThreads)
            				allStopped = allStopped && simW.isStopped();
            		}
            		wait(5);
            	}
            } catch(Exception e) {
                System.err.println("Could not stop WorkerThreads");
                System.err.println(e.getMessage());
                e.printStackTrace();
            }    		
    	}
		KillTreeWorker ktw = new KillTreeWorker(oldRoot);
		ktw.startKilling();
	}
}
