package simulation.montecarlo;

import ringclient.ClientRingDynamics;
import simulation.datastructure.DecisionArc;
import simulation.datastructure.LeafNode;
import simulation.datastructure.PlayerNode;
import simulation.datastructure.RandomNode;
import simulation.game.SimulationGame;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class PathSimulator {
	private INode root;

	private SimulationGame game;

	public PathSimulator(INode root, ClientRingDynamics crd) {
		this.root = root;
		this.game = new SimulationGame(crd, root);
	}

	public PathSimulator(INode root, SimulationGame game) {
		this.root = root;
		this.game = game;
	}

	public void simulatePath(INode node) {
		while (!(node instanceof LeafNode)) {
			if (node instanceof PlayerNode) {
				DecisionArc arc = game.getDecision((PlayerNode) node);
				node = arc.getChild();
			} else {
				node = game.getNextNode((RandomNode) node);
			}
		}
		LeafNode leaf = (LeafNode) node;
		backTrace(node.getParentArc(), leaf.getValue());
	}

	private void backTrace(IArc arc, double value) {
		if (root != null && arc!=null) {
			INode parent = arc.getParent();
			
			while (parent!=null && !parent.equals(root)) {
				arc.addValue(value);
				arc = parent.getParentArc();
				parent = arc.getParent();
			}
			arc.addValue(value);
		}
	}

	public void startPath(INode startNode) {
		this.simulatePath(startNode);
	}
}
