package simulation.UCT;

import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import simulation.game.SimulationGame;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;
import simulation.montecarlo.PathSimulator;
import data.Action;

public class SimulationWorker {

	private INode root;
	private SimulationGame game;
	private INode currentNode;
	private ExpansionWorker expansion;

	public SimulationWorker(INode root, INode selectedNode, SimulationGame currentGame, ExpansionWorker expansion) {
		this.root = root;
		this.currentNode = selectedNode;
		this.game = currentGame;
		this.expansion = expansion;
	}

	public void simulateChildPaths() {
		if(expansion==null) {
			PathSimulator ps = new PathSimulator(root,game);
			ps.simulatePath(currentNode);
		}
		else {
			ConcurrentHashMap<Action, SimulationGame> gamestates = expansion.getExpandedGameStates();
			Vector<simulation.montecarlo.SimulationWorker> simWorkers = new Vector<simulation.montecarlo.SimulationWorker>();
			for(IArc arc: currentNode.getChildArcs()) {
				simWorkers.add(new simulation.montecarlo.SimulationWorker(root, gamestates.get(arc.getDecision()), arc.getChild(), 5));
			}
	    	synchronized (this) {
	            try {
	            	boolean allStopped = false;
	            	while (!allStopped) {
	            		allStopped = true;
	            		synchronized (simWorkers) {
		            		for (simulation.montecarlo.SimulationWorker simW : simWorkers)
		            			allStopped = allStopped && simW.isStopped();
	            		}
	            		wait(3);
	            	}
	            } catch(Exception e) {
	                System.err.println("Could not stop WorkerThreads");
	                System.err.println(e.getMessage());
	                e.printStackTrace();
	            }    		
	    	}
		}
	}

}
