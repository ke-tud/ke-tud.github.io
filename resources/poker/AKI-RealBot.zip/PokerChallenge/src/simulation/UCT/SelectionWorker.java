package simulation.UCT;

import java.util.Vector;

import simulation.datastructure.PlayerNode;
import simulation.game.SimulationGame;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;

public class SelectionWorker {

	private double C;
	private SimulationGame game;
	private INode root;
//	private int ownSeat;

	public SelectionWorker(INode root, SimulationGame gameState, double c,
			int ownSeat) {
		this.game = gameState;
		this.C = c;
		this.root = root;
//		this.ownSeat = ownSeat;
	}

	public INode getSelectionNode() {
		return getSelectionNode(root);
	}

	private INode getSelectionNode(INode node) {
		if (node == null || node.children() == 0 || 
				node instanceof PlayerNode && node.children() < 2)
			return node;
		else {
			Vector<IArc> childArcs = node.getChildArcs();
			double n_p = 0;
			if (node.getParentArc() != null) {
				n_p = Math.log(node.getParentArc().getSimulationCount());
			}
			else {
				for (IArc arc : childArcs) {
					n_p += arc.getSimulationCount();
				}
				n_p = Math.log(n_p);
			}
			IArc choice = null;
			double k = 0;
			for (IArc arc : childArcs) {
				int n_i = arc.getSimulationCount();
				double v_i = getValue(arc);
				double k_i = v_i + C * (Math.sqrt(n_p / ((double) n_i)));
				if (choice == null || k_i > k) {
					k = k_i;
					choice = arc;
				}
			}
			game.incrementGame(choice);
			return getSelectionNode(choice.getChild());
		}
	}

	private double getValue(IArc arc) {
//		double sumValue = 0;
//		for (double d : arc.getValue()) {
//			sumValue += d;
//		}

//		return (2 * arc.getValue()[ownSeat]) - sumValue;
		return arc.getValue();
	}

}
