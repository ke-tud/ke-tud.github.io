package simulation.UCT;

import java.util.Vector;

import ringclient.ClientRingDynamics;
import simulation.datastructure.DecisionArc;
import simulation.datastructure.KillTreeWorker;
import simulation.datastructure.PlayerNode;
import simulation.game.SimulationGame;
import simulation.interfaces.IArc;
import simulation.interfaces.INode;
import simulation.interfaces.ISimulator;
import data.Action;
import data.Bucket;
import data.CONSTANT;

public class UCTSimulator implements ISimulator, Runnable {

	private int ownSeat;
	private INode root;
	private ClientRingDynamics crd;
	private SimulationGame game;
	private Thread UCT;
	private double C;
	private boolean started = false;
	private boolean locked = false;
	private INode oldRoot;

	public Action getDecision() {
		oldRoot = root;
		if (started) {
			UCT = null;
	    	synchronized (this) {
	            try {
	            	while (locked) {
	            		wait(2);
	            	}
	            } catch(Exception e) {
	                System.err.println("Could not stop SimulationThread");
	                System.err.println(e.getMessage());
	                e.printStackTrace();
	            }    		
	    	}
			Vector<IArc> rootChild = root.getChildArcs();
			int simCount = 0;
			int accSimCount = 0;
			Action action = Action.CALL;
			for (IArc a : rootChild) {
				if (a instanceof DecisionArc) {
					int tempSim = a.getSimulationCount();
					accSimCount += tempSim;
					if (tempSim > simCount) {
						action = a.getDecision();
						simCount = tempSim;
					}
				}
			}
			if (CONSTANT.DEBUG_IMMI) {
				System.out.println();
				System.out.println("SimCount: " + accSimCount);
			}
			started = false;
			return action;
		} else
			return Action.FOLD;
	}

	public void startSimulation(ClientRingDynamics crd) {
		if (CONSTANT.DEBUG_IMMI) {
			System.out.println("We use UCT Simulation and we are player: "
					+ crd.seatToPlayer(crd.seatTaken));
		}
		CONSTANT.NODE_ID = 0;
		this.ownSeat = crd.seatTaken;
		this.crd = crd;
		this.root = getRootNode();
		this.game = new SimulationGame(crd, root);
		this.C = Math.sqrt(2);
		this.started = true;
		this.UCT = new Thread(this);
		UCT.start();
	}

	private INode getRootNode() {
		PlayerNode node = new PlayerNode("SimBot", getOwnBucket(),
				getOwnFlopTurnRiver(), ownSeat, CONSTANT.getNodeId());
		return node;
	}

	private int[] getOwnFlopTurnRiver() {
		if (crd.roundIndex < 1)
			return new int[] { -1, -1, -1 };
		else
			return Bucket.getFlopTurnRiver(crd.board, crd.hole[ownSeat]);
	}

	private int getOwnBucket() {
		return Bucket.getBucket(crd.hole[ownSeat]);
	}

	public void run() {
		Thread currentThread = Thread.currentThread();
		locked = true;
		while (currentThread == UCT) {
			SimulationGame currentGame = new SimulationGame(game);
			SelectionWorker selection = new SelectionWorker(root, currentGame,
					C, ownSeat);
			INode selectedNode = selection.getSelectionNode();
			ExpansionWorker expansion = null;
			if (selectedNode instanceof PlayerNode) {
				if (selectedNode.children() < 2) {
					expansion = new ExpansionWorker((PlayerNode) selectedNode,
							currentGame);
					if (selectedNode.equals(root)) {
						expansion.expandRoot();
					} else {
						expansion.expandNode();
					}
				}
			}
			SimulationWorker simWorker = new SimulationWorker(root,
					selectedNode, currentGame, expansion);
			simWorker.simulateChildPaths();
		}
		locked = false;
	}

	public void killTree() {
		KillTreeWorker ktw = new KillTreeWorker(oldRoot);
		ktw.startKilling();
//		root = null;
	}
}
