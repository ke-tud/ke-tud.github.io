package simulation.UCT;

import java.util.concurrent.ConcurrentHashMap;

import simulation.datastructure.DecisionArc;
import simulation.datastructure.PlayerNode;
import simulation.game.SimulationGame;
import data.Action;

public class ExpansionWorker {
	private PlayerNode startNode;
	private SimulationGame game;
	private ConcurrentHashMap<Action, SimulationGame> expandedGameStates;

	public ExpansionWorker(PlayerNode selectedNode, SimulationGame currentGame) {
		this.game = currentGame;
		this.startNode = selectedNode;
		this.expandedGameStates = new ConcurrentHashMap<Action, SimulationGame>();
	}

	public void expandNode() {
		// Expand fold
//		SimulationGame fold = new SimulationGame(game);
//		DecisionArc foldArc = fold.getDecision(startNode, 0);
//		expandedGameStates.put(foldArc.getDecision(), fold);
		// Expand raise
		SimulationGame raise = new SimulationGame(game);
		DecisionArc raiseArc = raise.getDecision(startNode, 1);
		expandedGameStates.put(raiseArc.getDecision(), raise);
		if (raiseArc.getDecision() == Action.RAISE) {
			// Expand call
			SimulationGame call = new SimulationGame(game);
			DecisionArc callArc = call.getDecision(startNode, 2);
			expandedGameStates.put(callArc.getDecision(), call);
		}
		// TODO Expand Random Nodes

	}

	public void expandRoot() {

		// Expand fold
		SimulationGame fold = new SimulationGame(game);
		DecisionArc foldArc = fold.getDecision(startNode, 0);
		expandedGameStates.put(foldArc.getDecision(), fold);
		// Expand raise
		SimulationGame raise = new SimulationGame(game);
		DecisionArc raiseArc = raise.getDecision(startNode, 1);
		expandedGameStates.put(raiseArc.getDecision(), raise);
		if (raiseArc.getDecision() == Action.RAISE) {
			// Expand call
			SimulationGame call = new SimulationGame(game);
			DecisionArc callArc = call.getDecision(startNode, 2);
			expandedGameStates.put(callArc.getDecision(), call);
		}

		// TODO Expand Random Nodes

	}

	/**
	 * @return the expandedGameStates
	 */
	public ConcurrentHashMap<Action, SimulationGame> getExpandedGameStates() {
		return expandedGameStates;
	}

}
