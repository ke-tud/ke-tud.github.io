package simulation.interfaces;

import data.Action;
import ringclient.ClientRingDynamics;

public interface ISimulator {
	public Action getDecision();
	public void startSimulation(ClientRingDynamics crd);
	public void killTree();
}
