#!/bin/bash
java -Xms128m -Xmx256m -cp lib/pokerserver.jar:AKI.jar player.PokerPlayer $1 $2
