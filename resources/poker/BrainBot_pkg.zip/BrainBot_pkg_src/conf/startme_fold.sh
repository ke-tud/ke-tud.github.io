java -cp pokerserver.jar:simbot.jar de.tud.inf.poker.g7bot.G7_FoldBot $1 $2 
