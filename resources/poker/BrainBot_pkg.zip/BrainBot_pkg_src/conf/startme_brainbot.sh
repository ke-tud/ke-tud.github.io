java -Xmx256m -Xms256m -cp weka.jar:joone-engine.jar:pokerserver.jar:HoldEmShowdown.jar:simbot.jar de.tud.inf.poker.g7bot.G7_BrainBot $1 $2 
