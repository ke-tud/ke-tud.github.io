java -cp pokerserver.jar:HoldEmShowdown.jar:weka.jar:simbot.jar de.tud.inf.poker.g7bot.G7_OppBot $1 $2 
