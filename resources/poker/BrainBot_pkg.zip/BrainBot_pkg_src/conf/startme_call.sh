java -cp pokerserver.jar:simbot.jar de.tud.inf.poker.g7bot.G7_CallBot $1 $2 
