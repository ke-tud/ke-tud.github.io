java -cp pokerserver.jar:simbot.jar de.tud.inf.poker.g7bot.free.SampleAdvRingBot $1 $2 
