java -cp pokerserver.jar:HoldEmShowdown.jar:simbot.jar de.tud.inf.poker.g7bot.G7_PreFlopBot $1 $2 
