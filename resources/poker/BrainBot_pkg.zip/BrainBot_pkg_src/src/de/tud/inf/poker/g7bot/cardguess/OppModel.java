package de.tud.inf.poker.g7bot.cardguess;

import java.text.NumberFormat;
import ca.ualberta.cs.poker.free.dynamics.Card;
import com.stevebrecher.poker.HandEval;
import de.tud.inf.poker.g7bot.free.ClientRingDynamics;
import de.tud.inf.poker.g7bot.simulator.WinProbabilitySimulator;

/**
 * OppModel connects a g7_bot with a Weka training and classifying object:
 * How to implement Weka Opponent Modelling in a g7_bot:
 * Insert Objects in Class:   import de.tud.inf.poker.g7bot.cardguess.OppModel;
 *  and                       OppModel oppmodel;
 * call in bot constructor:   oppmodel = new OppModel(Dynamics);
 * call in newHandStarted:    oppmodel.newHandStarted(clientCards);
 * call in takeAction or act.Performed:        double[] winProbs = oppmodel.takeAction();
 * call in actionPerformed:   oppmodel.actionPerformed(lastAction, lastSeat, showdown);
 */
public class OppModel
{  

	public ClientRingDynamics Dynamics;
	long          myHoleCards;
	long          flop;
	long          turn;
	long          river;
	boolean       sysprints;
	int alterRoundBets;
	int newRound;
	
	// Cardguess for Opponent Model with WEKA
	CardguessWeka cardguessWeka;
	
	// gameStates holds information for each player and each round
	float         gameStates[][][];
	int           subround[];
	
	
	/**
	 * The constructor needs the Dynamics-Object of the Bot
	 * @MyDynamics is a ClientRingDynamics object of the bot
	 */
	public OppModel(ClientRingDynamics MyDynamics)
	{
		Dynamics = MyDynamics;
		sysprints = true;
		subround = new int[6];
		newRound = 0;
		

		// Initiate Cardguess for WEKA OppModel
		cardguessWeka = new CardguessWeka("winp1");
		//myBot.cardguessWekaSpectrum = new CardguessWeka("spec1");
		System.out.println("WEKA OppModel was initiated");
		gameStates = new float[6][5][10];
	}
	
	public void actionPerformed(char lastAction, int lastSeat,  boolean showdown)
	{
		
		// count roundBets - for longer consistens then the Dynamics.roundBets object
		if (Dynamics.roundIndex >= newRound) 
		{
			alterRoundBets = 0;
			newRound = Dynamics.roundIndex;
		}
		
		// WEKA OppModel TODO that does not look nice
		int playerNumber;
		if ( Dynamics.seatToAct == 0)
			playerNumber = 5;
			else 
			 playerNumber = Dynamics.seatToAct -1 ;
		
		//System.out.println("OppModel.actionPerformed for player " + playerNumber);
		int round = Dynamics.roundIndex;

		
		
		// WEKA OppModel: storeGameStat: gather and store data of a player
		if (lastAction != 'f') storeGameState(playerNumber, lastAction, alterRoundBets);
		
		// BWEKA OppModel: train on showdown
		if (showdown)
		{
			trainOppModel();
		}
		
		// WEKA OppModel: test classifier by simulation and WEKA predicting
		// winning probabilities of the own player
		// TODO Remove this part in final bots
		
		//String playerName = Dynamics.botNames[playerNumber];
		
		
		
		//String classifyValuesString = "WEKA classi for player " + playerName
		 //                             + " (" + playerNumber + ") with values: ";
		//for (int i = 0; i <= gameStates[playerNumber][round].length - 1; i++)
	//	{
		//	classifyValuesString = classifyValuesString + "; "
			//                       + ((Float) gameStates[playerNumber][round][i]).toString();
	//	}
		//System.out.println(classifyValuesString);
		
		
		
		
		// cardguessWeka.classi(playerNumber, classifyValues);
		// END WEKA OppModel: calculating winning probability of player with last
		// action
		
		
		if (Dynamics.firstActionOnRound) // update board cards
		{
			Card[] board = Dynamics.board;
			if (board != null)
			{
				if (board.length > 4)
					river = HandEval
					                .encode(com.stevebrecher.poker.Card
					                                                   .getInstance(board[4]
					                                                                        .toString()));
				else if (board.length > 3)
					turn = HandEval
					               .encode(com.stevebrecher.poker.Card
					                                                  .getInstance(board[3]
					                                                                       .toString()));
				else if (board.length > 0)
				   flop = HandEval
				                  .encode(com.stevebrecher.poker.Card
				                                                     .getInstance(board[0]
				                                                                          .toString()))
				          | HandEval
				                    .encode(com.stevebrecher.poker.Card
				                                                       .getInstance(board[1]
				                                                                            .toString()))
				          | HandEval
				                    .encode(com.stevebrecher.poker.Card
				                                                       .getInstance(board[2]
				                                                                            .toString()));
			}
		}
		
	}
	
	
	public void newHandStarted (Card[] clientCards)
	{	
		Card[] myCards = Dynamics.getMyHoleCards();
		myHoleCards = HandEval
		                      .encode(com.stevebrecher.poker.Card
		                                                         .getInstance(myCards[0]
		                                                                                .toString()))
		              | HandEval
		                        .encode(com.stevebrecher.poker.Card
		                                                           .getInstance(myCards[1]
		                                                                                  .toString()));
		flop = 0;
		turn = 0;
		river = 0;
		
/*		for (int i = 0; i<=5; i++)
		{
			for (int j = 0; j<=4; j++)
			{
				for (int k = 0; k <=9; k++)
				{
					gameStates[i][j][k] = -1;
				}
			}
		}*/
	}

	/**
	 * method retrieves information about the game and the player like position, potsize, actions and stores them in the gameStates-Array
	 * For each player and round one gameState is stored and at a showdown the saved data is trained to the Weka OppModel tree
	 * @param playerNumber index number of the player
	 * @param lastAction char with 'f', 'c', or 'r' - the players action
	 * @param roundbets how many Bets were made in this round
	 */
	public void storeGameState (int playerNumber, char lastAction, int roundBets)
	{
		
	
			// arff attributes: round, action: preflop, flop, turn, river,
			// position, potsize, activePlayer
			// 0,3,2,1,1,1,10,3,40
			
			// Time measurement
			long time1 = System.currentTimeMillis();
			
			float actionPreflop = -1;
			float actionFlop = -1;
			float actionTurn = -1;
			float actionRiver = -1;
			
			// get the action to a float value
			
			float actionOn = setGameStateAction(lastAction, roundBets);
			// System.out.println("lastAction of player " + playerNumber + " is " + lastAction + " so it is a " + actionOn);
			
			// get the round to a float value and action for round
			int round;
			
			if (river != 0)
				round = 3;
			else if (turn != 0)
				round = 2;
			else if (flop != 0)
				round = 1;
			else round = 0;
			
			
			// count subrounds: for each bet there is a virtual subround
				subround[playerNumber] = Dynamics.roundBets;
							
			
			// the seat of the given player is put into playerSeat
			int playerSeat = Dynamics.playerToSeat(playerNumber);
			
			// position of given player is put into playerPosition
			int position = playerSeat; // TODO Difference between Blind-Position on
												// PreFlop
			
			// numeric value of potsize
			int potSize = 0;
			for (int i = 0; i <= 5; i++)
			{
				potSize += Dynamics.inPot[i];
			}
	
			// number of player still in game
			int playerActive = 0;
			for (int i = 0; i <= 5; i++)
			{
				if (Dynamics.active[i]) playerActive++;
			}
			
			// action of this round and the previous round of that hand
			// 
			if (round == 0)
			{
				actionPreflop = actionOn;
			}
			else if (round == 1)
			{
				actionPreflop = gameStates[playerNumber][0][2];
				actionFlop = actionOn;
			}
			else if (round == 2)
			{
				actionPreflop = gameStates[playerNumber][0][2];
				actionFlop = gameStates[playerNumber][1][3];
				actionTurn = actionOn;
			}
			else if (round == 3)
			{
				actionPreflop = gameStates[playerNumber][0][2];
				actionFlop = gameStates[playerNumber][1][3];
				actionTurn = gameStates[playerNumber][2][4];
				actionRiver = actionOn;
			}
//System.out.println("Weka aktion preflop" + gameStates[playerNumber][0][2] + ", flop"
//+ gameStates[playerNumber][1][3] + ", " + actionOn);
			
			// arff attributes: round, action: preflop, flop, turn, river, position, potsize, activePlayer, zero-for unknown winProb
			gameStates[playerNumber][round] = new float[] { round,
			      subround[playerNumber], actionPreflop, actionFlop, actionTurn,
			      actionRiver, position, potSize, playerActive, 0 };
			time1 = System.currentTimeMillis() - time1;
			
				
			if (sysprints && false)
			System.out.println("storeGameState(" + playerNumber + ", " + lastAction + 
			                   ") stored: round:" +
			                   round  + " subround:" + subround[playerNumber]
			                   + " actionPreflop:" + actionPreflop
			                   + " actionFlop:" + actionFlop
			                   + " actionTurn:" + actionTurn
			                   + " actionRiver:" + actionRiver
			                   + " position:" + position
			                   + " potsize:" + potSize
			                   + " activeplayer:" + playerActive);
			

	}
	
	/**
	 * converts a action char into an 'int'eger
	 * Therefore the number of bets made in this round are important
	 * @param lastAction is f for fold, c for check oder r for raise
	 * @param number of bets made in this round so far
	 * @return integer, 0 for fold, number for bets for call, 10+number of bets for raise
	 */
	public float setGameStateAction (char lastAction, int roundBets)
	{
		// on PreFlop there is always one bet!
		float actionOn;
		if (lastAction == 'f') actionOn = 0;
		else if (lastAction == 'c')
			actionOn = roundBets + 1;
		else 
			{
			alterRoundBets++;
			actionOn = (roundBets + 10);
			}
		return actionOn;
		
	}
	
	/**
	 * predicts for test usage the own predicted winning probability
	 * should compare the own winning probability wit the prediced ones of the other players
	 * @param simMyWinningProbability a double value with the simulated winning probability
	 */
	public double[] takeAction()
	{
		
		// PRINT Double with 2 digits after .
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(4);
		
	// For the training Mode to generate the Initial Data with the MathBot
		//boolean generateInitialWekaData = true;
		int round = Dynamics.roundIndex;
		// TODO what happens
		//if (generateInitialWekaData && round <= 3)
	//	{
			// TODO works but not nice, is there a method?
			//int playerNumber = Dynamics.seatToPlayer(Dynamics.getMySeat());
			//int roundBets = Dynamics.roundBets;
			
/*			try
			{
		
				
				setGameStateAction(action, roundBets); 
				gameStates[playerNumber][round][9] = ((Double)simMyWinningProbability).floatValue();
//				                                                                                                                      .floatValue();
				
				// Classify only for a test to read the System.out.prints
				
				System.out
				          .println(" to "
				                   + nf.format(predictedWinProb)
				                   + " predicted (no Spectrum) by WEKA OppModel");
				
				// train the WEKA OppModel with the new Dataset:
				cardguessWeka.train(playerNumber, gameStates[playerNumber][round]);
				
			}
			catch (Exception ex)
			{  no recovery here... }*/

			
		//}
		
		double[] winProbs = new double[6];
		
		for (int player=0; player<=5; player++)
		{
			// System.out.println("VIB of player "+ player + " and round " + round + " is pot: " +gameStates[player][round][7]);
			
				
			winProbs[player] = cardguessWeka.classify(player,gameStates[player][round]);
		}


		return winProbs;
	}
	


	/**
	 * On a showdown card of active players are revealed, new datasets can be
	 * trained: during the game information about the gamestate: actions,
	 * potsizes ... were gathered now the cards for the player are known and
	 * winnigProbs ca be simulated for each round
	 */
	public void trainOppModel ()
	{
		
		//try
		//{
			long myFlop = flop;
			long myTurn = turn;
			long myRiver = river;
			
		//	for (int player = 0; player <= 5; player++){
		//	if (Dynamics.hole[player] == null) System.out.println("VIP player null: " + player);
		//	else System.out.println("VIP player "+ player + " not null: " + Dynamics.hole[player].toString());
			//}
			
			// for all active players, where cards are revealed
			
			for (int i= 0; i<=5 && Dynamics.hole[i] != null; i++)
			{ 
				int player = Dynamics.seatToPlayer(i);
			//	System.out.println("VIP player train! : " + player + " val potsize"  + gameStates[player][0][7]);
				for (int round = 3; round >= 0; round--)
				{
					
					// get learnValues from the gameState Array
					float[] learnValues = gameStates[player][round];
					
					// Fast Fix:
					if (round ==0) learnValues[2] = gameStates[player][1][2];
					
					
					// simulate winProbs for that player preflop, flop, turn & river
					Card hisHoleCard[] = Dynamics.hole[i];
					long hisHoleCards;
					hisHoleCards = HandEval
					                       .encode(com.stevebrecher.poker.Card
					                                                          .getInstance(hisHoleCard[0]
					                                                                                     .toString()))
					               | HandEval
					                         .encode(com.stevebrecher.poker.Card
					                                                            .getInstance(hisHoleCard[1]
					                                                                                       .toString()));
					try{
					WinProbabilitySimulator oppSim = new WinProbabilitySimulator();
					
					if (round == 2) myRiver = 0;
					if (round == 1) myTurn = 0;
					if (round == 0) myFlop = 0;
					oppSim.initialize(Dynamics.getNumActivePlayers(), hisHoleCards,
					                myFlop, myTurn, myRiver);
					oppSim.simulateHand(10000);
					
					 // get Winning Prob by simulation
					learnValues[learnValues.length - 1] = ((Double) oppSim
					                                                     .getMyWinningProbability())
					                                                                                 .floatValue();
					}
					catch (Exception e)
					{
						System.out.println("WEKA oppModel run sim error: " + e);
					}
					System.out.println("trainOppModel last value " + learnValues[learnValues.length-1]);
					
					// train the Weka Instances
					cardguessWeka.train(player, learnValues);
					if (sysprints && false)
						System.out.println("trainOppModel: cardguessWeka.train(" + player 
						                   + ") round: " +  learnValues[0]
						                   + " subround:" + learnValues[1]
						                   + " actionPreflop:" + learnValues[2]
						                   + " actionFlop:" + learnValues[3]
						                   + " actionTurn:" + learnValues[4]
						                   + " actionRiver:" + learnValues[5]
						                   + " position:" + learnValues[6]
						                   + " potsize:" + learnValues[7]
						                   + " activeplayer:" + learnValues[8]
						                   + " winProb:" + learnValues[9]
						                                               );
				}
				
			}

		
	}
	
	
}
