package de.tud.inf.poker.g7bot.free;

import ca.ualberta.cs.poker.free.dynamics.*;

/**
 * This class extends the RingDynamics class to be used on the client
 * side to keep track of the game dynamics.
 * Central to this class is the method processStateChange that 
 * uses a matchstate message to redo the game's actions.
 * @author Stefan L�ck
 */
public class ClientRingDynamics extends RingDynamics
{

	public int currentSeat;
	
	/**
	 * TimedAgents to track the time usage of the players.
	 * Designed for chessclock mode.
	 * Indexed by player (not seat).
	 */
	public TimedAgent[] Timers;
	
	/**
	 * Number of players active in the game (that is, positive stack left).
	 * Should equal numSeats, which is private in RingDynamics.
	 */
	public int playersActive;
	
	public ClientRingDynamics (int numPlayers, MatchType info, String[] botNames)
	{
		super(numPlayers, info, botNames);
		if (info.chessClock && info.timePerHand > 0)
		{
			long timeAllowed = info.timePerHand * info.numHands;
			Timers = new TimedAgent[numPlayers];
			for(int i=0; i < numPlayers; i++)Timers[i] = new TimedAgent(timeAllowed);
		}
	}
	
	/**
	 * Call this function from handleState in Client to update
	 * the current state of ClientRingDynamics.  
	 * @param stateMsg The state message as passed to handleStateChange
	 * @return Whether a new hand has just started.
	 */
	public boolean processStateChange(AdvMatchStateMessage msm)
	{
		boolean isNewHand = (hole == null || handOver);

		// first, stop clock for player that acted.
		if (!isNewHand && Timers != null) Timers[seatToPlayer(seatToAct)].TurnOver();
		
		if (isNewHand) // start a new hand
				nextHand();

		this.currentSeat = msm.seatTaken;
		
		// now set cards as given by matchstate (these are at least our own)
		this.setCardsFromMSM(msm);
		
		// In the next step we will locally redo last player's action.
		// This is necessary for keeping track of the stack sizes and allowed actions. 
		char lastAction = msm.getLastActionChar();
		if (lastAction != '\0') this.handleAction(lastAction);

		// finally we start the stop clock for the next player.
		if (!handOver && (Timers != null)) Timers[seatToPlayer(seatToAct)].TurnStarted();
		
		return isNewHand;
	}
	
   /**
    * Goes to the next hand. If the next hand is the first hand, leaves the hand
    * number and seats as is. Otherwise, increments them.
    * This is special for the client. We will perform all actions necessary to start
    * a new hand except card dealing, as we will get our cards from the server...
    * @param reader
    */
   public void nextHand(){
   	if (hole!=null){
   	  setHandNumber(handNumber+1);
   	  nextSeats();
   	}
   	initializeBets();
   }
	
	public void setCardsFromMSM(AdvMatchStateMessage msm)
	{
		playersActive = msm.hole.length;
		this.hole = new Card[playersActive][];
		
		for (int i = 0; i < playersActive; i++)
		{
			if (msm.hole[i] != null && !msm.hole[i].isEmpty())
				this.hole[i]= Card.toCardArray(msm.hole[i]);
			else
				this.hole[i]= null;
		}
		
		if (msm.board != null && !msm.board.isEmpty())
			this.board = Card.toCardArray(msm.board);
		else
			this.board = null;
	}
	
	public boolean isShowdown()
	{
		return (roundIndex == 4);
	}
	
	/**
	 * Returns the sum of all contributions to the pot (that is: the pot size).
	 * @return the pot size.
	 */
	public int getPotSum()
	{
		int potSum = 0;
		for (int i = 0; i < this.playersActive; i++)   
			potSum += inPot[i];
		return potSum;
	}
	
   /** 
    * Returns how many hands are left to play after the current hand.
    */
   public int getHandsLeft()
   {
   	return (info.numHands - handNumber);
   }
	
	
/* ****************************************************************************
 * From here on, we define some functions for the client to call to obtain some 
 * personalized game state info.
 * ****************************************************************************
 * */
	
	public Card[] getMyHoleCards()
	{
		return this.hole[currentSeat];
	}
	
	public boolean isMyTurn()
	{
		return (currentSeat == seatToAct);
	}
	
	public int getMyStackSize()
	{
		return stack[seatToPlayer(currentSeat)];
	}

	public int getMyPotContribution()
	{
		return inPot[currentSeat];
	}

	public int getMySeat()
	{
		return currentSeat;
	}
	
	public long getMyTimeRemaining()
	{
		if (Timers != null)
			return Timers[seatToPlayer(currentSeat)].getTimeRemaining();
		else
			return -1;
	}

}
