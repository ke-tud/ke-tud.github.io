package de.tud.inf.poker.g7bot.ActionGuessing;

import de.tud.inf.poker.g7bot.free.ClientRingDynamics;

/**
 * This class tracks the actions of the players and creates statistical values
 * that will be used to feed the neural networks in NNTrainer. 
 * NOTE: To make sure everything's in order,  
 *       we work solely based on playerIndex, not on current seat assignments.
 *       That enables us to easily reuse all our arrays (thus, declared final).
 * @author Stefan L�ck
 */
public class ParamProvider
{
	/** A constant that represents an action. Also used to index the NeuralNet output. */
	public static final int FOLD = 0, CALL = 1, RAISE = 2;
	/** The number of players in the game. */
	public static final int NUMPLAYERS = 6;
	/** The maximal number of betting rounds. */
	public static final int MAXBETROUNDS = NNActionGuesser.MAXBETROUNDS;
	
	/** Constant used for parameter mapping. Used in *_MAP arrays. */
	public static final int MAP_NONE = 0, MAP_OWN = 1, MAP_ALL = 2, MAP_OTHERS = -1;
	
	/** Constant representing a double of this value */
	public static final double ZERO = 0.0, ONE = 1.0, TWO = 2.0, THREE = 3.0, FOUR = 4.0;
	
	/** The amount to raise per betting round. */
	public static final double[] RAISEPERROUND = {TWO, TWO, FOUR, FOUR};
	
	/** 
	 * Contains the number of params that will be returned
	 * on a call to getParams. Per betRound.
	 * Will be filled in static constructor. 
	 * */
	public static final int[] PARAMCOUNTS;
	
	final double[][] outputs;

	public static final int
   	GS_activePlayers = 0,
   	GS_currBetRound = 1,
   	GS_totalBets = 2, // highest bet in pot
   	GS_raisesThisRound = 3,
   	GS_COUNT = 4;
   /** Holds general information about the gamestate. Indexed with GS_*. */
	final double[]   gameStats;
	/** Maps how the params should be copied to output.*/
   static final int MAP_GS[] = {MAP_OWN, MAP_OWN, MAP_OWN, MAP_OWN}; // only MAP_OWN or MAP_NONE!!

	public static final int
		PS_currSeat = 0, // the players current seat (0.0 to 5.0)
		PS_isNotActive = 1, // if the player is not active any more. 0.0 means active, 1.0 inactive.
   	PS_totalBet = 2, // the number of bets a player has in the pot (total)
		PS_COUNT = 3;
	/** holds general info about players (init once, do not change during a hand, per Player) index: [pIdx, PS_*] */
	final double[][] playerStats;
	/** Maps how the params should be copied to output.*/
	static final int MAP_PS[] = {MAP_OWN, MAP_OTHERS, MAP_OWN};

	public static final int
		CRS_turnNumber = 0, // how many times did he take an action in this round? 
   	CRS_lastAction = 1, // 0.0 should be CALL! --> (ACTION - 1)
   	CRS_countRaises = 2, // how many times a player has raised in this round
   	CRS_currentBet = 3, // the number of bets a player has already in the pot (this round)
   	CRS_COUNT = 4;
	/** info about players action in the current betting round. Indexed with [pIdx, CRS_*].
	 *  Will be resetted every time a new betting round starts. */
	final double[][] currRoundStats;
	/** Maps how the params should be copied to output.*/
	static final int MAP_CRS[] = {MAP_OWN, MAP_ALL, MAP_OWN, MAP_ALL};
	
	public static final int
   	BRS_countRaises = 0, // CRS_countRaises
   	BRS_betPlaced = 1, // CRS_currentBet
   	BRS_COUNT = 2;
	/** Holds general information about the gamestate. Indexed with [brIdx, pIdx, BRS_*]. */
	final double[][][] betRoundStats;
	/**
	 *  Maps how the params should be copied to output. First Index: betRound!
	 *  BetRound means: output params for bi-round in the consecutive rounds. 
	 */
	static final int MAP_BRS[][] = {{MAP_ALL, MAP_NONE},{MAP_ALL, MAP_NONE}, {MAP_ALL, MAP_NONE}};
	
	/** Holds the winningProbs for the players. Indexed with pIdx. */
	// final double[]   winProbs; // MIGHT BE A PARAMETER OF getParams!!
	static final int MAP_WP = MAP_OWN; // only MAP_OWN or MAP_NONE!
	
	/** Stores the current betting round */
	int curBetRound = 0;

	// Vars to save a state for later restoration. 
	int pushBetRound;
	final double[] pushGS;
	final double[][] pushPS;
	final double[][] pushCRS;

	
	/** Static constructor fills PARAMCOUNTS array. */
	static 
	{
		// calc param counts!!
		PARAMCOUNTS = calcParamCounts();
	}

	
	/**
	 * Constructor instantiates all the arrays needed for the tracking
	 * of parameters later.
	 */
	public ParamProvider()
	{
		outputs = new double[MAXBETROUNDS][];
		for (int bri = 0; bri < MAXBETROUNDS; bri++)
			outputs[bri] = new double[PARAMCOUNTS[bri]];
		
		gameStats = new double[GS_COUNT];
		pushGS = new double[GS_COUNT];
		if (MAP_GS.length != GS_COUNT) System.err.println("GS_COUNT is WRONG!!");
		clearDoubleArray1D(gameStats, ZERO);

		playerStats = new double[NUMPLAYERS][PS_COUNT];
		pushPS = new double[NUMPLAYERS][PS_COUNT];
		if (MAP_PS.length != PS_COUNT) System.err.println("PS_COUNT is WRONG!!");
		clearDoubleArray2D(playerStats, ZERO);

		currRoundStats = new double[NUMPLAYERS][CRS_COUNT];
		pushCRS = new double[NUMPLAYERS][CRS_COUNT];
		if (MAP_CRS.length != CRS_COUNT) System.err.println("CRS_COUNT is WRONG!!");
		clearDoubleArray2D(currRoundStats, ZERO);

		betRoundStats = new double[MAXBETROUNDS][NUMPLAYERS][BRS_COUNT];
		for (int bri = 0; bri < (MAXBETROUNDS-1); bri++)
		{
			clearDoubleArray2D(betRoundStats[bri], ZERO);
			if (MAP_BRS[bri].length != BRS_COUNT) System.err.println("BRS_COUNT is WRONG!! :: " + bri);
		}
		
		
	}
	

	/* *************************************************************************
	 * Public functions to work with the ParamProvider from here. 
	 * *************************************************************************
	 */

	/** Initialize ParamProvider when a new hand is started
	 * 
	 * @param dyn The ClientRingDynamics for the next hand
	 *            (used to track player's seats) 
	 */
	public void init(ClientRingDynamics dyn)
	{
		curBetRound = 0;
		
		clearDoubleArray1D(gameStats, ZERO);
		clearDoubleArray2D(playerStats, ZERO);
		clearDoubleArray2D(currRoundStats, ZERO);
		for (int bri = 0; bri < (MAXBETROUNDS - 1); bri++)
			clearDoubleArray2D(betRoundStats[bri], ZERO);
		
		gameStats[GS_currBetRound] = 0.0;
		gameStats[GS_totalBets] = TWO;
		gameStats[GS_activePlayers] = NUMPLAYERS;
		
		for (int pi = 0; pi < NUMPLAYERS; pi++)
		{
			playerStats[pi][PS_currSeat] = dyn.playerToSeat(pi);
			if (dyn.playerToSeat(pi) == 0)  // Small blind
			{
				playerStats[pi][PS_totalBet] = ONE;
				currRoundStats[pi][CRS_currentBet] = ONE;
			}
			if (dyn.playerToSeat(pi) == 1) // big blind
			{
				playerStats[pi][PS_totalBet] = TWO;
				currRoundStats[pi][CRS_currentBet] = TWO;
			}
		}
	}
	
	/**
	 * This method updates all statistics according to the action of the player.
	 * @param pIdx The player that acted.
	 * @param action The action.
	 */
	public void processAction(int pIdx, int action)
	{
		switch (action)
		{
   		case FOLD:
   			gameStats[GS_activePlayers] -= ONE;
   			playerStats[pIdx][PS_isNotActive] = ONE;
   			break;
   		case RAISE:
   			gameStats[GS_raisesThisRound] += ONE;
   			gameStats[GS_totalBets] += RAISEPERROUND[curBetRound];
   			currRoundStats[pIdx][CRS_countRaises] += ONE;
   			// FALL THROUGH HERE!!
   		case CALL:
   			double toCall = (gameStats[GS_totalBets] - playerStats[pIdx][PS_totalBet]); 
   			playerStats[pIdx][PS_totalBet] = gameStats[GS_totalBets];
   			currRoundStats[pIdx][CRS_currentBet] += toCall;
   			break;
		}
		currRoundStats[pIdx][CRS_turnNumber] += ONE;
		currRoundStats[pIdx][CRS_lastAction] = ((double)action) - ONE;
	}
	
	/** processes the last betting round and inits arrays for the next. */
	public void nextBetRound()
	{
		// update gamestate vars
		gameStats[GS_currBetRound] += ONE;
		gameStats[GS_raisesThisRound] = ZERO;
		gameStats[GS_raisesThisRound] = ZERO;

		// update BRS array
		for (int pi = 0; pi < NUMPLAYERS; pi++)
		{
			betRoundStats[curBetRound][pi][BRS_countRaises] = currRoundStats[pi][CRS_countRaises];
			betRoundStats[curBetRound][pi][BRS_betPlaced] = currRoundStats[pi][CRS_currentBet];
		}
		
		// reset currentRoundStats
		clearDoubleArray2D(currRoundStats, ZERO);

		curBetRound++;
	}
	
	/**
	 * Saves the current state.
	 * Call restoreStare to restore the state later.
	 * Important for resetting ParamProvider during simulation!
	 */
	public void pushState()
	{
		pushBetRound = curBetRound;
		copyDoubleArray1D(pushGS, gameStats);
		copyDoubleArray2D(pushPS, playerStats);
		copyDoubleArray2D(pushCRS, currRoundStats);
	}
	
	/**
	 * Restores the state formerly saved with pushState().
	 */
	public void restoreState()
	{
		curBetRound = pushBetRound;
		copyDoubleArray1D(gameStats, pushGS);
		copyDoubleArray2D(playerStats, pushPS);
		copyDoubleArray2D(currRoundStats, pushCRS);
	}
	
	/**
	 * Returns an array with the statistical values for the specified player.
	 * NOTE: The array is final and will be reused on next call!!!
	 *       If values should be preserved, they must be copied.
	 * @param pIdx The player index to deliver statistics for.
	 * @return
	 */
	public double[] getParams(int pIdx, double winProb)
	{
		int betRound = curBetRound;

		// fill output array from stat array and return it
		// this is needed for fast (no new's).
		
		double[] out = outputs[betRound]; // for convenience
		int currParamCount = 0;
		
		// first, copy gamestats params
		for (int vi = 0; vi < GS_COUNT; vi++)
		{
			switch(MAP_GS[vi]) // only OWN or NONE allowed!
			{
				case MAP_OWN: out[currParamCount++] = gameStats[vi];
					break;
			}
		}

		// second, copy playerstats params
		for (int vi = 0; vi < PS_COUNT; vi++)
		{
			switch(MAP_PS[vi])
			{
				case MAP_OWN: out[currParamCount++] = playerStats[pIdx][vi]; break;
				case MAP_ALL: 
					for(int pi = 0; pi < NUMPLAYERS; pi++) 
						out[currParamCount++] = playerStats[pi][vi];
					break;
				case MAP_OTHERS: 
					for(int pi = 0; pi < NUMPLAYERS; pi++)
						if (pi != pIdx) out[currParamCount++] = playerStats[pi][vi];
					break;
			}
		}

		// third, copy currRoundStats params
		for (int vi = 0; vi < CRS_COUNT; vi++)
		{
			switch(MAP_CRS[vi])
			{
				case MAP_OWN: out[currParamCount++] = currRoundStats[pIdx][vi]; break;
				case MAP_ALL: 
					for(int pi = 0; pi < NUMPLAYERS; pi++) 
						out[currParamCount++] = currRoundStats[pi][vi];
					break;
				case MAP_OTHERS: 
					for(int pi = 0; pi < NUMPLAYERS; pi++) 
						if (pi != pIdx) out[currParamCount++] = currRoundStats[pi][vi];
					break;
			}
		}

		// fourth, copy BetRoundStats params
		for (int vi = 0; vi < BRS_COUNT; vi++)
			for (int t_bi = 0; t_bi < betRound ; t_bi++)
   		{
   			switch(MAP_BRS[t_bi][vi])
   			{
   				case MAP_OWN: out[currParamCount++] = betRoundStats[t_bi][pIdx][vi]; break;
   				case MAP_ALL: 
   					for(int pi = 0; pi < NUMPLAYERS; pi++) 
   						out[currParamCount++] = betRoundStats[t_bi][pi][vi];
   					break;
   				case MAP_OTHERS: 
   					for(int pi = 0; pi < NUMPLAYERS; pi++) 
   						if (pi != pIdx) out[currParamCount++] = betRoundStats[t_bi][pi][vi];
   					break;
   			}
   		}

		// finally, copy WinProb param
		switch(MAP_WP)
		{
			case MAP_OWN: out[currParamCount++] = winProb; break;
		}
		
		if (currParamCount != PARAMCOUNTS[betRound])
		{
			System.err.println("Wrong size after collecting param!! PARAMSCOUNT says = " + PARAMCOUNTS[betRound] + "And I got:" + currParamCount);
			return null; 
		}
		
		return out;
	}
	
	
	/* *************************************************************************
	 * Properties from here
	 * *************************************************************************
	 */
	
	/**
    * @return the curBetRound
    */
   public int getCurBetRound ()
   {
   	return curBetRound;
   }

	/* *************************************************************************
	 * Static helper methods from here 
	 * *************************************************************************
	 */
	
	/**
	 * This function uses the mapping arrays *_MAP to calculate
	 * the number of params that will finally be included in the
	 * outputs when requesting params. 
	 * Called from static constructor.
	 */
	private static int[] calcParamCounts()
	{
		int[] retPC = new int[MAXBETROUNDS];
		
		for (int bri = 0; bri < MAXBETROUNDS; bri++)
		{
			retPC[bri] = 0;
			for (int i = 0; i < GS_COUNT; i++) retPC[bri] += paramMappingCount(MAP_GS[i]); 
			for (int i = 0; i < PS_COUNT; i++) retPC[bri] += paramMappingCount(MAP_PS[i]); 
			for (int i = 0; i < CRS_COUNT; i++) retPC[bri] += paramMappingCount(MAP_CRS[i]); 

			for (int t_bi = 0; t_bi < bri ; t_bi++)
				for (int i = 0; i < BRS_COUNT; i++) retPC[bri] += paramMappingCount(MAP_BRS[t_bi][i]); 

			retPC[bri] += paramMappingCount(MAP_WP);
			
		}
		
		return retPC;
	}
	
	
	/** Maps MAP_* constants to a count of expected parameters */
	private static int paramMappingCount(int mapping)
	{
		switch (mapping)
		{
			case MAP_NONE: return 0;
			case MAP_OWN: return 1;
			case MAP_ALL: return NUMPLAYERS;
			case MAP_OTHERS: return NUMPLAYERS - 1;
			default: return 0;
		}
	}
	
	/** Sets all array values to value. 1D-version. */
	private static void clearDoubleArray1D(double[] a, double value)
	{
		for (int r = a.length - 1; r >= 0; r--)
			a[r] = value;
	}

	/** Sets all array values to value. 2D-version. */
	private static void clearDoubleArray2D(double[][] a, double value)
	{
		for (int r = a.length - 1; r >= 0; r--)
			for (int c = a[r].length - 1; c >= 0; c--)
				a[r][c] = value;
	}

	/** Sets all array values to value. 1D-version. */
	private static void copyDoubleArray1D(double[] dest, double[] source)
	{
		for (int r = dest.length - 1; r >= 0; r--)
			dest[r] = source[r];
	}

	/** Sets all array values to value. 2D-version. */
	private static void copyDoubleArray2D(double[][] dest, double[][] source)
	{
		for (int r = dest.length - 1; r >= 0; r--)
			for (int c = dest[r].length - 1; c >= 0; c--)
				dest[r][c] = source[r][c];
	}
	
}
