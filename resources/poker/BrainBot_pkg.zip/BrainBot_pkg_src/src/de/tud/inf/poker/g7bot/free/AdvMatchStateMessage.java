package de.tud.inf.poker.g7bot.free;

import ca.ualberta.cs.poker.free.dynamics.MatchStateMessage;

/**
 * @author Stefan L�ck
 */
public class AdvMatchStateMessage extends MatchStateMessage
{
	
	public AdvMatchStateMessage (String message)
	{
		super(message);
	}

    public char getLastActionChar(){
        if (bettingSequence.length()==0){
            return '\0';
        }
        char lastChar = bettingSequence.charAt((endOfStage()) ? (bettingSequence.length()-2) : (bettingSequence.length()-1));
        return lastChar;
    }
    
    /**
     * This function is bullshit in the pokerserver implementation!!!
     */
    @Override
    public void setCards(String cardSequence)
    {
 		String[] cards = cardSequence.split("/");
		if (cards.length >= 2) flop = cards[1]; else flop = null;
		if (cards.length >= 3) turn = cards[2]; else turn = null;
		if (cards.length >= 4) river = cards[3]; else river = null;
		hole = cards[0].split("\\|", -1); // -1 for splitting empty entries
		
		board = flop;
		if (turn != null) board += turn;
		if (river != null) board += river;
   }

	
}
