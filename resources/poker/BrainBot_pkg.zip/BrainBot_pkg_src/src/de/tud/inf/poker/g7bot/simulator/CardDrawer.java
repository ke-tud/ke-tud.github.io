package de.tud.inf.poker.g7bot.simulator;

import com.stevebrecher.poker.*;
import com.stevebrecher.poker.Card.*;

public class CardDrawer
{  
	public final static int singlesCount = Suit.values().length * Rank.values().length;
	public final static int doublesCount = (singlesCount * (singlesCount-1) / 2); 
	public final static int triplesCount = (doublesCount * (singlesCount-2) / 3); 

	public final static Card[] singleCards = new Card[singlesCount];
	public final static long[] singleLongs = new long[singlesCount];

	public final static Card[][] doubleCards = new Card[doublesCount][2];
	public final static long[] doubleLongs = new long[doublesCount];

	public final static Card[][] tripleCards = new Card[triplesCount][3];
	public final static long[] tripleLongs = new long[triplesCount];
	
	public static long dbg_drawReq = 0;
	public static long dbg_drawReqCards = 0;
	public static long dbg_rndCalls = 0;

	private final MersenneTwisterFastRandom myRandom = new MersenneTwisterFastRandom(); 

	static
	{
		int idx;

		idx = -1;
		for (Suit s : Suit.values())
			for (Rank r : Rank.values())
			{	idx++;
				singleCards[idx] = new Card(r, s);
				singleLongs[idx] = HandEval.encode(singleCards[idx]); 
			}
		
		idx = -1;
		for (int c1 = 0; c1 < singlesCount; c1++)
			for (int c2 = (c1+1); c2 < singlesCount; c2++)
			{	idx++;
				doubleCards[idx][0] = singleCards[c1];
				doubleCards[idx][1] = singleCards[c2];
				doubleLongs[idx] = singleLongs[c1] | singleLongs[c2];
			}

		idx = -1;
		for (int c1 = 0; c1 < singlesCount; c1++)
			for (int c2 = (c1+1); c2 < singlesCount; c2++)
				for (int c3 = (c2+1); c3 < singlesCount; c3++)
			{	idx++;
   			tripleCards[idx][0] = singleCards[c1];
   			tripleCards[idx][1] = singleCards[c2];
   			tripleCards[idx][2] = singleCards[c3];
				tripleLongs[idx] = singleLongs[c1] | singleLongs[c2] | singleLongs[c3];
			}
	}
	
	
	public final long drawSingle(long cardsDrawn)
	{
		dbg_drawReq++; dbg_drawReqCards+=1;
		int drawidx = 1;
		do {drawidx = myRandom.nextInt (singlesCount); dbg_rndCalls++;}
			while ((cardsDrawn & singleLongs[drawidx]) != 0);
		return singleLongs[drawidx];
	}

	public final long drawDouble(long cardsDrawn)
	{
		dbg_drawReq++; dbg_drawReqCards+=2;
		int drawidx = 2;
		do {drawidx = myRandom.nextInt(doublesCount); dbg_rndCalls++;}
			while ((cardsDrawn & doubleLongs[drawidx]) != 0);
		return doubleLongs[drawidx];
	}

	public final long drawTriple(long cardsDrawn)
	{
		dbg_drawReq++; dbg_drawReqCards+=3;
		int drawidx = 3;
		do {drawidx = myRandom.nextInt(triplesCount); dbg_rndCalls++;}
			while ((cardsDrawn & tripleLongs[drawidx]) != 0);
		return tripleLongs[drawidx];
	}
	
	public static double dbg_getAvgCallsPerDraw()
	{
		return dbg_rndCalls / (double)dbg_drawReq;
	}

	public static double dbg_getAvgCallsPerCard()
	{
		return dbg_rndCalls / (double)dbg_drawReqCards;
	}
	
}
