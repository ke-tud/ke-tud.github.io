package de.tud.inf.poker.g7bot;

import java.net.InetAddress;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import de.tud.inf.poker.g7bot.free.AdvancedRingClient;

/**
 * This bot does exactly what it is called: It will always FOLD! 
 * @author Stefan L�ck
 */
public class G7_CallBot extends AdvancedRingClient
{
	
	public G7_CallBot (int numPlayers, MatchType matchtype)
	{
		super(numPlayers, matchtype);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception
	{
		MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000); 
		G7_CallBot myBot = new G7_CallBot(6, mt);

      System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
      myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
      System.out.println("Successful connection!");

		myBot.run();
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#actionPerformed(char, int, boolean, boolean)
    */
   @Override
   public void actionPerformed (char lastAction, int lastSeat,
                                boolean handOver, boolean showdown)
   {
   }

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#newHandStarted(ca.ualberta.cs.poker.free.dynamics.Card[])
    */
   @Override
   public void newHandStarted (Card[] clientCards)
   {
   }

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize,
                           int amountToCall, long timeRemaining)
   {
   	try
		{
			this.sendCall();
		}
		catch (Exception ex)
		{}
   }
	
	
	
}
