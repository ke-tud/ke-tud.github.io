package de.tud.inf.poker.g7bot.ActionGuessing;

/**
 * This class shows the of the ActionGuesser.
 * It is used by 
 * @author Stefan L�ck
 */
public interface ActionGuesser
{
	public static enum Action
	{
		FOLD, CALL, RAISE;
	}
	
	/**
	 * Returns an action for the player. 
	 * @param rnd A random integer to be used for decisions based on some random event.
	 * @param context 
	 * @return
	 */
	Action getAction(int rnd, int context);
}
