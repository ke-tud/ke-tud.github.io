package de.tud.inf.poker.g7bot.ActionGuessing;

import org.joone.engine.Layer;
import org.joone.engine.Monitor;
import org.joone.engine.NeuralNetEvent;
import org.joone.engine.NeuralNetListener;
import org.joone.engine.Pattern;
import org.joone.engine.Synapse;
import org.joone.engine.learning.TeachingSynapse;
import org.joone.helpers.factory.JooneTools;
import org.joone.io.MemoryInputSynapse;
import org.joone.net.NeuralNet;

/**
 * The NNTrainer is a class that cares for the training of a neural network.
 * It employes a separate thread to execute net training, that can be controlled
 * so not to hinder the execution of threads of higher importance.
 * 
 * A separate NNTrainer will be used for each neural net for opponent modelling.
 * That means, there will be 5 players * 4 betting rounds of NNTrainers. 
 * @author Stefan L�ck
 */
public class NNTrainer implements Runnable, NeuralNetListener
{
	/* *************************************************************************
	 * THESE HERE ARE THE BASIC CONSTANTS TO ADJUST THE LEARNING BEHAVIOUR OF
	 * NNTrainer!
	 * *************************************************************************
	 */
	
	/* Vars to control learning */
	/** The learning rate used to train the net. 1.0 for RPROP. */
	public static final double  LEARNINGRATE = 0.3;
	/** The momentum used to train the net. */
	public static final double  MOMENTUM = 0.5;
	/** The learning algorithm to update the weights. Taken from JooneTools. */
	public static final int     LEARNALGO = JooneTools.BPROP_ONLINE;
	/** Instructs the trainer to not randomize the net before learning is started. */
	public static final boolean INCREMENTALLEARNING = false;
	/** Amplitude for randomization of the neural net. */
	public static final double  RANDOMIZATIONAMP = 0.8;
	/** Minimal number of training patterns to start a training round. */
	public static final int     MINPATTERNFORTRAINING = 20;
	
	/* Vars to control error controlled termination of learning. */
	/** Improvement of error needed to be significant (keep the training running) */
	public final static double  SIGNIFICANTERROR = 0.0001;
	/** Number of epochs without error improvement after which training will be aborted */
	public final static int     NOIMPROVEMENTEPOCHSABORT = 30;
	/** Maximum numbers of epochs for training if not stopped with small error. */
	public final static int     MAXCYCLESFORTRAINING = 5000;

	/* Miscellaneous control constants */
	/** Number of possible actions (3: FOLD, CALL, RAISE) */
	public static final int     ACTIONSPOSSIBLE = 3;
	public static final int     FOLD  = ParamProvider.FOLD,
	                            CALL  = ParamProvider.CALL,
	                            RAISE = ParamProvider.RAISE;
	/** Variable to exclude time-consuming debugging code from final build.*/
	public final static boolean RELEASEVERSION = true;


	
	/** Stores the player number. Only for convenience. Set once in constructor. */
	public final int playerIdx;
	/** Stores the betting round index. Only for convenience. Set once in constructor. */
	public final int bettingRoundIdx;
	
	/** The thread that the trainer runs in. {@value null} after termination.*/
	private Thread thread;

	/**
	 * Neural net used for training.
	 * It has input synapses connected to the training data and
	 * training synapses for backprop feedback attached to the output layer. 
	 */
	private NeuralNet trainInstance;
	
	/**
	 * Neural net used to interrogate the network.
	 * There will always be a copy held available to use
	 * for net interrogation.
	 * Input and output are attached 
	 * This net is created after each successful training
	 * session by cloning the trainInstance and applying the necessary 
	 * modifications.   
	 */
	private NNExecutiveNet execInstance = null;
			
	/**
	 * The training data. Desired data (target values) is stored in desiredData.
	 * Array is used in round buffer mode. see {@code sampleCount} and {@code sampleOffset}
	 */
	double[][] trainData;
	/** The target values used for training. Three cols, one for FOLD/CALL/RAISE. */
	double[][] desiredData;

	/** number of params (cols) in training data. */
	final int paramsCount;
	
	/** number of used rows in training data. */
	int sampleCount;
	/** pointer to next overwritable entry in data set. */
	int sampleOffset;
	/** maximum number of samples to be stored and used for training. */
	final int maxSamples;

	/**
	 * New training data that arrived, corresponds to trainData. Used to buffer data
	 * while training is active and will be transferred to the trainData-Array when available.
	 * Used to not interfere with error based termination of training.   
	 * Array is always used from offset zero.
	 */
	double[][] newTrainData;
	/** Buffer for the new target values (see comment on updateTrainData. */
	double[][] newDesiredData;
	/** Number of new samples buffered. */
	int newSamplesCount;
	/** maximum number of new samples to be buffered for later training. */
	final int maxNewSamples;

	/**
	 * Constant used for controlling the trainer thread with threadMode.
	 * This vars are used as flags.  
	 * NOTE: COMMANDS are even, states are odd (command + 1)
	 */
	public static final int
		ALLSTATES = 0x0FFFFFFF, STATEBIT = 0x00000001, NOSTATEBITMASK = ALLSTATES & ~STATEBIT,
		WAIT = 2,        WAITING = WAIT | STATEBIT,
		RUN  = 4,        RUNNING = RUN | STATEBIT,
		INTERRUPT = 8,   INTERRUPTED = INTERRUPT | STATEBIT,
		TERMINATE = 128, TERMINATED = TERMINATE | STATEBIT;
	
	int threadMode = WAIT;

	
	/** Returns the number of new training patterns that have not yet been processed. */
	public int getNewSamplesCount()
	{
		synchronized(newTrainData)
		{
			return newSamplesCount;
		} 
	}
	
	/** Returns the number of training patterns currently stored and used. */
	public int getSampleCount()
	{ return sampleCount; }

	/** Returns the maximum number of samples the Trainer supports. */
	public int getMaxSampleCount()
	{ return maxSamples; }

	/** Returns the number of parameters use in the network, that is: number of input nodes. */
	public int getParamsCount()
	{ return paramsCount; }

	/** Returns the training pattens. Get target values separate via getDesiredData 
	 *  NOTE: This is no cloned copy! */
	public double[][] getTrainingData()
	{ return trainData;	}
	
	/** Returns the desired values used in the training. Corresponding pattern via getTrainingData. 
	 *  NOTE: This is no cloned copy! */
	public double[][] getDesiredData()
	{ return desiredData; }
	
   /** Returns the thread that performs neural net training. */
   public Thread getThread()
   { return thread; }
	
	
	/**
	 * Constructs a new NNTrainer given the parameters provided.
	 * The initial neural net will be cloned before it is used. 
	 * @param playerIdx The index of the player the trainer is working for.
	 * @param betRoundIdx The index of the betting round the trainer is used for.
	 * @param startInstance The initial net used for training. Input and output will be attached.
	 * @param threadPriority The priority of the thread. Set to a low level so main thread
	 *        used to execute a turn and the simulation will not be retarded.
	 */
	public NNTrainer(int playerIdx, int betRoundIdx, NeuralNet startInstance,
	                 boolean initializeNet, int maxSampleCount, int threadPriority)
	{
		this.playerIdx = playerIdx;
		this.bettingRoundIdx = betRoundIdx;
		
		this.maxSamples = maxSampleCount; 
		maxNewSamples = maxSamples / 2; 
	
		startInstance.getMonitor().setExporting(true);
		this.trainInstance = startInstance.cloneNet();
		startInstance.getMonitor().setExporting(false);
		paramsCount = startInstance.getInputLayer().getRows();
		
		// initialize everything for training.
		initDataArrays();
		configTrainingNet(initializeNet);
		// and also use initial net as first executive net.
		execInstance = new NNExecutiveNet(trainInstance); // to prevent lock error
		createExecNet();
		
		this.thread = new Thread(this);
		this.thread.setPriority(threadPriority);
		this.threadMode  = WAIT; // initial command to thread.
		this.thread.start();
	}
	
	/**
	 * Creates all necessary arrays and initializes the control vars.
	 * Called from constructor.
	 */
	private void initDataArrays()
	{
		trainData = new double[maxSamples][paramsCount];
		desiredData = new double[maxSamples][ACTIONSPOSSIBLE];
		sampleCount = 0;
		sampleOffset = 0;
		
		newTrainData = new double[maxNewSamples][paramsCount];
		newDesiredData = new double[maxNewSamples][ACTIONSPOSSIBLE];
		newSamplesCount = 0;
	}

	/**
	 * Sets the training data and desired values.
	 * Used to initialize the training data sets so the net will not have
	 * to start from zero on upwards...
	 * NOTE: Array will be copied! So it may be assigned to several NNTrainers
	 * @param patterns The patterns used for training.
	 * @param targets The target values.
	 * @return The number of patterns set in the training data.
	 */
	public int setTrainingData(double[][] patterns, double[][] targets, int count)
	{
		sampleCount = 0;
		sampleOffset = 0;
		return copyPatternsToTrainingData(patterns, targets, count);
	}
	
	/**
	 * Adds the training patterns to the actual training data. Data insertion begins at
	 * sampleOffset, representing the current insertion point in trainData which is
	 * considered a round buffer.
	 * @param patterns The pattern to be inserted.
	 * @param desireds The desired values matching the patterns.
	 * @param count The number of entries to be copied.
	 * @return Number of patterns added.
	 */
	private int copyPatternsToTrainingData(double[][] patterns, double[][] desireds, int count)
	{
		synchronized (trainData)
		{
			for (int pi = 0; pi < count; pi++)
			{
				for (int ri = 0; ri < paramsCount; ri++)
					trainData[sampleOffset][ri] = patterns[pi][ri];
				for (int ri = 0; ri < ACTIONSPOSSIBLE; ri++)
					desiredData[sampleOffset][ri] = desireds[pi][ri];
				sampleOffset = (sampleOffset + 1) % maxSamples;
				sampleCount++;
				if (sampleCount > maxSamples) sampleCount = maxSamples;
			}
		}
		return count;
	}
	
	/**
	 * Adds a training data pattern to the training data buffer.
	 * Data will then be used for the next training round started. 
	 * @param pattern The training pattern. Must have at least paramsCount entries. 
	 * @param target The target data. Must have at least ACTIONSPOSSIBLE(3) entries.
	 * @return Whether data could be added (buffer might be full).
	 */
	public boolean addTrainingPattern(double[] pattern, double[] target)
	{
		synchronized (newTrainData)
		{
			if (newSamplesCount >= maxNewSamples) return false;
			for (int i = 0; i < paramsCount; i++) newTrainData[newSamplesCount][i] = pattern[i];
			for (int i = 0; i < ACTIONSPOSSIBLE; i++) newDesiredData[newSamplesCount][i] = target[i];
			newSamplesCount++;
		}
		return true;
	}
	
	/**
	 * Configures the initial neural net so it can be subsequently trained with
	 * the collected data.
	 * Called once on startup before the net will go to the first training round. 
	 */
	private void configTrainingNet (boolean initNewNet)
	{
		// clear potential old stuff...
		trainInstance.removeAllInputs();
		trainInstance.removeAllListeners();
		trainInstance.removeAllOutputs();
		
		// now create input synapses for private and common data and also for target data ...
		MemoryInputSynapse synInput = new MemoryInputSynapse();
		synInput.setInputArray(trainData);
		synInput.setAdvancedColumnSelector("1-" + paramsCount);
		
		MemoryInputSynapse synTarget = new MemoryInputSynapse();
		synTarget.setInputArray(desiredData);
		synTarget.setAdvancedColumnSelector("1-" + ACTIONSPOSSIBLE);
		
		// ... and add them together with Teacher to the neural net. 
		trainInstance.addInputSynapse(synInput);
		TeachingSynapse teacher = new TeachingSynapse();
		teacher.setDesired(synTarget);
		trainInstance.addOutputSynapse(teacher);
		trainInstance.setTeacher(teacher);

		// configure monitor for learning by setting Learners and learning props...
		Monitor mon = trainInstance.getMonitor();
		mon.addLearner(JooneTools.BPROP_ONLINE, "org.joone.engine.BasicLearner"); // Default
		mon.addLearner(JooneTools.BPROP_BATCH, "org.joone.engine.BatchLearner");
		mon.addLearner(JooneTools.RPROP, "org.joone.engine.RpropLearner");
		mon.setLearningMode(LEARNALGO); // RPROP is sometimes trash, so better BPROB...
		
		if (LEARNALGO == JooneTools.RPROP) mon.setLearningRate(1.0);  // 1.0 for RPROP
		else mon.setLearningRate(LEARNINGRATE);
		mon.setMomentum(MOMENTUM); // not used actually in RPROP, is it?

		mon.setValidation(false);
		mon.setLearning(true);

		// add this class as a listener to the monitor to track events
		if (!RELEASEVERSION) mon.addNeuralNetListener(this, true);

		synInput.setFirstRow(0);
		synInput.setBuffered(false); // array is buffer enough...
		synTarget.setFirstRow(0);
		synTarget.setBuffered(false); // array is buffer enough...
		// these ones are adjusted during training
		mon.setBatchSize(1);
		mon.setTrainingPatterns(1);
		mon.setTotCicles(1000);

		trainInstance.setOrderedLayers(trainInstance.calculateOrderedLayers()); 

		for (Layer l : trainInstance.calculateOrderedLayers())
			l.init();
		
		if (initNewNet) // if net is new, we randomize values as starting point for the net.
		{
			trainInstance.randomize(RANDOMIZATIONAMP);
		}
	}
	
	/**
	 * Creates the execution net instance from the current training instance.
	 * Training components will be replaced by the components needed for
	 * interrogating the net (DirectSynapses). Called in training thread.
	 */
	private void createExecNet()
	{
		synchronized (execInstance) // finally set new net as execInstance
      {
			this.execInstance = new NNExecutiveNet(trainInstance);
      }
	}
	
	/** Var used to store point of interruption if thread is stopped during execution. */
	private int interruptedEpoch = -1, interruptedPattern = -1;
	
	/** Used to control error controlled abortion of training (epochs w/o improvement of error). */
	private int noImprovementEpochs;
	/** Used to control error controlled abortion of training (minimal error). */
	private double lastMinError;
	
	/**
	 * This method runs the NeuralNetwork in SingleThreadMode.
	 * Code is in part taken from NeuralNet.fastRun(...), but extended
	 * so it can be interrupted after each pattern, not only 
	 * every epoch (better for control of cpu time).
	 * @param continuation if set, signals that the net must still be initialized.
	 * @return true if network is terminated. false if interrupted.
	 */
	private boolean runNetwork (boolean continuation)
	{
		boolean contFromInterruption = (interruptedEpoch >= 0) && continuation;
		
		Monitor monitor = trainInstance.getMonitor();
		Layer[] ordLayers = trainInstance.calculateOrderedLayers();
		int layersCount = ordLayers.length;
		
		// Calls the init method for all the Layers
		if (!contFromInterruption && (!continuation || !INCREMENTALLEARNING))
		{
			for (int ly = 0; ly < layersCount; ++ly)
			{
				ordLayers[ly].init();
				for (Object in : ordLayers[ly].getAllInputs()) ((Synapse) in).reset();
			}
			trainInstance.randomize(RANDOMIZATIONAMP);
		}

		if (!contFromInterruption)
		{
			lastMinError = Double.MAX_VALUE;
			noImprovementEpochs = 0;
			synchronized (newTrainData) 
         { // import new training patterns 
				if (!RELEASEVERSION) System.out.println("ADDING!!!!!!! " + newSamplesCount + " Samples");
				copyPatternsToTrainingData(newTrainData, newDesiredData, newSamplesCount);
				newSamplesCount = 0;
			}
			monitor.setGlobalError(0.0);
			monitor.setTotCicles(MAXCYCLESFORTRAINING);
			monitor.setCurrentCicle(MAXCYCLESFORTRAINING);
			monitor.setTrainingPatterns(sampleCount);
			monitor.setBatchSize(sampleCount);
		}

		if (!RELEASEVERSION) System.out.println("STARTINGRUN!");

		monitor.setSingleThreadMode(true);
		int epochs = monitor.getCurrentCicle();
		int patterns = monitor.getNumOfPatterns();
		
		if (patterns < MINPATTERNFORTRAINING) return true; // to little to learn from!!!
		
		if (!contFromInterruption) monitor.fireNetStarted();
		
		for (int epoch = epochs; epoch > 0; --epoch)
		{
			if (contFromInterruption)
			{
				epoch = interruptedEpoch; interruptedEpoch = -1;
			} 
			monitor.setCurrentCicle(epoch);
			for (int p = 0; p < patterns; ++p)
			{
				if (contFromInterruption)
				{
					p = interruptedPattern;
					interruptedPattern = -1;
					contFromInterruption = false;
				} 
				if (threadMode == INTERRUPT || threadMode == TERMINATE)
				{
					interruptedEpoch = epoch;
					interruptedPattern = p;
					return false;
				}

				// INPLACE (org is protected): trainInstance.stepForward(null);
				for (int ly = 0; ly < layersCount; ++ly) // Forward processing
					ordLayers[ly].fwdRun(null);
				
				if (monitor.isLearningCicle(p + 1))
				{// INPLACE (org is protected): trainInstance.stepBackward(null);
					for (int ly = layersCount; ly > 0; ly--) // Backward processing
						ordLayers[ly - 1].revRun(null);
				}
				
			}
			monitor.fireCicleTerminated();
			// Error controlled execution breaker: stop if error is small enough...
			double currError = monitor.getGlobalError();
			if (currError > 0.0 && currError < SIGNIFICANTERROR) // directly break is net error is small enough!
			{
				if (threadMode != INTERRUPT) break;
			}
			else if (!Double.isNaN(currError) && currError > 0.0 && currError <= (lastMinError - SIGNIFICANTERROR))
			{
				if (!RELEASEVERSION) System.out.println("UPDATE: LAST=" + lastMinError + " CURR=" + currError);
				lastMinError = currError;
				noImprovementEpochs = 0;
			}
			else
			{
				if (!RELEASEVERSION) System.out.println("NOIMPROVE: LAST=" + lastMinError + " CURR=" + currError);
				noImprovementEpochs++;
				if (noImprovementEpochs > NOIMPROVEMENTEPOCHSABORT)
					if (threadMode != INTERRUPT) break;
			}
			
			if ((threadMode != RUNNING) && (threadMode != INTERRUPT))
				break;

			Thread.yield();
		}
		// send stop pattern through network...
		//! NO STOP PATTERN NEEDED IN SINGLE THREAD
//		trainInstance.getMonitor().setLearning(false);
//		Pattern stop = Pattern.makeStopPattern(ordLayers[0].getRows());
//		ordLayers[0].fwdRun(stop);
//		for (int ly = 1; ly < layersCount; ++ly) // Forward processing
//			ordLayers[ly].fwdRun(null);
		
		monitor.fireNetStopped();
		
		// create the execInstance (only if all cycles through) 
		createExecNet();

		return true;

	}
	
	
	
   /* **************************************************************************************
	 * Methods to control the trainer thread work from here (run() method plus methods to
	 * communicate with thread.
	 * **************************************************************************************
	 */
	
   /**
    * This is the main method of the training thread.
    * We monitor the threadMode variable that we use to pass commands to this thread.
    * Setting threadMode to RUN will cause the thread to initiate a new round of training
    * and the threadMode to become RUNNING.
    * Use startTraining(), stopTraining(), interruptTraining(), continueTraining() and
    * terminateTrainer() methods provided in this class to control thread execution. 
    */
	@Override
   public void run()
   {
		try
		{
      	while (threadMode != TERMINATE)
      	{
      		// System.out.println("THREADISRUNNING!");
      		switch(threadMode)
      		{
      			case WAIT:
      				threadMode = WAITING;
      				break;
      			case INTERRUPT:
      				threadMode = INTERRUPTED;
      				break;
         		case RUN: 
         			threadMode = RUNNING;
         			if (runNetwork(true) && threadMode == INTERRUPT) threadMode = WAITING;
         			break;
      			case INTERRUPTED: // Fall through here. Same as waiting. 
         		case WAITING: 
         			try {Thread.sleep(1);} catch(InterruptedException intEx){}
         			break;
         		case RUNNING: // if we arrive here: we go back to WAITING state
         			threadMode = WAITING;
         			break;
      		}
   			Thread.yield();
      	}
      	threadMode = TERMINATED;
		}
		catch (Exception ex)
		{
	   	threadMode = TERMINATED;
			System.err.println("Exception in training thread!!\r\n"); 
			                   ex.printStackTrace();
			//TODO: Repair something and restart thread!!!
			// Reinit the training net. --> then create a new thread and start it!
		}
   }
   
   public boolean startTraining()
   {
		return sendCommandToThread(RUN, WAITING);
   }
   
   public boolean stopTraining()
   {
		return sendCommandToThread(WAIT, RUNNING);
   }

   public boolean interruptTraining()
   {
		return sendCommandToThread(INTERRUPT, RUNNING);
   }

   public boolean continueTraining()
   {
   	return sendCommandToThread(RUN, INTERRUPTED);
   }

   public boolean terminateTrainer()
   {
   	boolean result = sendCommandToThread(TERMINATE, ALLSTATES);
   	if (result) this.thread = null;
   	return result;
   }
   
   /** Returns whether the training thread is still processing a command (not in a state). */ 
   private boolean threadCommandIssued()
   {
   	return ((threadMode & STATEBIT) == 0);
   }

   /**
    *  Sends a command to the thread performing the neural net training.
    *  @param command The command to be send (final set integer).
    *  @param validStateMask Represents valid states the thread must be in to receive the command.
    */
   private boolean sendCommandToThread(int command, int validStateMask)
   {
   	while (threadMode != TERMINATED)
   	{
      	if (!threadCommandIssued())
      	{
      		if ((threadMode & validStateMask & NOSTATEBITMASK) != 0)
      		{
      			// issue command by setting threadMode variable
         		threadMode = command;
         		//!! thread.notify();
         		return true;
      		}
      		else 
   			{
      			return false; // wrong state to receive command
   			}
      	}
      	else
      	{
      		//!! thread.notify();
      		Thread.yield();
      	}
   	}
		return false;
   }
   
   /** 
    * Returns the Neural net for interrogation packed in a NNExecutiveNet class
    * that enables direct interrogation via the interrogate() method.
    */
   public NNExecutiveNet getExecutiveNet()
   {
   	synchronized (execInstance)
      {
      	return execInstance;
      }
   }

   /** 
    * Returns the Neural net that is used for interrogation.
    * Use getExecutiveNet to get an NNExecutiveNet that is directly interrogatable.
    */
   public NeuralNet getExecutionInstance()
   {
   	synchronized (execInstance)
      {
      	return execInstance.getExecNet();
      }
   }

   /** Small helper function to format a training sample. */
   public static String formatSample(double[] pattern, double[] target)
   {
   	StringBuilder sb = new StringBuilder();
   	
   	sb.append("{");
    	for (int i = 0; i < pattern.length; i++)
 		{
    		sb.append(String.format("%.2f", pattern[i]));
    		if ((i+1) < pattern.length) sb.append(", ");
 		}
   	sb.append("} --> {");
    	for (int i = 0; i < target.length; i++)
 		{
    		sb.append(String.format("%.2f", target[i]));
    		if ((i+1) < target.length) sb.append(", ");
 		}
   	sb.append("}");
   	return sb.toString();
   }
   
   
   /* **************************************************************************************
    *  Implementation of NeuralNetListener from here.
    *  NOT used to update execInstance or interrupt training.
    *  May be used to write out some information
    *  NOTE: Will be disabled in release version of bot (saving resources).
    * **************************************************************************************
    */
   @Override
   public void cicleTerminated (NeuralNetEvent e)
   {
  	 System.out.println("CYCLEEND");
	}

   @Override
   public void errorChanged (NeuralNetEvent e)
   {
   	 System.out.println("ERRCHANGE=" + trainInstance.getMonitor().getGlobalError());
   }

   @Override
   public void netStarted (NeuralNetEvent e)
   {
    	 System.out.println("TRAINSTART pIdx=" + playerIdx);
   }

   @Override
   public void netStopped (NeuralNetEvent e)
   {
   	 System.out.println("NETSTOP pIdx=" + playerIdx + " Cycles= " + trainInstance.getMonitor().getCurrentCicle());
   }

   @Override
   public void netStoppedError (NeuralNetEvent e, String error)
   {
   	 System.out.println("NETSTOPERR pIdx=" + playerIdx);
   }
   
   
   /**
    * This is a helper class that provides functions for interrogating a neural network.
    * It should be faster than the JoneTools.interrogate() method,
    * as it is specially designed to not reinitialize the net every time
    * an interrogation is performed.
    * We use our knowledge here that the structure of the net is never changed after 
    * the instantiation of this class.
    * @author Stefan L�ck
    */
   public class NNExecutiveNet
   {
   	Layer[] netOrdLayers;
   	DirectSynapseWithResult netOutput;
      Pattern inputPattern;
   	NeuralNet execNet;
   	
   	/**
   	 * Construtor for NNExecutiveNet.
   	 * Creates an executive net from the given training net.
   	 * The net will be cloned and modified to be interrogatable via the interrogate() method.
   	 * @param fromTrainingNet The trained net to create the executive net from. 
   	 */
   	NNExecutiveNet(NeuralNet fromTrainingNet)
   	{

   		fromTrainingNet.getMonitor().setExporting(true);
   		this.execNet = fromTrainingNet.cloneNet();
   		fromTrainingNet.getMonitor().setExporting(false);
   		
   		this.execNet.removeAllInputs();
   		this.execNet.removeAllOutputs();
   		this.execNet.removeAllListeners();
   		
         this.netOutput = new DirectSynapseWithResult(); 
   		this.execNet.addOutputSynapse(this.netOutput);
   		this.execNet.getMonitor().setLearning(false);
   		
   		this.netOrdLayers = execNet.calculateOrderedLayers();
         this.inputPattern = new Pattern(null);
   	}

   	/** Getter for neural net this class is working on. */
   	public NeuralNet getExecNet ()
      { return execNet; }
   	
   	/**
   	 * Returns whether interrogation was successful.
   	 * Interrogation can fail with NaN in the result sometimes.
   	 * @param input The input values for the net. Size must equal paramsCount.
   	 * @param output Will be filled with the return values.
   	 * @return Whether result is valid.
   	 */
   	public boolean interrogate(double[] input, double[] output)
   	{
         boolean success = true;
         
         inputPattern.setValues(input);
         inputPattern.setCount(1);
         
         { // simulate a single step forward
            int layersCount = netOrdLayers.length;
            netOrdLayers[0].fwdRun(inputPattern);
            for (int ly=1; ly < layersCount; ++ly) {
                netOrdLayers[ly].fwdRun(null);
            }
            
         }
         
         double[] result = netOutput.getResult();
         for (int i = 0; i < ACTIONSPOSSIBLE; i++)
         {
         	if (Double.isNaN(result[i])) success = false;
         	output[i] = result[i];
         }
         
         return success;
   	}
   	
   }
}
