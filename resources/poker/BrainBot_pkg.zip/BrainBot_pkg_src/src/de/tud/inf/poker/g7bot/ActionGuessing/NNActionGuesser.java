package de.tud.inf.poker.g7bot.ActionGuessing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import org.joone.engine.FullSynapse;
import org.joone.engine.Layer;
import org.joone.engine.LinearLayer;
import org.joone.engine.SigmoidLayer;
import org.joone.engine.SoftmaxLayer;
import org.joone.helpers.factory.JooneTools;
import org.joone.net.NeuralNet;
import de.tud.inf.poker.g7bot.ActionGuessing.NNTrainer.NNExecutiveNet;


/**
 * This class implements an action guesser for opponents based on
 * a neural network. It relies on the joone framework for the modelling
 * and execution of the neural nets.
 * NOTE: The actual training code has been moved to the class NNTrainer. 
 * @author Stefan L�ck
 */
public class NNActionGuesser
{  
	/* *************************************************************************
	 * THE CONSTANTS HERE ARE USED TO ADJUST THE BEHAVIOUR OF NNActionGuesser.
	 * THE TYPE OF NETWORKS TO USE WITH NNTrainer CAN BE CONFIGURED HERE.
	 * *************************************************************************
	 */
	/** Define number of betting rounds. Must be 4. */
	public static final int MAXBETROUNDS = 4;
	/** Define the priority of trainer threads. Additional to the option of interrupting the threads. */
	public static final int TRAINERTHREADPRIO = (Thread.NORM_PRIORITY - 1) ; // + Thread.MIN_PRIORITY) / 2;
	/** Count of possible actions. Must be 3. */
	public static final int ACTIONSPOSSIBLE = NNTrainer.ACTIONSPOSSIBLE;
	
	/** Defines the number of training patterns the Trainers should work with (per round). */
	public static final int[] TRAININGDATAROWS = {1024, 2048, 2048, 1024}; 
	/** Defines the number of parameters to feed the nets (per round). */
	public static final int[] PARAMCOUNTS = ParamProvider.PARAMCOUNTS; 

	public static final String[] FILENAMES_DATA = {"preflop_data.pat", "flop_data.pat",
	                                               "turn_data.pat", "river_data.pat"}; 
	public static final String[] FILENAMES_NETS = {"preflop_model.snn", "flop_model.snn",
	                                               "turn_model.snn", "river_model.snn"};
	
	/** Defines whether new neural should have a shortcut synapse (first hidden to output) */  
	public static final boolean NEWNET_SHORTCUTS = true;
	/** Defines the type to use as output layer for new neural networks. */  
	@SuppressWarnings("unchecked")
	public static final Class NEWNET_OUTPUTCLASSTYPE = SoftmaxLayer.class;
	/** Defines the type to use as hidden layers for new neural networks. */  
	@SuppressWarnings("unchecked")
	public static final Class NEWNET_HIDDENCLASSTYPE = SigmoidLayer.class;
	/** Defines the network sizes (number of nodes) for the hidden layers (per round). */
	public static final int[][] NEWNET_SIZES = { {8, 5}, {8, 5}, {8, 5}, {8, 5} };

	
	/** Stores the initial neural nets for action guessing and further training. */
	public static final NeuralNet[] initialNets;


	/** Stores the player number. Only for convenience. Set once in constructor. */
	public final int playerIdx;
	
	/** Stores the NNTrainers (one per round) */ 
	public final NNTrainer[] trainers;
	
	/**
	 * Static constructor to initialize neural nets. 
	 */ 
	static 
	{
		initialNets = new NeuralNet[MAXBETROUNDS];
		for (int ri = 0; ri < MAXBETROUNDS; ri++)
			initialNets[ri] = createInitialActGuessNets(ri);
	}
	
	
	/**
	 * Constructor initializing the NNActionGuesser.
	 * The trainers for the different betting rounds will be created or loaded
	 * with initial values. 
	 */
	public NNActionGuesser(int playerIdx)
	{
		this.playerIdx = playerIdx;
		
		trainers = new NNTrainer[MAXBETROUNDS];
		for (int ri = 0; ri < MAXBETROUNDS; ri++)
		{
			trainers[ri] = new NNTrainer(playerIdx, ri, initialNets[ri], false, TRAININGDATAROWS[ri], TRAINERTHREADPRIO);
			loadInitialTrainingData(trainers[ri], ri);
		}
	}
	
	/**
	 * Returns the trainer for a specified betting rouound. 
	 * @param betRoundIdx The betting round a trainer is requested for. 
	 */
	public NNTrainer getTrainer(int betRoundIdx)
	{
		return trainers[betRoundIdx];
	}
	
	/**
	 * Returns an NNExecutiveNet for interrogation and thus, the final 
	 * guessing of an action.
	 * @param betRoundIdx The betting round an action guesser is requested for.
	 */
	public NNExecutiveNet getActionGuesser(int betRoundIdx)
	{
		return trainers[betRoundIdx].getExecutiveNet();
	}
	
	/**
	 * Export all trainers to disk. If no prefix is specified, the
	 * NNActionGuesser uses these files the next time to initialize
	 * the trainers. 
	 * @param prefixFilename A prefix for the filename. May be null.
	 */
	public void exportAllTrainers(String prefixFilename)
	{
		for (int ri = 0; ri < MAXBETROUNDS; ri++)
		exportTrainerData(trainers[ri], ri, prefixFilename);
	}
	
	/** Interrupts all trainers. Use continueTrainers to continue. */
	public void  interruptTrainers()
	{	for(NNTrainer t : trainers) t.interruptTraining(); }

	/** Lets all trainers continue neural net training. */
	public void  continueTrainers()
	{	for(NNTrainer t : trainers) t.continueTraining(); }

	/** Lets all trainers start neural net training. */
	public void  startTrainers()
	{	for(NNTrainer t : trainers) t.startTraining(); }

	/** Send a terminate command to all trainers. */
	public void  terminateTrainers()
	{	for(NNTrainer t : trainers) t.terminateTrainer(); }


   /* **************************************************************************************
	 * Static methods for for creation of networks here (either load / create).
	 * **************************************************************************************
	 */

	/**
	 * This methods creates the initial neural nets that will be used for the subsequent
	 * creation of NNTrainers.
	 */
	private static NeuralNet createInitialActGuessNets(int betRoundIdx)
	{
		NeuralNet retNet = null;
		File serNetFile = new File(FILENAMES_NETS[betRoundIdx]);
		if (serNetFile.exists()) // ok, there exists a serialized net to use!
		{
			try
			{ 
   			FileInputStream in = new FileInputStream(serNetFile);
   			retNet = importNeuralNet(in); 
   		}
			catch (Exception ex)
				{ System.err.println("Failed to load neural net!"); ex.printStackTrace(); }
			// now check if input size is valid...
			if ((retNet != null) && (retNet.getInputLayer().getRows() != PARAMCOUNTS[betRoundIdx]))  
				retNet = null;
		}
		
		if (retNet == null) // ok, no serialized net to use, so create a new one
		{
			retNet = buildABrain(PARAMCOUNTS[betRoundIdx], NEWNET_SIZES[betRoundIdx], ACTIONSPOSSIBLE,
			                     NEWNET_HIDDENCLASSTYPE, NEWNET_OUTPUTCLASSTYPE, NEWNET_SHORTCUTS);
			for (Layer l : retNet.calculateOrderedLayers()) l.init();
			retNet.randomize(NNTrainer.RANDOMIZATIONAMP);
		}
		
		return retNet;
	}
	
	/**
	 * Creates a Joone neural net according to the specified parameters.
	 * The net will neither be initialized nor will there be any input or output
	 * synapses attached.
	 * @param inputSize number of input neurons for the net 
	 * @param hiddenSizes an array specifying the number of hidden layers (.length) 
	 *                    and the number of neurons therein. 
	 * @param outputSize number of output neurons.
	 * @param addSCToOutput defines whether each hidden layer gets a shortcut
	 *                      to the output layer.
	 * @return The newly created neural net.
	 */
	@SuppressWarnings("unchecked")
	private static NeuralNet buildABrain (int inputSize, int[] hiddenSizes, int outputSize,
	                                      Class hiddenLayerType, Class outputLayerType,
	                                      boolean addSCToOutput)
	{
		NeuralNet retNet = new NeuralNet();
		
		Layer[] layers = new Layer[hiddenSizes.length + 2];
		
		// Create input layer first
		layers[0] = new LinearLayer();
		layers[0].setRows(inputSize);
		layers[0].setLayerName("input");
		retNet.addLayer(layers[0], NeuralNet.INPUT_LAYER);
		
		// Now create output layer
		try { layers[layers.length - 1] = (Layer) outputLayerType.newInstance(); }
		catch(Exception ex) { ex.printStackTrace(); System.exit(1); }
		layers[layers.length - 1].setRows(outputSize);
		layers[layers.length - 1].setLayerName("output");
		retNet.addLayer(layers[layers.length - 1], NeuralNet.OUTPUT_LAYER);
		
		// Now we add the hidden layers
		for (int i = 1; i <= hiddenSizes.length; i++)
		{
			// first create layer
			try { layers[i] = (Layer) hiddenLayerType.newInstance(); }
			catch(Exception ex) { ex.printStackTrace(); System.exit(1); }
			layers[i].setRows(hiddenSizes[i - 1]);
			layers[i].setLayerName("hidden" + i);
			retNet.addLayer(layers[i], NeuralNet.HIDDEN_LAYER);
			// now add normal synapse
			FullSynapse syn = new FullSynapse();
			layers[i - 1].addOutputSynapse(syn);
			layers[i].addInputSynapse(syn);
			// and finally shortcut synapse (always if last hidden layer)
			if (addSCToOutput || i == hiddenSizes.length)
			{
				FullSynapse sc = new FullSynapse();
				layers[i].addOutputSynapse(sc);
				layers[layers.length - 1].addInputSynapse(sc);
			}
		}
		
		return retNet;
	}

	/**
	 * Loads the initial training data set from a file to the specified trainer.
	 */
	private static int loadInitialTrainingData(NNTrainer trainer, int betRoundIdx)
	{
		int retCount = -1;
		File tDataFile = new File(FILENAMES_DATA[betRoundIdx]);
		if (tDataFile.exists()) // ok, there is training data to load!
		{
			try
			{
   			FileInputStream in = new FileInputStream(tDataFile);
   			retCount = importTrainingPatterns(trainer, in); 
			}
			catch (Exception ex)
				{ System.err.println("Failed to load training data!"); ex.printStackTrace(); }
		}
		return retCount;
	}
	
	/**
	 * Exports all data of a trainer to disk (the net and training data). 
	 * @param trainer The NNTrainer whose data should be exported.
	 * @param filePrefix A string to prepend the filename with. May be null.  
	 */
	private static void exportTrainerData(NNTrainer trainer, int betRoundIdx, String filePrefix)
	{
		if (filePrefix == null) filePrefix = "";

		try
		{
			File tDataFile = new File(filePrefix + FILENAMES_DATA[betRoundIdx]);
			FileOutputStream outData = new FileOutputStream(tDataFile, false);
			exportTrainingPatterns(trainer, outData); 

			File serNetFile = new File(filePrefix + FILENAMES_NETS[betRoundIdx]);
			FileOutputStream outNet = new FileOutputStream(serNetFile, false);
			exportExecNet(trainer, outNet); 
		
		}
		catch (Exception ex)
		{ System.err.println("Failed to export trainer data!\r\n" + ex.toString()); }
		
	}
	
	/* ***************************************************************************
	 * Methods for serialization of NNTrainers from here. That includes the
	 * NeuralNets as well as the training data NNTrainer is working with.
	 * **************************************************************************************
	 */
	
	/**
	 * Exports the training data of a NNTrainer to the specified output stream 
	 * using UTF-8 encoding.
	 * Format of file is: "V1|V2|V3|V4=T1|T2|T3\n", with the values being readable strings. 
	 * @param out The output stream to write to. Will be closed.
	 * @return Number of patterns written. -1 if error occured.
	 */
	private static int exportTrainingPatterns(NNTrainer trainer, OutputStream out)
	{
		OutputStreamWriter w = new OutputStreamWriter(out, Charset.forName("UTF-8"));
		StringBuilder pattern = new StringBuilder(256);
		int charsWritten = 0;
		int sampleCount = trainer.getSampleCount();
		double[][] trainData = trainer.getTrainingData();
		double[][] desiredData = trainer.getDesiredData();
		int paramsCount = trainer.getParamsCount();
		
		try
		{
   		for (int r = 0; r < sampleCount; r++)
   		{
   			pattern.setLength(0);
   			for (int c=0; c < paramsCount; c++)
   			{	pattern.append(trainData[r][c]); pattern.append('|'); }
   			pattern.setLength(pattern.length()-1);
   			pattern.append("=");
   			for (int c=0; c < ACTIONSPOSSIBLE; c++)
   			{	pattern.append(desiredData[r][c]); pattern.append('|'); }
   			pattern.setLength(pattern.length()-1);
   			pattern.append('\n');
   			
   			charsWritten += pattern.length(); 
   			w.write(pattern.toString());
   		}
   		w.flush();
   		w.close();
   		return sampleCount;
		}
		catch(IOException ex)
		{
			return -1;
		}
	}
	
	/**
	 * Reads in training patterns written out with exportTrainingPatterns().
	 * Data will be set in trainer via setTrainingPatterns.
	 * Stream will be closed on end of operation.
	 * @param in The input stream to read from. Will be closed when done.
	 * @return Number of patterns read. -1 on error.
	 */
	private static int importTrainingPatterns(NNTrainer trainer, InputStream in)
	{
		int maxSamples = trainer.getMaxSampleCount();
		int paramsCount = trainer.getParamsCount();
		int sampleCount = 0;
		int charsRead = 0, currChars = 0;

		InputStreamReader r = new InputStreamReader(in, Charset.forName("UTF-8"));
		char[] c = new char[256*256];
		String[] patterns = new String [maxSamples + 1];

		try
		{
			patterns[0] = "";
			while ((currChars = r.read(c)) >= 0 && sampleCount < maxSamples)
			{
				charsRead += currChars;
   			patterns[sampleCount] += String.copyValueOf(c, 0, currChars);
   			int nextPat;
   			while (sampleCount < maxSamples && (nextPat = patterns[sampleCount].indexOf('\n')) >= 0)
   			{
   				patterns[sampleCount + 1] = patterns[sampleCount].substring(nextPat+1);
   				patterns[sampleCount] = patterns[sampleCount].substring(0, nextPat);
   				sampleCount++;
   			}
			}
			r.close();
		}
		catch(IOException ex)
		{
			return -1;
		}
		
		double[][] trainData = new double[sampleCount][paramsCount];
		double[][] desiredData = new double[sampleCount][ACTIONSPOSSIBLE];
		
		// now transform patterns[] to data...
		for (int pi = 0; pi < sampleCount; pi++)
		{
			String[] sets, vals;
			sets = patterns[pi].split("=");
			
			vals = sets[0].split("\\|"); 
			for (int ci = 0; ci < paramsCount; ci++)
				trainData[pi][ci] = Double.parseDouble(vals[ci]);
			
			vals = sets[1].split("\\|");
			for (int ci = 0; ci < ACTIONSPOSSIBLE; ci++)
				desiredData[pi][ci] = Double.parseDouble(vals[ci]);
		}
			
		return trainer.setTrainingData(trainData, desiredData, sampleCount);
	}
	
	
	
	/**
	 * Exports the executive net for later use.
	 * Use exportTrainingPatterns() to export the training data set.
	 * OutputStream will be closed when done.
	 * @return Whether saving was successful.
	 */
	private static boolean exportExecNet(NNTrainer trainer, OutputStream out)
	{
		boolean result = true;
		NeuralNet execInstance = trainer.getExecutionInstance();
		
      execInstance.getMonitor().setExporting(true);
      NeuralNet exportInstance = execInstance.cloneNet();
      execInstance.getMonitor().setExporting(false);

      exportInstance.removeAllInputs();
      exportInstance.removeAllOutputs();
      exportInstance.removeAllListeners();
      exportInstance.getMonitor().setExporting(true);
      try { JooneTools.save_toStream(exportInstance, out); }
      catch (IOException ex) {result = false;}
      
		return result;
	}
	
	/**
	 * Imports a neural net formerly exported with exportExecNet().
	 * Stream is closed at end of operation. 
	 * NOTE: The net that is loaded is plain of any input and output synapses
	 * as they were removed during the export operation. Must be added to a 
	 * NNTrainer which automatically reconfigures the net before it can be 
	 * retrieved via getExecutionInstance. 
	 * @return The neural net loaded to be set via NNTrainer constructor.
	 */
	private static NeuralNet importNeuralNet(InputStream in)
	{
		NeuralNet nn = null;
      try { nn = JooneTools.load_fromStream(in); }
      catch (Exception ex) {return null;}
      
		return nn;
	}
	
	
}
