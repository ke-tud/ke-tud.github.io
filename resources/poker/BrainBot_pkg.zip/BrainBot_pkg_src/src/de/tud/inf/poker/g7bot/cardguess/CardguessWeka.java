package de.tud.inf.poker.g7bot.cardguess;

import java.io.BufferedReader;
import java.io.FileReader;
import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import weka.core.Instance;
import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.m5.*;
import weka.classifiers.trees.M5P;
import weka.classifiers.*;
import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * Cardguess_weka handles all WEKA learning and classifying of a Simulation Bot
 * for 5-6 player a is a classification tree build once: with init() for
 * training a FastVektor and the player tree is given to train() for
 * classification also a FastVektor and the player tree is given to classify()
 * 
 * @param args
 */
public class CardguessWeka
{
	String identifier;
	boolean    systemouts = false;
	FastVector player_instances;
	FastVector player_trees_active;
	FastVector player_trees_a;
	FastVector player_trees_b;
	boolean[] player_trees_a_active;
	boolean    treebuild_in_process;
	int        newDatasetsSinceTreeBuild[];
	public int bulidClassiefierEach;
	public int writeFileEach;
	int        absNewDatasets[];
	int        maximumInstances;
	
	// For time counting of different elements
	int[][]    timetable;
	String[]   timelabels;
	
	/**
	 * Running a test on methods: initialize(), learning() and classify() @param
	 * args - not needed for a test run
	 */
	public static void main (String[] args)
	{
		if (args != null)
		{
			System.out.println("Starting with CardGuessWeka()");
			CardguessWeka cardguessWeka = new CardguessWeka("maintest");
			
			// for a small example small values:
			cardguessWeka.bulidClassiefierEach = 6;
			cardguessWeka.writeFileEach = 5;
			cardguessWeka.maximumInstances = 10;
			
			// Train
			
			// % round, action: preflop, flop, turn, river, position, potsize,
			// activePlayer
			int learningPlayer = 0; // Test value
			
			float[] classiValues = new float[] { 1, -1, -1, -1, -1, 0, 20, 3, 0 }; // Test
			
			float[] classiValues2 = new float[] { 1, -1, -1, -1, -1, 0, 30, 3, 0 }; // Test
			
			// System.out .println("WEKA RESULT: "+
			// cardguessWeka.classify(learningPlayer, classiValues2));
			
			float[] learnValues2 = new float[] { 1, -1, -1, -1, -1, 0, 35, 3,
			      -0.099349f };
			System.out
			          .println("Number Instances"
			                   + ((Instances) cardguessWeka.player_instances
			                                                                .elementAt(0))
			                                                                              .numInstances());
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			System.out
			          .println(((M5P) cardguessWeka.player_trees_active
			                                                           .elementAt(0))
			                                                                         .toString());
			System.out
			          .println("Number Instances"
			                   + ((Instances) cardguessWeka.player_instances
			                                                                .elementAt(0))
			                                                                              .numInstances());
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			System.out
			          .println("Number Instances"
			                   + ((Instances) cardguessWeka.player_instances
			                                                                .elementAt(0))
			                                                                              .numInstances());
			
			float[] learnValues3 = new float[] { 1, -100, -100, -100, -100, 0,
			      3500, 300, -0.19349f };
			cardguessWeka.train(learningPlayer, learnValues3);
			cardguessWeka.train(learningPlayer, learnValues3);
			cardguessWeka.train(learningPlayer, learnValues3);
			cardguessWeka.train(learningPlayer, learnValues3);
			cardguessWeka.train(learningPlayer, learnValues3);
			System.out
			          .println("Number Instances"
			                   + ((Instances) cardguessWeka.player_instances
			                                                                .elementAt(0))
			                                                                              .numInstances());
			
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			cardguessWeka.train(learningPlayer, learnValues2);
			System.out
			          .println(((M5P) cardguessWeka.player_trees_active
			                                                           .elementAt(0))
			                                                                         .toString());
			
			float[] classiValues3 = new float[] { 1, -1, -1, -1, -1, 0, 20, 3, 0 }; // Test
			
			System.out.println("WEKA RESULT: "
			                   + cardguessWeka.classify(learningPlayer,
			                                            classiValues3));
			
			float[] classiValues4 = new float[] { 1, -1, -1, -1, -1, 0, 29.5f, 3,
			      0 }; // Test
			
			System.out.println("WEKA RESULT: "
			                   + cardguessWeka.classify(learningPlayer,
			                                            classiValues4));
			
		}
	}
	
	/*
	 * Init reading the file @param filepath The path on the disk, where the
	 * cardguesser_numeric_data_init_v1.arff is stored @return FastVector with
	 * elements, each a Instances for a player
	 */
	public void init ()
	{
		
		System.out.println("WEKA init start");
		String file = "Weka_OppModel_" + identifier + "_input.arff";
		
		Instances player_data_init = null;
		try
		{
			
			player_data_init = new Instances(
			                                 new BufferedReader(
			                                                    new FileReader(file)));
			
		}
		catch (Exception e)
		{
			System.out.println("Exception in read .arff file: " + e);
		}
		
		try
		{
			for (int i = 0; i <= 5; i++)
			{
				// Instances player_data_active = new Instances(player_data_init);
				// player_instances_active.addElement(player_data_active);
				Instances player_data_train = new Instances(player_data_init);
				
				if (player_data_train != null)
				   player_instances.addElement(player_data_train);
				
				// build a tree for each player
				buildTreeAndClassifier(i);
			}
		}
		catch (Exception e)
		{
			System.out.println("Exception in creating player_instances: " + e);
		}
	}
	
	/**
	 * Training - a given Dataset is learned by putting it into a Instances
	 * @param player_instances In this FastVector are all Instances of each
	 * player @param learningPlayer number which Instances should be changed
	 * @param learnValues String-Array of all Values, the order has to be
	 * correct!
	 */
	public void train (int learningPlayer, float[] learnValues)
	{
		
		
		/*
		 * Creating a learning case: An InstancE is created with new
		 * Attribute-Objects and Values The InstancE is added in the InstanceS of
		 * a given player
		 */

		Instances player_data = (Instances) player_instances
		                                                    .elementAt(learningPlayer);
		
		// Delete first 20% of datasets if there are more then maximumInstances allowes
		if (player_data.numInstances() >= maximumInstances)
			for (int i=(maximumInstances * 20 / 100); i>=0; i--)
			player_data.delete(i);
		
		// Create empty instancE with as many attribute values as needed
		Instance inst = new Instance(player_data.numAttributes());
		for (int i = 0; i < learnValues.length; i++)
		{
			inst.setValue(player_data.attribute(i), learnValues[i]);
		}
		
		// Set instancE's dataset
		inst.setDataset(player_data);
		
		// LEARNING: Add new dataset
		player_data.add(inst);
		
		//System.out.println("Weka instances trained! Number of instances: "
		  //                 + player_data.numInstances());
		
		// a tree is builded out of the given and learned Values each x time,
		// whereas x is a number defined in bulidClassiefierEach
		newDatasetsSinceTreeBuild[learningPlayer]++;
		if (newDatasetsSinceTreeBuild[learningPlayer] >= bulidClassiefierEach)
		   buildTreeAndClassifier(learningPlayer);
		
		// a file is written for generating learning value each x times, x is
		// defined in writeFileEach
		absNewDatasets[learningPlayer]++;
		if (absNewDatasets[learningPlayer] % writeFileEach == 0)
		{
			// write Datasets to a file
		//DISABLED FOR THE REAL BOT	writeInstances(learningPlayer);
			
			// write timeSummary in out.txt
			timeSummary();
		}
		
	}
	
	/**
	 * buildTrees building M5Prime trees for all Instances of the given FastVector
	 * @param player_number the tree for this player is build 
	 */
	public void buildTreeAndClassifier (int playerNumber)
	{
		if (!treebuild_in_process)
		{
			
			long time1 = System.currentTimeMillis();
			
			treebuild_in_process = true;
			newDatasetsSinceTreeBuild[playerNumber] = 0;
			
			String[] options = new String[1];
			options[0] = "-U"; // unpruned tree
			
			// J48 player_tree = new J48();
			M5P player_tree = new M5P();
			
			
			Instances player_data = (Instances) player_instances
			                                                    .elementAt(playerNumber);
			//System.out.println("BEFORE BUI�D TREE INSTANCES: " + player_data.toString());
			
			player_data.setClassIndex(player_data.numAttributes() - 1);
			try
			{
				player_tree.buildClassifier(player_data);
			}
			catch (Exception e)
			{
				System.out.println("OppModel WEKA: Error at building tree - " + e);
			}
			// player_trees_train.setElementAt(player_tree, playerNumber);
			player_trees_active.setElementAt(player_tree, playerNumber);
			
			Instances instances_copy = new Instances(
			                                         (Instances) player_instances
			                                                                     .elementAt(playerNumber));
			
			// Build Classifier:
			try
			{
				player_tree.buildClassifier(instances_copy);
			}
			catch (Exception e)
			{
				System.out
				          .println("Exception at creating M5P classifier for WEKA OppModel: "
				                   + e);
			}
			System.out.println("WEKA Tree and Classifier build for player" + playerNumber);
			treebuild_in_process = false;
			
			time1 = System.currentTimeMillis() - time1;
			timeMeasure(0, ((Long) time1).intValue());
		}
		
	}
	
	/**
	 * extracting the players tree-classifier and building a data-Instances with values to classify
	 * @param classyPlayer Integer which player is to looked at 
	 * @param classyfyValues String Values of the dataset to classify 
	 * @retun a numeric value of the winning probability
	 */
	public double classify (int classyPlayer, float[] classifyValues)
	{
		long time1 = System.currentTimeMillis();
		
		double result;
		//TODO ARRAY INSTEAD OF FASTVECTOR
		M5P player_tree = (M5P) player_trees_active.elementAt(classyPlayer);
		// System.out.println("M5P as string");
		
		Instances player_data = (Instances) player_instances
		                                                    .elementAt(classyPlayer);
		
		Instance inst = new Instance(player_data.numAttributes());
	
		// insert given values - should be all without the class attribute
		for (int i = 0; i < classifyValues.length - 1; i++)
		{
			//System.out.print(classifyValues[i] + " VIB ");
			inst.setValue(player_data.attribute(i), classifyValues[i]);
		}
		//System.out.println(player_data.toString());
		// assign InstancEwith player_data
		// TODO DO I NEED TYPE AGAIN
		inst.setDataset(player_data);
		
		// try to Classify with M5P
		try
		{
			result = 0;

			result = player_tree.classifyInstance(inst);
		//	System.out.println("WEKA Classify RESULT : " + result);
			time1 = System.currentTimeMillis() - time1;
			timeMeasure(1, ((Long) time1).intValue());
			
			return result;
		}
		catch (Exception e)
		{
			System.out
			          .println("Exception at creating M5P tree for WEKA OppModel: "
			                   + e);
			return -1;
		}
		}
	
	/** standard constructor with
	 * a string as token for the filename
	 */
	public CardguessWeka (String ident)
	{
		long time1 = System.currentTimeMillis();
		
		// Initialize
		treebuild_in_process = false;
		newDatasetsSinceTreeBuild = new int[] { 0, 0, 0, 0, 0, 0 };
		bulidClassiefierEach = 42;
		writeFileEach = 100; // DISABLED FOR BRAINBOT, write summary still alive
		maximumInstances = 800;
		absNewDatasets = new int[] { 0, 0, 0, 0, 0, 0 };
		
		// For time counting of different elements
		timetable = new int[3][10];
		timelabels = new String[10];
		
		player_instances = new FastVector(6);
		player_trees_a = new FastVector(6);
		player_trees_b = new FastVector(6);
		player_trees_a_active = new boolean[]{true,true,true,true,true,true};
		player_trees_active = new FastVector(6);
		
		identifier = ident;
		
		init();
		System.out.println("WEKA constructor begins");
		
		// Build trees
		time1 = System.currentTimeMillis() - time1;
		System.out.println("G7_Weka constructed in ms: " + time1);
		
	}
	

	/**
	 * this instance writes a file to harddisk with Instances for one player
	 * @param playerNumber the index number of the player
	 */
	public void writeInstances (int playerNumber)
	{
		
		try
		{
			String file = "Weka_OppModel_" + identifier +  "_" + playerNumber + "_output.arff";
			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			writer
			      .write(((Instances) player_instances.elementAt(playerNumber))
			                                                                   .toString());
			writer.newLine();
			writer.flush();
			writer.close();
			System.out.println("WEKA File was written.");
		}
		catch (Exception e)
		{
			System.out.println("Exception: WEKA file could not be written: " + e);
		}
		
	}
	
	/**
	 * Calculates the arithmetical average time, maximum time for a number of statistics
	 * @param place is a numeric token like a name
	 * @param time a time in milliseconds
	 */
	public void timeMeasure (int place, int time)
	{
		timelabels[0] = "Build tree in ms: ";
		timelabels[1] = "classify one Dataset: ";
		timelabels[2] = "buils classifyer from tree";
		
		// average time needed to do the action, for example building a tree
		timetable[place][0] = ((timetable[place][0] * timetable[place][1]) + time)
		                      / (timetable[place][1] + 1);
		timetable[place][1]++;
		
		//max time needed to do the action, for example building a tree
		if (time >= timetable[place][2]) timetable[place][2] = time;
	}
	
	public void timeSummary ()
	{
		System.out.println("TimeSummary:");
		int i = 0;
		while (timetable[i] != null && timetable[i][1] > 0)
		{
			System.out.println(timelabels[i] + "Average: " + timetable[i][0]
			                   + "  Counts: " + timetable[i][1] + "  Max: "
			                   + timetable[i][2]);
			i++;
		}
	}
}
