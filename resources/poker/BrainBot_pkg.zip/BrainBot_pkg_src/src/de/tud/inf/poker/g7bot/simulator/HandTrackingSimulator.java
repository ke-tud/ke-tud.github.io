package de.tud.inf.poker.g7bot.simulator;

import de.tud.inf.poker.g7bot.ActionGuessing.NNActionGuesser;
import de.tud.inf.poker.g7bot.ActionGuessing.NNTrainer;
import de.tud.inf.poker.g7bot.ActionGuessing.ParamProvider;
import de.tud.inf.poker.g7bot.ActionGuessing.NNTrainer.NNExecutiveNet;

public class HandTrackingSimulator
{  
	// CONSTANTS
	public static final int MAXPLAYERS = 6;

	public static final int MAXRAISES = 4;
	
	public static final int MAXROUNDS = 4;
	public static final int ROUND_PREFLOP = 0;
	public static final int ROUND_FLOP = 1;
	public static final int ROUND_TURN = 2;
	public static final int ROUND_RIVER = 3;
	public static final int ROUND_SHOWDOWN = 4;

	public static final int ACTIONSPOSSIBLE = NNTrainer.ACTIONSPOSSIBLE;
	public static final int CALL = NNTrainer.CALL;
	public static final int RAISE = NNTrainer.RAISE;
	public static final int FOLD = NNTrainer.FOLD;

	public static final int[] BLINDS = {1, 2};
	public static final int[] BETBYROUND = {2, 2, 4, 4};
	public static final int[] ROUNDSTART = {2, 0, 0, 0};

	public static final int[] NEXTPLAYER = {1, 2, 3, 4, 5, 0};
	public static final int[] LASTPLAYER = {5, 0, 1, 2, 3, 4};

	
	//	define static state
	int playerCount;
	int[] roundStart = ROUNDSTART.clone();

	// define dynamics (current state)
	public int round = ROUND_PREFLOP;
	public int raises = 0;
	public int nextRoundIn;
	public int playerToAct;
	public int playersActive;
	public boolean[] isActive = new boolean[MAXPLAYERS];
	public int[] nextPlayer = NEXTPLAYER.clone();
	public int[] lastPlayer = LASTPLAYER.clone();
	public int wholeBet; // amount each player has bet at whole
	public int totalPot; // amount in pot total
	public int hasInPot[] = new int[MAXPLAYERS]; // per player: pot contributions

	int push_round;
	int push_raises;
	int push_nextRoundIn;
	int push_playerToAct;
	int push_playersActive;
	boolean[] push_isActive = new boolean[MAXPLAYERS];
	int[] push_nextPlayer = new int[MAXPLAYERS];
	int[] push_lastPlayer = new int[MAXPLAYERS];
	int push_wholeBet;
	int push_totalPot;
	int[] push_hasInPot = new int[MAXPLAYERS];
	
	// simulation vars
	MersenneTwisterFastRandom simRandom = new MersenneTwisterFastRandom();
	boolean            simState = false;
	SimResults[]       results = new SimResults[ACTIONSPOSSIBLE]; 
	NNExecutiveNet[][] simActGuessers = null;
	ParamProvider      simParamProv = null;
	double[]           simWinProbs = null;
	
	
	public HandTrackingSimulator(int numplayers, int playerInSeat0)
	{
		for (int ri = 0; ri < MAXROUNDS; ri++)
			roundStart[ri] = ((roundStart[ri] + playerInSeat0) % numplayers);
		
		for (int ai = 0; ai < ACTIONSPOSSIBLE; ai++)
			results[ai] = new SimResults();
		
		playerCount = numplayers;
		nextPlayer[numplayers - 1] = 0;
		lastPlayer[0] = numplayers - 1;
		
		for (int pi = 0; pi < numplayers; pi++)
			isActive[pi] = true;
		
		// set blinds
		wholeBet = BLINDS[1];
		totalPot = BLINDS[0] + BLINDS[1];
		for (int pi = 0; pi < numplayers; pi++)
		{
			if (pi == (playerInSeat0) % numplayers) hasInPot[pi] = BLINDS[0]; // small
			else if (pi == (playerInSeat0 + 1) % numplayers) hasInPot[pi] = BLINDS[1]; // big
			else hasInPot[pi] = 0;
		}

		// store playerStates
		playersActive = numplayers;
		nextRoundIn = playersActive;
		playerToAct = roundStart[round];
		
	}
	
	/**
	 * Puts the HandTrackingSimulator from Tracking mode into simulation mode.
	 */
	public void startSimMode(double[] winProbs, ParamProvider paramProv, NNActionGuesser[] actGuessers)
	{
		simState = true;
		
		simWinProbs = winProbs;
		simParamProv = paramProv;
		simActGuessers = new NNExecutiveNet[playerCount][MAXROUNDS];
		
		for (int pi = 0; pi < playerCount; pi++)
			for (int ri = round; ri < MAXROUNDS; ri++)
				simActGuessers[pi][ri] = actGuessers[pi].getActionGuesser(ri);
		
		for (int ai = 0; ai < ACTIONSPOSSIBLE; ai++)
			results[ai].initialize(playerCount);

		pushState();
	}

	/**
	 * Ends simulation mode and returns to Tracking mode.
	 */
	public void endSimMode()
	{
		restoreState();

		simActGuessers = null;
		simParamProv = null;
		simWinProbs = null;

		simState = false;
	}
	
	/**
	 * Saves all state vars. Also the paramprovider.
	 */
	protected void pushState()
	{
		push_round = round;
		push_raises = raises;
		push_nextRoundIn = nextRoundIn;
		push_playerToAct= playerToAct;
		push_playersActive = playersActive;
		for(int pi = 0; pi < playerCount; pi++)
		{
			push_nextPlayer[pi] = nextPlayer[pi];
			push_lastPlayer[pi] = lastPlayer[pi];
			push_isActive[pi] = isActive[pi];
			push_hasInPot[pi] = hasInPot[pi];
		}
		push_wholeBet = wholeBet;
		push_totalPot = totalPot;
		
		simParamProv.pushState();
	}
	
	/**
	 * Restores all state vars. Also the paramprovider.
	 */
	protected void restoreState()
	{
		round = push_round;
		raises = push_raises;
		nextRoundIn = push_nextRoundIn;
		playerToAct = push_playerToAct;
		playersActive = push_playersActive;
		for(int pi = 0; pi < playerCount; pi++)
		{
			nextPlayer[pi] = push_nextPlayer[pi];
			lastPlayer[pi] = push_lastPlayer[pi];
			isActive[pi] = push_isActive[pi];
			hasInPot[pi] = push_hasInPot[pi];
		}
		wholeBet = push_wholeBet;
		totalPot = push_totalPot;
		
		simParamProv.restoreState();
	}
	
	/**
	 * Processes an action and updates the state accordingly. 
	 * @param action The action to process
	 * @return -1 if only one player left (all folded but one)
	 *          1 if showdown
	 *          0 else 
	 */
	public int processAction(int action)
	{

		if (simState) simParamProv.processAction(playerToAct, action);

		switch (action)
		{
			case RAISE:
				if (raises < MAXRAISES)
				{
					raises++;
					wholeBet += BETBYROUND[round];
					totalPot += wholeBet - hasInPot[playerToAct];  
					hasInPot[playerToAct] = wholeBet;
					nextRoundIn = playersActive; // will be decreased at end of turn
					break;
				}
				else { /* fall through to ACT_CALL*/ }
			case CALL:
				// first, update pot 
				totalPot += wholeBet - hasInPot[playerToAct];  
				hasInPot[playerToAct] = wholeBet;
				break;
			case FOLD:
				playersActive--;
				isActive[playerToAct] = false;
				nextPlayer[lastPlayer[playerToAct]] = nextPlayer[playerToAct]; 
				lastPlayer[nextPlayer[playerToAct]] = lastPlayer[playerToAct]; 
				break;
		}
		// now care for next player 
		playerToAct = nextPlayer[playerToAct];
		nextRoundIn--;
		
		if (playersActive == 1) return -1;
		if (nextRoundIn == 0)
		{
			if (simState) simParamProv.nextBetRound();
			round++;
			if (round == ROUND_SHOWDOWN) return 1;
			playerToAct = roundStart[round];
			while (!isActive[playerToAct]) playerToAct = ((playerToAct + 1) % playerCount);
			raises = 0;
			nextRoundIn = playersActive;
		}
		return 0;
		
	}
	
	
	/**
	 * Performs a simulation. Can be called multiple times to improve result.
	 * @param count number of simulation runs.
	 * @return runs performed. -1 on error. 
	 */
	public int simulateRounds(int count)
	{
		if (!simState) return -1;
		
		for (int i = 0; i < count; i++)
			for (int action = 0; action < ACTIONSPOSSIBLE; action++)
			{
				restoreState();
				switch (simHandToEnd(action))
				{
					case 1: // showdown!  Evaluate winProps.
						results[action].updateResults(totalPot, playerToAct, hasInPot);
						break;
					case -1: // all fold, winner is playerToAct
						results[action].updateResults(totalPot, isActive, simWinProbs, hasInPot);
						break;
				}
			}
		return count;
	}


	double[] outProbs = new double[ACTIONSPOSSIBLE];
	double[] stdProbs = {0.33, 0.33, 0.33};
	/**
	 * Simulates the hand until the end.
	 * The first action is specified to track the result.
	 * @param firstAction
	 * @return 1 if showdown, -1 if all but one folded.
	 */
	protected int simHandToEnd(int firstAction)
	{
		int nextAction = firstAction;
		int result;
		
		while ((result = processAction(nextAction)) == 0)
		{
			double[] params = simParamProv.getParams(playerToAct, simWinProbs[playerToAct]);
			double[] actionProbs;
			if(simActGuessers[playerToAct][round].interrogate(params, outProbs)) actionProbs = outProbs;
			else actionProbs = stdProbs;
			
			double realize = simRandom.nextDouble();
			double cumm = 0.0;
			for (nextAction = ACTIONSPOSSIBLE - 1; nextAction > 0; nextAction--)
			{
				cumm += actionProbs[nextAction];
				if (realize <= cumm) break;
			}
		}
		return result;
	}
	
	
	/**
	 * Reads the results for the single actions and returns the one delivering the
	 * highest expected payoff.
	 * @return an action.
	 */
	public int getBestAction()
	{
		int retResult = 0;
		
		if (!simState) return -1;
		restoreState(); // we need the playerIdx!
		
		// as we always do simulate
		for (int act = 1; act < ACTIONSPOSSIBLE; act++)
		{
			if (results[act].payouts[playerToAct] > results[retResult].payouts[playerToAct])
				retResult = act;
		}
		
		return retResult;
	}
	
	/**
	 * Get all the plain results.
	 * @return
	 */
	public SimResults[] getResults()
	{
		if (!simState) return null;
		else return results;
	}

	
}
