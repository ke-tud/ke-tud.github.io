package de.tud.inf.poker.g7bot.ActionGuessing;

import org.joone.engine.DirectSynapse;

/**
 * This class is originally part of the joone framework and
 * called DirectSynapseWithResult.
 * As it is not included in the joone-engine.jar, we 
 * have copied the source and renamed it to
 * DirectSynapseWithResult to prevent import-errors.
 */
@SuppressWarnings("serial")
public class DirectSynapseWithResult extends DirectSynapse {
    private double[] result;
    protected void forward(double[] pattern) {
        super.forward(pattern);
        setResult(outs);
    }
    
    public double[] getResult() {
   	 super.reset(); //SL: VERY IMPORTANT EXTENSION! 
        return result;
    }
    
    public void setResult(double[] result) {
        this.result = result;
    }
    
}

