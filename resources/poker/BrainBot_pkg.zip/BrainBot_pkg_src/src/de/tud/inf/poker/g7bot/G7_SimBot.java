package de.tud.inf.poker.g7bot;

import java.net.InetAddress;
import com.stevebrecher.poker.HandEval;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import de.tud.inf.poker.g7bot.free.AdvancedRingClient;
import de.tud.inf.poker.g7bot.simulator.WinProbabilitySimulator;

public class G7_SimBot extends AdvancedRingClient
{
	
	long myHoleCards;
	long flop;
	long turn;
	long river;
	
	public G7_SimBot (int numPlayers, MatchType matchtype)
	{
		super(numPlayers, matchtype);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception
	{
		MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000); 
		G7_SimBot myBot = new G7_SimBot(6, mt);

      // We will first set up a dummy simulator before we connect to our server.
		// This enables us to save the time when the static constructor run.  
		WinProbabilitySimulator dummyForInit = new WinProbabilitySimulator();
      dummyForInit.initialize(2, 3, 0, 0, 0);
      dummyForInit.simulateHand(1);
		
		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
      myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
      System.out.println("Successful connection!");
      
		myBot.run();

		// This is just to make sure that the java JIT will not try to be too
		// intelligent (that is: remove the wrong things from memory)...
		dummyForInit.simulateHand(1);

	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#actionPerformed(char, int, boolean, boolean)
    */
   @Override
   public void actionPerformed (char lastAction, int lastSeat,
                                boolean handOver, boolean showdown)
   {
      System.out.println("Action '"+ lastAction +"' received by seat " + lastSeat + "!");

      if (Dynamics.firstActionOnRound) System.out.println("New betting round has started(" + Dynamics.roundIndex + ")... Board cards are:" + Card.arrayToString(Dynamics.board));
      if (handOver) System.out.println("This hand is over" + (showdown ? " (showdown!)" : "") + "... My Stack-Size is: " + Dynamics.getMyStackSize() + "(" + Dynamics.amountWon[Dynamics.getMySeat()] + ")");

      if (Dynamics.firstActionOnRound) // update board cards
		{
      	Card[] board = Dynamics.board;
      	if (board != null)
      	{
      		if ( board.length > 4) 
      			river = HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[4].toString()));
      		else if ( board.length > 3)
      			turn = HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[3].toString()));
      		else if ( board.length > 0) 
      			flop = HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[0].toString()))
                    | HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[1].toString()))
                    | HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[2].toString()));
      	}
		}
   }

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#newHandStarted(ca.ualberta.cs.poker.free.dynamics.Card[])
    */
   @Override
   public void newHandStarted (Card[] clientCards)
   {
      System.out.println("Hand was started (#" + Dynamics.handNumber + ")! I'm in seat " + Dynamics.getMySeat() + " and got: " + Card.arrayToString(clientCards));

      Card[] myCards = Dynamics.getMyHoleCards();
      myHoleCards = HandEval.encode(com.stevebrecher.poker.Card.getInstance(myCards[0].toString()))
                  | HandEval.encode(com.stevebrecher.poker.Card.getInstance(myCards[1].toString()));
      flop = 0;
      turn = 0;
      river = 0;
   }

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize,
                           int amountToCall, long timeRemaining)
   {
      System.out.println("Supposed to take action (" + timeRemaining + "ms left)...");
      WinProbabilitySimulator sim = new WinProbabilitySimulator();
      sim.initialize(Dynamics.getNumActivePlayers(), myHoleCards, flop, turn, river);
      
      long startOfSim = System.currentTimeMillis();
      sim.simulateHand(10000);
      long stopOfSim = System.currentTimeMillis();

      int callPotSize = totalPotSize + amountToCall;
      int callInPotFromMe = Dynamics.getMyPotContribution() + amountToCall;
      int raisePotSize = callPotSize + Dynamics.getMaxRaise(Dynamics.getMySeat());
      int raiseInPotFromMe = callInPotFromMe + Dynamics.getMaxRaise(Dynamics.getMySeat());
      
      System.out.println("OK, did a Simulation(" + (stopOfSim - startOfSim) + " ms)" 
                         // + "\r\n CallPot=" + callPotSize + " CallInPotFromMe=" + callInPotFromMe
                         // + " RaisePot=" + raisePotSize + " RaiseInPotFromMe=" + raiseInPotFromMe
                         + "; My Winning Prob is:" + sim.getMyWinningProbability()
                         );

      try
      {
      	if (raiseAllowed && (sim.getMyWinningProbability() * raisePotSize > raiseInPotFromMe)) 
   			this.sendRaise();
   		else if ((amountToCall == 0) | (sim.getMyWinningProbability() * callPotSize > callInPotFromMe))
   			this.sendCall();
   		else
   			this.sendFold();
   		
   	}
   	catch (Exception ex) { /* no recovery here... */ }
   	
   }

}
