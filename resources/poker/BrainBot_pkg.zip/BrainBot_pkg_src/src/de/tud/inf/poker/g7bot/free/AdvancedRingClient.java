package de.tud.inf.poker.g7bot.free;

import java.io.IOException;
import java.net.SocketException;
import ca.ualberta.cs.poker.free.client.PokerClient;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

/**
 * This class serves as an extended base class to implement players
 * for ring games.
 * It keeps track of the current gamestate by maintaining the 
 * Dynamics object, which is an extension to the RingDynamics class.
 * It also introduces three new methods, that are supposed to be used
 * to react to changes of the game state.
 * <p> The event methods are:
 * 	newHandStarted(...), actionPerformed(...), takeAction(...)
 * @author Stefan L�ck
 */
public class AdvancedRingClient extends PokerClient
{
	public int numPlayers = 6;
	public MatchType matchtype = null;
	public LimitType def_limittype = LimitType.LIMIT;
	public int def_initialStackSize = 8000;
	public int def_numHands = 6000;
	
	public ClientRingDynamics Dynamics;

	public AdvancedRingClient (int numPlayers, MatchType matchtype)
   {
	   super();
	   this.numPlayers = numPlayers;
	   
	   if (matchtype == null)
	   	matchtype = new MatchType(def_limittype, (def_initialStackSize > 0), def_initialStackSize, def_numHands);
	   this.matchtype = matchtype;
	   
	   String[] names = new String[numPlayers];
	   for (int i = 0; i < numPlayers; i++ ) names[i] = "Player " + Integer.toString(i);
	   Dynamics = new ClientRingDynamics(numPlayers, matchtype, names);
   }

	/**
	 * @see ca.ualberta.cs.poker.free.client.PokerClient#handleStateChange()
	 */
   @Override
   public final void handleStateChange () throws IOException, SocketException
   {
   	AdvMatchStateMessage msm = new AdvMatchStateMessage(currentGameStateString);
   	
   	int lastSeat = Dynamics.seatToAct;
   	
   	boolean isNewHand = Dynamics.processStateChange(msm);

   	// make sure everything's fine with tracked state (should never be true)
   	if (!Dynamics.getMatchState(Dynamics.getMySeat()).equals(currentGameStateString))
   	{
      	System.out.println("BADMATCHSTATESTRING: ");
      	System.out.println("     Localstate : " + Dynamics.getMatchState(Dynamics.getMySeat()));
      	System.out.println("     From Server: " + currentGameStateString);
   	}

   	if (isNewHand)
   		newHandStarted(Dynamics.getMyHoleCards());
   	else // somebody must have taken an action...
   		actionPerformed(msm.getLastActionChar(), lastSeat, Dynamics.handOver, Dynamics.isShowdown());
   		
   	
   	if (!Dynamics.handOver && Dynamics.isMyTurn()) 
   		takeAction(
   		           Dynamics.canRaise(Dynamics.getMySeat()), 
   		           Dynamics.getPotSum(), 
   		           Dynamics.getAmountToCall(Dynamics.getMySeat()),
   		           Dynamics.getMyTimeRemaining()
   		           );
   	
   	if (Dynamics.handOver && (Dynamics.getHandsLeft() == 0))
   	{
   		matchIsOver();
   	}
   		
   }
   
/* *****************************************************************************
 * Auxiliary functions to be overridden in derived classes.
 * *****************************************************************************
 */   

   /**
    * This function is called after a state message arrived that indicates
    * a new hand was started. 
    * Can be used to start some computation.
    * NOTE: Will be called before takeAction, if it is the client's turn.
    * @param clientCards The client's cards.
    */
   public void newHandStarted(Card[] clientCards)
   {}

   /**
    * This function is called when the client is to take an action in the
    * game.
    * @param Indicates whether the client is allowed to raise.
    * @param totalPotSize Amount currently in the pot.
    * @param amountToCall Amount to be put in the pot when client decides to call. 
    * @param timeRemaining The time in milliseconds the client has left to act.
    */
   public void takeAction(boolean raiseAllowed, int totalPotSize, int amountToCall, long timeRemaining)
   {}

   /**
    * This function is called whenever a player has taken an action.
    * For convenience, this can also be caused by an client's action itself.
    * May be used to update internal statistics or manipulate off-turn computations
    * to regard the opponent's actions.
    * NOTE: Will be called before takeAction, if it is the client's turn.
    * @param lastAction The action that let to the state change.
    * @param lastSeat The seat that took the last action. 
    * @param handOver Indicates whether this was the last action of the hand. 
    * @param showdown If handOver is set, this indicates whether there was a showdown.
    */
   public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown)
   {}

   /**
    * Will be called after the last hand of the game is played.
    * Should be used to clean up.
    */
   public void matchIsOver()
   {}

}
