package de.tud.inf.poker.g7bot.simulator;

import java.util.Random;
import external.seanluke.ec.util.MersenneTwisterFast;

/**
 * A slight extension to the MersenneTwister class by Sean Luke
 * to make sure that when many instances for simulation are generated
 * at the same time they will still have different seeds.
 * @author Stefan L�ck
 */
public class MersenneTwisterFastRandom extends MersenneTwisterFast
{
   private static final long serialVersionUID = 1L;

   private static Random seedRandomizer;
   
	static
	{
		seedRandomizer = new Random();
	}
	
	public MersenneTwisterFastRandom ()
	{
		// we will actually crop to integer, as it preferred in super-class
		super(seedRandomizer.nextInt() ^ (System.currentTimeMillis() & 0xFFFFFFFFL));
	}
	
	public MersenneTwisterFastRandom (long seed)
	{
		super(seed);
	}
	
	public MersenneTwisterFastRandom (int[] array)
	{
		super(array);
	}
	
}
