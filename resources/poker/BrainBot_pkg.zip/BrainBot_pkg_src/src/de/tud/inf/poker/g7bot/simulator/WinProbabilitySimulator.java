package de.tud.inf.poker.g7bot.simulator;

/**
 * This class calculates the probability to win a hand given some
 * holecards and optionally also some board cards.
 * The calculation is done by simulation the drawing of cards and 
 * evaluating the outcomes.
 * <p>
 * Results: Starting from 1.000 iterations a good approximation of the
 * winning probability is reached.
 * <p>
 * Performance: Approx. 1.000.000 Iterations can be performed in one
 * second (Turion 1800Mhz Single Core)  
 * @author Stefan L�ck
 */
public class WinProbabilitySimulator
{  
	// define state
	long[] playerCards;
	long   flop, turn, river;
	int    numplayers;
	
	long fixedCards;
	final CardDrawer cardDrawer = new CardDrawer();

	// track simulation progress
	int simEntryPoint = 0; // which cards to simulate [bit-Array]
	final int entryFLOP = 1;
	final int entryTURN = 2;
	final int entryRIVER = 4;
	
	final SimResults results = new SimResults();

	public void initialize(int numplayers, long playerCards, long flop, long turn, long river)
	{
		if (this.numplayers != numplayers)
		{
			this.numplayers = numplayers;
			this.playerCards = new long[numplayers];
		}
		
		this.playerCards[0] = playerCards;
		simEntryPoint = 0;
		
		this.flop = flop;
		if (flop == 0) simEntryPoint |= entryFLOP; 
		this.turn = turn;
		if (turn == 0) simEntryPoint |= entryTURN; 
		this.river = river;
		if (river == 0) simEntryPoint |= entryRIVER;

		fixedCards = this.playerCards[0] | flop | turn | river;

		results.initialize(numplayers);

	}
	
	/**
	 * Returns the number of simulated iterations in this call.
	 * @param iters
	 * @return
	 */
	public int simulateHand(int iters)
	{
		long cardsDrawn;
		int i;
		
		for (i = 0; i < iters; i++)
		{
			cardsDrawn = fixedCards;
			if ((simEntryPoint & entryFLOP) != 0)
			{
				flop = cardDrawer.drawTriple(cardsDrawn);
				cardsDrawn |= flop;
			}
			if ((simEntryPoint & entryTURN) != 0)
			   turn = cardDrawer.drawTriple(cardsDrawn);
			{
				turn = cardDrawer.drawSingle(cardsDrawn);
				cardsDrawn |= turn;
			}
			if ((simEntryPoint & entryRIVER) != 0)
			   river = cardDrawer.drawTriple(cardsDrawn);
			{
				river = cardDrawer.drawSingle(cardsDrawn);
				cardsDrawn |= river;
			}
			
			for (int p = 1; p < numplayers; p++)
				playerCards[p] = cardDrawer.drawDouble(cardsDrawn);
			
			results.updateResults(0, playerCards, flop|turn|river);
		}
		
		return i;
	}
	
	/**
	 * Returns the winning probability calculated by the simulation.
	 * @return
	 */
	public double getMyWinningProbability()
	{
		return results.getWinningProbability(0);
	}

	public SimResults getCompleteResults()
	{
		return results;
	}

	
}
