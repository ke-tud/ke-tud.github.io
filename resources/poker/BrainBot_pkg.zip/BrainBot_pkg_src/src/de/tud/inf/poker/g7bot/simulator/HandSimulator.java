package de.tud.inf.poker.g7bot.simulator;

public class HandSimulator
{  
	// CONSTANTS
	public final int MAXPLAYERS = 6;

	public final int MAXRAISES = 4;
	
	public final int MAXROUNDS = 4;
	public final int ROUND_PREFLOP = 0;
	public final int ROUND_FLOP = 1;
	public final int ROUND_TURN = 2;
	public final int ROUND_RIVER = 3;
	public final int ROUND_SHOWDOWN = 4;

	public final int ACT_CALL = 0;
	public final int ACT_RAISE = 1;
	public final int ACT_FOLD = 2;

	public final int[] BLINDS = {1, 2};
	public final int[] BETBYROUND = {2, 2, 4, 4};
	public final int[] ROUNDSTART = {2, 0, 0, 0};

	public final int[] NEXTPLAYER = {1, 2, 3, 4, 5, 0};
	public final int[] LASTPLAYER = {5, 0, 1, 2, 3, 4};

	
	// define static state
	int playerCount;
	int players[];
	// CardGenerator cardGens[];
	// MoveGenerator moveGens[];

	CardGenerator[] cardGens;
	MoveGenerator[] Actors;

	// define initial state (start of simulation)
	// String bettingSeq;
	// int[] pot;
	// int[] missingInPot;
	
	
	// define dynamics (current state)
	int round = ROUND_PREFLOP;
	int raises = 0;
	int playerToAct;
	int playersActive;
	int[] nextPlayer = NEXTPLAYER.clone(); // new int[MAXPLAYERS];
	int[] lastPlayer = LASTPLAYER.clone(); // new int[MAXPLAYERS];
	int wholeBet; // amount each player has bet at whole
	int totalPot; // amount in pot total
	int hasInPot[] = new int[MAXPLAYERS]; // per player: pot contributions
	
	// helpers (not needed)
	boolean[] isActive = new boolean[MAXPLAYERS];
	
	//	history
	int[][][] actsPlayer = new int[6][4][5]; // per player per round
	int[] actSeq = new int[6*4*5];
	int[] roundActStartAt = new int [4]; // points to offsets in actSeq where round starts 
	
	// simulation results
	SimResults results = new SimResults();
	//! at least 3: fold, call raise;
	
	int[] wins;
	int[] winShowdown;
	int[] foldInRound[][];
	int[][] raiseInRound[][];
	int[] lost;
	int[] lostShowdown;
	int[] draw;
	
	public void initialize(int numplayers, long playerCards[], long board, String bettingSeqeunce)
	{
		results.initialize(numplayers);
		
	}
	
	protected void playHand()
	{
		int nextRoundIn;
		
		restoreStartState();
		drawHoleCardsPrePlayer();
		
		nextPlayer = NEXTPLAYER.clone();
		lastPlayer = LASTPLAYER.clone();
		nextPlayer[numplayers - 1] = 0;
		lastPlayer[0] = numplayers - 1;
		
		while (playersActive > 1 && round < ROUND_SHOWDOWN) // all folded or showdown
		{
			nextRoundIn = playersActive;
			raises = 0;
			while (playersActive > 1 && (nextRoundIn > 0)) // a betting round
			{
				int action = Actors[playerToAct].getAction(this, isANewRound); 
				switch (action)
				{
					case ACT_RAISE:
						if (raises < MAXRAISES)
						{
							raises++;
							wholeBet += BETBYROUND[round];
							totalPot += wholeBet - hasInPot[playerToAct];  
							hasInPot[playerToAct] = wholeBet;
							nextRoundIn = playersActive; // will be decreased at end of turn
							break;
						}
						else { /* fall through to ACT_CALL*/ }
					case ACT_CALL:
						// first, update pot 
						totalPot += wholeBet - hasInPot[playerToAct];  
						hasInPot[playerToAct] = wholeBet;
						break;
					case ACT_FOLD:
						playersActive--;
						isActive[playerToAct] = false;
						nextPlayer[lastPlayer[playerToAct]] = nextPlayer[playerToAct]; 
						lastPlayer[nextPlayer[playerToAct]] = lastPlayer[playerToAct]; 
						break;
				}

				// now care for next player 
				playerToAct += nextPlayer[playerToAct];
				nextRoundIn--;
			}	
			round++;
		}
		
		// now handle outcome of game
		if (playersActive == 1) // all folded but one (playerToAct has won it all)!
			results.updateResults(totalPot, playerToAct);
			// winner = playerToAct;
		else // showdown
			results.updateResults(totalPot, playerCards, board);
			// evaloutcome();
		
	}
}
