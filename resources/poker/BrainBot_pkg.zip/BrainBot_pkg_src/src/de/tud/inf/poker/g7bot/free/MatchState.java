package de.tud.inf.poker.g7bot.free;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * This class is constructed from a Matchstate-String
 */
public class MatchState
{
	public static enum MatchstateType {PREFLOP, FLOP, TURN, RIVER, ENDOFGAME};
	public static enum Action
	{
		FOLD, CALL, RAISE;
		public static Action parse(char actionChar)
		{
			switch (Character.toLowerCase(actionChar))
			{	case 'r': return RAISE; case 'c': return CALL; case 'f': return FOLD;}
			return null;
		}
	};
	
	public int PlayersSeat;
	public int HandNumber;
	
	public String PreflopHistory; 
	public String FlopHistory;
	public String TurnHistory;
	public String RiverHistory;
	
	public Card[] PlayerCards;
	public Card[][] AllCards;
	
	public Card[] FlopCards;
	public Card   TurnCard;
	public Card   RiverCard;
	
	/**
	 * Represents the Type (Round) the hand is currently in. There is no
	 * special Type for the Start of a hand. It is just PREFLOP.
	 */
	public MatchstateType MatchstateType;
	
	public Action LastAction;

	public MatchState(String matchstate)
	{
		String[] byColon = matchstate.split(":");
		if (!byColon[1].equals("MATCHSTATE")) throw new IllegalArgumentException();
		
		PlayersSeat = Integer.parseInt(byColon[1]);
		HandNumber = Integer.parseInt(byColon[2]);
		
		String[] histories = byColon[3].split("/");
		if (histories.length >= 1) PreflopHistory = histories[0];
		if (histories.length >= 2) FlopHistory = histories[1];
		if (histories.length >= 3) TurnHistory = histories[2];
		if (histories.length >= 4) RiverHistory = histories[3];
		
		String[] cards = byColon[4].split("/");
		if (cards.length >= 2) FlopCards = Card.toCardArray(cards[1]);
		if (cards.length >= 2) TurnCard = new Card (cards[2]);
		if (cards.length >= 2) RiverCard = new Card (cards[3]);

		String[] holecards = cards[0].split("|");
		AllCards = new Card[holecards.length][];
		for (int i = 0; i<holecards.length;i++)
		{
			if (!holecards[i].isEmpty()) AllCards[i] = Card.toCardArray(holecards[i]);
		}

	}
	
}

