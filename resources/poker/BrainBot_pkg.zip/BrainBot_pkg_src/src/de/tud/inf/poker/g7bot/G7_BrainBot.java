package de.tud.inf.poker.g7bot;

import java.net.InetAddress;
import com.stevebrecher.poker.HandEval;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import de.tud.inf.poker.g7bot.ActionGuessing.NNActionGuesser;
import de.tud.inf.poker.g7bot.ActionGuessing.NNTrainer;
import de.tud.inf.poker.g7bot.ActionGuessing.ParamProvider;
import de.tud.inf.poker.g7bot.cardguess.OppModel;
import de.tud.inf.poker.g7bot.free.AdvancedRingClient;
import de.tud.inf.poker.g7bot.simulator.HandTrackingSimulator;
import de.tud.inf.poker.g7bot.simulator.WinProbabilitySimulator;


/**
 * The main class of the BrainBot.
 */

public class G7_BrainBot extends AdvancedRingClient
{
	public final int MAXBETROUNDS = 4;
	
	public NNActionGuesser[] actGuessers;
	public ParamProvider     paramProvider;
	public OppModel oppmodel;
	public HandTrackingSimulator handSimulator;

	public long myHoleCards, flop, turn, river;
	public WinProbabilitySimulator simWinProb = new WinProbabilitySimulator();

	public G7_BrainBot (int numPlayers, MatchType matchtype)
	{
		super(numPlayers, matchtype);
		
		paramProvider = new ParamProvider();

		actGuessers = new NNActionGuesser[numPlayers];
		for (int pi = 0; pi < numPlayers; pi++)
			actGuessers[pi] = new NNActionGuesser(pi);

		oppmodel = new OppModel(Dynamics);
		
	}
	
   @Override
   public void actionPerformed (char lastAction, int lastSeat,
                                boolean handOver, boolean showdown)
   {
   	oppmodel.actionPerformed(lastAction, lastSeat, showdown);
   	double[] winProbs = oppmodel.takeAction();
   	
   	/* *******************************************
   	 * ==> START OF PARAMPROVIDERCODE
   	 */
   	int lastPlayerIdx = Dynamics.seatToPlayer(lastSeat);
   	int lastIntAction = ParamProvider.CALL;
   	
   	switch (Character.toLowerCase(lastAction))
   	{
   		case 'f': lastIntAction = ParamProvider.FOLD; break;
   		case 'c': lastIntAction = ParamProvider.CALL; break;
   		case 'r': lastIntAction = ParamProvider.RAISE; break;
   	}
   	// Call the handlers. 
   	handSimulator.processAction(lastIntAction);
   	handleActionPerformed_ActGuesser(lastPlayerIdx, lastIntAction, winProbs[lastPlayerIdx]);

   	/* <== END OF PARAMPROVIDERCODE
   	 * *******************************************/
   	
   	/* *******************************************
   	 * ==> TESTCODE
   	 */
//   	if (!handOver)
//   	{
//      	int nextPlayerIdx = Dynamics.seatToPlayer(Dynamics.seatToAct);
//      	NNExecutiveNet testGuess = actGuessers[nextPlayerIdx].getActionGuesser(paramProvider.getCurBetRound());
//      	double[] retOut = new double[NNTrainer.ACTIONSPOSSIBLE];
//      	double[] inPat = paramProvider.getParams(nextPlayerIdx, winProbs[nextPlayerIdx]);
//      	testGuess.interrogate(inPat, retOut);
//      	
//      	System.out.println("OK, my guess for player in seat " + Dynamics.seatToAct + " is: " + NNTrainer.formatSample(inPat, retOut));
//   	}
   	
   	/* 
   	 * <== TESTCODE
   	 * *******************************************/

      if (Dynamics.firstActionOnRound) // update board cards
		{
      	Card[] board = Dynamics.board;
      	if (board != null)
      	{
      		if ( board.length > 4) 
      			river = HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[4].toString()));
      		else if ( board.length > 3)
      			turn = HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[3].toString()));
      		else if ( board.length > 0) 
      			flop = HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[0].toString()))
                    | HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[1].toString()))
                    | HandEval.encode(com.stevebrecher.poker.Card.getInstance(board[2].toString()));
      	}
		}
   	
   	
   	if (lastSeat == Dynamics.getMySeat()) // last action was me --> now call the GC
   	{
   		System.gc(); // clean up
   	}
   	
   }

   @Override
   public void newHandStarted (Card[] clientCards)
   {
      Card[] myCards = Dynamics.getMyHoleCards();
      myHoleCards = HandEval.encode(com.stevebrecher.poker.Card.getInstance(myCards[0].toString()))
                  | HandEval.encode(com.stevebrecher.poker.Card.getInstance(myCards[1].toString()));
      flop = turn = river = 0;

      handSimulator = new HandTrackingSimulator(numPlayers, Dynamics.seatToPlayer(0));
   	paramProvider.init(this.Dynamics);
   	oppmodel.newHandStarted(clientCards);

//   	if (Dynamics.handNumber % 500 == 0) // export Nets
//      	for(int pi=0; pi<numPlayers; pi++)    	
//      		actGuessers[pi].exportAllTrainers("H" + Dynamics.handNumber + "_P" + pi + "_");
   		
   }

   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize,
                           int amountToCall, long timeRemaining)
   {
   	// try{Thread.sleep(200);}catch(InterruptedException ex){}
   	for(int pi=0; pi<numPlayers; pi++) actGuessers[pi].interruptTrainers();

   	double[] winProbs = oppmodel.takeAction();
   	
      simWinProb.initialize(Dynamics.getNumActivePlayers(), myHoleCards, flop, turn, river);
      simWinProb.simulateHand(1000);
      winProbs[Dynamics.seatToPlayer(Dynamics.getMySeat())] = simWinProb.getMyWinningProbability(); 
   	
   	
		handSimulator.startSimMode(winProbs, paramProvider, actGuessers);
   	
		try
   	{
			long startingTime = System.currentTimeMillis();
			long timeAllowed = timeRemaining / (Dynamics.getHandsLeft() + 1) / 10;
			while ((System.currentTimeMillis() - startingTime) < timeAllowed)
				handSimulator.simulateRounds(10);
			
			int bestAction = handSimulator.getBestAction();
//			System.out.println("I DECIDE: Action " + bestAction + 
//			                   " delivers " + handSimulator.getResults()[bestAction].payouts[Dynamics.seatToPlayer(Dynamics.getMySeat())] +
//			                   " found by iters " + handSimulator.getResults()[bestAction].getItersDone());
			switch(bestAction)
			{
				case HandTrackingSimulator.FOLD: sendFold(); break;
				case HandTrackingSimulator.CALL: sendCall(); break;
				case HandTrackingSimulator.RAISE: sendRaise(); break;
			}

   	}
   	catch (Exception ex)
   	{
   		ex.printStackTrace();
   		try{this.sendCall();} catch(Exception exex){}
   	}
		
   	handSimulator.endSimMode();

   	for(int pi=0; pi<numPlayers; pi++) actGuessers[pi].continueTrainers();
   }
   
   @Override
   public void matchIsOver ()
   {
//   	try{Thread.sleep(100000);} catch(InterruptedException ex){}
//   	// restartTrainers to use all patterns!
//   	for(int pi=0; pi<numPlayers; pi++) actGuessers[pi].startTrainers();

   	try{Thread.sleep(10000);} catch(InterruptedException ex){}

   	for(int pi=0; pi<numPlayers; pi++) actGuessers[pi].terminateTrainers();

   	try{Thread.sleep(10000);} catch(InterruptedException ex){}

   	System.exit(0);

//   	System.out.println("EXPORTING");
//   	for(int pi=0; pi<numPlayers; pi++)    	
//   		actGuessers[pi].exportAllTrainers("" + pi + "_");
   	
   	
   }

	public static void main (String[] args)
	throws Exception
   {
   	System.out.println("WELCOME!! Starting the BrainBot...");

		MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 6000);
		mt.timePerHand = 6500;
   	G7_BrainBot myBot = new G7_BrainBot(6, mt);
   	
   	System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
      myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
      System.out.println("Successful connection!");
      
   	myBot.run();
   }
	
	private void handleActionPerformed_ActGuesser(int lastPlayerIdx, int lastIntAction, double lastPlayerWinProb)
	{
   	double[] pattern = paramProvider.getParams(lastPlayerIdx, lastPlayerWinProb);
   	double[] target = new double[NNTrainer.ACTIONSPOSSIBLE];
   	NNTrainer lastPlayerTrainer = actGuessers[lastPlayerIdx].getTrainer(paramProvider.getCurBetRound());

   	// First: Get current pattern and create a training pattern!
   	//        Add this to the action guesser.

   	for (int ai = 0; ai < NNTrainer.ACTIONSPOSSIBLE; ai++)
   		if (ai == lastIntAction) target[ai] = 1.0; else target[ai] = 0.0;
   	
   	lastPlayerTrainer.addTrainingPattern(pattern, target);
   	
   	// Try to start training if at least MINPATTERNFORTRAINING new datasets added
   	if (lastPlayerTrainer.getNewSamplesCount() >= NNTrainer.MINPATTERNFORTRAINING) lastPlayerTrainer.startTraining(); 
   	
   	// Now tell ParamProvider to process the last action.
   	if (!Dynamics.handOver)
   	{
      	paramProvider.processAction(lastPlayerIdx, lastIntAction);
      	if (Dynamics.firstActionOnRound) // a new betting round has started!
      		paramProvider.nextBetRound();
   	}
		
	}

}
