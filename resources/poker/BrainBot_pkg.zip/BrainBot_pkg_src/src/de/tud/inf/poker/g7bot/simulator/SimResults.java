package de.tud.inf.poker.g7bot.simulator;

import com.stevebrecher.poker.HandEval;

/**
 * This class is used to store the results of a simulation.
 * It also provides methods to evaluate the outcome of a simulation
 * run, that is, evaluate the cards and split the pot accordingly.
 * 
 * For evaluation we rely on Steve Brecher's Hand Evaluator for fast 
 * hand evaluation (in case of showdown). 
 * @author Stefan L�ck
 */
public class SimResults
{  
	public final static int[] winBaseCount = // basis for counting wins (dividable through 1..numplayers)
	{ 0, 1, 2, 2*3, 3*4, 3*4*5, 3*4*5, 3*4*5*7, 3*5*7*8};

	public final int INIT_PCOUNT = 6;
	int    numplayers = INIT_PCOUNT;
	
	MersenneTwisterFastRandom random = new MersenneTwisterFastRandom();

	int itersdone; // number of sim-runs performed
	public int[] wins = new int[INIT_PCOUNT]; // count of wins
	public int[] payouts = new int[INIT_PCOUNT]; // pot-based calculation of what is won

	// private arrays to instance functions (avoid dynamic allocation in heap)
	// --> speeds up code a little, but beware: not thread-safe!!!
	int[] handVals = new int[INIT_PCOUNT]; // private to updateResults
	
	public void initialize(int numplayers)
	{
		if (wins.length < numplayers)
		{
			handVals = new int[numplayers];
			wins = new int[numplayers];
			payouts = new int[numplayers];
		}

		this.numplayers = numplayers;

		itersdone = 0;
		for (int p = 0; p < numplayers ; p++)
		{
			wins[p] = 0;
			payouts[p] = 0;
		}

	}
	
	public void updateResults (int pot, int winner)
	{
		updateResults (pot, winner, null);
	}

	/**
	 * Update the results after a single player has won (no showdown). 
	 * @param pot Total amount in pot.
	 * @param winner The winner of the pot.
	 */
	public void updateResults (int pot, int winner, int[] potContributions)
	{
		subPotContrib(potContributions);
		itersdone ++;
		wins[winner] += winBaseCount[numplayers];
		payouts[winner] += pot;
	}
	
	/**
	 * Read the WinningProbabilities of the active players and decide randomly
	 * who has won the hand!
	 * This is mathematically not correct, but it is faster than really simulating
	 * cards and gives a fair approximation of who is going to win.
	 */
	public void updateResults (int pot, boolean[] isActive, double[] simWinProbs, int[] potContributions)
	{
		itersdone ++;
		int winnerBits = 0;
		int allWinnerBits = 0;
		int winners = 0;
		int currentPlayer = 1;
		int activeCount = 0;
		
		subPotContrib(potContributions);
		
		
		for (int pi = 0; pi < numplayers; pi++)
			payouts[pi] += (int) (pot * simWinProbs[pi]);
		
		if (true) return;
		
		
		// code from here is not really working!!!
		

		double winningProb = random.nextDouble();
		double minProb = Double.MAX_VALUE, maxProb = Double.MIN_VALUE;
		for (int pi = 0; pi < numplayers; pi++)
		{
			if (isActive[pi])
			{
				activeCount++;
				allWinnerBits |= currentPlayer;
   			if (simWinProbs[pi] < minProb) minProb = simWinProbs[pi];
   			if (simWinProbs[pi] > maxProb) maxProb = simWinProbs[pi];
			}
			currentPlayer <<= 1;		
		}
		
		// correction factors
		// minProb =  minProb / (double)activeCount;
		// maxProb = ((1.0 - maxProb) / (double)activeCount);
		
		double correct = maxProb * minProb;
			
		currentPlayer = 1;
		for (int pi = 0; pi < numplayers; pi++)
		{
			if (isActive[pi])
   		{
   			if (simWinProbs[pi] - correct > winningProb) {winnerBits |= currentPlayer; winners ++;} 
   		}
			currentPlayer <<= 1;		
		}
		
		if (winners == 0) {winners = activeCount; winnerBits = allWinnerBits; } 

		// now update their outcomes
		int payout = pot / winners;
		int winCount = winBaseCount[numplayers] / winners;
		
		for (int p = 0; winnerBits != 0 ; p++)
		{
			if ((winnerBits & 1) == 1)
			{
				payouts[p] += payout;
				wins[p] += winCount;
			}
			winnerBits >>= 1;
		}
	
	}
	
	/**
	 * Evaluate the given cards and distribute pot to players accordingly  
	 * @param pot Total amount in pot. 
	 * @param playerCards Array with the cards of the players.
	 * @param board The board cards.
	 */
	public void updateResults (int pot, long[] playerCards, long board)
	{
		int maxVal  = HandEval.hand7Eval(playerCards[0] | board);
		int winners = 1;
		int winnerBits = 1;
		int currentPlayer = 1;
		
		itersdone++;

		// first determine the winner (multiple if tie) of the hand
		for (int p=1; p<numplayers; p++)
		{
			currentPlayer <<= 1;
			handVals[p] = HandEval.hand7Eval(playerCards[p] | board);
			if (handVals[p] > maxVal)
				{winnerBits = currentPlayer; maxVal = handVals[p]; winners = 1;}
			else if (handVals[p] == maxVal) { winnerBits |= currentPlayer; winners++; } 
		}
		
		// now update their outcomes
		int payout = pot / winners;
		int winCount = winBaseCount[numplayers] / winners;
		
		for (int p = 0; winnerBits != 0 ; p++)
		{
			if ((winnerBits & 1) == 1)
			{
				payouts[p] += payout;
				wins[p] += winCount;
			}
			winnerBits >>= 1;
		}
		
	}
	
	/** subtracts pot contribution from payoffs */
	private void subPotContrib (int[] potContributions)
	{
		if (potContributions == null) return;
		for (int p=1; p<numplayers; p++)
			payouts[p] -= potContributions[p];
		
	}
	
	/**
	 * Returns the Winning probability of player <code>player</code>.
	 * @return
	 */
	public double getWinningProbability(int player)
	{
		return ((double)wins[player]) / winBaseCount[numplayers] / itersdone;
	}
	
	public int getItersDone()
	{
		return itersdone;
	}
	
}
