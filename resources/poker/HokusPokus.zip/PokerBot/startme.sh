java -cp pokerserver.jar:simulator.jar bot.B2Bot $1 $2
