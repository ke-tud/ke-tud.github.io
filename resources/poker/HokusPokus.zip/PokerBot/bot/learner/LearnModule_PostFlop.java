package bot.learner;

import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.analyzer.Combination;

public class LearnModule_PostFlop extends LearnModule {
	
	private static final boolean LEARN_FROM_ALL = true;
	private static final boolean LEARN_SHOWDOWN_ONLY = true;

		
	public void learn(GameSituation gs) {
		if (!gs.isHandFinished())
			return;
		if (gs.getPlayerCards() == null && LEARN_FROM_ALL)
			return;
		if (LEARN_SHOWDOWN_ONLY && !gs.cameToShowDown())
			return;
		

		
		// PreFlop lernen (aus allen Playern, die gezeigt haben)
		Vector<Vector<Card>> playerCards = gs.getPlayerCards();
		
		
		// PostFlop lernen 
		if (gs.getBoardCards() != null && gs.getBoardCards().size() >= 3) {
			if (LEARN_FROM_ALL) { // Lernen von allen
				for (int i=0; i<playerCards.size(); i++) {
					if (playerCards.get(i) != null) {
						
						Vector<Card> cards = playerCards.get(i);
						Player player = gs.getPlayers().get(i);
						
						// Player die am Ende nicht dabei waren, ausblenden
						if (gs.getActionsFromPlayerInSituation(player, GameSituation.STATE_RIVER).size() <= 0)
							continue;
						
						FullCombo fc = new FullCombo(cards.toArray(new Card[0]), gs.getBoardCards().toArray(new Card[0]));
						Combination c = fc.getBestCombo();
						
						int cBucket = LearnerTools.getCombinationBucket(c);
						boolean hasWon = gs.getWinners().contains(player);
						
						int amount = gs.getPlayers().get(i).getWinAtRound(gs.getRound());

						
						Instance inst = new Instance(new int[] {cBucket}, hasWon);
						
						for (int j=0; j<Math.abs(amount); j++)
							learner.learnInstance(inst);
					}

				}
			}
			else { // Nur meine Karten lernen
				Vector<Card> cards = gs.getOwnCards();
				
				FullCombo fc = new FullCombo(cards.toArray(new Card[0]), gs.getBoardCards().toArray(new Card[0]));
				Combination c = fc.getBestCombo();
				
				int cBucket = LearnerTools.getCombinationBucket(c);
				boolean hasWon = gs.haveIWon();
				
				int amount = gs.getPlayers().get(gs.getPosition()).getWinAtRound(gs.getRound());

				
				Instance inst = new Instance(new int[] {cBucket}, hasWon);
				
				learner.learnInstance(inst);

			}
		}
	}
	
	public double rankSituation(GameSituation gs) {
		Vector<Card> cards = gs.getOwnCards();
	
		
		FullCombo fc = new FullCombo(cards.toArray(new Card[0]), gs.getBoardCards().toArray(new Card[0]));
		Combination c = fc.getBestCombo();
		
		int cBucket = LearnerTools.getCombinationBucket(c);
		
		Instance inst = new Instance(new int[] {cBucket});
		
		return learner.classifyRank(inst);

	}
	
	public void printState() {
		learner.printAllClasses();
	}
	
	public BayesianLearner getLearner() {
		return learner;
	}
	
	public LearnModule_PostFlop(String name) {
		super(name);
		
		// erstmal nur Karten lernen, also 1 Dimension jeweils
		learner = new BayesianLearner(new int[] {LearnerTools.COMBINATION_BUCKETS});
	}

}
