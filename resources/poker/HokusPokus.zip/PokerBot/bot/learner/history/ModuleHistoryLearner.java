package bot.learner.history;

import java.io.FileReader;
import java.util.Vector;

import bot.learner.BayesianLearner;
import bot.learner.Instance;
import bot.learner.LearnModule;
import bot.learner.LearnerTools;
import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.Player;
import bot.utils.ResultsMatchStateConverter;
import bot.utils.analyzer.Combination;

public class ModuleHistoryLearner {
	
	public static void learnStaticFile(String fileName, String ownPlayerName, LearnModule lm) {
		try {
			int i = 0;
			LineReader lr = new LineReader(fileName);
			String line = "";
			
			Player myPlayer = new Player(ownPlayerName);
			Vector<Player> players = new Vector<Player>();
			// TODO 6 statisch drin
			for (int j=0; j<6; j++) {
				players.add(new Player("P_" + j));
			}

			
			while ((line = lr.readLine()) != null) {
				i++; 
				
				if (line.charAt(0) == '#')
					continue;
				
				try {
					GameSituation gs = new GameSituation();

					
					gs.updateSituation(ResultsMatchStateConverter.convertResultToMatchState(line, ownPlayerName));

					Vector<Player> ps = gs.getPlayers();
					
					for (Player p : ps) {

						
						for (int j=0; j<players.size(); j++) {
							if (p.getName().equals(players.get(j).getName()))
								p.takeValues(players.get(j));
						}
						if (p.getName().equals(Config.PLAYER_NAME))
							p.takeValues(myPlayer);

					}


					
					for (int j=0; j<players.size(); j++) {
//						Player p = null;
						int posX = 0;
						for (int x=0; x<gs.getPlayers().size(); x++) {
							if (gs.getPlayers().get(x).getName().equals(players.get(j).getName())) {
//								p = gs.getPlayers().get(x);
								posX = x;
							}
								
						}
						players.get(j).addWin(gs.getPlayerWin(posX));
						
					}
					myPlayer.addWin(gs.getPlayerWin(gs.getPosition()));

					

					if (gs.cameToShowDown()) {
//						System.out.println(gs);
						lm.learn(gs);
					
					}
					
				}
				catch (Exception e) {
					System.out.println("ModuleHistoryLearner> Error: " + e);
					e.printStackTrace();
				}
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
