package bot.learner.history;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.ObservingCallBot;
import bot.learner.BayesianLearner;
import bot.learner.LearnModule;
import bot.learner.LearnModule_PreFlop;
import bot.opponent.SituationStore;
import bot.opponent.SituationStoreController;
import bot.utils.Config;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.Player;
import bot.utils.ResultsMatchStateConverter;

public class HistoryStatistics {
	
	private String fileName;
	
	public SituationStore getPlayerStatistics(String player) {
		try {
			Player myPlayer = new Player(player);
			Player other = new Player("OTHER");
			
			SituationStoreController ssc = new SituationStoreController();
			
			LineReader lr = new LineReader(fileName);
			String line = "";
			while ((line = lr.readLine()) != null) {
				if (line.charAt(0) == '#')
					continue;
				
				GameSituation gs = new GameSituation();
				
				gs.updateSituation(ResultsMatchStateConverter.convertResultToMatchState(line, player));
	
				// Player replacen
				Vector<Player> ps = gs.getPlayers();
				for (Player p : ps) {
					if (p.getName().equals(Config.PLAYER_NAME))
						p.takeValues(myPlayer);
					else
						p.takeValues(other);
				}
					
				ssc.addObservation(gs);
	
					
			}
			lr.close();
			
			
			printPlayerStat(myPlayer);
			
			return myPlayer.getSituationStore();
		}
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void printStatistics() {
		try {
			LineReader lr = new LineReader(fileName);
			String line = "";
			
			while ((line = lr.readLine()) != null) {
				if (line.charAt(0) != '#')
					break;
			}
			lr.close();
			
			String[] players = line.split(":")[0].replace("|", ":").split(":");
			
			for (int i=0; i<players.length; i++) {
				getPlayerStatistics(players[i]);
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public static void printPlayerStat(Player p) {
		System.out.println("Statistiken für Spieler " + p + ":");
		System.out.print("- Fold insgesamt PreFlop -> ");
		System.out.println(p.getSituationStore().getFrequency(0, 0, 0, 0, 0));
		System.out.print("- Call insgesamt PreFlop -> ");
		System.out.println(p.getSituationStore().getFrequency(0, 0, 0, 0, 1));
		System.out.print("- Raise insgesamt PreFlop -> ");
		System.out.println(p.getSituationStore().getFrequency(0, 0, 0, 0, 2));
		System.out.print("- Fold insgesamt Flop -> ");
		System.out.println(p.getSituationStore().getFrequency(1, 0, 0, 0, 0));
		System.out.print("- Call insgesamt Flop -> ");
		System.out.println(p.getSituationStore().getFrequency(1, 0, 0, 0, 1));
		System.out.print("- Raise insgesamt Flop -> ");
		System.out.println(p.getSituationStore().getFrequency(1, 0, 0, 0, 2));
		System.out.print("- Fold insgesamt Turn -> ");
		System.out.println(p.getSituationStore().getFrequency(2, 0, 0, 0, 0));
		System.out.print("- Call insgesamt Turn -> ");
		System.out.println(p.getSituationStore().getFrequency(2, 0, 0, 0, 1));
		System.out.print("- Raise insgesamt Turn -> ");
		System.out.println(p.getSituationStore().getFrequency(2, 0, 0, 0, 2));
		System.out.print("- Fold insgesamt River -> ");
		System.out.println(p.getSituationStore().getFrequency(3, 0, 0, 0, 0));
		System.out.print("- Call insgesamt River -> ");
		System.out.println(p.getSituationStore().getFrequency(3, 0, 0, 0, 1));
		System.out.print("- Raise insgesamt River -> ");
		System.out.println(p.getSituationStore().getFrequency(3, 0, 0, 0, 2));

	}
	
	public static void main(String[] args) {
		File f = new File("../data/results");
		
		File[] fs = f.listFiles();
		for (int i=0; i<fs.length; i++) {
			String fileName = fs[i].getAbsolutePath();
			if (fileName.contains(".log")) {
				System.out.println("Statistics for File " + fileName + " -----------------------------");
				HistoryStatistics hs = new HistoryStatistics(fileName);
				
				hs.printStatistics();
			}
		}
	}

	
	public HistoryStatistics(String fileName) {
		this.fileName = fileName;
	}
}
