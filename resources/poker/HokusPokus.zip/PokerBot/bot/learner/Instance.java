package bot.learner;

public class Instance {
	public int[] values;
	
	public boolean outcome;
	public boolean classified;
	
	public String toString() {
		String out = "[";
		for (int i=0; i<values.length; i++) {
			out += "v" + i + "=" + values[i] + "|";
		}
		
		if (classified)
			out += outcome + "]";
		else
			out = out.substring(0,out.length() - 1) + "]";
			
		return out;
	}
	
	public Instance(int[] values, boolean outcome) {
		this.values = values;
		this.outcome = outcome;
		classified = true;
	}
	
	public Instance(int[] values) {
		this.values = values;
		classified = false;
	}
}
