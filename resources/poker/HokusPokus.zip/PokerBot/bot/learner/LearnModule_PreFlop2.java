package bot.learner;

import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.analyzer.Combination;

public class LearnModule_PreFlop2 extends LearnModule {
	
	
	private PreFlopChart preFlopChart;
	
	private static final boolean LEARN_FROM_ALL = true;
	private static final boolean LEARN_SHOWDOWN_ONLY = true;

	
	public void learn(GameSituation gs) {
		if (!gs.isHandFinished())
			return;
		if (gs.getPlayerCards() == null && LEARN_FROM_ALL)
			return;
		if (LEARN_SHOWDOWN_ONLY && !gs.cameToShowDown())
			return;

		
		// PreFlop lernen (aus allen Playern, die gezeigt haben)
		Vector<Vector<Card>> playerCards = gs.getPlayerCards();
		
		if (LEARN_FROM_ALL) { // Lernen von allen
			for (int i=0; i<playerCards.size(); i++) {
				if (playerCards.get(i) != null) {
					Vector<Card> cards = playerCards.get(i);
					Player player = gs.getPlayers().get(i);
					
					// Player die am Ende nicht dabei waren, ausblenden
					if (gs.getActionsFromPlayerInSituation(player, GameSituation.STATE_RIVER).size() <= 0)
						continue;
					
					int cBucket = preFlopChart.getBucket(cards);
					int position = LearnerTools.getPositionBucket(i, gs.getPlayerCount());
					
					boolean hasWon = gs.getWinners().contains(player);
					
					
					int amount = player.getWinAtRound(gs.getRound());
					
					
					Instance inst = new Instance(new int[] {cBucket, position}, hasWon);
					
					for (int j=0; j<Math.abs(amount); j++)
						learner.learnInstance(inst);
				}
			}
		}
		else { // Lernen nur von mir
			Vector<Card> cards = gs.getOwnCards();
			
			int cBucket = preFlopChart.getBucket(cards);
			int position = LearnerTools.getPositionBucket(gs);
			
			boolean hasWon = gs.getWinners().contains(gs.getPlayers().get(gs.getPosition()));
			
			int amount = gs.getPlayers().get(gs.getPosition()).getWinAtRound(gs.getRound());

			
			Instance inst = new Instance(new int[] {cBucket, position}, hasWon);
			
			for (int j=0; j<Math.abs(amount); j++)
				learner.learnInstance(inst);

		}
		
	}
	
	public BayesianLearner getLearner() {
		return learner;
	}
	
	public double rankSituation(GameSituation gs) {
		Vector<Card> cards = gs.getOwnCards();
		
		int cBucket = preFlopChart.getBucket(cards);
		int position = LearnerTools.getPositionBucket(gs);
		

		
		Instance inst = new Instance(new int[] {cBucket, position});
		
		return learner.classifyRank(inst);

	}
	
	public void printState() {
		learner.printAllClasses();
	}
	
	public LearnModule_PreFlop2(String name) {
		super(name);
		
		preFlopChart = new PreFlopChart();
		
		// erstmal nur Karten lernen, also 1 Dimension jeweils
		learner = new BayesianLearner(new int[] {PreFlopChart.BUCKETS, LearnerTools.POSITION_BUCKETS});
	}

}
