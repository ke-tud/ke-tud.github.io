package bot.learner;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Date;

import bot.utils.GameSituation;

public abstract class LearnModule {

	public abstract void learn(GameSituation gs);
	public abstract double rankSituation(GameSituation gs);
	public abstract void printState();
	public abstract BayesianLearner getLearner();
	
	protected BayesianLearner learner;
	protected String name;
	
	public String getName() {
		return name;
	}
	
	public void writeLearner(String filename) {
		try {
			ObjectOutputStream objOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(filename)));
			objOut.writeObject(learner);
			objOut.close(); 
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	public void writeLearner() {
		System.out.println(getClass().getSimpleName() + "> Write serialized Learner in " + getFileName() + "...");

		writeLearner(getFileName());
	}
	
	public void readLearner(String filename) {
		try {
			ObjectInputStream objIn = new ObjectInputStream(new BufferedInputStream(new FileInputStream(filename)));
			learner = (BayesianLearner) objIn.readObject( );
			objIn.close(); 
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void readLearner() {
		try {
	
			File f = new File(getFileName());
			
			if (f.exists()) {
				System.out.println(getClass().getSimpleName() + "> Found serialized Learner in " + getFileName() + ", loading...");
				readLearner(getFileName());
			}
			else {
				System.out.println(getClass().getSimpleName() + "> No learner found in " + getFileName() + ".");
				
			}
		}
		catch (Exception e) {
			System.err.println(getClass().getSimpleName() + "> Error: " + e.getMessage());
		}
	}
	
	public String getFileName() {
		try {
			char t = System.getenv("TEMP").contains("\\") ? '\\' : '/';
		
			Date d = new Date(System.currentTimeMillis());
		
			return System.getenv("TEMP") + t + d + "_" + name + ".pser";
		}
		catch (Exception e) {
			System.err.println(getClass().getSimpleName() + "> Error: " + e.getMessage());
			return "";
		}
	}
	
	public LearnModule(String name) {
		this.name = name;
		
	}

}
