package bot.learner;

import java.util.Vector;

import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Flush;
import bot.utils.analyzer.FullHouse;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;
import bot.utils.analyzer.Quadruplet;
import bot.utils.analyzer.RoyalFlush;
import bot.utils.analyzer.Straight;
import bot.utils.analyzer.StraightFlush;
import bot.utils.analyzer.Triplet;
import bot.utils.analyzer.TwoPair;

public class LearnerTools {
	
	public static final int COMBINATION_BUCKETS = 12;
	public static final int ACTION_BUCKETS = 3;
	public static final int RAISE_BUCKETS = 3;
	public static final int USEDCARDS_BUCKETS = 3;
	public static final int POSITION_BUCKETS = 3;
	public static final int PAIR_BUCKETS = 2;
	public static final int SUITED_BUCKETS = 2;
	public static final int NUMBER_BUCKETS = 5;
	public static final int STRENGTH_BUCKETS = 5;
	
	public static int getNumberBucket(Card c) {
		if (c.getNumber() == Card.N2) return 0;
		if (c.getNumber() == Card.N3) return 0;
		if (c.getNumber() == Card.N4) return 0;
		if (c.getNumber() == Card.N5) return 1;
		if (c.getNumber() == Card.N6) return 1;
		if (c.getNumber() == Card.N7) return 1;
		if (c.getNumber() == Card.N8) return 2;
		if (c.getNumber() == Card.N9) return 2;
		if (c.getNumber() == Card.NT) return 2;
		if (c.getNumber() == Card.NJ) return 3;
		if (c.getNumber() == Card.NQ) return 3;
		if (c.getNumber() == Card.NK) return 4;
		if (c.getNumber() == Card.NA) return 4;
		
		return 0;
	}
	
	public static int getPairBucket(Vector<Card> cards) {
		if (cards.get(0).getNumber() == cards.get(1).getNumber())
			return 1;
		else
			return 0;
	}
	
	public static int getSuitedBucket(Vector<Card> cards) {
		if (cards.get(0).getColor() == cards.get(1).getColor())
			return 1;
		else 
			return 0;
	}

	public static int getAction(GameSituation gs, int state) {
		int action = 0;
		
		for (GameAction a : gs.getActions()) {
			if (a.getSituation() == state) {
				if (a.getType() == GameAction.ACTION_CALL) action++;
				else if (a.getType() == GameAction.ACTION_RAISE) action += 2;
			}
		}
		
		
		return action;
	}

	public static int getActionBucket(GameSituation gs, int state) {
		int action = getAction(gs, state);
		
		if (action <= gs.getPlayerCount())
			return 0;
		if (action <= 1.5*gs.getPlayerCount())
			return 1;
		else
			return 2;
	}
	
	public static int getCombinationBucket(Combination c) {
		if (c instanceof Highest) return 0;
		if (c instanceof Pair) {
			if (((Pair)c).getNumber() < Card.N7)
				return 1;
			if (((Pair)c).getNumber() < Card.NJ)
				return 2;
			else 
				return 3;
		}
		if (c instanceof TwoPair) return 4;
		if (c instanceof Triplet) return 5;
		if (c instanceof Straight) return 6;
		if (c instanceof Flush) return 7;
		if (c instanceof FullHouse) return 8;
		if (c instanceof Quadruplet) return 9;
		if (c instanceof StraightFlush) return 10;
		if (c instanceof RoyalFlush) return 11;
		
		else return 0;
	}
	
	public static double getRaisesPercentage(GameSituation gs) {
		double count = 0, raises = 0;
		
//		System.out.println("### " + gs.getActions());
		
		for (GameAction a : gs.getActions()) {
			if (a.getType() == GameAction.ACTION_RAISE)
				raises++;
			
//			System.out.println("## " + a);
			
			count++;
		}
		
		
		if (count == 0)
			return 0;
		
		return raises / count;
	}
	
	public static int getRaiseBucket(GameSituation gs) {
		double p = getRaisesPercentage(gs);
		
//		System.out.println("# " + p);
		
		if (p < 0.1) return 0;
		else if (p < 0.2) return 1;
		else return 2;
	}
	
	public static int getUsedHoleCards(Vector<Card> myCards, Vector<Card> board) {
		FullCombo fc = new FullCombo(myCards.toArray(new Card[0]), board.toArray(new Card[0]));
		
		Combination c = fc.getBestCombo();
		
		Card[] cards = c.getCards();
		int eq = 0;
		for (int i=0; i<cards.length; i++) {
			if (cards[i].equals(myCards.get(0)) || cards[i].equals(myCards.get(1)))
				eq++;
		}
		
		return eq;
	}
	
	public static int getPositionBucket(GameSituation gs) { 
		if (gs.getPlayerCount() == 2)
			return gs.getPosition();
		
		if (gs.getPlayerCount() == 6) {
			if (gs.getPosition() == 0 || gs.getPosition() == 1)
				return 0;
			else if (gs.getPosition() == 2 || gs.getPosition() == 3)
				return 1;
			else
				return 2;
		}
		
		return 0;
	}
	
	public static int getPositionBucket(int pos, int pCount) { 
		if (pCount == 2)
			return pos;
		
		if (pCount == 6) {
			if (pos == 0 || pos == 1)
				return 0;
			else if (pos == 2 || pos == 3)
				return 1;
			else
				return 2;
		}
		
		return 0;
	}
	
	public static int getCardStrength(Vector<Card> cards) {
		double count = 0;
		double[] colors = new double[4];
		
		for (int i=0; i<cards.size(); i++) {
			count += cards.get(i).getNumber();
			colors[cards.get(i).getColor()]++;
		}
		
		double maxColors = getMax(colors) / 10 + 1;
		
		return (int) (count * maxColors);
		
		
	}
	
//	public static int getOwnStrengthBucket(Vector<Card> cards) {
//		
//	}
	
	public static double getMax(double[] array) {
		double max = 0;
		for (int i=0; i<array.length; i++) {
			if (array[i] > max)
				max = array[i];
		}
		
		return max;
	}

}
