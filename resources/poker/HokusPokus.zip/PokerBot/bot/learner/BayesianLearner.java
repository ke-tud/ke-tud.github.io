package bot.learner;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;
import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.utils.Config;

public class BayesianLearner implements Serializable {
	
	private static final long serialVersionUID = -3887450330825379144L;

//	private Set<Instance> instances;
	
	private double instanceCount;
	private double pYes;
	private double pNo;

	private Vector<Vector<Double>> pVYes; // erstes Feld Instance, zweites Wert
	private Vector<Vector<Double>> pVNo;	 // erstes Feld Instance, zweites Wert

	private static final boolean DEBUG = false; 

	
	public void learnInstance(Instance i) {
//		instances.add(i);
		
		
		if (i.outcome) {
			pYes++;
			for (int j=0; j<i.values.length; j++) {
//				System.out.println(pVYes);
//				System.out.println(j + " " + i.values[j]);
				pVYes.get(j).set(i.values[j],pVYes.get(j).get(i.values[j]) + 1); 
			}

		}
		else {
			pNo++;
			for (int j=0; j<i.values.length; j++) {
//				System.out.println(pVNo);
//				System.out.println(j + " " + i.values[j]);
				pVNo.get(j).set(i.values[j],pVNo.get(j).get(i.values[j]) + 1); 
			}
		}
		
		instanceCount++;
		
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Learned instance " + i);
	}
	
	public boolean classify(Instance i) {
		double yes = (pYes/instanceCount);
		double no = (pNo/instanceCount);
		
		for (int j=0; j<i.values.length; j++) {
			double tmpY = (pVYes.get(j).get(i.values[j]) / instanceCount);
			yes *= (tmpY == Double.NaN) ? 1 : tmpY;
			
			double tmpN = (pVNo.get(j).get(i.values[j]) / instanceCount);
			no *= (tmpN == Double.NaN) ? 1 : tmpN;
		}
		
		
		double rank = yes / (yes+no);

		
		if (DEBUG) System.out.print(getClass().getSimpleName() + "> Classifiing " + i + ": yes->" + yes + " no->" + no + " rank->" + rank);
		
		if (yes>no) {
			if (DEBUG) System.out.println(" => yes");
			return true;
		}
		else {
			if (DEBUG) System.out.println(" => no");
			return false;
		}
	}
	
	public double classifyRank(Instance i) {
		double yes = (pYes/instanceCount);
		double no = (pNo/instanceCount);
		
		for (int j=0; j<i.values.length; j++) {
			double tmpY = (pVYes.get(j).get(i.values[j]) / instanceCount);
			yes *= (tmpY == Double.NaN) ? 1 : tmpY;
			
			double tmpN = (pVNo.get(j).get(i.values[j]) / instanceCount);
			no *= (tmpN == Double.NaN) ? 1 : tmpN;
		}
		
		
		double rank = yes / (yes+no);

		
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Classifiing " + i + ": yes->" + yes + " no->" + no + " rank->" + rank);

		if (Double.isNaN(rank)) {
			rank = 1;
		}
			
		return rank;
	}
	
//	public void printAllClasses() {
//		System.out.println(getClass().getSimpleName() + "> All Instances: ");
//		
//		for (int cl=0; cl<pVYes.size(); cl++) {
//			for (int val=0; val<pVYes.get(cl).size(); val++) {
//				double yes = (pYes/instanceCount)*(pVYes.get(cl).get(val)/instanceCount);
//				double no = (pNo/instanceCount)*(pVNo.get(cl).get(val)/instanceCount);
//				double rank = yes / (yes+no);
//				
////				double yes = pVYes.get(cl).get(val);
////				double no = pVNo.get(cl).get(val);
////				double rank = yes / (yes+no);
//				
//				System.out.println(getClass().getSimpleName() + "> Class c" + cl + "=" + val + ": " + " yes=" + yes + " no=" + no + " rank=" + rank);
//			}
//		}
//		System.out.println(getClass().getSimpleName() + "> learned " + instanceCount + " instances.");
//
//	}
	
	public void printAllClasses() {
		System.out.println(getClass().getSimpleName() + "> All Instances: ");
		
		int[] values = new int[pVYes.size()];
		
		for (int i=0; i<values.length; i++) 
			values[i] = 0;
		
		while (true) {
			Instance i = new Instance(values);
			System.out.println(getClass().getSimpleName() + "> " + i + " -> " + classifyRank(i));
			
			// feststellen, was erhöhen geht
			int j = -1;
			for (int x=0; x<values.length; x++) {
				if (pVYes.get(x).size() > values[x] + 1) {
					j = x;
					break;
				}
			}
			
			if (j == -1)
				break;
			
//			System.out.println("# Erhöhe " + j + " auf " + (values[j] + 1));
			
			values[j]++;
			
			for (int x=0; x<j; x++) {
				values[x] = 0;
			}
		}
		
//		for (int cl=0; cl<pVYes.size(); cl++) {
//			for (int val=0; val<pVYes.get(cl).size(); val++) {
//				double yes = (pYes/instanceCount)*(pVYes.get(cl).get(val)/instanceCount);
//				double no = (pNo/instanceCount)*(pVNo.get(cl).get(val)/instanceCount);
//				double rank = yes / (yes+no);
//				
////				double yes = pVYes.get(cl).get(val);
////				double no = pVNo.get(cl).get(val);
////				double rank = yes / (yes+no);
//				
//				System.out.println(getClass().getSimpleName() + "> Class c" + cl + "=" + val + ": " + " yes=" + yes + " no=" + no + " rank=" + rank);
//			}
//		}
		System.out.println(getClass().getSimpleName() + "> learned " + instanceCount + " instances.");

	}
	
	
	public BayesianLearner(int[] instanceValues) {
//		instances = new HashSet<Instance>();
		
		instanceCount = 0;
		pYes = 0;
		pNo = 0;

		pVYes = new Vector<Vector<Double>>();
		pVNo = new Vector<Vector<Double>>();
		
		for (int i=0; i<instanceValues.length; i++) {
			Vector<Double> tYes = new Vector<Double>();
			for (int j=0; j<instanceValues[i]; j++)
				tYes.add(0d);
			
			pVYes.add(tYes);
			
			Vector<Double> tNo = new Vector<Double>();
			for (int j=0; j<instanceValues[i]; j++)
				tNo.add(0d);
			
			pVNo.add(tNo);
		}
		
		
		
		
	}
	


}
