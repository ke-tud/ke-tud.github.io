package bot.pokertools;

import java.util.HashMap;
import java.util.Vector;

import sun.reflect.ReflectionFactory.GetReflectionFactoryAction;

import bot.utils.Card;
import bot.utils.GameAction;
import bot.utils.GameSituation;

public class PreFlopChartPS {
	
	public PreFlopChartPS() {
		initORC();
	}
	
	private HashMap<String, Info> preFlopChart = new HashMap<String, Info>();

	public int getAction(Vector<Card> holeCards, GameSituation gs) {
		if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) == null) {
			return GameAction.ACTION_FOLD;
		}
		
		//Monster eh immer raisen
		if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) != null) {
			Info info = preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1)));
			
			if(info.canCap)
				return GameAction.ACTION_RAISE;
		}	
		
		//Blinddefence
		if(gs.getPosition() == 1 && gs.getAmountToCall() == 2) {
			int raisePosition = getRaiserPosition(gs); //Position des Raisers bestimmen
			
			if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) != null) {
				Info info = preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1)));
				
				if(info.positionToRaise != -1) {
					//kann geraist werden
					if(raisePosition == 0 && info.positionToRaise == 6) {
						return GameAction.ACTION_RAISE;
					}
					else if(raisePosition >= info.positionToRaise) {
						return GameAction.ACTION_RAISE;
					}
					//kann gecalled werden
					else {
						if(raisePosition == 0 && info.positionToCall == 6) {
							return GameAction.ACTION_CALL;
						}
						else if(raisePosition >= info.positionToCall) {
							return GameAction.ACTION_CALL;
						}
						else {
							return GameAction.ACTION_FOLD;
						}
					}
				}
				//kann gecalled werden
				else {
					if(raisePosition == 0 && info.positionToCall == 6) {
						return GameAction.ACTION_CALL;
					}
					else if(raisePosition >= info.positionToCall) {
						return GameAction.ACTION_CALL;
					}
					else {
						return GameAction.ACTION_FOLD;
					}
				}
			}	
		}
		else if(gs.getPosition() != 1){
			if(amIFirstIn(gs)) {
				int position = gs.getPosition();
				
				if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) != null) {
					Info openRaiseInfo = preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1)));
					if(openRaiseInfo.raiseFromPositionGreaterEqualThan == -1) {
						return GameAction.ACTION_FOLD;
					}
					else if(position == 0) {
						return GameAction.ACTION_RAISE;
					}
					else if(position >= openRaiseInfo.raiseFromPositionGreaterEqualThan) {
						return GameAction.ACTION_RAISE;
					}
					else {
						return GameAction.ACTION_FOLD;
					}
				}
				else {
					return GameAction.ACTION_FOLD;
				}	
			}
			
			if(areThereOnlyLimper(gs)) {
				int numberLimpers = getLimperCount(gs); /* Anzahl der Limper bestimmen */
				
				if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) != null) {
					Info info = preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1)));
					
					if(info.numberOfLimpersToRaise >= numberLimpers) {
						return GameAction.ACTION_RAISE;
					}
					else if(info.numberOfLimpersToCall <= numberLimpers) {
						return GameAction.ACTION_CALL;
					}
					else {
						return GameAction.ACTION_FOLD;
					}
				}	
			}
			
			if(hasOnlyOneGuyRaised(gs)) {
				int numberColdCaller = getLimperCount(gs); //Anzahl der ColdCaller bestimmen
				int raisePosition = getRaiserPosition(gs); //Position des Raisers bestimmen
				boolean amISmallBlind;
				if(gs.getPosition() == 0) 
					amISmallBlind = true;
				else
					amISmallBlind = false;
				
				if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) != null) {
					Info info = preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1)));
					
					//testen ob man 3-Betten kann
					if(numberColdCaller >= 1) {
						if(amISmallBlind) {
							if(info.threeBetVsRaisePositionSmallBlind >= raisePosition) {
								return GameAction.ACTION_RAISE;
							}
							else if(info.canCallPositionvsRaiseAndCall != -1) {
								return GameAction.ACTION_CALL;
							}
							else {
								return GameAction.ACTION_FOLD;
							}
						}
						else if(!amISmallBlind) {
							if(info.threeBetVsRaisePositionNoBlind >= raisePosition) {
								return GameAction.ACTION_RAISE;
							}
							else if(info.canCallPositionvsRaiseAndCall != -1) {
								return GameAction.ACTION_CALL;
							}
							else {
								return GameAction.ACTION_FOLD;
							}
						}
					}
					else {
						if(amISmallBlind) {
							if(info.threeBetVsRaisePositionSmallBlindnoCall >= raisePosition) {
								return GameAction.ACTION_RAISE;
							}
							else {
								return GameAction.ACTION_FOLD;
							}
						}
						else if(!amISmallBlind) {
							if(info.threeBetVsRaisePositionNoBlindNoCall >= raisePosition) {
								return GameAction.ACTION_RAISE;
							}
							else {
								return GameAction.ACTION_FOLD;
							}
						}
					}
				
					
				}	
			}
			
			if(playVsThreeBet(gs)) {
				if(preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1))) != null) {
					Info info = preFlopChart.get(PreFlopChart.getCardString(holeCards.get(0), holeCards.get(1)));
					
					if(info.canCap)
						return GameAction.ACTION_RAISE;
					else if(gs.getAmountToCall() > 2) {
						return GameAction.ACTION_FOLD;
					}
				}	
			}
		}
		else if(gs.getAmountToCall() > 2) {
			return GameAction.ACTION_FOLD;
		}
		
		return GameAction.ACTION_CALL;
	}
	
	private void initORC() {
		//Pairs
		preFlopChart.put("22", new Info(6, -1, 3, -1, -1, -1, 5, 2, false, -1, 2));
		preFlopChart.put("33", new Info(5, -1, 3, -1, -1, -1, 5, 2, false, 6, 2));
		preFlopChart.put("44", new Info(4, -1, 2, -1, -1, -1, 5, 2, false, 5, 2));
		preFlopChart.put("55", new Info(3, 1, 2, -1, -1, 4, 4, 2, false, 5, 2));
		preFlopChart.put("66", new Info(2, 1, 2, -1, -1, 3, 3, 2, false, 5, 2));
		preFlopChart.put("77", new Info(2, 1, 2, -1, -1, 3, 3, 2, false, 4, 2));
		preFlopChart.put("88", new Info(2, 2, 3, -1, -1, 2, 2, 2, false, 3, 2));
		preFlopChart.put("99", new Info(2, 3, -1, 2, 2, 2, 2, 2, false, 2, 2));
		preFlopChart.put("TT", new Info(2, 3, -1, 2, 2, 2, 2, 2, true, 2, 2));
		preFlopChart.put("JJ", new Info(2, 3, -1, 2, 2, 2, 2, 2, true, 2, 2));
		preFlopChart.put("QQ", new Info(2, 3, -1, 2, 2, 2, 2, 2, true, 2, 2));
		preFlopChart.put("KK", new Info(2, 3, -1, 2, 2, 2, 2, 2, true, 2, 2));
		preFlopChart.put("AA", new Info(2, 3, -1, 2, 2, 2, 2, 2, true, 2, 2));
		
		//Suited Cards
		
		//Suited Aces
		preFlopChart.put("A2s", new Info(4, -1, 3, -1, 5, -1, -1, -1, false, 6, 2));
		preFlopChart.put("A3s", new Info(4, -1, 3, -1, 5, -1, -1, -1, false, 6, 2));
		preFlopChart.put("A4s", new Info(4, -1, 3, -1, 5, -1, -1, -1, false, 6, 2));
		preFlopChart.put("A5s", new Info(4, -1, 3, -1, 5, -1, -1, -1, false, 5, 2));
		preFlopChart.put("A6s", new Info(3, 1, 1, -1, 5, -1, -1, -1, false, 5, 2));
		preFlopChart.put("A7s", new Info(3, 1, 1, 4, 4, -1, -1, -1, false, 5, 2));
		preFlopChart.put("A8s", new Info(2, 2, 1, 4, 4, -1, -1, -1, false, 5, 2));
		preFlopChart.put("A9s", new Info(2, 2, 1, 3, 3, -1, -1, -1, false, 4, 2));
		preFlopChart.put("ATs", new Info(2, 3, 1, 2, 2, -1, -1, -1, false, 3, 2));
		preFlopChart.put("AJs", new Info(2, 3, 1, 2, 2, -1, -1, -1, false, 2, 2));
		preFlopChart.put("AQs", new Info(2, 3, 1, 2, 2, -1, -1, -1, true, 2, 2));
		preFlopChart.put("AKs", new Info(2, 3, 1, 2, 2, -1, -1, -1, true, 2, 2));
		
		//Suited Kings 
		preFlopChart.put("K2s", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("K3s", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("K4s", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("K5s", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("K6s", new Info(5, -1, 3, -1, -1, -1, -1, -1, false, 6, 3));
		preFlopChart.put("K7s", new Info(5, -1, 3, -1, -1, -1, -1, -1, false, 6, 3));
		preFlopChart.put("K8s", new Info(4, -1, 3, -1, -1, -1, -1, -1, false, 6, 3));
		preFlopChart.put("K9s", new Info(3, 1, 1, -1, 5, -1, -1, -1, false, 6, 2));
		preFlopChart.put("KTs", new Info(2, 2, 1, 4, 4, -1, -1, -1, false, 6, 2));
		preFlopChart.put("KJs", new Info(2, 2, 1, 4, 4, -1, -1, 2, false, 5, 2));
		preFlopChart.put("KQs", new Info(2, 3, 1, 2, 2, -1, -1, 2, false, 5, 2));
		
		//Suited Queens
		preFlopChart.put("Q2s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("Q3s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("Q4s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("Q5s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("Q6s", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("Q7s", new Info(5, -1, 3, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("Q8s", new Info(4, -1, 3, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("Q9s", new Info(3, 1, 1, -1, -1, -1, -1, -1, false, -1, 2));
		preFlopChart.put("QTs", new Info(2, 2, 1, 4, 5, -1, -1, 2, false, -1, 2));
		preFlopChart.put("QJs", new Info(2, 2, 1, 4, 5, -1, -1, 2, false, 6, 2));
		
		//Suited Jacks
		preFlopChart.put("J2s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("J3s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("J4s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("J5s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("J6s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("J7s", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("J8s", new Info(4, -1, -1, -1, -1, -1, -1, -1, false, -1, 2));
		preFlopChart.put("J9s", new Info(3, 1, 2, -1, -1, -1, -1, -1, false, -1, 2));
		preFlopChart.put("JTs", new Info(2, 2 ,3, -1, -1, -1, -1, 2, false, -1, 2));
		
		//Suited Tens
		preFlopChart.put("T2s", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("T3s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("T4s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("T5s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("T6s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("T7s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("T8s", new Info(5, -1, 3, -1, -1, -1, -1, -1, false, -1, 2));
		preFlopChart.put("T9s", new Info(3, 1, 2, -1, -1, -1, -1, -1, false, -1, 2));
		
		//Suited Nines
		preFlopChart.put("92s", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("93s", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("94s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("95s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("96s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("97s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 2));
		preFlopChart.put("98s", new Info(4, -1, 3, -1, -1, -1, -1, -1, false, -1, 2));
		
		//Suited Eights
		preFlopChart.put("84s", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("85s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("86s", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 2));
		preFlopChart.put("87s", new Info(5, -1, 3, -1, -1, -1, -1, -1, false, -1, 2));
		
		//Suited Sevens
		preFlopChart.put("74s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("75s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("76s", new Info(5, -1, 3, -1, -1, -1, -1, -1, false, -1, 2));
		
		//Suited Sixes
		preFlopChart.put("63s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("64s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("65s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 2));
		
		//Suited Fives
		preFlopChart.put("52s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("53s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("54s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 2));
		
		//Suited Fours
		preFlopChart.put("43s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, 5));
		
		//Suited Threes
		preFlopChart.put("32s", new Info(-1, -1, 3, -1, -1, -1, -1, -1, false, -1, -1));
		
		//Offsuited Cards
		
		//Aces
		preFlopChart.put("A2", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, 6, 3));
		preFlopChart.put("A3", new Info(5, -1, -1, -1, 5, -1, -1, -1, false, 6, 3));
		preFlopChart.put("A4", new Info(5, -1, -1, -1, 5, -1, -1, -1, false, 6, 3));
		preFlopChart.put("A5", new Info(5, -1, -1, -1, 5, -1, -1, -1, false, 6, 3));
		preFlopChart.put("A6", new Info(5, -1, -1, -1, 5, -1, -1, -1, false, 6, 3));
		preFlopChart.put("A7", new Info(4, -1, -1, -1, 5, -1, -1, -1, false, 6, 2));
		preFlopChart.put("A8", new Info(4, -1, -1, 4, 4, -1, -1, -1, false, 5, 2));
		preFlopChart.put("A9", new Info(3, 1, 2, 4, 4, -1, -1, -1, false, 5, 2));
		preFlopChart.put("AT", new Info(2, 3, 2, 3, 3, -1, -1, -1, false, 4, 2));
		preFlopChart.put("AJ", new Info(2, 3, 2, 2, 2, -1, -1, -1, false, 3, 2));
		preFlopChart.put("AQ", new Info(2, 3, 2, 2, 2, -1, -1, -1, false, 2, 2));
		preFlopChart.put("AK", new Info(2, 3, 2, 2, 2, -1, -1, -1, true, 2, 2));
		
		//Kings
		preFlopChart.put("K3", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("K4", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("K5", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("K6", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("K7", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("K8", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, 6, 4));
		preFlopChart.put("K9", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, 6, 4));
		preFlopChart.put("KT", new Info(4, -1, -1, -1, 5, -1, -1, -1, false, 6, 3));
		preFlopChart.put("KJ", new Info(2, 2, -1, -1, 5, -1, -1, -1, false, 5, 2));
		preFlopChart.put("KQ", new Info(2, 3, -1, 3, 3, -1, -1, -1, false, 5, 2));
		
		//Queens
		preFlopChart.put("Q4", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("Q5", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("Q6", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("Q7", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("Q8", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("Q9", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("QT", new Info(4, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		preFlopChart.put("QJ", new Info(3, 1, 2, -1, -1, -1, -1, -1, false, 6, 2));
		
		//Jacks
		preFlopChart.put("J5", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("J6", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("J7", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("J8", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("J9", new Info(5, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		preFlopChart.put("JT", new Info(4, -1, -1, -1, -1, -1, -1, -1, false, -1, 3));
		
		//Tens
		preFlopChart.put("T6", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("T7", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("T8", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("T9", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		
		//Nines
		preFlopChart.put("96", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("97", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		preFlopChart.put("98", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 4));
		
		//Eights
		preFlopChart.put("86", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
		preFlopChart.put("87", new Info(6, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		
		//Sevens
		preFlopChart.put("76", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 5));
		
		//Sixes
		preFlopChart.put("65", new Info(-1, -1, -1, -1, -1, -1, -1, -1, false, -1, 6));
	}
	
	private int getRaiserPosition(GameSituation gs) {
		Vector<GameAction> actions =  gs.getActionsInRound(GameSituation.STATE_PREFLOP);
		for(GameAction a : actions) {
			if(a.getType() == GameAction.ACTION_RAISE) {
				return gs.getPlayers().indexOf(a.getPlayer());
			}
		}
		return -1;
	}
	
	private boolean amIFirstIn(GameSituation gs) {
		Vector<GameAction> actions =  gs.getActionsInRound(GameSituation.STATE_PREFLOP);
		for(GameAction a : actions) {
			if(a.getType() != GameAction.ACTION_FOLD) {
				return false;
			}
		}
		return true;
	}
	
	private boolean areThereOnlyLimper(GameSituation gs) {
		Vector<GameAction> actions =  gs.getActionsInRound(GameSituation.STATE_PREFLOP);
		for(GameAction a : actions) {
			if(a.getType() == GameAction.ACTION_RAISE) {
				return false;
			}
		}
		return true;
	}
	
	private int getLimperCount(GameSituation gs) {
		Vector<GameAction> actions =  gs.getActionsInRound(GameSituation.STATE_PREFLOP);
		int counter = 0;
		
		for(GameAction a : actions) {
			if(a.getType() == GameAction.ACTION_CALL) {
				counter++;
			}
		}
		return counter;
	}
	
	private boolean hasOnlyOneGuyRaised(GameSituation gs) {
		Vector<GameAction> actions =  gs.getActionsInRound(GameSituation.STATE_PREFLOP);
		int counter = 0;
		
		for(GameAction a : actions) {
			if(a.getType() == GameAction.ACTION_RAISE) {
				counter++;
			}
		}
		
		if(counter == 1)
			return true;
		else
			return false;
	}
	
	private boolean playVsThreeBet(GameSituation gs) {
		Vector<GameAction> actions =  gs.getActionsInRound(GameSituation.STATE_PREFLOP);
		int counter = 0;
		
		for(GameAction a : actions) {
			if(a.getType() == GameAction.ACTION_RAISE) {
				counter++;
			}
		}
		
		if(counter > 1)
			return true;
		else
			return false;
	}
	
	private class Info {
		//Open Raising
		public int raiseFromPositionGreaterEqualThan;
		
		//vs Limper
		public int numberOfLimpersToRaise;
		public int numberOfLimpersToCall;
		
		//vs 1 Raise and 1 Call
		public int threeBetVsRaisePositionNoBlind;
		public int threeBetVsRaisePositionSmallBlind;
		public int threeBetVsRaisePositionNoBlindNoCall;
		public int threeBetVsRaisePositionSmallBlindnoCall;
		public int canCallPositionvsRaiseAndCall;
		
		//vs 3Bet
		public boolean canCap;
		
		//Blind Defence
		public int positionToRaise;
		public int positionToCall;
		
		
		public Info(int raiseFrom, int numberRaise, int numberCall, int threeBetNoBlind, int threeBetSmallBlind, int threeBetCallNoBlind, int threeBetCallSmallBlind, int canCall, boolean canCap, int posToRaise, int posToCall) {
			raiseFromPositionGreaterEqualThan = raiseFrom;
			numberOfLimpersToRaise = numberRaise;
			numberOfLimpersToCall = numberCall;
			threeBetVsRaisePositionNoBlind = threeBetNoBlind;
			threeBetVsRaisePositionSmallBlind = threeBetSmallBlind;
			threeBetVsRaisePositionNoBlindNoCall = threeBetCallNoBlind;
			threeBetVsRaisePositionSmallBlindnoCall = threeBetCallSmallBlind;
			canCallPositionvsRaiseAndCall = canCall;	
			this.canCap = canCap;
			positionToRaise = posToRaise;
			positionToCall = posToCall;
		}
		
	}
}
