package bot.pokertools;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.utils.Card;
import bot.utils.CardParser;



public class PreFlopChart {
	
	private Hashtable<String, PreFlopInfo> preflopHands;
	private double playPercentage;
	private double variance = 0.05;
	
	public static final int PREFLOP_COMBINATIONS = 169;
	public static final int BUCKETS = 12;
	
	private static final boolean DEBUG = false;

	public double getVariance() {
		return variance;
	}
	
	public void setVariance(double var) {
		variance = var;
	}
	
	public double getRank(Vector<Card> cards) {
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> HandRank of " + cards + " is " + getHandRank(cards) + " -> Rank is " + getRank(getCardString(cards.get(0), cards.get(1))));
		return getRank(getCardString(cards.get(0), cards.get(1)));
	}
	
	public double getRank(String cards) {
//		if (DEBUG) System.out.println(getClass().getSimpleName() + "> HandRank of " + cards + " is " + getHandRank(cards) + " -> Rank is " + getRank(cards));
		int hRank = getHandRank(cards);
		

	
	//  =WENN(A3<($E$2-$H$2)*169;1;WENN((A3>($E$2+$H$2)*169);0;1-(A3-($E$2-$H$2)*169)/(2*$H$2*169)))

		if (hRank < (playPercentage - variance) * PREFLOP_COMBINATIONS)
			return 1;
		else if (hRank > (playPercentage + variance) * PREFLOP_COMBINATIONS)
			return 0.01d;
		else {
			double r = 1 - (hRank - (playPercentage - variance) * PREFLOP_COMBINATIONS)/(2*variance*169);
			return r;
		}
		
	}
	
	public boolean shouldPlay(Vector<Card> cards) {
		int hRank = getHandRank(cards);
		
		int mRank = (int) (playPercentage * PREFLOP_COMBINATIONS);
		
		if (hRank > mRank)
			return false;
		else
			return true;
	}
	
	public boolean shouldPlay(String cards) {
		int hRank = getHandRank(cards);
		
		int mRank = (int) (playPercentage * PREFLOP_COMBINATIONS);
		
		if (hRank > mRank)
			return false;
		else
			return true;
	}
	
	public int getBucket(Vector<Card> cards) {
		int rank = getHandRank(cards);
		
		double combinationsPerBucket = PREFLOP_COMBINATIONS / BUCKETS;
		for (int i=0; i<BUCKETS; i++) {
			if (rank > i*combinationsPerBucket && rank < (i+1)*combinationsPerBucket)
				return i;
		}
		
		return BUCKETS - 1;
	}
	
	public void setPlayPercentage(double val) {
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> PlayPercentage set to " + val);
		playPercentage = val;
	}
	
	public int getHandRank(Vector<Card> cards) {
		PreFlopInfo pfi = preflopHands.get(getCardString(cards.get(0), cards.get(1)));
		
		if (pfi == null)
			return PREFLOP_COMBINATIONS;
		
		return pfi.rank;
	}
	
	public int getHandRank(String cards) {
		PreFlopInfo pfi = preflopHands.get(cards);
		
		if (pfi == null)
			return PREFLOP_COMBINATIONS;
		
		return pfi.rank;
	}
	
	public double getWinPercentage(Vector<Card> cards) {
		PreFlopInfo pfi = preflopHands.get(getCardString(cards.get(0), cards.get(1)));
		
		if (pfi == null)
			return 0;
		
		return pfi.winPercentage;
	}

	public static String getCardString(Card c1, Card c2) {
		if (c1.compareTo(c2) < 0) {
			String out = c1.toString().substring(0,1) + c2.toString().substring(0,1);
			if (c1.getColor() == c2.getColor()) out += "s";
			return out;
		}
		else {
			String out = c2.toString().substring(0,1) + c1.toString().substring(0,1);
			if (c1.getColor() == c2.getColor()) out += "s";
			return out;			
		}
	}
	
	public void printRanks() {
//		Hashtable<Double, String> ranks = new Hashtable<Double, String>();
//		Vector<Double> ranks2 = new Vector<Double>();
//		
//		Enumeration<String> it = preflopHands.keys();
//		while (it.hasMoreElements()) {
//			String tmp = it.nextElement();
//			ranks.put(getRank(tmp), tmp);
//			ranks2.add(getRank(tmp));
//		}
//		
//		
//		Collections.sort(ranks2);
//		
//		int i=169;
//		
//		for (double d : ranks2) {
//			System.out.println(i + ": " + ranks.get(d) + " -> " + d);
//			i--;
//		}
		
		Enumeration<String> it = preflopHands.keys();
		
		while (it.hasMoreElements()) {
			String s = it.nextElement();
			System.out.println(s + ": " + getHandRank(s) + " -> " + getRank(s));
		}
	}
	
	private void initDB() {
		preflopHands = new Hashtable<String, PreFlopInfo>();
		
		preflopHands.put("AA", new PreFlopInfo(0.31,1));
		preflopHands.put("AKs", new PreFlopInfo(0.2019,4));
		preflopHands.put("AQs", new PreFlopInfo(0.1866,6));
		preflopHands.put("AJs", new PreFlopInfo(0.1747,8));
		preflopHands.put("ATs", new PreFlopInfo(0.1663,12));
		preflopHands.put("A9s", new PreFlopInfo(0.146,19));
		preflopHands.put("A8s", new PreFlopInfo(0.1389,24));
		preflopHands.put("A7s", new PreFlopInfo(0.1335,30));
		preflopHands.put("A6s", new PreFlopInfo(0.1297,34));
		preflopHands.put("A5s", new PreFlopInfo(0.1343,28));
		preflopHands.put("A4s", new PreFlopInfo(0.1317,32));
		preflopHands.put("A3s", new PreFlopInfo(0.1307,33));
		preflopHands.put("A2s", new PreFlopInfo(0.1269,39));
		
		preflopHands.put("AK", new PreFlopInfo(0.1667,11));
		preflopHands.put("AQ", new PreFlopInfo(0.1487,18));
		preflopHands.put("AJ", new PreFlopInfo(0.1345,27));
		preflopHands.put("AT", new PreFlopInfo(0.1243,42));
		preflopHands.put("A9", new PreFlopInfo(0.1020,76));
		preflopHands.put("A8", new PreFlopInfo(0.0942,91));
		preflopHands.put("A7", new PreFlopInfo(0.0883,102));
		preflopHands.put("A6", new PreFlopInfo(0.0839,113));
		preflopHands.put("A5", new PreFlopInfo(0.0892,101));
		preflopHands.put("A4", new PreFlopInfo(0.0872,104));
		preflopHands.put("A3", new PreFlopInfo(0.0850,109));
		preflopHands.put("A2", new PreFlopInfo(0.0818,117));
		
		preflopHands.put("KK", new PreFlopInfo(0.2602,2));
		preflopHands.put("KQs", new PreFlopInfo(0.1808,7));
		preflopHands.put("KJs", new PreFlopInfo(0.1705,9));
		preflopHands.put("KTs", new PreFlopInfo(0.1614,14));
		preflopHands.put("K9s", new PreFlopInfo(0.1415,22));
		preflopHands.put("K8s", new PreFlopInfo(0.1277,37));
		preflopHands.put("K7s", new PreFlopInfo(0.1223,44));
		preflopHands.put("K6s", new PreFlopInfo(0.1184,53));
		preflopHands.put("K5s", new PreFlopInfo(0.1157,55));
		preflopHands.put("K4s", new PreFlopInfo(0.1140,58));
		preflopHands.put("K3s", new PreFlopInfo(0.1126,60));
		preflopHands.put("K2s", new PreFlopInfo(0.1127,59));
		
		preflopHands.put("KQ", new PreFlopInfo(0.1443,20));
		preflopHands.put("KJ", new PreFlopInfo(0.1318,31));
		preflopHands.put("KT", new PreFlopInfo(0.1223,45));
		preflopHands.put("K9", new PreFlopInfo(0.0993,81));
		preflopHands.put("K8", new PreFlopInfo(0.0845,112));
		preflopHands.put("K7", new PreFlopInfo(0.0786,122));
		preflopHands.put("K6", new PreFlopInfo(0.0746,125));
		preflopHands.put("K5", new PreFlopInfo(0.0713,128));
		preflopHands.put("K4", new PreFlopInfo(0.0695,132));
		preflopHands.put("K3", new PreFlopInfo(0.0687,133));
		preflopHands.put("K2", new PreFlopInfo(0.0676,135));

		preflopHands.put("QQ", new PreFlopInfo(0.2203,3));
		preflopHands.put("QJs", new PreFlopInfo(0.1658,13));
		preflopHands.put("QTs", new PreFlopInfo(0.1584,15));
		preflopHands.put("Q9s", new PreFlopInfo(0.1382,25));
		preflopHands.put("Q8s", new PreFlopInfo(0.1242,43));
		preflopHands.put("Q7s", new PreFlopInfo(0.1120,61));
		preflopHands.put("Q6s", new PreFlopInfo(0.1085,66));
		preflopHands.put("Q5s", new PreFlopInfo(0.1055,69));
		preflopHands.put("Q4s", new PreFlopInfo(0.1043,71));
		preflopHands.put("Q3s", new PreFlopInfo(0.1042,72));
		preflopHands.put("Q2s", new PreFlopInfo(0.1028,75));
		
		preflopHands.put("QJ", new PreFlopInfo(0.1289,35));
		preflopHands.put("QT", new PreFlopInfo(0.1199,49));
		preflopHands.put("Q9", new PreFlopInfo(0.0981,83));
		preflopHands.put("Q8", new PreFlopInfo(0.0828,115));
		preflopHands.put("Q7", new PreFlopInfo(0.0697,131));
		preflopHands.put("Q6", new PreFlopInfo(0.0658,137));
		preflopHands.put("Q5", new PreFlopInfo(0.0626,141));
		preflopHands.put("Q4", new PreFlopInfo(0.0613,143));
		preflopHands.put("Q3", new PreFlopInfo(0.0605,144));
		preflopHands.put("Q2", new PreFlopInfo(0.0595,146));

		preflopHands.put("JJ", new PreFlopInfo(0.1909,5));
		preflopHands.put("JTs", new PreFlopInfo(0.1578,16));
		preflopHands.put("J9s", new PreFlopInfo(0.1380,26));
		preflopHands.put("J8s", new PreFlopInfo(0.1247,41));
		preflopHands.put("J7s", new PreFlopInfo(0.1112,64));
		preflopHands.put("J6s", new PreFlopInfo(0.1010,79));
		preflopHands.put("J5s", new PreFlopInfo(0.0986,82));
		preflopHands.put("J4s", new PreFlopInfo(0.0973,86));
		preflopHands.put("J3s", new PreFlopInfo(0.0957,87));
		preflopHands.put("J2s", new PreFlopInfo(0.0950,89));
		
		preflopHands.put("JT", new PreFlopInfo(0.1213,47));
		preflopHands.put("J9", new PreFlopInfo(0.0999,80));
		preflopHands.put("J8", new PreFlopInfo(0.0850,108));
		preflopHands.put("J7", new PreFlopInfo(0.0710,129));
		preflopHands.put("J6", new PreFlopInfo(0.0594,147));
		preflopHands.put("J5", new PreFlopInfo(0.0563,149));
		preflopHands.put("J4", new PreFlopInfo(0.0550,152));
		preflopHands.put("J3", new PreFlopInfo(0.0541,153));
		preflopHands.put("J2", new PreFlopInfo(0.0533,155));

		preflopHands.put("TT", new PreFlopInfo(0.1683,10));
		preflopHands.put("T9s", new PreFlopInfo(0.1407,23));
		preflopHands.put("T8s", new PreFlopInfo(0.1273,38));
		preflopHands.put("T7s", new PreFlopInfo(0.1147,57));
		preflopHands.put("T6s", new PreFlopInfo(0.1031,74));
		preflopHands.put("T5s", new PreFlopInfo(0.0923,93));
		preflopHands.put("T4s", new PreFlopInfo(0.0911,95));
		preflopHands.put("T3s", new PreFlopInfo(0.0906,96));
		preflopHands.put("T2s", new PreFlopInfo(0.0897,98));
		
		preflopHands.put("T9", new PreFlopInfo(0.1038,73));
		preflopHands.put("T8", new PreFlopInfo(0.0893,100));
		preflopHands.put("T7", new PreFlopInfo(0.0753,124));
		preflopHands.put("T6", new PreFlopInfo(0.0628,140));
		preflopHands.put("T5", new PreFlopInfo(0.0522,157));
		preflopHands.put("T4", new PreFlopInfo(0.0504,158));
		preflopHands.put("T3", new PreFlopInfo(0.0495,160));
		preflopHands.put("T2", new PreFlopInfo(0.0488,162));

		preflopHands.put("99", new PreFlopInfo(0.1529,17));
		preflopHands.put("98s", new PreFlopInfo(0.1263,40));
		preflopHands.put("97s", new PreFlopInfo(0.1174,54));
		preflopHands.put("96s", new PreFlopInfo(0.1065,68));
		preflopHands.put("95s", new PreFlopInfo(0.0956,88));
		preflopHands.put("94s", new PreFlopInfo(0.0870,106));
		preflopHands.put("93s", new PreFlopInfo(0.0853,107));
		preflopHands.put("92s", new PreFlopInfo(0.0846,111));
		
		preflopHands.put("98", new PreFlopInfo(0.0897,99));
		preflopHands.put("97", new PreFlopInfo(0.0796,119));
		preflopHands.put("96", new PreFlopInfo(0.0677,134));
		preflopHands.put("95", new PreFlopInfo(0.0560,150));
		preflopHands.put("94", new PreFlopInfo(0.0465,164));
		preflopHands.put("93", new PreFlopInfo(0.0451,165));
		preflopHands.put("92", new PreFlopInfo(0.0447,166));
		
		preflopHands.put("88", new PreFlopInfo(0.1416,21));
		preflopHands.put("87s", new PreFlopInfo(0.1202,48));
		preflopHands.put("86s", new PreFlopInfo(0.1116,62));
		preflopHands.put("85s", new PreFlopInfo(0.1012,78));
		preflopHands.put("84s", new PreFlopInfo(0.0914,94));
		preflopHands.put("83s", new PreFlopInfo(0.0823,116));
		preflopHands.put("82s", new PreFlopInfo(0.0811,118));
		
		preflopHands.put("87", new PreFlopInfo(0.0836,114));
		preflopHands.put("86", new PreFlopInfo(0.0740,126));
		preflopHands.put("85", new PreFlopInfo(0.0630,139));
		preflopHands.put("84", new PreFlopInfo(0.0525,156));
		preflopHands.put("83", new PreFlopInfo(0.0433,167));
		preflopHands.put("82", new PreFlopInfo(0.0420,168));

		preflopHands.put("77", new PreFlopInfo(0.1336,29));
		preflopHands.put("76s", new PreFlopInfo(0.1147,56));
		preflopHands.put("75s", new PreFlopInfo(0.1069,67));
		preflopHands.put("74s", new PreFlopInfo(0.0974,85));
		preflopHands.put("73s", new PreFlopInfo(0.0875,103));
		preflopHands.put("72s", new PreFlopInfo(0.0791,120));
		
		preflopHands.put("76", new PreFlopInfo(0.0788,121));
		preflopHands.put("75", new PreFlopInfo(0.0701,130));
		preflopHands.put("74", new PreFlopInfo(0.0596,145));
		preflopHands.put("73", new PreFlopInfo(0.0494,161));
		preflopHands.put("72", new PreFlopInfo(0.0404,169));

		preflopHands.put("66", new PreFlopInfo(0.1277,36));
		preflopHands.put("65s", new PreFlopInfo(0.1113,63));
		preflopHands.put("64s", new PreFlopInfo(0.1044,70));
		preflopHands.put("63s", new PreFlopInfo(0.0949,90));
		preflopHands.put("62s", new PreFlopInfo(0.0848,110));
		
		preflopHands.put("65", new PreFlopInfo(0.0757,123));
		preflopHands.put("64", new PreFlopInfo(0.0675,136));
		preflopHands.put("63", new PreFlopInfo(0.0573,148));
		preflopHands.put("62", new PreFlopInfo(0.0472,163));

		preflopHands.put("55", new PreFlopInfo(0.1215,46));
		preflopHands.put("54s", new PreFlopInfo(0.1090,65));
		preflopHands.put("53s", new PreFlopInfo(0.1018,77));
		preflopHands.put("52s", new PreFlopInfo(0.0925,92));
		
		preflopHands.put("54", new PreFlopInfo(0.0736,127));
		preflopHands.put("53", new PreFlopInfo(0.0657,138));
		preflopHands.put("52", new PreFlopInfo(0.0556,151));
		
		preflopHands.put("44", new PreFlopInfo(0.1194,50));
		preflopHands.put("43s", new PreFlopInfo(0.0981,84));
		preflopHands.put("42s", new PreFlopInfo(0.0902,97));
		
		preflopHands.put("43", new PreFlopInfo(0.0617,142));
		preflopHands.put("42", new PreFlopInfo(0.0540,154));
		
		preflopHands.put("33", new PreFlopInfo(0.1193,51));
		preflopHands.put("32s", new PreFlopInfo(0.0870,105));
		
		preflopHands.put("32", new PreFlopInfo(0.0502,159));
		
		preflopHands.put("22", new PreFlopInfo(0.1186,52));
		
	
	}
	
	public PreFlopChart() {
		playPercentage = 0.2;
		initDB();
	}
	
	private class PreFlopInfo {
		public double winPercentage;
		public int rank;
		
		public PreFlopInfo(double winPercentage, int rank) {
			this.winPercentage = winPercentage;
			this.rank = rank;
		}
	}
	


}
