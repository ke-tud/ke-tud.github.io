package bot.pokertools;

import java.util.Vector;

import bot.utils.Card;



public class PreFlopChart2{

	public static double getRank(Vector<Card> cards) {
		
		
		Card card1 = cards.get(0);
		Card card2 = cards.get(1);
		
		int maxnumber = 2*Card.NA;
		int minnumber = 2*Card.N2;
			
		int number = card1.getNumber() + card2.getNumber();
			
		double rank = (number-minnumber)/(double)maxnumber;
		
		if (card1.getColor() == card2.getColor())
			rank *= 1.1;
		if (card1.getNumber() == card2.getNumber())
			rank *= 1.5;
		
		rank = Math.max(0, Math.min(1, rank));	
		
//		System.out.println("Number: " + number + " Rank: " + rank);
			
		return rank;
		
		
	
}

	public PreFlopChart2() {

	}


}
