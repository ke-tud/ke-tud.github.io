/*
 * RandomPokerClient.java
 *
 * Created on April 19, 2006, 2:04 PM
 */

package bot;


import java.io.*;
import java.net.*;
import java.util.Vector;

import bot.learner.LearnerTools;
import bot.pokertools.PreFlopChart;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class MatchStateBot extends PokerClient {
	
	private GameSituation publicState;
	private GameStatistics stats;
	private static final boolean DEBUG = true;
	
	
    
    public void handleStateChange() throws IOException, SocketException{
    	long time = System.currentTimeMillis();
    	
    	System.out.print(getClass().getSimpleName() + "> ");
    	publicState.updateSituation(currentGameStateString);
    	System.out.print(LearnerTools.getActionBucket(publicState, GameSituation.STATE_PREFLOP) + " " + LearnerTools.getAction(publicState, GameSituation.STATE_FLOP) + " " + LearnerTools.getAction(publicState, GameSituation.STATE_TURN) + " " + LearnerTools.getAction(publicState, GameSituation.STATE_RIVER));
    	System.out.println("  --  " + LearnerTools.getRaisesPercentage(publicState));
    	
    	
    	sendCall();
    	
//    	if (DEBUG) System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + " ms taken.");    	


    }

    
    public MatchStateBot(){
      super();
      publicState = new GameSituation();
      stats = new GameStatistics();
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        MatchStateBot rpc = new MatchStateBot();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
    
}
