package bot.extern;

import bot.pokertools.PreFlopChart;

public class PreFlopStatic {
	
	public static void main(String args[]) {
		int players = Integer.parseInt(args[0]);
		
		PreFlopChart pfc = new PreFlopChart();
		pfc.setPlayPercentage(((double) 1 / (double) players)*1.2);
		
//		Card c1 = CardParser.parseCard(args[1]);
//		Card c2 = CardParser.parseCard(args[2]);
//		
//		Vector<Card> c = new Vector<Card>();
//		c.add(c1);
//		c.add(c2);
		
		int hR = pfc.getHandRank(args[1]);
		boolean s = pfc.shouldPlay(args[1]);
		double r = pfc.getRank(args[1]);
		
		System.out.println("Cards: " + args[1] + " -> HandRank: " + hR + " Rank: " + r + " Should: " + s);
	}


}
