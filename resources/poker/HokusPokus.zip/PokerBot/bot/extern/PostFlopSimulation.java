package bot.extern;

import java.util.Vector;

import bot.utils.Card;
import bot.utils.CardParser;
import bot.utils.ShowdownSimulator;

public class PostFlopSimulation {
	
	public static void main(String args[]) {
		int players = Integer.parseInt(args[0]);
		
//		PreFlopChart pfc = new PreFlopChart();
//		pfc.setPlayPercentage(((double) 1 / (double) players)*1.2);
		
		Card c1 = CardParser.parseCard(args[1].substring(0, 2));
		Card c2 = CardParser.parseCard(args[1].substring(2, 4));
		
		Vector<Card> myC = new Vector<Card>();
		myC.add(c1);
		myC.add(c2);
		
		Card cb1 = CardParser.parseCard(args[2].substring(0, 2));
		Card cb2 = CardParser.parseCard(args[2].substring(2, 4));
		Card cb3 = CardParser.parseCard(args[2].substring(4, 6));

		if (args[2].length() > 6) {
			
		}
		
		Vector<Card> bC = new Vector<Card>();
		bC.add(cb1);
		bC.add(cb2);
		bC.add(cb3);
		
		if (args[2].length() > 6) {
			Card cb4 = CardParser.parseCard(args[2].substring(6, 8));
			bC.add(cb4);
		}
		if (args[2].length() > 8) {
			Card cb5 = CardParser.parseCard(args[2].substring(8, 10));
			bC.add(cb5);
		}
		
		ShowdownSimulator ss = new ShowdownSimulator(players, myC, bC);
		ss.runSimulations(5000, true);

		
		System.out.println("MyCards: " + myC + ", BoardCards: " + bC);
		System.out.println("Win: " + ss.getWinPercentage() + " Tie: " + ss.getTiePercentage() + " Loose: " + ss.getLoosePercentage());
		
	}


}
