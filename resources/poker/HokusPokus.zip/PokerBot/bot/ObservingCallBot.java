/*
	Beobachtet wie die anderen Bots spielen; erstellt also ein Opponent Modell von diesen. 
	Beachtet das aber nicht sondern called die ganze Zeit.
*/

package bot;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.security.SecureRandom;
import java.util.Vector;

import ca.ualberta.cs.poker.free.client.PokerClient;

import bot.opponent.SituationStoreController;
import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;

public class ObservingCallBot extends PokerClient{

	private GameSituation publicState;
	private SituationStoreController situtationStoreController;
	private int counter = 0;
	SecureRandom random = new SecureRandom();
	
	public void handleStateChange() throws IOException, SocketException{
    	long time = System.currentTimeMillis();
    	
    	publicState.updateSituation(currentGameStateString);
    	
        if (publicState.isHandFinished()) {
        	situtationStoreController.addObservation(publicState);
        	counter++;
        }
        if(counter == 1000) {
        	counter = 0;
        	Vector<Player>  players = publicState.getPlayers();
        	for(Player p : players) {
        		System.out.println("Statistiken für Spieler:");
        		System.out.println(p.getName());
        		System.out.print("Fold b2C = 0 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 0, 2, 2, 0));
        		System.out.print("Call b2C = 0 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 0, 2, 2, 1));
        		System.out.print("Raise b2C = 0 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 0, 2, 2, 2));
        		System.out.print("Fold b2C = 1 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 1, 2, 2, 0));
        		System.out.print("Call b2C = 1 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 1, 2, 2, 1));
        		System.out.print("Raise b2C = 1 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 1, 2, 2, 2));
        		System.out.print("Fold b2C > 1 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 2, 2, 2, 0));
        		System.out.print("Call b2C > 1 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 2, 2, 2, 1));
        		System.out.print("Raise b2C > 1 PreFlop -> ");
        		System.out.println(p.getSituationStore().getFrequency(0, 2, 2, 2, 2));
        		
        		
        		
        		System.out.print("Fold b2C = 0 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 0, 2, 2, 0));
        		System.out.print("Call b2C = 0 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 0, 2, 2, 1));
        		System.out.print("Raise b2C = 0 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 0, 2, 2, 2));
        		System.out.print("Fold b2C = 1 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 1, 2, 2, 0));
        		System.out.print("Call b2C = 1 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 1, 2, 2, 1));
        		System.out.print("Raise b2C = 1 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 1, 2, 2, 2));
        		System.out.print("Fold b2C > 1 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 2, 2, 2, 0));
        		System.out.print("Call b2C > 1 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 2, 2, 2, 1));
        		System.out.print("Raise b2C > 1 Flop -> ");
        		System.out.println(p.getSituationStore().getFrequency(1, 2, 2, 2, 2));
        		
        		
        		System.out.print("Fold b2C = 0 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 0, 2, 2, 0));
        		System.out.print("Call b2C = 0 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 0, 2, 2, 1));
        		System.out.print("Raise b2C = 0 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 0, 2, 2, 2));
        		System.out.print("Fold b2C = 1 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 1, 2, 2, 0));
        		System.out.print("Call b2C = 1 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 1, 2, 2, 1));
        		System.out.print("Raise b2C = 1 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 1, 2, 2, 2));
        		System.out.print("Fold b2C = 2 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 2, 2, 2, 0));
        		System.out.print("Call b2C = 2 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 2, 2, 2, 1));
        		System.out.print("Raise b2C = 2 Turn -> ");
        		System.out.println(p.getSituationStore().getFrequency(2, 2, 2, 2, 2));
        		
        		
        		
        		System.out.print("Fold b2C = 0 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 0, 2, 2, 0));
        		System.out.print("Call b2C = 0 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 0, 2, 2, 1));
        		System.out.print("Raise b2C = 0 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 0, 2, 2, 2));
        		System.out.print("Fold b2C = 1 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 1, 2, 2, 0));
        		System.out.print("Call b2C = 1 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 1, 2, 2, 1));
        		System.out.print("Raise b2C = 1 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 1, 2, 2, 2));
        		System.out.print("Fold b2C = 2 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 2, 2, 2, 0));
        		System.out.print("Call b2C = 2 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 2, 2, 2, 1));
        		System.out.print("Raise b2C = 2 River -> ");
        		System.out.println(p.getSituationStore().getFrequency(3, 2, 2, 2, 2));
        	} 	
        }
        
        if(publicState.getState() == 0) {
        	double dart = random.nextDouble();
        	if(changeAmountToCall(publicState.getAmountToCall()) == 0) {
        		if (dart<0.20){
                    sendFold();
                } else if (dart<0.60){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else if(changeAmountToCall(publicState.getAmountToCall()) == 1) {
        		if (dart<0.40){
                    sendFold();
                } else if (dart<0.70){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else {
        		if (dart<0.80){
                    sendFold();
                } else if (dart<0.90){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        }
        else if(publicState.getState() == 1) {
        	double dart = random.nextDouble();
        	if(changeAmountToCall(publicState.getAmountToCall()) == 0) {
        		if (dart<0.00){
                    sendFold();
                } else if (dart<0.60){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else if(changeAmountToCall(publicState.getAmountToCall()) == 1) {
        		if (dart<0.35){
                    sendFold();
                } else if (dart<0.70){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else {
        		if (dart<0.60){
                    sendFold();
                } else if (dart<0.80){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        }
        else if(publicState.getState() == 2) {
        	double dart = random.nextDouble();
        	if(changeAmountToCall(publicState.getAmountToCall()) == 0) {
        		if (dart<0.00){
                    sendFold();
                } else if (dart<0.30){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else if(changeAmountToCall(publicState.getAmountToCall()) == 1) {
        		if (dart<0.10){
                    sendFold();
                } else if (dart<0.60){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else {
        		if (dart< 2){
                    sendFold();
                } else if (dart<0.80){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        }
        else {
        	double dart = random.nextDouble();
        	if(changeAmountToCall(publicState.getAmountToCall()) == 0) {
        		if (dart<0.00){
                    sendFold();
                } else if (dart<0.90){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else if(changeAmountToCall(publicState.getAmountToCall()) == 1) {
        		if (dart<0.60){
                    sendFold();
                } else if (dart<0.70){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        	else {
        		if (dart< 2){
                    sendFold();
                } else if (dart<0.90){
                    sendCall();
                } else {
                    sendRaise();
                }
        	}
        }
        
    }
	
	private int changeAmountToCall(int amount) {
		if(publicState.getState() <= GameSituation.STATE_FLOP) return amount/2;
		else return amount/4;
	}
	
	
	public static void printPlayerStat(Player p) {
		System.out.println("Statistiken für Spieler " + p + ":");
		System.out.println(p.getName());
		System.out.print("Fold insgesamt PreFlop -> ");
		System.out.println(p.getSituationStore().getFrequency(0, 0, 0, 0, 0));
		System.out.print("Call insgesamt PreFlop -> ");
		System.out.println(p.getSituationStore().getFrequency(0, 0, 0, 0, 1));
		System.out.print("Raise insgesamt PreFlop -> ");
		System.out.println(p.getSituationStore().getFrequency(0, 0, 0, 0, 2));
		System.out.print("Fold insgesamt Flop -> ");
		System.out.println(p.getSituationStore().getFrequency(1, 0, 0, 0, 0));
		System.out.print("Call insgesamt Flop -> ");
		System.out.println(p.getSituationStore().getFrequency(1, 0, 0, 0, 1));
		System.out.print("Raise insgesamt Flop -> ");
		System.out.println(p.getSituationStore().getFrequency(1, 0, 0, 0, 2));
		System.out.print("Fold insgesamt Turn -> ");
		System.out.println(p.getSituationStore().getFrequency(2, 0, 0, 0, 0));
		System.out.print("Call insgesamt Turn -> ");
		System.out.println(p.getSituationStore().getFrequency(2, 0, 0, 0, 1));
		System.out.print("Raise insgesamt Turn -> ");
		System.out.println(p.getSituationStore().getFrequency(2, 0, 0, 0, 2));
		System.out.print("Fold insgesamt River -> ");
		System.out.println(p.getSituationStore().getFrequency(3, 0, 0, 0, 0));
		System.out.print("Call insgesamt River -> ");
		System.out.println(p.getSituationStore().getFrequency(3, 0, 0, 0, 1));
		System.out.print("Raise insgesamt River -> ");
		System.out.println(p.getSituationStore().getFrequency(3, 0, 0, 0, 2));

	}
	
	
	public ObservingCallBot() {
	    super();
	    publicState = new GameSituation();
	    situtationStoreController = new SituationStoreController();
	}
	    
    /**
     * @param args the command line parameters (IP and port)
     */
	public static void main(String[] args) throws Exception {
	    ObservingCallBot rpc = new ObservingCallBot();
	    System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

	    rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
	    System.out.println("Successful connection!");
	    rpc.run();
	}
}
