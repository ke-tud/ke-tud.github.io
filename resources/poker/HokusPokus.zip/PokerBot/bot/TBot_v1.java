/*
 * TBot v1: spielt PreFlop nach PreflopChart, PostFlop nur wenn er was hat
 */

package bot;


import java.io.*;


import java.net.*;
import java.util.Vector;

import bot.learner.LearnerTools;
import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.GameSituation;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class TBot_v1 extends PokerClient {
	
	private GameSituation publicState;
	private PreFlopChart preFlopChart;
	private static final boolean DEBUG = true;
    
    public void handleStateChange() throws IOException, SocketException{
    	long time = System.currentTimeMillis();
    	
    	publicState.updateSituation(currentGameStateString);
    	
        if (publicState.isHandFinished()) {
        	if (publicState.cameToShowDown())
        		System.out.println("Hand " + publicState.getRound() + " finished -> Showdown, Board: " + publicState.getBoardCards() + " played Cards: " + publicState.getPlayerCards() + " => Winners: " + publicState.getWinners());
        	else
        		System.out.println("Hand " + publicState.getRound() + " finished -> Betting Winner: " + publicState.getWinners());
        	
//        	System.out.println("-- (" + currentGameStateString + ")");
        }
        
    	
        
        if (publicState.getPlayerCount() == 2)
        	preFlopChart.setPlayPercentage(0.6);
    	
        
        Vector<Card> myCards = publicState.getOwnCards();
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
        	boolean should = preFlopChart.shouldPlay(myCards);
        	
        	if (DEBUG) System.out.print("PREFLOP: " + myCards + " -> ");
        	if(should){
        		if (DEBUG) System.out.println("RAISE");
        		sendRaise();
        	}
        	else {
        		if (DEBUG) System.out.println("FOLD");
        		sendFold();
        	}
    	}
    	
    	else {
        	myCards.addAll(publicState.getBoardCards());

    		Combination c = Analyzer.test(myCards);
    		if (DEBUG) System.out.print("POSTFLOP: " + c + " -> ");
    		if (LearnerTools.getCombinationBucket(c) == 0) {
    			if (publicState.getPlayerCount() == 2 && ((Highest)c).getCards()[0].getNumber() >= Card.NJ) {
    				if (DEBUG) System.out.println("CALL");
            		sendCall();
    			}
    			else {
    				if (DEBUG) System.out.println("FOLD");
        			sendFold();
    			}
    		}
    		else if (LearnerTools.getCombinationBucket(c) == 1) {
    			if (publicState.getPlayerCount() == 2)
    				sendCall();
    			sendFold();
    		}
    		else if (LearnerTools.getCombinationBucket(c) == 2) {
    			if (publicState.getPlayerCount() == 2)
    				sendRaise();
    			sendCall();
    		}
    		else {
    			if (DEBUG) System.out.println("RAISE");
    			sendRaise();
    		}
    	}

    	//System.out.println("TBot> " + (System.currentTimeMillis() - time) + " ms taken.");

    }

    
    public TBot_v1(){
      super();
      publicState = new GameSituation();
      preFlopChart = new PreFlopChart();
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        TBot_v1 rpc = new TBot_v1();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
    
}
