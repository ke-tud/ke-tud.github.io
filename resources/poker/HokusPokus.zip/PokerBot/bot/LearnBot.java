/*
 * RandomPokerClient.java
 *
 * Created on April 19, 2006, 2:04 PM
 */

package bot;


import java.io.*;
import java.net.*;
import java.util.Vector;

import bot.learner.LearnModule;
import bot.learner.LearnModule_PostFlop;
import bot.learner.LearnModule_PreFlop;
import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class LearnBot extends PokerClient {
	
	private GameSituation publicState;
	private PreFlopChart preFlopChart;
	private LearnModule preFlopLearner;
	private LearnModule postFlopLearner;
	private static final boolean DEBUG = true;
	
	private static final boolean PREFLOP_ACTIVE = true;
	private static final boolean POSTFLOP_ACTIVE = true;
	
    
    public void handleStateChange() throws IOException, SocketException{
    	long time = System.currentTimeMillis();
    	
    	publicState.updateSituation(currentGameStateString);

    	if (publicState.isHandFinished())
    		System.out.println(publicState);
    	
    	if (publicState.getRound() == Config.ROUNDTOPRINT && publicState.isHandFinished()) {
    		if (PREFLOP_ACTIVE) preFlopLearner.printState();
    		if (POSTFLOP_ACTIVE) postFlopLearner.printState();
    	}
    	
		// Lernen
        if (publicState.isHandFinished()) {
        	
//        	boolean outcome = publicState.haveIWon();
//        	int cardBucket = preFlopChart.getBucket(publicState.getOwnCards());
//        	int position = publicState.getPosition();
        	
//        	PreFlopInstance i = new PreFlopInstance(cardBucket, position, outcome);
        	if (publicState.getRound() <= Config.ROUNDSTOLEARN)
        		preFlopLearner.learn(publicState);
        	
        	if (publicState.cameToShowDown()) {			
//				FullCombo fc = new FullCombo(publicState.getOwnCards().toArray(new Card[1]), publicState.getBoardCards().toArray(new Card[1]));
//				Combination comb = fc.getBestCombo();
//				int combBucket = PostFlopBayesianLearner.getCombinationBucket(comb);
//            	int actionBucket = PostFlopBayesianLearner.getActionBucket(publicState.getActions()); 

				if (publicState.getRound() <= Config.ROUNDSTOLEARN)
					postFlopLearner.learn(publicState);

        	}
        	
        }

        
        
        // Spielen    	
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
 
    		// Am Anfang Call, nur Lernen
        	if (publicState.getRound() <= Config.ROUNDSTOLEARN || !PREFLOP_ACTIVE) {
        		sendCall();
        	}
        	else {
//            	int cardBucket = preFlopChart.getBucket(publicState.getOwnCards());
//            	int position = publicState.getPosition();
//            	
//            	PreFlopInstance i = new PreFlopInstance(cardBucket, position);

//        		boolean good = preFlopLearner.classify(i);
//        		if (good) sendRaise();
//        		else sendFold();
            	
            	double rank = preFlopLearner.rankSituation(publicState);
            	double rand = Math.random();
            	if (rand < rank)
            		sendRaise();
            	else
            		sendFold(); //sendCall();
        	}
    	}
    	else {
    		// Am Anfang Call, nur Lernen
        	if (publicState.getRound() <= Config.ROUNDSTOLEARN || !POSTFLOP_ACTIVE) {
        		sendCall();
        	}
        	else {
//				FullCombo fc = new FullCombo(publicState.getOwnCards().toArray(new Card[1]), publicState.getBoardCards().toArray(new Card[1]));
//				Combination comb = fc.getBestCombo();
//				int combBucket = PostFlopBayesianLearner.getCombinationBucket(comb);
//            	int actionBucket = PostFlopBayesianLearner.getActionBucket(publicState.getActions()); 

            	
//            	PostFlopInstance i = new PostFlopInstance(combBucket);

//        		boolean good = postFlopLearner.classify(i);
//        		if (good) sendRaise();
//        		else sendFold();
        		
            	double rank = postFlopLearner.rankSituation(publicState);
            	double rand = Math.random();
            	if (rand < rank)
            		sendRaise();
            	else
            		sendFold(); //sendCall();
        	}
    		
    	}
    	
    	if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + " ms taken.");    	


    }

    
    public LearnBot(){
      super();
      publicState = new GameSituation();
      preFlopChart = new PreFlopChart();
      preFlopLearner = new LearnModule_PreFlop("preflop");
      postFlopLearner = new LearnModule_PostFlop("postflop");
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        LearnBot rpc = new LearnBot();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
    
}
