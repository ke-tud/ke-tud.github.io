package bot;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import bot.pokertools.PreFlopChartPS;
import bot.utils.GameAction;
import bot.utils.GameSituation;

public class B2BotPS extends B2Bot {
	
	PreFlopChartPS pChartPS;
	
	public B2BotPS() {
		super();
		pChartPS = new PreFlopChartPS();
	}
	
	public void getDecision() throws IOException, SocketException{
		
		if (publicState.getState() == GameSituation.STATE_PREFLOP) {
			int action = pChartPS.getAction(publicState.getOwnCards(), publicState);
			System.out.println(getClass().getSimpleName() + "> Playing PS Chart...");
			if(action == GameAction.ACTION_FOLD) {
    			sendFold();
    		}
    		else if(action == GameAction.ACTION_CALL) {
    			sendCall();
    		}
    		else if(action == GameAction.ACTION_RAISE) {
    			sendRaise();
    		}
		}
		else {
			super.getDecision();
		}
		
	}
	
    public static void main(String[] args) throws Exception{
        B2BotPS rpc = new B2BotPS();
//        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
//        System.out.println("Successful connection!");
        rpc.run();
    }

}
