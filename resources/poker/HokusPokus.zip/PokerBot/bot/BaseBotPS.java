package bot;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import bot.pokertools.PreFlopChartPS;
import bot.utils.GameAction;
import bot.utils.GameSituation;

public class BaseBotPS extends BaseBot {
	
	PreFlopChartPS pChartPS;
	
	public BaseBotPS() {
		super();
		pChartPS = new PreFlopChartPS();
	}
	
	public void getDecision() throws IOException, SocketException{
		
		if (publicState.getState() == GameSituation.STATE_PREFLOP) {
			int action = pChartPS.getAction(publicState.getOwnCards(), publicState);
    		if(action == GameAction.ACTION_FOLD) {
    			sendFold();
    		}
    		else if(action == GameAction.ACTION_CALL) {
    			sendCall();
    		}
    		else if(action == GameAction.ACTION_RAISE) {
    			sendRaise();
    		}
		}
		else {
			super.getDecision();
		}
		
	}
	
    public static void main(String[] args) throws Exception{
        BaseBotPS rpc = new BaseBotPS();
//        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
//        System.out.println("Successful connection!");
        rpc.run();
    }

}
