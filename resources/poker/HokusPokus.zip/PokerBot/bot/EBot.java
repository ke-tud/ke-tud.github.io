package bot;


import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


import bot.learner.LearnModule;
import bot.learner.LearnModule_PostFlop;
import bot.learner.LearnModule_PostFlop2;
import bot.learner.LearnModule_PreFlop;
import bot.opponent.HandSorter;
import bot.opponent.HandStrength;
import bot.opponent.OutsCalculator;
import bot.opponent.SituationStoreController;
import bot.pokertools.PreFlopChart;
import bot.pokertools.PreFlopChartPS;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.ShowdownSimulator;
import bot.utils.ShowdownSimulatorUseBetsToCall;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class EBot extends PokerClient {
	
	protected GameSituation publicState;
	protected PreFlopChart preFlopChart;
	protected PreFlopChartPS pChartPS;
	protected Hashtable<String, LearnModule> learners;
	protected Hashtable<String, Double> learnerWeights;
	protected int folds, calls, raises; 
	protected ShowdownSimulator sim;
//	protected ShowdownSimulatorUseBetsToCall sim;
	protected SituationStoreController sitStoreController;
	
	protected HandStrength hs;
	protected OutsCalculator outsC;
	protected HandSorter handSorter;

	protected HRThread hrThread;
	
	
	
	protected int wins = 0;
	protected long time = 0;
	
	protected boolean bluffing;

	
	protected static final boolean DEBUG = true;
	protected static final double AGRESSIVE_FACTOR = 1.3;
	protected static final double BLUFF_PERCENTAGE = 0.002;
	protected static int EXPONENT = 2;

	protected int roundsToPlay = 3000;
	
	protected double learnerValue;
	protected double learnerRank;
	protected double chartRank;
	protected double simValue;
	protected double simRank;
	protected double potOdds;
	
	
	// Alles, was mit Lernern zu tun hat
	// ----------------------------------------------------------------------
	
	protected void learn() {
		Enumeration<LearnModule> it = learners.elements();
		while (it.hasMoreElements()) {
			LearnModule tmp = it.nextElement();
//			System.out.println("# learning " + tmp);
			tmp.learn(publicState);
		}
	}
	
	protected double getLearnerDecision(String learner) {
		try {
			if (!learners.containsKey(learner))
				return -1;
			
			else
				return learners.get(learner).rankSituation(publicState);
		}
		catch (Exception e) {
			System.err.println(getClass().getSimpleName() + "> " + " " + e);
			e.printStackTrace();
			return 0;
		}
	}

	protected double getLearnerDecision() {
		Enumeration<String> l = learners.keys();
		double maxWeight = 0;
		double sumDecision = 0;
		
		if (DEBUG) System.out.print(getClass().getSimpleName() + "> Learner: ");
		
		while (l.hasMoreElements()) {
			String thisL = l.nextElement();
			
			double weight = learnerWeights.get(thisL);
			double lD = (weight != 0) ? getLearnerDecision(thisL) : 0;
			
			if (DEBUG) System.out.print(thisL + "(" + weight + ")" + "=" + round(lD) + " ");
			
			sumDecision += lD * weight;
			maxWeight += weight;
		}
		
		
		
		if (DEBUG) System.out.println(" -> learner=" + round(sumDecision / maxWeight) + " (rank=" + round(valToRank(sumDecision / maxWeight, publicState.getPlayersInHand(), EXPONENT)) + ")");
		
		return sumDecision / maxWeight;
	}
	
	protected void initLearners() {
		learners = new Hashtable<String, LearnModule>();
		learnerWeights = new Hashtable<String, Double>();
		
		registerLearner(new LearnModule_PreFlop("preflop"));
		registerLearner(new LearnModule_PostFlop2("postflop"));
		
		printLearnerState();
	}
	
	protected void closeLearners() {
		Enumeration<String> it = learners.keys();
		while (it.hasMoreElements()) {
			String l = it.nextElement();
			learners.get(l).writeLearner();
		}
	}
	
	protected void registerLearner(LearnModule lm) {
		learners.put(lm.getName(), lm); learnerWeights.put(lm.getName(), 1d);
//		lm.readLearner();
	}

	protected void setLearnersWeight(String learner, double weight) {
		learnerWeights.put(learner, weight);
	}
	
	protected void printLearnerState() {
		Enumeration<String> it = learners.keys();
		while (it.hasMoreElements()) {
			String learner = it.nextElement();
			System.out.println(getClass().getSimpleName() + "> State for " + learner + ":");
			learners.get(learner).printState();
		}
	}

	protected void adjustLearnerWeights() {
	   	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
    		setLearnersWeight("preflop", 1);
    		setLearnersWeight("postflop", 0);
    	}
    	else if (publicState.getState() == GameSituation.STATE_FLOP) {
    		setLearnersWeight("preflop", 1);
    		setLearnersWeight("postflop", 3);
    	}
    	else if (publicState.getState() == GameSituation.STATE_TURN) {
    		setLearnersWeight("preflop", 1);
    		setLearnersWeight("postflop", 5);
    	}
    	else if (publicState.getState() == GameSituation.STATE_RIVER) {
    		setLearnersWeight("preflop", 1);
    		setLearnersWeight("postflop", 7);
    	}
    	else {
    		System.err.println(getClass().getSimpleName() + "> ERROR: Ungültiger State: " + publicState.getState());
    	}
 
	}
	
	
	// Simulationen
	public void runSimulations(int betsToCallFromLastAction) {
//		sim.reInit(publicState.getPlayersInHand(), publicState.getOwnCards(), publicState.getBoardCards(), betsToCallFromLastAction);
		sim.reInit(publicState.getPlayersInHand(), publicState.getOwnCards(), publicState.getBoardCards());
		
//		sim.setGameSituation(publicState);
		
		// Simulator Opponent Model beibringen
		if (publicState.getRound() > Config.ROUND_USE_OPPONENTMODEL) {
			
			if(DEBUG) System.out.println(getClass().getSimpleName() + "> Use Opponent Model for Simulation.");
			int j=0;
			for (int i=0; i<publicState.getPlayerCount(); i++) {
				if (publicState.isPlayerInGame(publicState.getPlayers().get(i)) && i != publicState.getPosition()) {
					sim.setPlayerSituationStore(j, publicState.getPlayers().get(i).getSituationStore());
//					sim.setPlayerCardRange(j, publicState.getPlayers().get(i).getHandRange().getHandrange());
					j++;
				}
			}
		}
	
		sim.runSimulations(Config.NUM_SIMULATIONS, true);

	}
	
	public void handleStateChange() throws IOException, SocketException {
    	long time = System.currentTimeMillis();
    	
    	if (publicState.isNewRound(currentGameStateString)) {
    		handleNewRound();
    	}
    	

    	
    	publicState.updateSituation(currentGameStateString);
    	
    	// TODO Statisch
    	roundsToPlay = (publicState.getPlayerCount() == 6) ? 1000 : 3000;
    	
    	// TODO weg
//    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
//    		if (publicState != null && publicState.getPlayers() != null) {
//    	    	for (int i=0; i<publicState.getPlayers().size(); i++) {
//    	    		if (i != publicState.getPosition())
//    	    			sim.normalize(publicState.getPlayers().get(i).getHandRange().getHandrange());
//    	    	}
//    		}
//
//    	}
    	
    	if (publicState.getRound() >= Config.ROUND_USE_OPPONENTMODEL) {
//    		hrThread = new HRThread();
//    		hrThread.start();
//    		while (!hrThread.isFinished()) {
//    			try { wait(100); System.out.println("Thread not ready."); }
//    			catch (Exception e) { e.printStackTrace(); }
//    		}
    		handleHandRanges();
    	}



    	if (publicState.isHandFinished()) {
    		handleHandFinished();

    	}
    	
    	if (publicState.getRound() < Config.ROUNDSTOLEARN && publicState.isHandFinished()) {
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> Learning..."); 
    		learn();
    	}
    	
    	if (publicState.getRound() == Config.ROUNDTOPRINT && publicState.isHandFinished())
    		printLearnerState();
    	
    	if (publicState.amIOnMove()) {
    		String cBString = (publicState.getBoardCards().size() > 0) ? " " + publicState.getBoardCards() : "";
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> --- Decision on " + GameAction.getSituationString(publicState.getState()) + " (Cards: " + publicState.getOwnCards() + cBString +  ") ---"); 
    		if (bluffing) {
    			doBluff();
    		}
    		else {
    			prepareDecision();
    			getDecision();
    		}
    	}


    	
    	if (publicState.amIOnMove()) {
    		this.time += System.currentTimeMillis() - time;
        	if (DEBUG) System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + " ms taken.");    	
    	}

    	if (publicState.getRound() == roundsToPlay - 1 && publicState.isHandFinished()) {
//    		closeLearners();
    		
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Folds: " + folds + " Calls: " + calls + " Raises: " + raises + " - " + round(this.time / roundsToPlay) + "ms taken on average.");
    		
    	}

	}
	
	public void handleHandRanges() {
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Handle Hand Ranges.");

		if (!publicState.isPlayerInGame(publicState.getMyPlayer()))
			return;
		
        if(publicState.getState() == GameSituation.STATE_PREFLOP) {
        	if(publicState.isPlayerInGame(publicState.getPlayers().get(publicState.getPosition()))) {
//	        	System.out.println("PREFLOP!");
	        	//System.out.println("PreFlop");
	        	//PreFlopRanges für den Spieler erzeugen, der gerade was gemacht hat
	        	Vector<GameAction> actions = publicState.getActions();
	        	Player tempPlayer; 
	        	if(actions != null && actions.size() > 0) {
	        		tempPlayer = actions.lastElement().getPlayer();
	        		if(actions.lastElement().getType() != GameAction.ACTION_FOLD) {
	        			tempPlayer.getHandRange().weigthPreFlopHandRange(tempPlayer.getSituationStore().getFrequency(0, changeAmountToCall(publicState.getAmountToCallFromPlayer(tempPlayer)), playerMadePreviousBet(tempPlayer), playerPreviousAmountToCall(tempPlayer), GameAction.ACTION_RAISE), tempPlayer.getSituationStore().getFrequency(0, changeAmountToCall(publicState.getAmountToCallFromPlayer(tempPlayer)), playerMadePreviousBet(tempPlayer), playerPreviousAmountToCall(tempPlayer), GameAction.ACTION_CALL), publicState.getOwnCards(), actions.lastElement().getType());
//	        			tempPlayer.getHandRange().weigthPreFlopHandRange(0.3f, 0.2f, publicState.getOwnCards(), actions.lastElement().getType());
	        		}
	        	}
        	}
        }
        else {
        	if(publicState.isPlayerInGame(publicState.getPlayers().get(publicState.getPosition()))) {
//	        	System.out.println("POSTFLOP!");
	        	if(publicState.getActionsInRound(publicState.getState()).size() == 0) {
//	        		System.out.println("DES GEHT!! " + publicState.getRound() + " " + publicState.getSituationString());
	        		
	        		long time = System.currentTimeMillis();
	        		handSorter.initCombinations(publicState.getBoardCards()); 
	        		System.out.println(getClass().getSimpleName() + "> Initing Handrange (" + (System.currentTimeMillis() - time) + "ms).");
	        		
//	        		System.out.println(handSorter.getHandRange());
	        	}
	        	
	        	Vector<GameAction> actions = publicState.getActions();
	        	Player tempPlayer; 
	        	
	        	if(actions != null && actions.size() > 0) {
	        		tempPlayer = actions.lastElement().getPlayer();
	        		if(actions.lastElement().getType() != GameAction.ACTION_FOLD) {
//	        			tempPlayer.getHandRange().weigthPostFlopHandRange(0.3f, 0.2f, publicState.getOwnCards(), actions.lastElement().getType(), handSorter.getHandRange());
	        			tempPlayer.getHandRange().weigthPostFlopHandRange(tempPlayer.getSituationStore().getFrequency(0, changeAmountToCall(publicState.getAmountToCallFromPlayer(tempPlayer)), playerMadePreviousBet(tempPlayer), playerPreviousAmountToCall(tempPlayer), GameAction.ACTION_RAISE), tempPlayer.getSituationStore().getFrequency(0, changeAmountToCall(publicState.getAmountToCallFromPlayer(tempPlayer)), playerMadePreviousBet(tempPlayer), playerPreviousAmountToCall(tempPlayer), GameAction.ACTION_CALL), publicState.getOwnCards(), actions.lastElement().getType(), handSorter.getHandRange());
	        		}
	        	}
	        }	
       	}
        
//        for (Player p : publicState.getPlayers()) {
//        	System.out.println(p.getHandRange().getHandrange());
//        }

	}
  
	public void prepareDecision() {
    	adjustLearnerWeights();
    	
    	learnerValue = getLearnerDecision();
    	learnerRank = valToRank(learnerValue, publicState.getPlayersInHand(), EXPONENT);
    
    		
    	
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
    		preFlopChart.setPlayPercentage((1 / (double) publicState.getPlayerCount())*AGRESSIVE_FACTOR);
    		chartRank = preFlopChart.getRank(publicState.getOwnCards());
    	
    	}
    	else {
    		runSimulations(0);

    		
    		simValue = sim.getWinPercentage() + sim.getTiePercentage();
    		simRank = valToRank(simValue, publicState.getPlayersInHand(), EXPONENT);
    		potOdds = publicState.getPotOdds();    		

    	}
    	
	}
	
    public void getDecision() throws IOException, SocketException {
    	double random = Math.random();
    	double rank = 0;
    	
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {

   		
    		rank = chartRank;
    		
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> PREFLOP: learner=" + round(learnerValue) + "->" + round(learnerRank) + ", chart=" + round(chartRank) + "  => rank=" + round(rank));

    		
        	if (rank > 0.6)
        		sendRaise();
        	else if (rank > 0.4)
        		sendCall();
        	else
        		sendFold();
    	}
    	else {
    		
    		double ew = sim.getAverageWinAmount();
    		System.out.println(getClass().getSimpleName() + "> Expected Win: " + ew);
    		if (ew < 0) 
    			sendFold();
    		else if (ew > 0.5)
    			sendFold();
    		else
    			sendCall();
    	}


    		
    }
    
    public void doBluff() throws IOException, SocketException {
		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> Bluffing.");
		sendRaise();
    }


    
    // Hilfsfunktionen
    // --------------------------------------------------------------------
    
	// Formel: Exponent bestimmt Varianz, Rest siehe Tabelle
	public static double valToRank(double val, int playerCount, int exp) {
		
		// =WENN(A3>2*(1/$E$2);1;WENN(A3<1/$E$2;MIN(1;(A3*$E$2)^$H$2*0,5);MIN(1;1-((1-A3-(1-2*(1/$E$2)))*$E$2)^$H$2*0,5)))
		
		double p = (double) playerCount;
		
		if (val > 2/p)
			return 1;
		
		if (val < (1/p)) 
			return Math.min(1, Math.pow(val*p, exp) * 0.5);
		else
			return Math.min(1, 1-Math.pow((1-val-(1-2*(1/p)))*p,exp)*0.5);
		
	}
	
	public static double round(double val) {
		
		return ((double)Math.round(val*100))/100;
		
	}
	
    public void sendRaise() throws SocketException, IOException {
    	if (DEBUG) System.out.println(getClass().getSimpleName() + "> Raising.");
    	raises++;
    	super.sendRaise();
    }
    
    public void sendCall() throws SocketException, IOException  {
    	if (DEBUG) System.out.println(getClass().getSimpleName() + "> Calling.");
    	calls++;
    	super.sendCall();
    }
    
    public void sendFold() throws SocketException, IOException  {
    	if (publicState.getAmountToCall() != 0) {
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Folding.");
        	folds++;
        	super.sendFold();
    	}
    	else {
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Should fold, but nothing to call.");
    		sendCall();
    	}
    }
    
    public void handleHandFinished() {
		sitStoreController.addObservation(publicState);
//		System.err.println(publicState);


		
    	if (publicState.haveIWon())
    		wins++;
    }
    
    public void handleNewRound() {
		
    	for(Player p : publicState.getPlayers()) {
    		p.getHandRange().reinit();
    	}
    	
		System.out.println(getClass().getSimpleName() + "> ---------- Starting Round " + (publicState.getRound()+1) + ", " + wins + " wins till now (" + publicState.getOwnPlayer().getWinSum() + "). ----------");
    	bluffing = (Math.random() < BLUFF_PERCENTAGE);
    }
    
    public EBot(){
      super();
      System.out.println(getClass().getSimpleName() + "> Starting...");
      
      publicState = new GameSituation();
      preFlopChart = new PreFlopChart();
//      sim = new ShowdownSimulatorUseBetsToCall();
//      sim = new ShowdownSimulator();
      
		hs = new HandStrength();
		outsC = new OutsCalculator();
		handSorter = new HandSorter(hs, outsC);

      
      hrThread = new HRThread();
		
      initLearners();
      sitStoreController = new SituationStoreController();
    }
    
	private int playerMadePreviousBet(Player p) {
		Vector<GameAction> playerActions = publicState.getActionsFromPlayer(p);
		int size = playerActions.size();
		if(size <= 1) {
			return 0;
		}
		else if(playerActions.get(size-2).getType() == GameAction.ACTION_RAISE) {
			return 1;
		}
		
		return 0;
	}
	
	private int playerPreviousAmountToCall(Player p) {
		Vector<GameAction> playerActions = publicState.getActionsFromPlayer(p);
		int size = playerActions.size();
		if(size <= 1) {
			return 0;
		}
		else if(playerActions.get(size-2).getToCall() > 0) {
			return 1;
		}
		
		return 0;
	}
	
	private int changeAmountToCall(int amount) {
		if(publicState.getState() <= GameSituation.STATE_FLOP) return amount/2;
		else return amount/4;
	}
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        EBot rpc = new EBot();
//        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
//        System.out.println("Successful connection!");
        rpc.run();
    }
    
    public class HRThread extends Thread {
    	private boolean finished = false;
    	
    	public void run() {
    		handleHandRanges();
    		finished = true;
    	}
    	
    	public boolean isFinished() {
    		return finished;
    	}
    	
    	public void reInit() {
    		finished = false;
    	}
    }
    
}