package bot;


import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


import bot.learner.LearnModule;
import bot.learner.LearnModule_PostFlop;
import bot.learner.LearnModule_PostFlop2;
import bot.learner.LearnModule_PreFlop;
import bot.opponent.SituationStoreController;
import bot.pokertools.PreFlopChart;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.PotSimulator;
import bot.utils.ShowdownSimulator;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class BaseBotSimPot extends BaseBot {
	
	private PotSimulator potSimulator = new PotSimulator();
	
	
	double expectedAvPot;
	double expectedAvInset;
	
	private double expectedFoldValue;
	private double expectedCallValue;
	private double expectedRaiseValue;
	
	protected static final boolean DEBUG_POT = false;
	protected static final boolean DEBUG_EXPECTED_VALUE = false;
	protected static final boolean DEBUG_EXPECTED_VALUE_DETAILS = false;
	
	public void handleStateChange() throws IOException, SocketException {
    	long time = System.currentTimeMillis();
    	
    	if (publicState.isNewRound(currentGameStateString)) {
    		System.out.println(getClass().getSimpleName() + "> ---------- Starting Round " + (publicState.getRound()+1) + ", " + wins + " wins till now (" + publicState.getOwnPlayer().getWinSum() + "). ----------");
        	bluffing = (Math.random() < BLUFF_PERCENTAGE);
    	}
    	
    	
    	publicState.updateSituation(currentGameStateString);
    	
    	// TODO Statisch
    	roundsToPlay = (publicState.getPlayerCount() == 6) ? 1000 : 3000;
    	
    	if (publicState.isHandFinished() && publicState.haveIWon())
    		wins++;

    	if (publicState.isHandFinished()) {
    		sitStoreController.addObservation(publicState);
//    		System.err.println(publicState);
    		
    		if(DEBUG_POT) System.out.println("************ REAL POT: " + publicState.getPot() + " ************");
    	}
    	
    	if (publicState.getRound() < Config.ROUNDSTOLEARN && publicState.isHandFinished()) {
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> Learning..."); 
    		learn();
    	}
    	
    	if (publicState.getRound() == Config.ROUNDTOPRINT && publicState.isHandFinished())
    		printLearnerState();
    	
    	if (publicState.amIOnMove()) {
    		String cBString = (publicState.getBoardCards().size() > 0) ? " " + publicState.getBoardCards() : "";
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> --- Decision on " + GameAction.getSituationString(publicState.getState()) + " (Cards: " + publicState.getOwnCards() + cBString +  ") ---"); 
    		if (bluffing) {
    			doBluff();
    		}
    		else {
    			prepareDecision();
    			getDecision();
    		}
    	}


    	
    	if (publicState.amIOnMove()) {
        	if (DEBUG) System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + " ms taken.");    	
    	}

    	if (publicState.getRound() == Config.ROUNDSTOLEARN && publicState.isHandFinished()) {
//    		closeLearners();
    		
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Folds: " + folds + " Calls: " + calls + " Raises: " + raises);
    		
    	}

	}
  
	public void prepareDecision() {
    	adjustLearnerWeights();
    	
    	learnerValue = getLearnerDecision();
    	learnerRank = valToRank(learnerValue, publicState.getPlayersInHand(), EXPONENT);
    	
    	
		double winProbCall;
		double winProbRaise;
		
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
    		preFlopChart.setPlayPercentage((1 / (double) publicState.getPlayerCount())*AGRESSIVE_FACTOR);
    		
    		Vector<Card> ownCards = publicState.getOwnCards();
    		chartRank = preFlopChart.getRank(ownCards);
    		
    		if(preFlopChart.shouldPlay(ownCards)){
//    			expectedCallValue = 0;
//            	expectedRaiseValue = 1;
            	
            	winProbCall = 0.0;
        		winProbRaise = 1.0;
    		}else{
//    			expectedCallValue = - 100;
//            	expectedRaiseValue = - 1000;
            	
            	winProbCall = 0.0;
        		winProbRaise = 0.0;
    		}
    	
    	}
    	else {
//    		if (publicState.getRound() >= 0){
    			int betAmount = 2;
    			if(publicState.getState() >= GameSituation.STATE_TURN){
    				betAmount = 4;
    			}
    			
//    			run call Simulation
    			runSimulations(0);
    			
        		
        		simValue = sim.getWinPercentage() + sim.getTiePercentage();
        		simRank = valToRank(simValue, publicState.getPlayersInHand(), EXPONENT);
        		potOdds = publicState.getPotOdds();

        		winProbCall = simValue;
        		
        		runSimulations(betAmount);
        		
        		simValue = sim.getWinPercentage() + sim.getTiePercentage();
        		simRank = valToRank(simValue, publicState.getPlayersInHand(), EXPONENT);
        		potOdds = publicState.getPotOdds();

        		winProbRaise = simValue;
        		
        		if(DEBUG_EXPECTED_VALUE_DETAILS) System.err.println("Round:" + publicState.getRound() +  " => winProbCall: " + winProbCall + " || winProbRaise: " + winProbRaise);
//        		
//        		runSimulations(0);
//        		expectedCallValue = sim.getAverageWinAmount();
//        		
//        		runSimulations(betAmount);
//            	expectedRaiseValue = sim.getAverageWinAmount();
//    		}else{
//    			preFlopChart.setPlayPercentage((1 / (double) publicState.getPlayerCount())*AGRESSIVE_FACTOR);
//    			
//    			Vector<Card> ownCards = publicState.getOwnCards();
//        		chartRank = preFlopChart.getRank(ownCards);
//        		
//        		if(preFlopChart.shouldPlay(ownCards)){
//        			expectedCallValue = 0;
//                	expectedRaiseValue = 1;
//        		}else{
//        			expectedCallValue = - publicState.getPlayerInsets(publicState.getOwnPlayer()) - 10;
//                	expectedRaiseValue = - publicState.getPlayerInsets(publicState.getOwnPlayer()) - 10;
//        		}
//        		
//        		
//    		}
    		
    	}
		
		
		getAvSimPot(GameAction.ACTION_CALL);
    	double expectedAvCallPot = expectedAvPot;
    	double avCallInset = expectedAvInset;
    	
    	getAvSimPot(GameAction.ACTION_RAISE);
    	double expectedAvRaisePot = expectedAvPot;
    	double avRaiseInset = expectedAvInset;
    	
    	if(DEBUG_POT) System.err.println("expectedCallPot: " + expectedAvCallPot + " | expectedRaisePot: " + expectedAvRaisePot + " (Round: " + publicState.getRound() + " || Betting Round: " + publicState.getState() + ")");
    	if(DEBUG_EXPECTED_VALUE_DETAILS) System.err.println("avCallInset: " + avCallInset + " | avRaiseInset: " + avRaiseInset + " || winProbCall: " + winProbCall + " || winProbRaise: " + winProbRaise + " || expectedCallPot: " + expectedAvCallPot + " | expectedRaisePot: " + expectedAvRaisePot);
    	
    	expectedFoldValue = - publicState.getPlayerInsets(publicState.getOwnPlayer());
    	expectedCallValue = winProbCall * expectedAvCallPot - (1 -winProbCall) * avCallInset;
    	expectedRaiseValue = winProbRaise * expectedAvRaisePot - (1 -winProbRaise) * avRaiseInset;
    	
//    	expectedFoldValue = expectedFoldValue + Math.abs(expectedFoldValue * 0.8);
//    	expectedRaiseValue = expectedRaiseValue + Math.abs(expectedFoldValue * 0.3);
//    	expectedCallValue = expectedCallValue - Math.abs(expectedFoldValue * 0.8);
    	
//    	expectedFoldValue = 1.0;
//    	expectedRaiseValue = 0;
//    	expectedCallValue = 0;
	}
	
    private void getAvSimPot(int action) {
    	int expectedPotSum = 0;
    	int expectedInsetSum = 0;
    	
    	Player player = publicState.getOwnPlayer();
    	
    	int anzSims = 20;
    	for(int i = 0; i < anzSims; i++){
    		expectedPotSum += potSimulator.startSimulation(publicState, action);
    		expectedInsetSum += potSimulator.getPotInsets(player); 
    	}
    	
    	expectedAvPot = (expectedPotSum / anzSims);
    	expectedAvInset = (expectedInsetSum / anzSims);
	}

	public void getDecision() throws IOException, SocketException {
		
		if(DEBUG_EXPECTED_VALUE) System.err.println(publicState.getSituationString());
		if(DEBUG_EXPECTED_VALUE) System.err.println("expectedRaiseValue: " + expectedRaiseValue + " || expectedCallValue: " + expectedCallValue + " || expectedFoldValue: " + expectedFoldValue);
		
    	if ((expectedRaiseValue >= expectedCallValue) && (expectedRaiseValue >= expectedFoldValue)){
    		sendRaise();
    		if(DEBUG_EXPECTED_VALUE) System.err.println("RAISE!");
    	} else if ((expectedFoldValue >= expectedRaiseValue) && (expectedFoldValue >= expectedCallValue)){
    		sendFold();
    		if(DEBUG_EXPECTED_VALUE) System.err.println("FOLD!");
    	} else{
    		sendCall();
    		if(DEBUG_EXPECTED_VALUE) System.err.println("CALL!");
    	}
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        BaseBotSimPot rpc = new BaseBotSimPot();
//        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
//        System.out.println("Successful connection!");
        rpc.run();
    }
    
}