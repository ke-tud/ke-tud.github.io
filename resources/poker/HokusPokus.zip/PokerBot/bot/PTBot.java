package bot;


import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;


import bot.learner.LearnModule;
import bot.learner.LearnModule_PostFlop;
import bot.learner.LearnModule_PostFlop2;
import bot.learner.LearnModule_PreFlop;
import bot.opponent.HandSorter;
import bot.opponent.HandStrength;
import bot.opponent.OutsCalculator;
import bot.opponent.SituationStoreController;
import bot.pokertools.PreFlopChart;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.ShowdownSimulator;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class PTBot extends PokerClient {
	
	protected GameSituation publicState;
	protected PreFlopChart preFlopChart;
	protected int folds, calls, raises; 
	
	
	protected int wins = 0;
	protected long time = 0;
	

	
	protected static final boolean DEBUG = true;
	protected static final double AGRESSIVE_FACTOR = 1.3;

	protected int roundsToPlay = 3000;
	
	protected double chartRank;
	
	
	public void handleStateChange() throws IOException, SocketException {
    	long time = System.currentTimeMillis();
    	
    	if (publicState.isNewRound(currentGameStateString)) {
    		handleNewRound();
    	}
    	

    	
    	publicState.updateSituation(currentGameStateString);
    	
    	// TODO Statisch
    	roundsToPlay = (publicState.getPlayerCount() == 6) ? 1000 : 3000;
    	
    	// TODO weg
//    	if (publicState != null && publicState.getPlayers() != null) {
//	    	for (int i=0; i<publicState.getPlayers().size(); i++) {
//	    		if (i != publicState.getPosition())
//	    			sim.normalize(publicState.getPlayers().get(i).getHandRange().getHandrange());
//	    	}
//    	}
    	


    	if (publicState.isHandFinished()) {
    		handleHandFinished();

    	}
    	
    	if (publicState.getRound() < Config.ROUNDSTOLEARN && publicState.isHandFinished()) {
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> Learning..."); 
    	}
    	    	
    	if (publicState.amIOnMove()) {
    		String cBString = (publicState.getBoardCards().size() > 0) ? " " + publicState.getBoardCards() : "";
    		if (DEBUG) System.out.println(this.getClass().getSimpleName() + "> --- Decision on " + GameAction.getSituationString(publicState.getState()) + " (Cards: " + publicState.getOwnCards() + cBString +  ") ---"); 
   			
    		prepareDecision();
   			getDecision();
    	}


    	
    	if (publicState.amIOnMove()) {
    		this.time += System.currentTimeMillis() - time;
        	if (DEBUG) System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + " ms taken.");    	
    	}

    	if (publicState.getRound() == roundsToPlay - 1 && publicState.isHandFinished()) {
//    		closeLearners();
    		
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Folds: " + folds + " Calls: " + calls + " Raises: " + raises + " - " + round(this.time / roundsToPlay) + "ms taken on average.");
    		
    	}

	}
	
	public static double round(double val) {
		
		return ((double)Math.round(val*100))/100;
		
	}
	
  
	public void prepareDecision() {
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
    		preFlopChart.setPlayPercentage((1 / (double) publicState.getPlayerCount())*AGRESSIVE_FACTOR);
    		chartRank = preFlopChart.getRank(publicState.getOwnCards());
    	
    	}
    	
	}
	
    public void getDecision() throws IOException, SocketException {
    	double random = Math.random();
    	double rank = 0;
    	
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {

   			rank = chartRank;
    		
    		
        	if (rank > 0.6)
        		sendRaise();
        	else if (rank > 0.4)
        		sendCall();
        	else
        		sendFold();
    	}
    	else {
    		sendCall();
    	}
    		
    }
    
	
    public void sendRaise() throws SocketException, IOException {
    	if (DEBUG) System.out.println(getClass().getSimpleName() + "> Raising.");
    	raises++;
    	super.sendRaise();
    }
    
    public void sendCall() throws SocketException, IOException  {
    	if (DEBUG) System.out.println(getClass().getSimpleName() + "> Calling.");
    	calls++;
    	super.sendCall();
    }
    
    public void sendFold() throws SocketException, IOException  {
    	if (publicState.getAmountToCall() != 0) {
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Folding.");
        	folds++;
        	super.sendFold();
    	}
    	else {
    		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Should fold, but nothing to call.");
    		sendCall();
    	}
    }
    
    public void handleHandFinished() {
		
    	if (publicState.haveIWon())
    		wins++;
    }
    
    public void handleNewRound() {
		System.out.println(getClass().getSimpleName() + "> ---------- Starting Round " + (publicState.getRound()+1) + ", " + wins + " wins till now (" + publicState.getOwnPlayer().getWinSum() + "). ----------");
    }
    
    public PTBot(){
      super();
      System.out.println(getClass().getSimpleName() + "> Starting...");
      
      publicState = new GameSituation();
      preFlopChart = new PreFlopChart();
    }
    
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        PTBot rpc = new PTBot();
//        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
//        System.out.println("Successful connection!");
        rpc.run();
    }
    
   
}