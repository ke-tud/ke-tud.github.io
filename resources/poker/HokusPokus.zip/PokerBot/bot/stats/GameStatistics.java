package bot.stats;

import java.util.Vector;

import com.javaflair.pokerprophesier.api.adapter.PokerProphesierAdapter;
import com.javaflair.pokerprophesier.api.card.CommunityCards;
import com.javaflair.pokerprophesier.api.card.Hand;
import com.javaflair.pokerprophesier.api.card.HoleCards;
import com.javaflair.pokerprophesier.api.exception.SimulatorException;
import com.javaflair.pokerprophesier.api.helper.MyGameStatsHelper;
import com.javaflair.pokerprophesier.api.helper.MyHandHelper;
import com.javaflair.pokerprophesier.api.helper.MyHandStatsHelper;
import com.javaflair.pokerprophesier.api.helper.MyOutsHelper;

import bot.utils.Card;

public class GameStatistics {
	
	private PokerProphesierAdapter stats = null;
	
	public void runSimulation(Vector<Card> myCards, Vector<Card> boardCards, int playerCount) throws SimulatorException {
		stats.setMyOutsHoleCardSensitive(true);
		stats.setOppHoleCardsRealistic(true);
		stats.setOppProbMyHandSensitive(true);
		HoleCards hC = new HoleCards(convertCard(myCards.get(0)), convertCard(myCards.get(1)));
		 
		CommunityCards cC = null;
		int situation = PokerProphesierAdapter.HOLE_CARDS_DEALT;
		 
		if (boardCards != null){
			com.javaflair.pokerprophesier.api.card.Card[] cCA = new com.javaflair.pokerprophesier.api.card.Card[boardCards.size()];
			for (int i=0; i<boardCards.size(); i++) {
				cCA[i] = convertCard(boardCards.get(i));
			}
			 
			if(boardCards.size() > 0){
				cC = new CommunityCards(cCA);
			}
			 
			if (cCA.length == 0) situation = PokerProphesierAdapter.HOLE_CARDS_DEALT;
			if (cCA.length == 3) situation = PokerProphesierAdapter.FLOP_CARDS_DEALT;
			if (cCA.length == 4) situation = PokerProphesierAdapter.TURN_CARD_DEALT;
			if (cCA.length == 5) situation = PokerProphesierAdapter.RIVER_CARD_DEALT;
		}

		stats.runMySimulations(hC, cC, playerCount, situation);
	}
	
//	------- MyGameStatsHelper: -------
		public double getWinPropability(){
		MyGameStatsHelper gameStats = stats.getMyGameStatsHelper();
		return gameStats.getWinProb();
	}
	
	public double getTiePropability(){
		MyGameStatsHelper gameStats = stats.getMyGameStatsHelper();
		return gameStats.getTieProb();
	}
	
	public double getLosePropability(){
		MyGameStatsHelper gameStats = stats.getMyGameStatsHelper();
		return gameStats.getLoseProb();
	}
	
	public double getNumSimPlayers(){
		MyGameStatsHelper gameStats = stats.getMyGameStatsHelper();
		return gameStats.getNumSimPlayers();
	}
	
	public double getNumSimulations(){
		MyGameStatsHelper gameStats = stats.getMyGameStatsHelper();
		return gameStats.getNumSimulations();
	}
//	----------------------------------
	
	
//	------- MyHandStatsHelper: -------
	public float[] getAllHandsProbs(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getAllProbs();
	}
	
	public float getFlushProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getFlushProb();
	}
	
	public float getFourOfAKindProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getFourOfAKindProb();
	}
	
	public float getFullHouseProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getFullHouseProb();
	}
	
	public float getHighCardProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getHighCardProb();
	}
	
	public float getPairProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getPairProb();
	}
	
	public float getStraightFlushProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getStraightFlushProb();
	}
	
	public float getStraightProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getStraightProb();
	}
	
	public float getThreeOfAKindProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getThreeOfAKindProb();
	}
	
	public float getTotalProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getTotalProb();
	}
	
	public float getTwoPairsProb(){
		MyHandStatsHelper handStats = stats.getMyHandStatsHelper();
		return handStats.getTwoPairsProb();
	}
//	----------------------------------
	
//	------- MyHandStatsHelper: -------
	public Hand getHand(){
		MyHandHelper handHelper = stats.getMyHandHelper();
		return handHelper.getHand();
	}
//	----------------------------------
	
//	------- MyHandStatsHelper: -------
	public com.javaflair.pokerprophesier.api.card.Card[][] getAllOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getAllOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getFlushOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getFlushOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getFourOfAKindOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getFourOfAKindOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getFullHouseOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getFullHouseOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getHighCardOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getHighCardOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getPairOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getPairOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getStraightFlushOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getStraightFlushOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getStraightOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getStraightOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getThreeOfAKindOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getThreeOfAKindOuts();
	}
	
	public int getTotalNumOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getTotalNumOuts();
	}
	
	public com.javaflair.pokerprophesier.api.card.Card[] getTwoPairsOuts(){
		MyOutsHelper outsHelper = stats.getMyOutsHelper();
		return outsHelper.getTwoPairsOuts();
	}
//	----------------------------------
	
	public void setNumSimulations(int sim) {
		stats.setNumSimulations(sim);
	}
	
	public GameStatistics() {
		stats = new PokerProphesierAdapter();
	}
	
	public static com.javaflair.pokerprophesier.api.card.Card convertCard(Card c) {
		int color = -1;
		if (c.getColor() == Card.CLUB) 
			color = com.javaflair.pokerprophesier.api.card.Card.CLUBS;
		else if (c.getColor() == Card.DIAMOND) 
			color = com.javaflair.pokerprophesier.api.card.Card.DIAMONDS;
		else if (c.getColor() == Card.HEART)
			color = com.javaflair.pokerprophesier.api.card.Card.HEARTS;
		else if (c.getColor() == Card.SPADE)
			color = com.javaflair.pokerprophesier.api.card.Card.SPADES;
		
		int number = -1;
		if (c.getNumber() == Card.N2)
			number = com.javaflair.pokerprophesier.api.card.Card.TWO;
		else if (c.getNumber() == Card.N3)
			number = com.javaflair.pokerprophesier.api.card.Card.THREE;
		else if (c.getNumber() == Card.N4)
			number = com.javaflair.pokerprophesier.api.card.Card.FOUR;
		else if (c.getNumber() == Card.N5)
			number = com.javaflair.pokerprophesier.api.card.Card.FIVE;
		else if (c.getNumber() == Card.N6)
			number = com.javaflair.pokerprophesier.api.card.Card.SIX;
		else if (c.getNumber() == Card.N7)
			number = com.javaflair.pokerprophesier.api.card.Card.SEVEN;
		else if (c.getNumber() == Card.N8)
			number = com.javaflair.pokerprophesier.api.card.Card.EIGHT;
		else if (c.getNumber() == Card.N9)
			number = com.javaflair.pokerprophesier.api.card.Card.NINE;
		else if (c.getNumber() == Card.NT)
			number = com.javaflair.pokerprophesier.api.card.Card.TEN;
		else if (c.getNumber() == Card.NJ)
			number = com.javaflair.pokerprophesier.api.card.Card.JACK;
		else if (c.getNumber() == Card.NQ)
			number = com.javaflair.pokerprophesier.api.card.Card.QUEEN;
		else if (c.getNumber() == Card.NK)
			number = com.javaflair.pokerprophesier.api.card.Card.KING;
		else if (c.getNumber() == Card.NA)
			number = com.javaflair.pokerprophesier.api.card.Card.ACE;
		
//		System.out.println("# N:" + number + " C:" + color);
		
		return new com.javaflair.pokerprophesier.api.card.Card(number, color);
	}

}
