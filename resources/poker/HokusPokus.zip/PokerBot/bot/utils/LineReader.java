package bot.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LineReader{
	
	private FileReader fr;
	
	public String readLine() throws IOException {
		String buffer = "";
		int c = 0;
		while ((c = fr.read()) != -1) {
			if ((char)c == '\r')
				continue;
			if ((char)c == '\n')
				break;
			if (c == -1)
				return null;
			
			buffer += (char) c;
		}
		
		if (buffer.length() == 0)
			return null;
		
		return buffer;
		
		
		
	}
	
	public void close() throws IOException {
		fr.close();
	}
	
	public LineReader(String filename) throws FileNotFoundException {
		fr = new FileReader(filename);
		
	}

}
