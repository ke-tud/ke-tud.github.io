package bot.utils;

import java.util.Arrays;

import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;





public class FullCombo {
	
	private Card[] playerCards;

	private Card[] boardCards;

	
	public Combination getBestCombo() {
		Card[] best = new Card[5];
		Card[] allCards = new Card[7];
		Combination bestCombo = null;
		
		allCards[0] = playerCards[0];
		allCards[1] = playerCards[1];
		allCards[2] = boardCards[0];
		allCards[3] = boardCards[1];
		allCards[4] = boardCards[2];
		allCards[5] = boardCards[3];
		allCards[6] = boardCards[4];
		
		
		if (allCards[5] == null) {
//			System.out.println("5 cards");
			best[0] = allCards[0];
			best[1] = allCards[1];
			best[2] = allCards[2];
			best[3] = allCards[3];
			best[4] = allCards[4];
			
			
			bestCombo = Analyzer.test(best);
			bestCombo.makeKickerRow(best);
			return bestCombo;
		}
		else if (allCards[6] == null) {
//			System.out.println("6 cards");
			Card[] current = new Card[5];
			Combination currentCombo = null;
			
			for (int i=0; i<6; i++) {
				

				current = takeWithOutIndex(allCards, i);
				
				currentCombo = Analyzer.test(current);
				currentCombo.makeKickerRow(current);
				
//				System.out.println("## current: " + Arrays.toString(current));
//				print(current);
				if (bestCombo == null || currentCombo.isHigherThan(bestCombo) > 0) {
					bestCombo = currentCombo;
					
					best[0] = current[0];
					best[1] = current[1];
					best[2] = current[2];
					best[3] = current[3];
					best[4] = current[4];
				}
				
			}
			bestCombo.makeKickerRow(best);
			return bestCombo;
		}
		else {
//			System.out.println("7 cards");
			Card[] current = new Card[5];
			Combination currentCombo = null;
			
			for (int i=0; i<7; i++) {
				for (int j=i+1; j<7; j++) {
					
					current = takeWithOutIndex2(allCards, i, j);
					
					currentCombo = Analyzer.test(current);
					currentCombo.makeKickerRow(current);

//					System.out.print("current: ");
//					print(current);
//					System.out.println("   " + currentCombo + "    best: " + bestCombo);

					if (bestCombo == null || currentCombo.isHigherThan(bestCombo) > 0) {
//						System.out.println("took");
						bestCombo = currentCombo;
						
						best[0] = current[0];
						best[1] = current[1];
						best[2] = current[2];
						best[3] = current[3];
						best[4] = current[4];
					}
				}
				
			}
			
			bestCombo.makeKickerRow(best);
			return bestCombo;
		}
	}
	
//	public Card[] getBestCombo() {
//		Card[] best = new Card[5];
//		Card[] allCards = new Card[7];
//		Combination bestCombo = null;
//		
//		allCards[0] = playerCards[0];
//		allCards[1] = playerCards[1];
//		allCards[2] = boardCards[0];
//		allCards[3] = boardCards[1];
//		allCards[4] = boardCards[2];
//		allCards[5] = boardCards[3];
//		allCards[6] = boardCards[4];
//		
//		
//		if (allCards[5] == null) {
//			System.out.println("5 cards");
//			best[0] = allCards[0];
//			best[1] = allCards[1];
//			best[2] = allCards[2];
//			best[3] = allCards[3];
//			best[4] = allCards[4];
//			
//			return best;
//		}
//		else if (allCards[6] == null) {
//			System.out.println("6 cards");
//			Card[] current = new Card[5];
//			Combination currentCombo = null;
//			
//			for (int i=0; i<6; i++) {
//				
//				current = takeWithOutIndex(allCards, i);
//				System.out.print("current: ");
//				print(current);
//				
//				currentCombo = Analyzer.test(current);
//				if (bestCombo == null || currentCombo.isHigherThan(bestCombo)) {
//					bestCombo = currentCombo;
//					
//					best[0] = current[0];
//					best[1] = current[1];
//					best[2] = current[2];
//					best[3] = current[3];
//					best[4] = current[4];
//				}
//				
//			}
//			return best;
//		}
//		else {
//			System.out.println("7 cards");
//			Card[] current = new Card[5];
//			Combination currentCombo = null;
//			
//			for (int i=0; i<7; i++) {
//				for (int j=i+1; j<7; j++) {
//					
//					current = takeWithOutIndex2(allCards, i, j);
//					System.out.print("current: ");
//					print(current);
//					System.out.println("   " + currentCombo + "    best: " + bestCombo);
//					
//					currentCombo = Analyzer.test(current);
//					if (bestCombo == null || currentCombo.isHigherThan(bestCombo)) {
//						System.out.println("took");
//						bestCombo = currentCombo;
//						
//						best[0] = current[0];
//						best[1] = current[1];
//						best[2] = current[2];
//						best[3] = current[3];
//						best[4] = current[4];
//					}
//				}
//				
//			}
//			return best;
//		}
//	}

	
	private Card[] takeWithOutIndex(Card[] which, int index) {
		Card[] result = new Card[5];
		int resultIndex = 0;
		
		for (int i=0; i<6; i++) {
			if (i != index) {
				result[resultIndex] = which[i];
				resultIndex++;
			}
		}
		
		return result;
	}
	
	private Card[] takeWithOutIndex2(Card[] which, int index1, int index2) {
		Card[] result = new Card[5];
		int resultIndex = 0;
		
		for (int i=0; i<7; i++) {
			if (i != index1 && i != index2) {
				result[resultIndex] = which[i];
				resultIndex++;
			}
		}
		
		return result;
	}
	
	public FullCombo(Card[] player, Card[] board) {
		playerCards = new Card[2];
		boardCards = new Card[5];
		
		if (player.length == 2 && board.length >= 3) {
			playerCards[0] = player[0];
			playerCards[1] = player[1];

			boardCards[0] = board[0];
			boardCards[1] = board[1];
			boardCards[2] = board[2];
			if (board.length >= 4) boardCards[3] = board[3];
			else boardCards[3] = null;
			
			if (board.length >= 5) boardCards[4] = board[4];
			else boardCards[4] = null;
		}
		
//		System.out.println("# PC: " + Arrays.toString(playerCards) + ", BC: " + Arrays.toString(boardCards));
		
	}
	
	
	public static void print(Card[] cards) {
		for (int i=0; i<cards.length; i++) {
			System.out.print(cards[i] + "  ");
		}
	}
	
}
