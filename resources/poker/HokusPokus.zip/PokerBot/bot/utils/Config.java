package bot.utils;

public class Config {
	
	// Allgemeines
	public static final String PLAYER_NAME = "MYSELF";
	
	public static final int MAX_PLAYERS = 6;

	public static final int SMALL_BLIND = 1;
	public static final int BIG_BLIND = 2;
	
	public static final int SMALL_BET_AMOUNT = 2;
	public static final int BIG_BET_AMOUNT = 4;
	
	
	public static final int NUM_SIMULATIONS = 500;
	
	public static final boolean DEBUG_GLOBAL = true;
	
	// Lerner
	public static final int ROUNDSTOLEARN = 900;
	public static final int ROUNDTODECIDE = 300;
	public static final int ROUNDTOPRINT = 600;
	
//	public static final int PREFLOP_ROUNDSTOLEARN = 300;
//	public static final int POSTFLOP_ROUNDSTOLEARN = 300;
	
	public static final boolean DEBUG_LEARNER = false; 
	public static final int ROUND_USE_OPPONENTMODEL = 100;

}
