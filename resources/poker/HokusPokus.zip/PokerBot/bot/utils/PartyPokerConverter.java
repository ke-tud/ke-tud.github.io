package bot.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;

public class PartyPokerConverter {
	
	private int roundCount;
	private long time;
	
	public void convertFile(String ppFile, String msFile) throws FileNotFoundException, IOException {
		String history = "";
		FileReader fr = new FileReader(ppFile);
		int c = 0;
		while ((c = fr.read()) != -1) {
			history += (char) c;
		}
		fr.close();
		Vector<String> msString = convertHistory(history);
		
//		File msF = new File(msFile);
//		if (msF.exists())
//			msF.delete();
		
		FileWriter fw = new FileWriter(msFile, true);
		
		for (int i=0; i<msString.size(); i++) {
			fw.append(msString.get(i) + "\r\n");
		}
		fw.close();
		
		
	}
	
	public Vector<String> convertHistory(String history) {
		System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + "ms taken. Replacing r's..."); System.out.flush();
		history = history.replace("\r", "");

		Vector<String> out = new Vector<String>();
		System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + "ms taken. Splitting hands..."); System.out.flush();
		String singleHistories[] = history.split("Game #<do not remove this line!> starts.\n");
		
		System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + "ms taken. Processing " + singleHistories.length + " hands..."); System.out.flush();
		
		for (int i=0; i<singleHistories.length; i++) {
			System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + "ms taken. Hand: " + roundCount); System.out.flush();
			
			if (singleHistories[i].length() > 10) {
//				System.out.println(singleHistories[i]);
				String thisHand = convertPPToMatchState(singleHistories[i]);
				out.add(thisHand);
			}
		}
		
		return out;
	}
	
	public String convertPPToMatchState(String history) {
		history = history.replace("\r", "");
		
		String[] rows = history.split("\n");
		int currentRow = 3;
		
		
		int numPlayers = Integer.parseInt(rows[4].replace("Total number of players : ", ""));
		currentRow = 5;
		
		String[] players = new String[numPlayers];
		int[] inPot = new int[numPlayers]; // evtl double
		
		String[] tempPlayers = new String[10];
		
		for (int i=currentRow; i<5+numPlayers; i++) {
			int seatNr = Integer.parseInt(rows[i].substring(5,rows[i].indexOf(":")));
			
			String name = "";
			int charPos = rows[i].indexOf(":")+2;
			char c;
			while (true) {
				c = rows[i].charAt(charPos);
				if (c == ' ')
					break;
				name += c;
				charPos++;
			}
			
//			System.out.println("# Seat + " + seatNr + " -> " + name);
			tempPlayers[seatNr-1] = name;
			
			currentRow = i;
		}
		
		int j = 0;
		for (int i=0; i<10; i++) {
			if (tempPlayers[i] != null) {
				players[j++] = tempPlayers[i]; 
			}
				
		}
		
		int buttonSeatNr = Integer.parseInt(rows[3].replace("Seat ", "").replace(" is the button", ""));// - 1 % numPlayers;
		int buttonSeat = indexOf(players, tempPlayers[buttonSeatNr-1]);
		int sbSeat = mod(buttonSeat + 1, numPlayers);
		int bbSeat = mod(buttonSeat + 2, numPlayers);

		
		currentRow++;
		
		// In Pot Rauskriegen + ActionString
//		inPot[sbSeat] = Double.parseDouble(getStringBetween(rows[currentRow++], '[', ']').replace("$", "").replace(" USD", ""));
//		inPot[bbSeat] = Double.parseDouble(getStringBetween(rows[currentRow++], '[', ']').replace("$", "").replace(" USD", ""));
		String actionString = "";
		Vector<String> winners = new Vector<String>();
		String flopCards = "";
		String turnCard = "";
		String riverCard = "";
		
		String[] playerCards = new String[numPlayers];
		
		for (int i=currentRow; i<rows.length; i++) {
			if (rows[i].charAt(0) != '*' && (rows[i].contains("bets") || rows[i].contains("calls") || rows[i].contains("folds") || rows[i].contains("raises") || rows[i].contains("posts"))) {
				String name = rows[i].substring(0, rows[i].indexOf(" "));

				if (rows[i].contains("folds")) actionString += "f";
				else {
					double val = Double.parseDouble(getStringBetween(rows[i], '[', ']').replace(",",".").replace(" ", "").replace("$", "").replace("USD", ""));
				
					int valI = (int) Math.round(val * 100);
				
					inPot[indexOf(players, name)] += valI;
//					System.out.println("# " + name + " -> " + val);
				
					if (rows[i].contains("calls")) actionString += "c";
					if (rows[i].contains("bets") || rows[i].contains("raises")) actionString += "r";
				}
			}
			else if (rows[i].contains("Flop") || rows[i].contains("Turn") || rows[i].contains("River")) {
				actionString += "/";
				String cards = getStringBetween(rows[i], '[', ']');
				cards = cards.replace(" ", "").replace(",", "");
				if (rows[i].contains("Flop")) flopCards = cards;
				if (rows[i].contains("Turn")) turnCard = cards;
				if (rows[i].contains("River")) riverCard = cards;
			}
			else if (rows[i].contains("wins")) {
				String name = rows[i].substring(0, rows[i].indexOf(" "));
				winners.add(name);
			}
			else if (rows[i].contains("show")) {
				String name = rows[i].substring(0, rows[i].indexOf(" "));
				String cards = getStringBetween(rows[i], '[', ']');
				cards = cards.replace(" ", "").replace(",", "");
				
				playerCards[indexOf(players, name)] = cards;
			}
		}
		
		String cardString = "";
		for (int i=sbSeat; i<sbSeat+numPlayers; i++) {
			if (playerCards[i % numPlayers] != null)
				cardString += playerCards[i % numPlayers];
			cardString += "|";
		}
		cardString = cardString.substring(0, cardString.length() - 1);
		
		cardString += "/" + flopCards + "/" + riverCard + "/" + turnCard;
		
		
		String moneyString = "";
		int moneySum = 0;
		for (int i=0; i<inPot.length; i++) {
			moneySum += inPot[i];
			inPot[i] = - inPot[i];
		}
		for (int i=0; i<winners.size(); i++) {
			inPot[indexOf(players, winners.get(i))] += moneySum / winners.size();
		}
		for (int i=sbSeat; i<sbSeat+numPlayers; i++) {
			moneyString += inPot[i % numPlayers] + "|";
		}
		moneyString = moneyString.substring(0, moneyString.length() - 1);
		
		
		String finalString = "";
		for (int i=sbSeat; i<sbSeat+numPlayers; i++) {
			finalString += players[i % numPlayers] + "|";
		}
		
		finalString = finalString.substring(0, finalString.length() - 1);
		
		finalString += ":" + roundCount + ":" + actionString + ":" + cardString + ":" + moneyString;
		
//		System.out.println(history);
//		System.out.println("buttonSeat: " + buttonSeat);
//		System.out.println("numPlayers: " + numPlayers);
//		System.out.println("players: " + Arrays.toString(players));
//		System.out.println("inPot: " + Arrays.toString(inPot));
//		System.out.println("actionString: " + actionString);
//		System.out.println("playerCards: " + Arrays.toString(playerCards));
//		System.out.println("finalString: " + finalString);
		
		roundCount++;
		
		return finalString;
	}
	
	public static String getStringBetween(String in, char first, char last) {
		String ret = "";
		boolean copy = false;
		for (int pos=0; pos<in.length(); pos++) {
			if (in.charAt(pos) == last) copy = false;
			
			if (copy)
				ret += in.charAt(pos);
			if (in.charAt(pos) == first) copy = true;

		}
		return ret;
	}
	
	public static int indexOf(String[] of, String val) {
		for (int i=0; i<of.length; i++) {
			if (of[i].equals(val))
				return i;
		}
		return -1;
	}
	
	public static int indexOf(int[] of, int val) {
		for (int i=0; i<of.length; i++) {
			if (of[i] == val)
				return i;
		}
		return -1;
	}
	
	public static int mod(int i, int m) {
		
		while (i >= m)
			i = i - m;
		
		return i;
	}
	
	public PartyPokerConverter() {
		roundCount = 0;
		time = System.currentTimeMillis();
	}

}
