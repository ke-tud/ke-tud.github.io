package bot.utils;

import java.util.Random;
import java.util.Vector;

import bot.opponent.MoveGuesser;

public class PotSimulator {
	
	private class SimPlayer {
		String name;
		int toCall;
		int previousToCall;
		int previousAction;
		int potAmount;
		boolean stillInGame = true;
		
		public String toString(){
			return "toCall: " + toCall + " || previousToCall: " + previousToCall + " || previousAction: " + previousAction; 
		}
	}
	
	private int pot;
	private int aktPosition;
	private int bettingRound;
	private int anzRaises;
	private int anzRecentCalls;
	private int activePlayers;
	
	private Vector<SimPlayer> simPlayers = null;
	
	private static final boolean DEBUG = false;
	private static final boolean DEBUG_PROBS = false;
	private static final boolean DEBUG_PLAYER = false;
	
	
	public int startSimulation(GameSituation gs, int firstAction){
		pot = gs.getPot();
		aktPosition = gs.getPosition();
		bettingRound = gs.getState();
		
		if(DEBUG) System.err.println("StartPot: " + pot + " at Betting Round: " + bettingRound + " Round: " +  gs.getRound());
		
		simPlayers = new Vector<SimPlayer>();
		if(gs.getActionsInRound(bettingRound) == null){
			if(DEBUG) System.err.println("Actions == null !!!!");
		}else if(gs.getActionsInRound(bettingRound).size() == 0){
			if(DEBUG) System.err.println("Actions.size() == 0 !!!!");
			anzRaises = 0;
			anzRecentCalls = 0;
		}else{
			anzRaises = getAnzRaises(gs.getActionsInRound(bettingRound));
			anzRecentCalls = getAnzRecentCalls(gs.getActionsInRound(bettingRound));
		}
		
//		player einlesen:
		Vector<Player> players = gs.getPlayers();
		for(int i = 0; i < players.size(); i++){
			
			Player tmpPlayer = players.get(i);
			SimPlayer tmpsimPlayer = this.new SimPlayer();
			
			
			tmpsimPlayer.name = tmpPlayer.getName();
			tmpsimPlayer.potAmount = gs.getPlayerInsets(tmpPlayer);
			
			tmpsimPlayer.toCall = gs.getAmountToCallFromPlayer(tmpPlayer);
			if(tmpsimPlayer.toCall == -1){
				tmpsimPlayer.stillInGame = false;
			}
			
			Vector<GameAction> actions = gs.getActionsFromPlayer(tmpPlayer);
			if(actions.size() > 0){
				if(actions.lastElement().getType() == GameAction.ACTION_RAISE){
					tmpsimPlayer.previousAction = 1;
				}else{
					tmpsimPlayer.previousAction = 0;
				}
				tmpsimPlayer.previousToCall = actions.lastElement().getToCall();
			}else{
				tmpsimPlayer.previousAction = 2;
				tmpsimPlayer.previousToCall = 0;
			}
			
			
			simPlayers.add(tmpsimPlayer);
			if(DEBUG_PLAYER) System.err.println(tmpsimPlayer.name + " => tmpsimPlayer.toCall: " + tmpsimPlayer.toCall + " tmpsimPlayer.potAmount: " +  tmpsimPlayer.potAmount);
		}
		
		activePlayers = simPlayers.size();

		while(! isHandFinished()){
			doAction(simPlayers.get(aktPosition), players.get(aktPosition), firstAction);
			firstAction = -1;
			
			if(activePlayers > 0){
				do{
					aktPosition = (aktPosition + 1) % simPlayers.size();
				}while(! simPlayers.get(aktPosition).stillInGame);
				
			}
			
			if(DEBUG) System.err.println("anzRecentCalls: " + anzRecentCalls + " | activePlayers: " + activePlayers);
			
			if(isStateFinished()){
				if(DEBUG) System.err.println("***StateFinished!***");
				bettingRound++;
				anzRecentCalls = 0;
				anzRaises = 0;
			}
		}
		
		if(DEBUG) System.err.println("------------- HandFinished! ----------------");
		return pot;
	}
	
	public int getPotInsets(Player player){
		return getSimPlayerByPlayer(player).potAmount;		
	}
	
	private SimPlayer getSimPlayerByPlayer(Player player){
		for(int i = 0; i < simPlayers.size(); i++){
			SimPlayer simPlayer = simPlayers.get(i);
			if (simPlayer.name.equals(player.getName())){
				return simPlayer;
			}
		}
		
		return null;
	}
	
	private boolean isHandFinished() {
		if((bettingRound > GameSituation.STATE_RIVER) || (activePlayers == 0)){
			return true;
		}
		return false;
	}

	private boolean isStateFinished() {
		if((anzRecentCalls >= activePlayers) || (activePlayers == 0)){
			return true;
		}else{
			return false;
		}		
	}

	private void doAction(SimPlayer simPlayer, Player player, int firstAction){
		
		if(firstAction == GameAction.ACTION_FOLD){
			doFold(simPlayer);
		}else if(firstAction == GameAction.ACTION_CALL){
			doCall(simPlayer);
		} else if(firstAction == GameAction.ACTION_RAISE){
			doRaise(simPlayer);
		} else{
			if(DEBUG) System.err.println(simPlayer.name + " =>   bettingRound:" + bettingRound + " || simPlayer.toCall:" + simPlayer.toCall + " || simPlayer.previousAction:" + simPlayer.previousAction + " || simPlayer.previousToCall:" + simPlayer.previousToCall);
//			double foldProb = player.getSituationStore().getFrequency(bettingRound, simPlayer.toCall, simPlayer.previousAction, simPlayer.previousToCall, GameAction.ACTION_FOLD);
//			double callProb = player.getSituationStore().getFrequency(bettingRound, simPlayer.toCall, simPlayer.previousAction, simPlayer.previousToCall, GameAction.ACTION_CALL);
//			double raiseProb = player.getSituationStore().getFrequency(bettingRound, simPlayer.toCall, simPlayer.previousAction, simPlayer.previousToCall, GameAction.ACTION_RAISE);
			
			double foldProb = player.getSituationStore().getFrequency(bettingRound, simPlayer.toCall, 2, 2, GameAction.ACTION_FOLD);
			double callProb = player.getSituationStore().getFrequency(bettingRound, simPlayer.toCall, 2, 2, GameAction.ACTION_CALL);
			double raiseProb = player.getSituationStore().getFrequency(bettingRound, simPlayer.toCall, 2, 2, GameAction.ACTION_RAISE);
			
			if(DEBUG_PROBS) System.err.println(simPlayer.name + " =>   FOLD PROB: " + foldProb + " || CALL PROB: " + callProb + " || RAISE PROB: " + raiseProb);
			
			double rand = Math.random();
			
			if((rand < foldProb) && (player.getName() != "MYSELF")){
				doFold(simPlayer);
			}else if (rand > foldProb + callProb){
				doRaise(simPlayer);
			}else{
				doCall(simPlayer);
			}
		}
	}
	
	private void doFold(SimPlayer simPlayer){
//		delete simPlayer from simPlayers
//		Vector<SimPlayer> newSimPlayers = new Vector<SimPlayer>();
//		for(int i = 0; i < simPlayers.size(); i++){
//			SimPlayer tmpPlayer = simPlayers.get(i);
//			if(! tmpPlayer.equals(simPlayer)){
//				newSimPlayers.add(tmpPlayer);
//			}
//		}
//		simPlayers = newSimPlayers;
		
//		deactivate simPlayer
		simPlayer.stillInGame = false;
		activePlayers--;
		
		if(DEBUG) System.err.println(simPlayer.name + ">>  DO_FOLD (Pot: " + pot + ")");
		simPlayer.previousAction = 0;
	}
	
	private void doCall(SimPlayer simPlayer){
		pot += simPlayer.toCall;
		simPlayer.potAmount += simPlayer.toCall;
		if(DEBUG) System.err.println(simPlayer.name + ">>  DO_CALL (ToCall: " + simPlayer.toCall +" => Pot: " + pot + ")");
		
		simPlayer.toCall = 0;
		
		anzRecentCalls++;
		simPlayer.previousAction = 0;
		
	}

	private void doRaise(SimPlayer simPlayer){
		if((anzRaises >= 4) || ((bettingRound == GameSituation.STATE_PREFLOP) && (anzRaises >= 3)) ){
			doCall(simPlayer);
		}else{
			int betAmount = 2;
			if(bettingRound >= GameSituation.STATE_TURN){
				betAmount = 4;
			}
			
			pot += simPlayer.toCall + betAmount;
			simPlayer.potAmount += simPlayer.toCall + betAmount;
			if(DEBUG) System.err.println(simPlayer.name + ">>  DO_RAISE (ToCall: " + simPlayer.toCall +", betAmount: " + betAmount + " => Pot: " + pot + ")");
			
			updateToCall(simPlayers.indexOf(simPlayer), betAmount);
			
			anzRaises++;
			anzRecentCalls = 0;
			simPlayer.previousAction = 1;
		}
	}
	
	private void updateToCall(int raisePosition, int betAmount){
		for(int i = 0; i < simPlayers.size(); i++){
			if((i != raisePosition)){
				simPlayers.get(i).toCall += betAmount;
			}else{
				simPlayers.get(i).previousToCall = simPlayers.get(i).toCall;
				simPlayers.get(i).toCall = 0;
			}
		}
	}
	
	private int getAnzRaises(Vector<GameAction> actions){
		int raises = 0;
		
		for(int i = 0; i < actions.size(); i++){
			if(actions.get(i).getType() == GameAction.ACTION_RAISE){
				raises++;
			}
		}
		
		return raises;
	}
	
	
	private int getAnzRecentCalls(Vector<GameAction> actions){
		int anzRecentCalls = 0;
		
		int i = Math.max(actions.size() -1, 0);
		while((i >= 0 ) && (actions.get(i).getType() == GameAction.ACTION_CALL)){
			anzRecentCalls++;
			i--;
		}
		
		return anzRecentCalls;
	}
}
