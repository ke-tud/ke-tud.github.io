package bot.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Vector;


public class ResultsMatchStateConverter {
	
	public static int getPositionOfPlayer(String resultString, String playerName){
		String[] players = resultString.split(":")[0].replace("|", ":").split(":");
		
		int pPos=-1;
		for (int i=0; i<players.length; i++) {
			if (players[i].equals(playerName)){
				pPos = i;
			}
		}
		if (pPos == -1)
			System.err.println("Player " + playerName + " does not exist.");
		
		return pPos;
	}
	
	public static String convertResultToMatchState(String resultString, String ownPlayerName) throws Exception {
		// Bot|Raise1:15:rc/crc/crc/crc:AhKc|2d4h/Ks2h4d/4c/Qc:-14|14
		
		// MATCHSTATE:1:0:crc/rc/rc/rc:KsJh|3h6s/Qc9hTs/4s/9d
		
		int pPos = getPositionOfPlayer(resultString, ownPlayerName);
				
		String msPos = "" + pPos;
		String msRound = resultString.split(":")[1];
		String msBetSeq = resultString.split(":")[2];
		String msCardStr = resultString.split(":")[3];;
		
		String msString = "MATCHSTATE:" + msPos + ":" + msRound + ":" + msBetSeq + ":" + msCardStr;
		
		return msString;
	}
	
	public static Hashtable<String, Vector<GameSituation>> getSituations(String resultFile) throws FileNotFoundException, IOException {
		Vector<String> histories = new Vector<String>();
		LineReader fr = new LineReader(resultFile);
		String line = "";
		while ((line = fr.readLine()) != null) {
			histories.add(line);
		}
		
//		history.replace("\r", "");
//		String[] histories = history.split("\n");
		
		Hashtable<String, Vector<GameSituation>> playerSituations = new Hashtable<String, Vector<GameSituation>>();
		
		
		for (int i=0; i<histories.size(); i++) {
			System.out.println("ResultsMatchStateConverter> Parsing Hand " + i);
			String[] players = histories.get(i).split(":")[0].replace("|", ":").split(":");
			for (int j=0; j<players.length; j++) {
				System.out.println("ResultsMatchStateConverter> Parsing Player " + players[j]);
				if (!playerSituations.containsKey(players[j])) {
					playerSituations.put(players[j], new Vector<GameSituation>());
				}

				try {
					GameSituation tempGS = new GameSituation();
					tempGS.updateSituation(convertResultToMatchState(histories.get(i), players[j]));
					playerSituations.get(players[j]).add(tempGS);
				}
				catch (Exception e) {
					System.out.println("ResultsMatchStateConverter> Could not parse Hand: " + histories.get(i) + " for Player " + players[j]);
					System.out.println("ResultsMatchStateConverter> Reason: " + e.getMessage());
				}

			}
		}
		
		return playerSituations;

	}

	public static Hashtable<String, Vector<GameSituation>> getSituations(String resultFile, String playerName) throws FileNotFoundException, IOException {
		Vector<String> histories = new Vector<String>();
		LineReader fr = new LineReader(resultFile);
		String line = "";
		while ((line = fr.readLine()) != null) {
			if(! line.startsWith("#")){
				histories.add(line);
			}
		}
		
//		history.replace("\r", "");
//		String[] histories = history.split("\n");
		
		Hashtable<String, Vector<GameSituation>> playerSituations = new Hashtable<String, Vector<GameSituation>>();
		
		for (int i=0; i<histories.size(); i++) {
//			System.out.println("ResultsMatchStateConverter> Parsing Hand " + i);
			
			
//				System.out.println("ResultsMatchStateConverter> Parsing Player " + playerName);
				if (!playerSituations.containsKey(playerName)) {
					playerSituations.put(playerName, new Vector<GameSituation>());
				}

				try {
					GameSituation tempGS = new GameSituation();
					tempGS.updateSituation(convertResultToMatchState(histories.get(i), playerName));
					playerSituations.get(playerName).add(tempGS);
				}
				catch (Exception e) {
					System.out.println("ResultsMatchStateConverter> Could not parse Hand: " + histories.get(i) + " for Player " +playerName);
					System.out.println("ResultsMatchStateConverter> Reason: " + e.getMessage());
				}

		}
		
		return playerSituations;

	}
	
	public static int getNumberRounds(String resultFile) throws FileNotFoundException, IOException {
		int anzRounds = 0;
		LineReader fr = new LineReader(resultFile);
		String line = "";
		while ((line = fr.readLine()) != null) {
			if(! line.startsWith("#")){
				anzRounds++;
			}
		}
		
		return anzRounds;
	}
	
	private static Vector<String> histories = null;
	private static String aktResultFile = "";
	
	private static void loadHistories(String resultFile) throws FileNotFoundException, IOException {
		if((histories == null) || (! aktResultFile.equals(resultFile))){
			histories = new Vector<String>();
			aktResultFile = resultFile;
			
			LineReader fr = new LineReader(resultFile);
			String line = "";
			while ((line = fr.readLine()) != null) {
				if(! line.startsWith("#")){
					histories.add(line);
				}
			}
		}
		
	}
	
	public static GameSituation getSituationAtRound(String resultFile, String playerName, int round){
		
		try {
			loadHistories(resultFile);
		} catch (Exception e) {
			System.out.println("loadHistories(resultFile) => ERROR!!!");
		}
		
		GameSituation gameSituation = new GameSituation();
		try {
			gameSituation.updateSituation(convertResultToMatchState(histories.get(round), playerName));
		}
		catch (Exception e) {
			System.out.println("ResultsMatchStateConverter> Could not parse Hand: " + histories.get(round) + " for Player " +playerName);
			System.out.println("ResultsMatchStateConverter> Reason: " + e.getMessage());
		}
		
		return gameSituation;

	}

	public static int getPositionOfPlayerAtRound(String resultFile, String playerName, int round) throws FileNotFoundException, IOException {
		try {
			loadHistories(resultFile);
		} catch (Exception e) {
			System.out.println("loadHistories(resultFile) => ERROR!!!");
		}
		
		try {
			return getPositionOfPlayer(histories.get(round), playerName);
		}
		catch (Exception e) {
			System.out.println("ResultsMatchStateConverter> Could not parse Hand: " + histories.get(round) + " for Player " +playerName);
			System.out.println("ResultsMatchStateConverter> Reason: " + e.getMessage());
		}
		
		return -1;
	}
}
