package bot.utils;


public class Card implements Comparable<Card> {
	
	public static final int DIAMOND = 0,	// Karo
							HEART = 1,		// Herz
							SPADE = 2,		// Pik
							CLUB = 3;		// Kreuz
	
	public static final int N2 = 2,
							N3 = 3,
							N4 = 4,
							N5 = 5,
							N6 = 6,
							N7 = 7,
							N8 = 8,
							N9 = 9,
							NT = 10,
							NJ = 11,
							NQ = 12,
							NK = 13,
							NA = 14;
	
	private int number;
	private int color;

	
	public boolean equals(Card c) {
		if (c.color != color)
			return false;
		if (c.number != number)
			return false;
		
		return true;
	}
	
	public int getNumber() {
		return number;
	}
	
	public int getColor() {
		return color;
	}
	
	public String toString() {
		String out = "";
		
		if (number <= N9) 
			out += number;
		else if (number == NT)
			out += "T";
		else if (number == NJ)
			out += "J";
		else if (number == NQ)
			out += "Q";
		else if (number == NK)
			out += "K";
		else if (number == NA)
			out += "A";
		
		if (color == CLUB)
			out += "c";
		else if (color == DIAMOND)
			out += "d";
		else if (color == HEART)
			out += "h";
		else if (color == SPADE)
			out += "s";
		
		
		return out;
	}
	
	public String toPlainString() {
		String out = "";
		
		if (number <= N9) 
			out += number;
		else if (number == NT)
			out += "T";
		else if (number == NJ)
			out += "J";
		else if (number == NQ)
			out += "Q";
		else if (number == NK)
			out += "K";
		else if (number == NA)
			out += "A";
		return out;
	}
	
	public int compareTo(Card c) {
		if (number < c.number)
			return 1;
		if (number > c.number)
			return -1;
		else
			return 0;
		// TODO evtl Farben mit rein
	}
	
	public Card(int color, int number) {
		this.number = number;
		this.color = color;
	}
	
	
	public Card(String cString) {
		Card c = CardParser.parseCard(cString);
		number = c.number;
		color = c.color;
	}

}
