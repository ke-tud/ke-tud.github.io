package bot.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;

public class GameSituation {
	
	private int round;
	private int position;
	private int state;
	private int playerCount;
	private Vector<Player> players;
	private Vector<Card> ownCards;
	private Vector<Card> flopCards;
	private Card turnCard;
	private Card riverCard;
	private Vector<GameAction> actions;
	
	private int pot = 0;
	private int[] playerInset = new int[playerCount];
	private int[] sbToCall = new int[playerCount];
	
	private boolean[] playerInGame;
	private Vector<Vector<Card>> playerCards;
	private String currentSituationString;
	private Player betWinner;
	private boolean initiated;
	private Combination winnerCombo;
	
	private static final boolean DEBUG_POT = false;
	
	public static final int STATE_PREFLOP = 0,
							STATE_FLOP = 1,
							STATE_TURN = 2,
							STATE_RIVER = 3;
	
	public int getRound() {
		return round;
	}
	
	public int extractPlayerCount() {
		String allCardString = currentSituationString.split(":")[4].split("/")[0].replace("|",":");
		
		int count = 1;
		for (int i=0; i<allCardString.length(); i++) {
			if (allCardString.charAt(i) == ':')
				count++;
		}

		
		return count;
	}
	
	public int getPlayerCount() {
		return playerCount;
	}
	
	public int getPosition() {
		return position;
	}
	
	
	public int getState() {
		return state;
	}
	
	public Vector<Card> getOwnCards() {
		return ownCards;
	}
	
	public Vector<Vector<Card>> getPlayerCards() {
		return playerCards;
	}
	
	public Vector<Card> getFlopCards() {
		return flopCards;
	}
	
	public Card getTurnCard() {
		return turnCard;
	}
	
	public Card getRiverCard() {
		return riverCard;
	}
	
	public Vector<Player> getPlayers() {
		return players;
	}
	
	public Player getOwnPlayer() {
		return players.get(position);
	}
	
	public Vector<GameAction> getActions() {
		return actions;
	}
	
	public void addAction(GameAction newAction){
		actions.add(newAction);
	}
	
	public void addActions(Vector<GameAction> newActions){
		actions.addAll(newActions);
	}
	
	public void setActions(Vector<GameAction> newActions){
		actions = newActions;
	}
	
	public boolean isNewRound(String situation) {
		int newRound = extractRound(situation);
		
		if (round != newRound)
			return true;
		else
			return false;
	}
	
	public Player getSmallBlindPlayer() {
		return players.get(0);
	}
	
	public Player getMyPlayer() {
		return players.get(position);
	}
	
	public Player getBigBlindPlayer() {
		return players.get(1);
	}
	
	public double getPotOdds() {
		if (pot == 0)
			return 1;
		
//		System.out.println("PO: " + pot + " " + getAmountToCall());
		
		return (double) getAmountToCall() / ((double) pot + (double) getAmountToCall());
	}
	
	public void initiate() {

		position = extractPosition(currentSituationString);
		playerCount = extractPlayerCount();
		
		players = new Vector<Player>();
		for (int i=0; i<playerCount; i++) {
			if (i == position)
				players.add(new Player(Config.PLAYER_NAME)); // mit Namen etc.
			else	
				players.add(new Player("P_" + i)); // mit Namen etc.
			
		}
		
		if (Config.DEBUG_GLOBAL)
//			System.out.println(getClass().getSimpleName() + "> initiated: players="+playerCount + ", " + players);
		
		playerInset = new int[playerCount];
		sbToCall = new int[playerCount];
			
		initiated = true;
	}

	public boolean cameToShowDown() {
		String allCardString = currentSituationString.split(":")[4].split("/")[0];
		String[] myCardString = allCardString.replace("|", ":").split(":");

		
		int cCount = 0;
		for (int i=0; i<myCardString.length; i++) {
			if (myCardString[i].length() > 1)
				cCount++; 
		}
		
		if (cCount > 1)
			return true;
		return false;
	}
	
	
	
	public Vector<GameAction> getActionsInRound(int round) {
		Vector<GameAction> out = new Vector<GameAction>();
		
		if (actions == null)
			return out;
		
		for (int i=0; i<actions.size(); i++) {
			if (actions.get(i).getSituation() == round)
				out.add(actions.get(i));
		}
		
		return out;
	}
	
	public Vector<GameAction> getActionsFromPlayer(Player p) {
		Vector<GameAction> out = new Vector<GameAction>();
		
		if (actions == null)
			return out;
		
		for (int i=0; i<actions.size(); i++) {
			if (actions.get(i).getPlayer() == p)
				out.add(actions.get(i));
		}
		
		return out;
	}
	
	public Vector<GameAction> getActionsFromPlayerInSituation(Player p, int state) {
		Vector<GameAction> out = new Vector<GameAction>();
		
		if (actions == null)
			return out;
		
		for (int i=0; i<actions.size(); i++) {
			if (actions.get(i).getPlayer().getName().equals(p.getName()) && actions.get(i).getSituation() == state)
				out.add(actions.get(i));
		}
		
		return out;
	}
	
	public String getSituationString() {
		return currentSituationString;
	}
	
	public Vector<GameAction> getMyActions() {
		Vector<GameAction> out = new Vector<GameAction>();
		
		if (actions == null)
			return out;
		
		for (int i=0; i<actions.size(); i++) {
			if (actions.get(i).getPlayer() == players.get(position))
				out.add(actions.get(i));
		}
		
		return out;
	}
	
	public Vector<Card> getBoardCards() {
		Vector<Card> temp = new Vector<Card>();
		
		if (flopCards != null) temp.addAll(flopCards);
		if (turnCard != null) temp.add(turnCard);
		if (riverCard != null) temp.add(riverCard);
		
		return temp;
	}
	
	public Vector<Player> getWinners() {
		if (betWinner != null) {
			Vector<Player> winners = new Vector<Player>();
			winners.add(betWinner);
//			System.out.println("BET " + winners);
			return winners;
		}
		
		else {
			Vector<Player> winners = determineCardWinners();
//			System.out.println("CARD " + winners);
			return winners;
		}
	}
	
	public boolean haveIWon() {
    	Vector<Player> winners = getWinners();
    	if (winners == null)
    		return false;
    	

    	for (int i=0; i<winners.size(); i++) {
    		if (winners.get(i).getName().equals(Config.PLAYER_NAME))
    			return true;
    	}
    	return false;
	}
	
	public boolean isHandFinished() {
		if (betWinner != null || cameToShowDown())
			return true;
		return false;
	}
	
	public Vector<Player> determineCardWinners() {
		Combination highest = new Highest(new Card(Card.CLUB,Card.N2));
		Vector<Player> winners = new Vector<Player>();
		
		for (int i=0; i<playerCards.size(); i++) {
			Vector<Card> pCards = playerCards.get(i);
			if (isPlayerInGame(players.get(i)) && pCards != null) {
//				Vector<Card> allCards = new Vector<Card>();
//			
//				allCards.addAll(getBoardCards());
//				allCards.addAll(pCards);
//			
//
//				System.out.print("# All Cards of " + i + ": " + allCards);
				
				FullCombo fc = new FullCombo(pCards.toArray(new Card[1]), getBoardCards().toArray(new Card[1]));
				Combination pComb = fc.getBestCombo();

//				Combination pComb = Analyzer.test(allCards);
//				System.out.println(" --> " + pComb);
				
				
				if (pComb.isHigherThan(highest) > 0) {
					winners = new Vector<Player>();
					winners.add(players.get(i));
					highest = pComb;
				}
				else if (pComb.isHigherThan(highest) == 0) {
					winners.add(players.get(i));
				}
			}
		}
		
		winnerCombo = highest;
		
//		System.out.println("# Winners: " + winners + " Comb: " + highest);
		
//		if(winners.size() > 1){
//			System.out.println(this.getClass() + " => anzWinner: " + winners.size());
//			
//			System.out.print("# BoardCards: " + getBoardCards());
//			for (int i=0; i<playerCards.size(); i++) {
//				System.out.println("HandCards of " + i + " : " + playerCards.get(i) + "Position:" + players.indexOf(players.get(i)));
//			}
//			System.out.println();
//			System.out.println("# Winners: " + winners + " Comb: " + highest);
//		}
		
		return winners;
	}
	
	public void updateSituation(String situation) {
		boolean debug = false;
		
		currentSituationString = situation;
		
		if (initiated == false){
			initiate();
			initPlayerInGame();
		}
		
		position = extractPosition(situation);
		
		if (isNewRound(situation)){
			initPlayerInGame();
			rotate(players);
			
			if(debug){
				System.out.println(getClass().getSimpleName() + "> this:" + this);
			}
		}
			
		round = extractRound(situation);
		ownCards = extractOwnCards(situation, position);
		flopCards = extractFlopCards(situation);
		turnCard = extractTurnCard(situation);
		riverCard = extractRiverCard(situation);
		
		if (riverCard != null) state = STATE_RIVER;
		else if (turnCard != null) state = STATE_TURN;
		else if (flopCards != null) state = STATE_FLOP;
		else state = STATE_PREFLOP;

		 actions = extractGameActions(situation);
		 
		 if (actions != null){
			 updatePot();
		 }
		 
//		 if (isHandFinished() && cameToShowDown()){
//			 playerCards = extractPlayerCards(situation);
//		 }
		 if (isHandFinished()){
			 playerCards = extractPlayerCards(situation); 
		 }
						 
		 if(isHandFinished()){
			 int[] playerWin = getPlayerWin();
			 
			 for(int i = 0; i < playerCount; i++){
				 getPlayers().get(i).addWin(playerWin[i]);
			 }
		 }
	}
	
	public int getAmountToCallFromPlayer(Player p){
		int position = players.indexOf(p);
		
		return sbToCall[position];
	}
	
	public int getAmountToCall(){
		return sbToCall[getPosition()];
	}

	public int getPlayerWin(int p){
		int[] playerWin = getPlayerWin();
		return playerWin[p];
	}
	
	private int[] getPlayerWin(){
		int[] playerWin = new int[playerCount];
		
		int restGewinn = -1;
		Vector<Player> cardWinners = getWinners();
		int anzWinner = cardWinners.size();

		if(anzWinner > 1){ // tie
			for (int i = 0; i < playerCount; i++){
				boolean isWinner = false;
				for (int j = 0; j < anzWinner; j++){
					int winnerPosition = getPlayers().indexOf(cardWinners.get(j));
					if(i == winnerPosition){
						isWinner = true;
//						continue;
					}
				}
				
				if (isWinner){
					playerWin[i] = Math.round(pot / anzWinner) - playerInset[i];
					
					if(restGewinn == -1){
						restGewinn = pot % anzWinner;
					}
					
					if(restGewinn > 0){
						playerWin[i]++;
						restGewinn--;
					}
					
				}else{
					playerWin[i] = - playerInset[i];
				}
			}
		}else{ // win
			int winnerPosition = getPlayers().indexOf(cardWinners.get(0));
			for (int i = 0; i < playerCount; i++){
				if(i == winnerPosition){
					playerWin[i] = pot - playerInset[i];
				}else{
					playerWin[i] = - playerInset[i];
				}	
			}
		}
		return playerWin;
	}
	
	private int[] updateSBtoCall(int[] sbToCall, int raisePosition, int sbCount, boolean[] activePlayers){
		for(int i = 0; i < playerCount; i++){
			if((i != raisePosition)){
				sbToCall[i] += sbCount;
				if (DEBUG_POT && (sbToCall[i] > 16)) System.err.println("!!!!!!!!!!!!sbToCall[i] > 16 => sbToCall[i] = " + sbToCall[i] + "  !!!!!!!!!!!!!!!!!");
			}else{
				sbToCall[i] = 0;
			}
			
			if(activePlayers[i] == false ){
				sbToCall[i] = -1;
				if (DEBUG_POT) System.err.println(players.get(i).getName() + " => NOT IN GAME!");
			}
		}
		return sbToCall;
	}
	
	private void updatePot() {
		
		playerInset = new int[playerCount];
		sbToCall = new int[playerCount];
		
		boolean[] activePlayers = new boolean[playerCount];
		for(int i = 0; i < playerCount; i++){
			activePlayers[i] = true;
		}

		
		
//		for 6 player game
//		if(playerCount > 2){
//			init Blinds:
			pot = Config.SMALL_BLIND + Config.BIG_BLIND;
			
			playerInset[0] = Config.SMALL_BLIND;
			playerInset[1] = Config.BIG_BLIND;
			
			sbToCall[0] = Config.SMALL_BLIND;
			sbToCall[1] = 0;
			
//			init smallBlindsToCallArray:
			for (int i=2; i < playerCount; i++) {
				sbToCall[i] = Config.BIG_BLIND;
			}
//		}else{
////			init Blinds:
//			pot = Config.SMALL_BLIND;
//			
//			playerBets[0] = Config.SMALL_BLIND;
//			sbToCall[1] = Config.SMALL_BLIND;
//		}

		Iterator<GameAction> avtionIter = actions.iterator();
		while (avtionIter.hasNext()){
			GameAction tmpAction = avtionIter.next();
			Player tmpPlayer = tmpAction.getPlayer();
			
			int position = players.indexOf(tmpPlayer);
			
			if (DEBUG_POT) System.err.println("sbToCall: " + Arrays.toString(sbToCall) + " || playerInset: " + Arrays.toString(playerInset));
			
			if(tmpAction.getType() == GameAction.ACTION_RAISE){
				pot += sbToCall[position];
				playerInset[position] += sbToCall[position];
				
				if(tmpAction.getSituation() <= STATE_FLOP){
					pot += Config.SMALL_BET_AMOUNT;
					playerInset[position] += Config.SMALL_BET_AMOUNT;
					updateSBtoCall(sbToCall, position, Config.SMALL_BET_AMOUNT, activePlayers);
				}else{
					pot += Config.BIG_BET_AMOUNT;
					playerInset[position] += Config.BIG_BET_AMOUNT;
					updateSBtoCall(sbToCall, position, Config.BIG_BET_AMOUNT, activePlayers);
				}
				
				if (DEBUG_POT) System.err.println(tmpPlayer.getName() + " => RAISE!!");
			} else if(tmpAction.getType() == GameAction.ACTION_CALL){
				pot += sbToCall[position];
				playerInset[position] += sbToCall[position];
				sbToCall[position] = 0;
				
				if (DEBUG_POT) System.err.println(tmpPlayer.getName() + " => CALL!!");
			} else if(tmpAction.getType() == GameAction.ACTION_FOLD){
				sbToCall[position] = -1;
				activePlayers[position] = false;
				
				if (DEBUG_POT) System.err.println(tmpPlayer.getName() + " => FOLD!!");
			}
		}
	}
	
	private void initPlayerInGame() {
		playerInGame = new boolean[playerCount];
		
		for (int i=0; i<playerInGame.length; i++) {
			playerInGame[i] = true;
		}
		
//		Iterator<GameAction> avtionIter = actions.iterator();
//		while (avtionIter.hasNext()){
//			GameAction tmpAction = avtionIter.next();
//			int position = players.indexOf(tmpAction.getPlayer()); //tmpAction.getPlayer().getPosition();
//			
//			if(tmpAction.getType() == GameAction.ACTION_FOLD){
//				playerInGame[position] = false;
////				System.out.println("Player " + position + " => FOLD");
//			}
//		}
	}
	
	public Player getPlayerOnMove(){
		int lastActionPosition = -1;
		int aktPosition = 0;
		
		if (isHandFinished())
			return null;
		
		if (actions == null || getActionsInRound(state).size() == 0) {
			
			if(playerCount == 2){
				//	falls HeadsUp
				if(getState() == STATE_PREFLOP){
					aktPosition = 1 % playerCount;
				}else{
					aktPosition = 0;
				}
			}else{
				//	falls kein HeadsUp
				if(getState() == STATE_PREFLOP){
					aktPosition = 2 % playerCount;
				}else{
					aktPosition = 0;
				}
			}
			while(! playerInGame[aktPosition]){
				aktPosition = (aktPosition + 1) % playerCount;
			}
				
			return players.get(aktPosition);
		}else{
			lastActionPosition = players.indexOf(actions.lastElement().getPlayer());
			aktPosition = (lastActionPosition + 1) % playerCount;
			
			while(! playerInGame[aktPosition]){
				aktPosition = (aktPosition + 1) % playerCount;
			}
		}
		
		return players.get(aktPosition);
	}

	
	public boolean amIOnMove(){
		if (isHandFinished())
			return false;
		
		Player p = getPlayerOnMove();
		
		if (p == null)
			return true;
		else if (p == players.get(position))
			return true;
		else
			return false;
		
		
	}
	
	public String toString() {
		String out = "Public Game State\n-------------------------------------\n";
		out += "Game-String: " + currentSituationString + "\n";
		out += "Round: " + round + "\n";
		out += "State: " + state + "\n";
		out += "Players: " + players + "\n";
		out += "Position: " + position + "\n";
		if (ownCards != null) out += "Own Cards: " + ownCards.get(0) + " " + ownCards.get(1) + "\n";
		
		if (playerCards != null) {
			for (int i=0; i<playerCards.size(); i++) {
				if (i != position && playerCards.get(i) != null && playerCards.get(i).size() > 0) {
					out += "Player Cards (" + i + "): " + playerCards.get(i).get(0) + " " + playerCards.get(i).get(1)+ "\n";
				}
				else if (playerCards.get(i) == null) {
					out += "Player Cards (" + i + "): not shown\n";
				}
			}
		}
		
		out += "Board Cards: ";
		if (flopCards != null) {
			out +=flopCards.get(0) + " " + flopCards.get(1) + " " + flopCards.get(2) + " ";
		}
		if (turnCard != null) {
			out += "| " + turnCard + " ";
		}
		if (riverCard != null) {
			out += "| " + riverCard;
		}
		out += "\n";
		if (actions != null) {
			for (int i=0; i<actions.size(); i++) {
				out += actions.get(i) + "\n";
			}
		}
		
		out += "Pot: " + pot + "\n";
		if (isHandFinished()) {
			out += "Winners: " + getWinners();
			if (betWinner != null)
				out += " BET" + "\n";
			else
				out += " Combo: " + winnerCombo + " Board: " + getBoardCards() + "\n";
		}
		out += "-------------------------------------\n";
		
		return out;
	}
	
	public static int extractPosition(String situation) {
		return Integer.parseInt(situation.split(":")[1]);
	}
	
	public static String extractBetSequence(String situation) {
		return situation.split(":")[3];
	}
	
	public static int extractRound(String situation) {
		return Integer.parseInt(situation.split(":")[2]);
	}
	
	public Vector<Vector<Card>> extractPlayerCards(String situation) {
		Vector<Vector<Card>> players = new Vector<Vector<Card>>();
			
		for (int i=0; i<playerCount; i++) {
			Vector<Card> pCards = extractOwnCards(situation, i);
//				if (pCards != null)
				players.add(pCards);
		}
		return players;
	}
	
	public static Vector<Card> extractOwnCards(String situation, int pos) {
		try {
			String allCardString = situation.split(":")[4].split("/")[0];
			String myCardString = allCardString.replace("|", ":").split(":")[pos];
	
//			System.out.println("P sit=" + situation + " pos=" + pos + " mC=" + myCardString);
	
			Card c1 = CardParser.parseCard(myCardString.substring(0,2));
			Card c2 = CardParser.parseCard(myCardString.substring(2,4));
			
			Vector<Card> cards = new Vector<Card>();
			cards.add(c1);
			cards.add(c2);	
			
			return cards;
		}
		catch (Exception e) {
			return null;
		}
	}
	
	public static String extractBetSequenceNr(String situation, int nr) {
		String[] overall = extractBetSequence(situation).split("/");
		return overall[nr];
		
	}

	public Vector<GameAction> extractGameActions(String situation) {
			actions = new Vector<GameAction>();
			
			// TODO Player-Objekte konsistent lassen
			Vector<Player> players = new Vector<Player>();
			players.addAll(this.players);
			
			for (int i=STATE_PREFLOP; i<=state; i++) {
				try {
					String seq = extractBetSequenceNr(situation, i);

				
					int position = -1;
					

					if(playerCount == 2){
						//	falls HeadsUp
						if (i == STATE_PREFLOP){
							position = (1 % players.size()); 
						}else{
							position = 0;
						}
					}else{
						//	falls kein HeadsUp
						if (i == STATE_PREFLOP){
							position = (2 % players.size()); 
						}else{
							position = 0;;
						}
					}
					
					
					for (int j=0; j<seq.length(); j++) {
						GameAction currentAction = new GameAction(players.elementAt(position), getActionFromChar(seq.charAt(j)), i, getAmountToCallFromPlayer(players.elementAt(position)));
						actions.add(currentAction);
						
						if (currentAction.getType() == GameAction.ACTION_FOLD){
							players = safeRemove(players, currentAction.getPlayer());
							playerInGame[this.players.indexOf(currentAction.getPlayer())] = false;
							
							// wenn der letzte Player im Vector gel�scht wird, muss position wieder auf 0 gesetzt werden!!							
							if(position > players.size() -1){
								position = 0;
							}
						}else if(position == players.size() -1){
							position = 0;
						}else{
							// position darf bei fold nicht erh�ht werden!							
							position++;
						}
					}
				}catch (Exception e) {
//					e.printStackTrace();
				}
			}
			
			// Gewinner nach bieten
			if (players.size() == 1)
				betWinner = players.firstElement();
			else
				betWinner = null;
			

			
			return actions;
	}
	
	public static Vector<Player> safeRemove(Vector<Player> p, Player e) {
		Vector<Player> out = new Vector<Player>();
		for (int i=0; i<p.size(); i++) {
			if (p.elementAt(i) != e)
				out.add(p.elementAt(i));
		}
		
		return out;
	}
	
	public void rotate(Vector<Player> in) {
		while(! Config.PLAYER_NAME.equals(in.get(position).getName())){
			Collections.rotate(in, -1);
		}
	}
	
	public static int getActionFromChar(char c) {
		if (c == 'c') return GameAction.ACTION_CALL;
		if (c == 'f') return GameAction.ACTION_FOLD;
		if (c == 'r') return GameAction.ACTION_RAISE;
		
		return -1;
	}
	
	public static String getActionFromInt(int i) {
		if (i == GameAction.ACTION_CALL) return "CALL";
		if (i == GameAction.ACTION_FOLD) return "FOLD";
		if (i == GameAction.ACTION_RAISE) return "RAISE";
		return "UNKNOWN ACTION";
	}
	
	public static Vector<Card> extractFlopCards(String situation) {
		try { 
			
//			String allCardString = situation.split(":")[4].replace("|", ":").split("/")[1]; 
			
			String allCardString = situation.split(":")[4].split("/")[1]; 

			Card c1 = CardParser.parseCard(allCardString.substring(0,2));
			Card c2 = CardParser.parseCard(allCardString.substring(2,4));
			Card c3 = CardParser.parseCard(allCardString.substring(4,6));
			
			Vector<Card> cards = new Vector<Card>();
			cards.add(c1);
			cards.add(c2);	
			cards.add(c3);	
			
			return cards;
		}
		catch (Exception e) {
//			System.out.println(e);
			return null;
		}
	}
	
	public static Card extractTurnCard(String situation) {
		try { 
			
//			String allCardString = situation.split(":")[4].replace("|", ":").split("/")[2]; 
			String allCardString = situation.split(":")[4].split("/")[2]; 

			Card c1 = CardParser.parseCard(allCardString.substring(0,2));

			
			return c1;
		}
		catch (Exception e) {
			return null;
		}
	}
	
	public static Card extractRiverCard(String situation) {
			try { 
				
//				String allCardString = situation.split(":")[4].replace("|", ":").split("/")[3]; 
				String allCardString = situation.split(":")[4].split("/")[3]; 
	
				Card c1 = CardParser.parseCard(allCardString.substring(0,2));
	
	//			System.out.println("RIVER: " + c1);
				return c1;
			}
			catch (Exception e) {
				return null;
			}
		}

	public GameSituation() {
		initiated = false;
	}

	public int getPlayerInsets(Player player) {
		return playerInset[players.indexOf(player)];
	}

	public int getPot(){
		return pot;
	}
	
	public int getMyAmountOfPot(){
		return playerInset[position];
	}
	
	public boolean isPlayerInGame(Player player) {
		return playerInGame[players.indexOf(player)];
	}
	
	public int getPlayersInHand() {
		int numbActivePlayer = 0;
		for(int i = 0; i < playerCount; i++){
			if(playerInGame[i]){
				numbActivePlayer++;
			}
		}
		return numbActivePlayer;
	}

}
