package bot.utils;

import java.util.Vector;

import bot.BaseBot;
import bot.opponent.Hand;
import bot.opponent.SituationStore;
import bot.pokertools.PreFlopChart;
import bot.utils.analyzer.Combination;

public class ShowdownSimulator {

	private static final boolean DEBUG = false;
	private static final int EXCEPTION_THRESHOLD = 2000;

	private int players;
	private Vector<Card> myCards;
	private Vector<Card> boardCards;
	private Vector<Card> tabuCards;
	private Vector<Vector<Card>> enemyCards;
	
	private Vector<Vector<Hand>> enemyCardRange;
	private Vector<SituationStore> enemySituationStores;
	private PotSimulator potSim;
	private GameSituation gameSituation;
	
	
	private PreFlopChart preFlopChart;
	
	private int wins = 0;
	private int ties = 0;
	private int losses = 0;
	private int simulations = 0;
	private int winAmount = 0;
	
	private boolean isCardTabu(Card c) {
		for (Card t : tabuCards) {
			if (c.equals(t))
				return true;
		}
		return false;
	}
	
	private Vector<Card> getEnemyCards(int playerNr) throws Exception {
		int nr = 0;
		int i = 0;
		
		// Ohne PreFlop_percentage
		if (enemySituationStores.get(playerNr) == null) {
			do {
				nr = (int) (Math.random() * enemyCards.size());
				i++;
				
				if (i>EXCEPTION_THRESHOLD)
					throw new Exception("Konnte keine Gegner-Karten zuweisen.");
				
			} while (isCardTabu(enemyCards.get(nr).get(0)) || isCardTabu(enemyCards.get(nr).get(1)));

			return enemyCards.get(nr);
		}
		else {
		
			// Mit PreFlop-Range Gegner
			preFlopChart.setPlayPercentage(1 - enemySituationStores.get(playerNr).getFrequency(GameSituation.STATE_PREFLOP, 3, 2, 2, GameAction.ACTION_FOLD));
			do {
				nr = (int) (Math.random() * enemyCards.size());
				i++;
				
				
				if (i>EXCEPTION_THRESHOLD)
					throw new Exception("Konnte keine Gegner-Karten zuweisen.");
				
			} while (isCardTabu(enemyCards.get(nr).get(0)) || isCardTabu(enemyCards.get(nr).get(1)) || !preFlopChart.shouldPlay(enemyCards.get(nr)));

			return enemyCards.get(nr);
		}
	}
	
	private Vector<Card> getEnemyCardsFromRange(int playerNr) throws Exception {
		int nr = 0;
		int i = 0;
		
		if (enemyCardRange.get(playerNr) == null || enemyCardRange.get(playerNr).size() == 0) {
//			System.err.println(getClass().getSimpleName() + "> Konnte keine Gegner-Karten zuweisen, CardRange=0.");
			return getEnemyCards(playerNr);
		}
		
		
		do {
			double rnd = Math.random();
			double sum = 0;
			for (int j=0; j<enemyCardRange.get(playerNr).size(); j++) {
				sum += enemyCardRange.get(playerNr).get(j).getNormWeight();
				if (sum >= rnd) {
					nr = j;
					break;
				}
			}
//			nr = (int) (Math.random() * enemyCardRange.get(playerNr).size());
			i++;

			if (i>EXCEPTION_THRESHOLD) {
//				throw new Exception("Konnte keine Gegner-Karten zuweisen.");
				return getEnemyCards(playerNr);
			}
			
			
			
		} while (isCardTabu(enemyCardRange.get(playerNr).get(nr).getHand().get(0)) || isCardTabu(enemyCardRange.get(playerNr).get(nr).getHand().get(1)));
		
		
//		System.out.println(getClass().getSimpleName() + "> " + enemyCardRange.get(playerNr).get(nr).getHand() + " -> " + enemyCardRange.get(playerNr).get(nr).getWeight());
		return enemyCardRange.get(playerNr).get(nr).getHand();
	}
	
	private Card getCard() throws Exception {
		Card c = null;
		int i = 0;
		do {
			int nr = (int) (Math.random() * 13) + 2;
			int col = (int) (Math.random() * 4);
			
			c = new Card(col, nr);
			
			i++;
			if (i>EXCEPTION_THRESHOLD)
				throw new Exception("Konnte keine Gegner-Karten zuweisen.");

			
		} while (isCardTabu(c));
		
		return c;
	}
	
	private boolean shouldPlayerPlay(int playerNr) {
		if (enemySituationStores.get(playerNr) == null)
			return true;
		
		double flopFold = enemySituationStores.get(playerNr).getFrequency(GameSituation.STATE_FLOP, 3, 2, 2, GameAction.ACTION_FOLD);
		double turnFold = enemySituationStores.get(playerNr).getFrequency(GameSituation.STATE_TURN, 3, 2, 2, GameAction.ACTION_FOLD);
		double riverFold = enemySituationStores.get(playerNr).getFrequency(GameSituation.STATE_RIVER, 3, 2, 2, GameAction.ACTION_FOLD);

//		double flopFold = 0.5d;
//		double turnFold = 0.5d;
//		double riverFold = 0.5d;

		double out = flopFold + (1-flopFold)*turnFold + (1-flopFold)*(1-turnFold)*riverFold;
		
		double rand = Math.random();
		
		if (rand < out)
			return false;
		else 
			return true;
	}
	
	private void initHoleCards() {
		long time = System.currentTimeMillis();
		
		enemyCards = new Vector<Vector<Card>>();
		
		for (int c1=Card.DIAMOND; c1<=Card.CLUB; c1++) {
			for (int n1=Card.N2; n1<=Card.NA; n1++) {
				for (int c2=Card.DIAMOND; c2<=Card.CLUB; c2++) {
					for (int n2=n1; n2<=Card.NA; n2++) {
						Card card1 = new Card(c1,n1);
						Card card2 = new Card(c2,n2);
						
//						if (isCardTabu(card1) || isCardTabu(card2))
//							continue;
						if (card1.equals(card2))
							continue;
						
						Vector<Card> thisC = new Vector<Card>();
						thisC.add(card1);
						thisC.add(card2);
						
						enemyCards.add(thisC);
						
					}	
				}	
			}	
		}
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Hole Cards inited, found " + enemyCards.size() + " Opponent Combinations (" + (System.currentTimeMillis() - time) + " ms taken).");



	}
	
	public void runSimulations(int simulations, boolean simToEnd) {
		long time = System.currentTimeMillis();
		this.simulations = 0;
		
		FullCombo myFC = new FullCombo(myCards.toArray(new Card[0]), boardCards.toArray(new Card[0]));
		Combination myC = myFC.getBestCombo();
		
		Vector<Vector<Card>> playerCards = new Vector<Vector<Card>>();
		
		
		for (int i=0; i<simulations; i++) {
			try {
				Vector<Card> tempTabuCards = new Vector<Card>();
				tempTabuCards.addAll(tabuCards);
	
				Vector<Card> tempBoardCards = new Vector<Card>();
				tempBoardCards.addAll(boardCards);
				
				
				FullCombo myFC_SE;
				Combination myC_SE = null;
				
				if (simToEnd) {
					if (boardCards.size() == 3) boardCards.add(getCard()); tabuCards.add(boardCards.get(3));
					if (boardCards.size() == 4) boardCards.add(getCard()); tabuCards.add(boardCards.get(4));
				
					myFC_SE = new FullCombo(myCards.toArray(new Card[0]), boardCards.toArray(new Card[0]));
					myC_SE = myFC_SE.getBestCombo();
	
				}
				
				for (int p=0; p<players; p++) {
					if (shouldPlayerPlay(p)) {
					
						if (enemyCardRange.get(p) == null)
							playerCards.add(getEnemyCards(p));
						else
							playerCards.add(getEnemyCardsFromRange(p));
						
						tabuCards.addAll(playerCards.get(p));
					}
					else {
						playerCards.add(null);
					}
				}
				
				
				Combination bestOpCombo = null;
				int nrOfEnemyWinners = 0;
				
				for (int p=0; p<players; p++) {
					if (playerCards.get(p) == null)
						continue;
					
					FullCombo pFC = new FullCombo(playerCards.get(p).toArray(new Card[0]), boardCards.toArray(new Card[0]));
					Combination pc = pFC.getBestCombo();
					
					if (bestOpCombo == null || pc.isHigherThan(bestOpCombo) > 0) {
						bestOpCombo = pc;
						nrOfEnemyWinners = 1;
					}
					if (pc.isHigherThan(bestOpCombo) == 0) {
						nrOfEnemyWinners++;
					}
				}
				

				
				String res = "";
				
				Combination checkC = simToEnd ? (myC_SE) : myC;
				
				if (bestOpCombo == null || checkC.isHigherThan(bestOpCombo) > 0) {
					wins++;
					res = "win";
				}
				else if (checkC.isHigherThan(bestOpCombo) == 0) {
					ties++;
					res = "tie";
				}
				else {
					losses++;
					res = "loss";
				}
				
				int pot = -1;
				int putAmount = -1;

				if (gameSituation != null) {
					if (DEBUG) System.out.println(getClass().getSimpleName() + "> Use Pot Simulator...");
					
					pot = potSim.startSimulation(gameSituation, -1);
					
					putAmount = potSim.getPotInsets(gameSituation.getMyPlayer());
					
					if (res.equals("win"))
						winAmount += pot;
					else if (res.equals("tie"))
						winAmount += (pot) / (nrOfEnemyWinners + 1);
					else 
						winAmount -= putAmount;
				}
				
				if (DEBUG) System.out.println(getClass().getSimpleName() + "> Simulation " + i + ": myCards=" + myCards + " boardCards=" + boardCards + " opponentCards=" + playerCards + " myCombo: " + checkC + " bestOCombo: " + bestOpCombo + " pot: " + pot + "(myAmount: " + putAmount + ") -> " + res);
	
				
				tabuCards = tempTabuCards;
				boardCards = tempBoardCards;
				playerCards.removeAllElements();
				
				this.simulations++;
			}
			catch (Exception e) {
				System.err.println(getClass().getSimpleName() + "> Exception: " + e);
				e.printStackTrace();
			}
		}
		
		double percentage = (double) wins / (double) this.simulations;
		if (DEBUG) System.out.println(getClass().getSimpleName() + "> Simulations ended: w/t/l " + wins + "/" + ties + "/" + losses + " (" + simulations + ") -> " + Math.round(percentage*100) + "%, Amount: "  + getAverageWinAmount() + " (" + (System.currentTimeMillis() - time) + " ms taken).");
		
		
	}
	
	public void setPlayerCardRange(int playerNr, Vector<Hand> range) {
		if (playerNr > enemyCardRange.size())
			System.err.println(getClass().getSimpleName() + "> Cant set enemy card range, player " + playerNr + " doesnt exist (" + enemyCardRange.size() + " players).");
		else {
			normalize(range);
//			System.out.println(range);
			enemyCardRange.set(playerNr, range);
		}
	}
	
	public void normalize(Vector<Hand> range) {
		double sum = 0;
		for (int i=0; i<range.size(); i++) {
			sum += range.get(i).getWeight();
		}
		
		double sumAfter = 0;
		for (int i=0; i<range.size(); i++) {
			if (range.get(i).getWeight() > 0.01f)
//				System.out.println(getClass().getSimpleName() + "> Normalizing " + range.get(i).getHand() + ", before " + BaseBot.round(range.get(i).getWeight()) + ", after " + BaseBot.round(range.get(i).getWeight() / sum) + " strength=" + range.get(i).getHandStrength());
			range.get(i).setNormWeight((float) (range.get(i).getWeight() / sum));
			sumAfter += range.get(i).getNormWeight();
		}
//		System.out.println(getClass().getSimpleName() + "> Sums: before=" + sum + ", after=" + sumAfter);
	}
	
	public void setPlayerSituationStore(int playerNr, SituationStore sit) {
		if (playerNr > enemyCardRange.size())
			System.err.println(getClass().getSimpleName() + "> Cant set enemy situation store, player " + playerNr + " doesnt exist (" + enemyCardRange.size() + " players).");
		else
			enemySituationStores.set(playerNr, sit);
	}
	
	public void setGameSituation(GameSituation gs) {
		this.gameSituation = gs;
	}
	
	public double getAverageWinAmount() {
		double amount = (double) winAmount / (double) simulations;
		return amount;
		
	}
	
	public double getWinPercentage() {
		double percentage = (double) wins / (double) simulations;
		return percentage;
	}
	
	public double getTiePercentage() {
		double percentage = (double) ties / (double) simulations;
		return percentage;
	}
	
	public double getLoosePercentage() {
		double percentage = (double) losses / (double) simulations;
		return percentage;
	}
	
	public int getNumSimulationsDone() {
		return simulations;
	}
	
//	public double getExpectedWinValue(double pot) {
//		return (pot * getWinPercentage() + pot * getTiePercentage()/2);
//	}
	
	public void reInit(int players, Vector<Card> myCards, Vector<Card> boardCards) {
		this.players = players - 1;	// mich rausrechnen
		this.myCards = myCards;
		this.boardCards = boardCards;
		
		tabuCards = new Vector<Card>();
		tabuCards.addAll(myCards);
		tabuCards.addAll(boardCards);

		enemyCardRange = new Vector<Vector<Hand>>();
		enemySituationStores = new Vector<SituationStore>();
		for (int i=0; i<this.players; i++) {
			enemyCardRange.add(null);
			enemySituationStores.add(null);
		}


		
		wins = 0;
		ties = 0;
		losses = 0;
		simulations = 0;
		winAmount = 0;
		
		potSim = new PotSimulator();
	}
	
	
	public ShowdownSimulator() {
		initHoleCards();
		
		preFlopChart = new PreFlopChart();
	}
	
	public ShowdownSimulator(int players, Vector<Card> myCards, Vector<Card> boardCards) {
		
		reInit(players, myCards, boardCards);
		initHoleCards();
		
		preFlopChart = new PreFlopChart();
	}
	

}
