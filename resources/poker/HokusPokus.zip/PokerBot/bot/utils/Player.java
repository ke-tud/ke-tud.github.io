package bot.utils;

import java.util.Vector;

import bot.opponent.HandRange;
import bot.opponent.SituationStore;
import bot.opponent.WeightTable;
import bot.pokertools.PreFlopChart;

public class Player {
	
	private String name;
	private SituationStore sitStore = new SituationStore();
	private HandRange hr = new HandRange();
	Vector<Integer> winHistory = new Vector();
	
	public String getName() {
		return name;
	}
	
	public HandRange getHandRange() {
		return hr;
	}
	
	public SituationStore getSituationStore() {
		return sitStore;
	}
	
	public int getWinSum(){
		int tmpSum = 0;
		for(int i = 0; i < winHistory.size(); i++){
			tmpSum += winHistory.get(i);
		}
		return tmpSum;
	}
	
	public Vector<Integer> getWinHistory(){
		return winHistory;
	}
	
	public int getWinAtRound(int round){
		return winHistory.get(round).intValue();
	}
	
	
	public void setWinAtRound(int round, int amount){
		winHistory.add(round, new Integer(amount));
	}
	
	public void addWin(int amount){
		winHistory.add(new Integer(amount));
	}
	
	public void takeValues(Player other) {
		this.name = other.name;
		this.sitStore = other.sitStore;
		this.hr = other.hr;
		this.winHistory = other.winHistory;
	}
	
	public String toString() {
		return name;
	}
	
	public Player(String name) {
		this.name = name;
	}
}
