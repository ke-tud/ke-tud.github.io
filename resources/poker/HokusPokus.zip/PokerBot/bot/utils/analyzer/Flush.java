package bot.utils.analyzer;

import java.util.Arrays;

import bot.utils.Card;





public class Flush extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair)
			return 1;
		if (c instanceof Triplet)
			return 1;
		if (c instanceof Straight)
			return 1;
		if (c instanceof Flush) {

			int myHN = 0;
			int otherHN = 0;
			
			int[] myNumbers = getHighestNumbers();
			int[] otherNumbers = ((Flush)c).getHighestNumbers();
			
			
			for (int i=4; i>=0; i--) {
				if (myNumbers[i] == otherNumbers[i])
					continue;
				
				myHN = myNumbers[i];
				otherHN = otherNumbers[i];
				break;
			}
			
			if (myHN > otherHN)
				return 1;
			if (myHN == otherHN)
				return 0;
			else
				return -1;
		}
		
		return -1;
	}
	
	public int getColor() {
		return cards[0].getColor();
	}

	public String toString() {
		return "[Flush: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + ", " + cards[4] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getHighestNumber() {
		int maxNumber = cards[0].getNumber();
		for (int i=1; i<5; i++) {
			if (cards[i].getNumber() > maxNumber)
				maxNumber = cards[i].getNumber();
		}
		return maxNumber;
	}
	
	public int[] getHighestNumbers() {
		int[] numbers = new int[5];
		for (int i=0; i<5; i++) {
			numbers[i] = cards[i].getNumber();
		}
		
		Arrays.sort(numbers);
		return numbers;
	}

	public static boolean isFlush(Card c1, Card c2, Card c3, Card c4, Card c5) {
		return (c1.getColor() == c2.getColor() && c1.getColor() == c3.getColor() && c1.getColor() == c4.getColor() && c1.getColor() == c5.getColor());
	}
	
	public Flush(Card c1, Card c2, Card c3, Card c4, Card c5) {
		cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
	}
}
