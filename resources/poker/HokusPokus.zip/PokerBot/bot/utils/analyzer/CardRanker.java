package bot.utils.analyzer;

public class CardRanker {

}
