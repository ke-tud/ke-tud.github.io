package bot.utils.analyzer;



import java.util.Vector;

import bot.utils.Card;





public class FullHouse extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair)
			return 1;
		if (c instanceof Triplet)
			return 1;
		if (c instanceof Straight)
			return 1;
		if (c instanceof Flush)
			return 1;
		if (c instanceof FullHouse) {
			
			if (getTripletNumber() > ((FullHouse)c).getTripletNumber()) 
				return 1;
			else if (getTripletNumber() == ((FullHouse)c).getTripletNumber() && getPairNumber() > ((FullHouse)c).getPairNumber())
				return 1;
			else if (getTripletNumber() == ((FullHouse)c).getTripletNumber() && getPairNumber() == ((FullHouse)c).getPairNumber())
				return 0;
		}
		
		return -1;
	}

	public String toString() {
		return "[FullHouse: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + ", " + cards[4] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getTripletNumber() {
		Triplet t = Analyzer.testTriplet(cards);
		return t.getNumber();
	}
	
	public int getPairNumber() {
		int tNr = Analyzer.testTriplet(cards).getNumber();
		
		int nr = 0;
		for (int i=0; i<5; i++) {
			if (cards[i].getNumber() != tNr)
				nr = cards[i].getNumber();
		}

		return nr;
	}

	public static boolean isFullhouse(Card c1, Card c2, Card c3, Card c4, Card c5) {
		Card[] cards = new Card[5];
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
		
		Triplet t = Analyzer.testTriplet(cards);
		
		if (t == null)
			return false;
		
		Vector<Card> rCards = new Vector<Card>();
		for (int i=0; i<5; i++) {
			boolean doIn = true;
			for (int j=0;j<3;j++)
				if (t.getCards()[j].equals(cards[i]))
					doIn = false;
			
			if (doIn)
				rCards.add(cards[i]);
		}
		
		
		
		if (Pair.isPair(rCards.get(0), rCards.get(1)))
			return true;
		
		return false;
	}
	
	public FullHouse(Card c1, Card c2, Card c3, Card c4, Card c5) {
		cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
	}
}
