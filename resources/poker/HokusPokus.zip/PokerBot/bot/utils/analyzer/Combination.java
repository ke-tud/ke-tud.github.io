package bot.utils.analyzer;


import java.util.Collections;
import java.util.Vector;

import bot.utils.Card;


public abstract class Combination {

	protected Card[] cards;
	protected Vector<Card> kickerRow;
	
	public Card[] getCards() {
		return cards;
	}
	
	public Card getKickerNr(int index) {
		return kickerRow.get(index);
	}
	
	public int getKickers() {
		if (kickerRow == null)
			return 0;
		else
			return kickerRow.size();
	}
	
	abstract public int isHigherThan(Combination c);
	abstract public String toString();
	
	public void makeKickerRow(Card[] board) {
		if (cards.length >= 5)
			return;
		
		kickerRow = new Vector<Card>();
		
		for (int i=0; i<board.length; i++) {
			if (!belongsToCombo(board[i])) {
				kickerRow.add(board[i]);
			}
		}
		
		
//		for (int i=0; i<player.length; i++) {
//			if (!belongsToCombo(player[i])) {
//				kickerRow.add(player[i]);
//			}
//		}
		
		Collections.sort(kickerRow);
		
//		System.out.println("KS:" + kickerRow.size());
		int kickerCount = Math.max(0, 5 - cards.length);
		for(int i=kickerCount; i<kickerRow.size(); i++) {
			kickerRow.remove(i);
		}
		
//		System.out.println("KS:" + kickerRow.size());
	}
	
	private boolean belongsToCombo(Card card) {
		for (int i=0; i<cards.length; i++) {
			if (cards[i].equals(card))
				return true;
		}
		return false;
	}
	
	public int isKickerHigherThan(Combination c) {
//		System.out.println("Kickertest");
		if (kickerRow == null)
			return -1;
		if (c.kickerRow == null)
			return 1;
		int search = Math.min(getKickers(), c.getKickers());
		for (int i=0; i<search; i++) {
			if (kickerRow.get(i).getNumber() > c.kickerRow.get(i).getNumber())
				return 1;
			if (kickerRow.get(i).getNumber() < c.kickerRow.get(i).getNumber())
				return -1;
		}
		
		return 0;
	}
	
}
