package bot.utils.analyzer;

import bot.utils.Card;




public class Pair extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair) {
			if (getNumber() == ((Pair)c).getNumber()) 
				return isKickerHigherThan(c);
			else if (getNumber() > ((Pair)c).getNumber())
				return 1;
		}
		return -1;
	}

	public String toString() {
		return "[Pair: " + cards[0] + ", " + cards[1] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getNumber() {
		return cards[0].getNumber();
	}

	public static boolean isPair(Card c1, Card c2) {
		return (c1.getNumber() == c2.getNumber());
	}
	
	public Pair(Card c1, Card c2) {
		cards = new Card[2];
		
		cards[0] = c1;
		cards[1] = c2;
	}
}
