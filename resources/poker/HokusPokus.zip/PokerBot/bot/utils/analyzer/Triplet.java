package bot.utils.analyzer;

import bot.utils.Card;




public class Triplet extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair)
			return 1;
		if (c instanceof Triplet) {
			if (getNumber() > ((Triplet)c).getNumber())
				return 1;
			else if (getNumber() == ((Triplet)c).getNumber())
				return isKickerHigherThan(c);
			else
				return -1;
		}
		
		return -1;
	}

	public String toString() {
		return "[Triplet: " + cards[0] + ", " + cards[1] + ", " + cards[2] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getNumber() {
		return cards[0].getNumber();
	}

	public static boolean isTriplet(Card c1, Card c2, Card c3) {
		return (c1.getNumber() == c2.getNumber() && c1.getNumber() == c3.getNumber());
	}
	
	public Triplet(Card c1, Card c2, Card c3) {
		cards = new Card[3];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
	}
}
