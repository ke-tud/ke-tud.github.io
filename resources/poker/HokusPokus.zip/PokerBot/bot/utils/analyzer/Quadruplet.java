package bot.utils.analyzer;
import bot.utils.Card;





public class Quadruplet extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair)
			return 1;
		if (c instanceof Triplet)
			return 1;
		if (c instanceof Straight)
			return 1;
		if (c instanceof Flush)
			return 1;
		if (c instanceof FullHouse)
			return 1;
		if (c instanceof Quadruplet) {
			if (getNumber() > ((Quadruplet)c).getNumber())
				return 1;
			else if (getNumber() == ((Quadruplet)c).getNumber())
				return isKickerHigherThan(c);
			else 
				return -1;
		}
		
		return -1;
	}

	public String toString() {
		return "[Quadruplet: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getNumber() {
		return cards[0].getNumber();
	}

	public static boolean isQuadruplet(Card c1, Card c2, Card c3, Card c4) {
		return (c1.getNumber() == c2.getNumber() && c1.getNumber() == c3.getNumber() && c1.getNumber() == c4.getNumber());
	}
	
	public Quadruplet(Card c1, Card c2, Card c3, Card c4) {
		cards = new Card[4];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
	}
}
