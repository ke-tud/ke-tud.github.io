package bot.utils.analyzer;

import java.util.Arrays;
import java.util.Vector;

import bot.utils.Card;






public class Analyzer {
	
	public static Triplet testTriplet(Card[] cards) {
		Triplet max = null;
		
		for (int i=0; i<3; i++) {
			for (int j=i+1; j<4; j++) {
				for (int k=j+1; k<5; k++)
				if (Triplet.isTriplet(cards[i], cards[j], cards[k])) {
					Triplet current = new Triplet(cards[i], cards[j], cards[k]);
					if (max == null)
						max = current;
					else if (current.isHigherThan(max) > 0)
						max = current;
				}
			}
		}
		
		return max;
		
	}
	
	public static Quadruplet testQuadruplet(Card[] cards) {
		for (int i=0; i<2; i++) {
			for (int j=i+1; j<3; j++) {
				for (int k=j+1; k<4; k++) {
					for (int l=k+1; l<5; l++) {
						if (Quadruplet.isQuadruplet(cards[i], cards[j], cards[k], cards[l]))
							return new Quadruplet(cards[i], cards[j], cards[k], cards[l]);
					}
				}
			}
		}
		return null;
	}
	
	public static FullHouse testFullHouse(Card[] cards) {

		if (FullHouse.isFullhouse(cards[0], cards[1], cards[2], cards[3], cards[4]))
			return new FullHouse(cards[0], cards[1], cards[2], cards[3], cards[4]);
		
		return null;
	}
	
	public static Straight testStraight(Card[] cards) {

		if (Straight.isStraight(cards[0], cards[1], cards[2], cards[3], cards[4]))
			return new Straight(cards[0], cards[1], cards[2], cards[3], cards[4]);
		
		return null;
	}
	
	public static RoyalFlush testRoyalFlush(Card[] cards) {

		if (RoyalFlush.isRoyalFlush(cards[0], cards[1], cards[2], cards[3], cards[4]))
			return new RoyalFlush(cards[0], cards[1], cards[2], cards[3], cards[4]);
		
		return null;
	}
	
	public static Flush testFlush(Card[] cards) {

		if (Flush.isFlush(cards[0], cards[1], cards[2], cards[3], cards[4]))
			return new Flush(cards[0], cards[1], cards[2], cards[3], cards[4]);
		
		return null;
	}
	
	public static StraightFlush testStraightFlush(Card[] cards) {

		if (StraightFlush.isStraightFlush(cards[0], cards[1], cards[2], cards[3], cards[4]))
			return new StraightFlush(cards[0], cards[1], cards[2], cards[3], cards[4]);
		
		return null;
	}
	
	public static TwoPair testTwoPair(Card[] cards) {
		for (int i=0; i<2; i++) {
			for (int j=i+1; j<3; j++) {
				for (int k=j+1; k<4; k++) {
					for (int l=k+1; l<5; l++) {
						if (TwoPair.isTwoPair(cards[i], cards[j], cards[k], cards[l]))
							return new TwoPair(cards[i], cards[j], cards[k], cards[l]);
					}
				}
			}
		}
		return null;
	}
	
	public static Pair testPair(Card[] cards) {
		Pair max = null;
		
		for (int i=0; i<4; i++) {
			for (int j=i+1; j<5; j++) {
				if (Pair.isPair(cards[i], cards[j])) {
					Pair current = new Pair(cards[i], cards[j]);
					if (max == null)
						max = current;
					else if (current.isHigherThan(max) > 1)
						max = current;
				}
			}
		}
		
		return max;
		
	}
	
	public static Highest testHighest(Card[] cards) {
//		System.out.println("HC: " + Arrays.toString(cards));
		Card max = cards[0];
		for (int i=1; i<cards.length; i++) {
			if (cards[i].compareTo(max) < 1)
				max = cards[i];
		}
//		System.out.println("HT: " + max);
		return new Highest(max);
		
//		Highest max = new Highest(cards[0]);
//		for (int i=1; i<5; i++) {
//			Highest temp = new Highest(cards[i]);
//			if (temp.isHigherThan(max) > 1)
//				max = temp;
//		}
//		return max;
	}
	
	public static Combination test(Card[] cards) {
		
		Combination current;
		

		current = testRoyalFlush(cards);
		if (current != null)
			return current;
		
		current = testStraightFlush(cards);
		if (current != null)
			return current;
		
		current = testQuadruplet(cards);
		if (current != null)
			return current;
		
		
		current = testFullHouse(cards);
		if (current != null)
			return current;

		
		current = testFlush(cards);
		if (current != null)
			return current;

		current = testStraight(cards);
		if (current != null)
			return current;
		

		current = testTriplet(cards);
		if (current != null)
			return current;

		current = testTwoPair(cards);
		if (current != null)
			return current;
		
		current = testPair(cards);
		if (current != null)
			return current;
		
		current = testHighest(cards);
		if (current != null)
			return current;
		
		return null;
	}
	
	public static Combination test(Vector<Card> cards) {
    	Card[] cardArray = new Card[cards.size()];
    	for (int i=0; i<cards.size(); i++) {
    		cardArray[i] = cards.get(i);
    	}
    	
    	
    	return test(cardArray);
	}

}
