package bot.utils.analyzer;

import bot.utils.Card;





public class RoyalFlush extends Combination {

	public int isHigherThan(Combination c) {

		if (c instanceof RoyalFlush)
			return 0;
		
		return 1;
	}

	public String toString() {
		return "[RoyalFlush: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + ", " + cards[4] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public static boolean isRoyalFlush(Card c1, Card c2, Card c3, Card c4, Card c5) {
		Card[] cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
		
		return (Straight.isStraight(c1, c2, c3, c4, c5) && Flush.isFlush(c1, c2, c3, c4, c5) && getMinNumber(cards) == Card.NT); 
	}
	
	public int getColor() {
		return cards[0].getColor();
	}
	
	private static int getMinNumber(Card[] cards) {
		int minNumber = cards[0].getNumber();
		for (int i=1; i<5; i++) {
			if (cards[i].getNumber() < minNumber)
				minNumber = cards[i].getNumber();
		}
		return minNumber;
	}
	
	
	public RoyalFlush(Card c1, Card c2, Card c3, Card c4, Card c5) {
		cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
	}
}
