package bot.utils.analyzer;

import bot.utils.Card;





public class Highest extends Combination {

	public int isHigherThan(Combination c) {
			
		if (c instanceof Highest && cards[0].getNumber() > ((Highest)c).cards[0].getNumber())
			return 1;
		if (c instanceof Highest && cards[0].getNumber() == ((Highest)c).cards[0].getNumber()) {
			return isKickerHigherThan(c);
		}		
		
		return -1;
	}

	public String toString() {
		return "[Highest: " + cards[0] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}

	public static boolean isHighest(Card c1) {
		return true;
	}
	
	public Highest(Card c1) {
		cards = new Card[1];
		
		cards[0] = c1;
	}
}
