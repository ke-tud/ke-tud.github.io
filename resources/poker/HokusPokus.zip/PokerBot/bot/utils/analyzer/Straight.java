package bot.utils.analyzer;

import java.util.Arrays;

import bot.utils.Card;




public class Straight extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair)
			return 1;
		if (c instanceof Triplet)
			return 1;
		if (c instanceof Straight) {
			if (getMinNumber() > ((Straight)c).getMinNumber())
				return 1;
			else if (getMinNumber() == ((Straight)c).getMinNumber()) 
				return 0;
			else 
				return -1;
		}
		return -1;
	}

	public String toString() {
		return "[Straight: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + ", " + cards[4] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getMinNumber() {
		return getMinNumber(cards);
	}
	
	public int getMaxNumber() {
		return getMaxNumber(cards);
	}

	public static boolean isStraight(Card c1, Card c2, Card c3, Card c4, Card c5) {
		Card[] cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
		
		// Einzelfall, wenn Ass dabei ist A = 1
		if (containsNumber(cards, Card.NA) && containsNumber(cards, Card.N2) && containsNumber(cards, Card.N3) && containsNumber(cards, Card.N4) && containsNumber(cards, Card.N5)) {
			return true;
		}

		int minNumber = getMinNumber(cards);
		for (int n=minNumber; n<=minNumber+4; n++) {
			if (!(containsNumber(cards, n))) {
				return false;
			}
		}
		
		
		
		return true;
		
		
	}
	
	private static int getMinNumber(Card[] cards) {
		
		// Sonderfall Straße ab 1
		if (containsNumber(cards, Card.NA) && containsNumber(cards, Card.N2) && containsNumber(cards, Card.N3) && containsNumber(cards, Card.N4) && containsNumber(cards, Card.N5)) {
			return 1;
		}

		
		
		int minNumber = cards[0].getNumber();
		for (int i=1; i<5; i++) {
			if (cards[i].getNumber() < minNumber)
				minNumber = cards[i].getNumber();
		}
		return minNumber;
	}
	
	private static int getMaxNumber(Card[] cards) {
		int maxNumber = cards[0].getNumber();
		for (int i=1; i<5; i++) {
			if (cards[i].getNumber() > maxNumber)
				maxNumber = cards[i].getNumber();
		}
		return maxNumber;
	}
	
	private static boolean containsNumber(Card[] cards, int number) {
		for (int i=0; i<cards.length; i++) {
			if (cards[i].getNumber() == number)
				return true;
			if (cards[i].getNumber() == Card.NA && number == 1)
				return true;
		}
		
		return false;
	}
	
	public Straight(Card c1, Card c2, Card c3, Card c4, Card c5) {
		cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
	}
}
