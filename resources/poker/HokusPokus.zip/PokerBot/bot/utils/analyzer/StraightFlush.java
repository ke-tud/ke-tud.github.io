package bot.utils.analyzer;

import bot.utils.Card;





public class StraightFlush extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair)
			return 1;
		if (c instanceof Triplet)
			return 1;
		if (c instanceof Straight)
			return 1;
		if (c instanceof Flush)
			return 1;
		if (c instanceof FullHouse)
			return 1;
		if (c instanceof Quadruplet)
			return 1;
		if (c instanceof StraightFlush) {
			if (getMinNumber() > ((StraightFlush)c).getMinNumber())
				return 1;
			else if (getMinNumber() == ((StraightFlush)c).getMinNumber())
				return 0;
			else
				return -1;
		}
		return -1;
	}

	public String toString() {
		return "[StraightFlush: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + ", " + cards[4] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getMinNumber() {
		return getMinNumber(cards);
	}

	public static boolean isStraightFlush(Card c1, Card c2, Card c3, Card c4, Card c5) {
		return (Straight.isStraight(c1, c2, c3, c4, c5) && Flush.isFlush(c1, c2, c3, c4, c5)); 
	}
	
	private static int getMinNumber(Card[] cards) {
		int minNumber = cards[0].getNumber();
		for (int i=1; i<5; i++) {
			if (cards[i].getNumber() < minNumber)
				minNumber = cards[i].getNumber();
		}
		return minNumber;
	}
	
	
	public StraightFlush(Card c1, Card c2, Card c3, Card c4, Card c5) {
		cards = new Card[5];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
		cards[4] = c5;
	}
}
