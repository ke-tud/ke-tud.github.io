package bot.utils.analyzer;

import bot.utils.Card;





public class TwoPair extends Combination {

	public int isHigherThan(Combination c) {
		if (c instanceof Highest)
			return 1;
		if (c instanceof Pair)
			return 1;
		if (c instanceof TwoPair) {
			if (getHigherNumber() > ((TwoPair)c).getHigherNumber()) 
				return 1;
			else if (getHigherNumber() == ((TwoPair)c).getHigherNumber() && getLowerNumber() > ((TwoPair)c).getLowerNumber())
				return 1;
			else if (getHigherNumber() == ((TwoPair)c).getHigherNumber() && getLowerNumber() == ((TwoPair)c).getLowerNumber())
				return isKickerHigherThan(c);
		}
		return -1;
	}

	public String toString() {
		return "[TwoPair: " + cards[0] + ", " + cards[1] + ", " + cards[2] + ", " + cards[3] + "]" + ((kickerRow != null) ? "[Kickers: " + kickerRow + "]" : "");
	}
	
	public int getHigherNumber() {
		int max = 0;
		for (int i=0; i<4; i++) {
			if (cards[i].getNumber() > max)
				max = cards[i].getNumber();
		}
		
		return max;
	}
	
	public int getLowerNumber() {
		int min = 1000;
		for (int i=0; i<4; i++) {
			if (cards[i].getNumber() < min)
				min = cards[i].getNumber();
		}
		
		return min;
	}

	public static boolean isTwoPair(Card c1, Card c2, Card c3, Card c4) {
		boolean result = false;
		
		if (c1.getNumber() == c2.getNumber() && c3.getNumber() == c4.getNumber())
			result = true;
		if (c2.getNumber() == c3.getNumber() && c1.getNumber() == c4.getNumber())
			result = true;		
		if (c1.getNumber() == c3.getNumber() && c2.getNumber() == c4.getNumber())
			result = true;
		
		return result;
	}
	
	public TwoPair(Card c1, Card c2, Card c3, Card c4) {
		cards = new Card[4];
		
		cards[0] = c1;
		cards[1] = c2;
		cards[2] = c3;
		cards[3] = c4;
	}
}
