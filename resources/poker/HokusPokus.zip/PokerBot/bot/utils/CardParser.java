package bot.utils;



public class CardParser {
	
	public static Card parseCard(String in) {
		
		if (in.length() != 2)
			return null;
		
		int number = -1;
		int color = -1;
		
		if (in.charAt(0) == '2') number = Card.N2;
		else if (in.charAt(0) == '3') number = Card.N3;
		else if (in.charAt(0) == '4') number = Card.N4;
		else if (in.charAt(0) == '5') number = Card.N5;
		else if (in.charAt(0) == '6') number = Card.N6;
		else if (in.charAt(0) == '7') number = Card.N7;
		else if (in.charAt(0) == '8') number = Card.N8;
		else if (in.charAt(0) == '9') number = Card.N9;
		else if (in.charAt(0) == 'T') number = Card.NT;
		else if (in.charAt(0) == 'J') number = Card.NJ;
		else if (in.charAt(0) == 'Q') number = Card.NQ;
		else if (in.charAt(0) == 'K') number = Card.NK;
		else if (in.charAt(0) == 'A') number = Card.NA;
		
		if (in.charAt(1) == 's') color = Card.SPADE;
		if (in.charAt(1) == 'c') color = Card.CLUB;
		if (in.charAt(1) == 'd') color = Card.DIAMOND;
		if (in.charAt(1) == 'h') color = Card.HEART;
		
		if (number == -1 || color == -1)
			return null;
		else 
			return new Card(color, number);
		
		
	}

}
