package bot.utils;

public class GameAction {
	
	private int type;
	private Player player;
	private int situation; //  PREFLOP etc.
	private int toCall;    // Wieviel zu callen war
	
	public static final int ACTION_FOLD = 0,
							ACTION_CALL = 1,
							ACTION_RAISE = 2;
	
	public int getType() {
		return type;
	}
	
	public Player getPlayer() {
		return player;
	}
	
	public int getSituation() {
		return situation;
	}
	
	public int getToCall() {
		return toCall;
	}
	
	
	public String toString() {
		String out = "[" + player.getName() + " did ";

		out += getActionString(type);
		
		out += " on ";
		
		out += getSituationString(situation);
		
		out += "(toCall: " + toCall + ")]";
		return out;
	}
	
	public static String getActionString(int type) {
		String out = "";
		if (type == ACTION_FOLD) out = "FOLD";
		else if (type == ACTION_CALL) out = "CALL";
		else if (type == ACTION_RAISE) out = "RAISE";
		else out = "" + type;
		
		return out;
	}
	
	public static String getSituationString(int situation) {
		String out = "";
		
		if (situation == GameSituation.STATE_PREFLOP) out = "PREFLOP";
		else if (situation == GameSituation.STATE_FLOP) out = "FLOP";
		else if (situation == GameSituation.STATE_TURN) out = "TURN";
		else if (situation == GameSituation.STATE_RIVER) out = "RIVER";
		else out += "" + situation;
		
		return out;
	}
	
	public GameAction(Player p, int type, int situation, int toCall) {
		this.type = type;
		this.player = p;
		this.situation = situation;
		this.toCall = toCall;
	}

}
