/*
 * MBot v1: spielt PreFlop nach PreflopChart, danach, wenns mathematisch Sinn macht
 */

package bot;


import java.io.*;


import java.net.*;
import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.Config;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.ShowdownSimulator;
import bot.utils.analyzer.Analyzer;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Highest;
import bot.utils.analyzer.Pair;

import ca.ualberta.cs.poker.free.client.PokerClient;


public class MBot extends PokerClient {
	
	private GameSituation publicState;
	private PreFlopChart preFlopChart;
	private GameStatistics gStats;
	private ShowdownSimulator sim;
	
	private int wins = 0;
	
	private static final boolean DEBUG = true;
	
	private static final double AGRESSIVE_FACTOR = 1.4;
    
    public void handleStateChange() throws IOException, SocketException{
    	long time = System.currentTimeMillis();
    	
    	if (publicState.isNewRound(currentGameStateString))
    		System.out.println(getClass().getSimpleName() + "> ---------- Starting Round " + (publicState.getRound()+1) + ", " + wins + " wins till now. ----------");
    	
    	
    	publicState.updateSituation(currentGameStateString);
    	
    	if (publicState.isHandFinished() && publicState.haveIWon())
    		wins++;

    	if (!publicState.amIOnMove())
    		return;
    	
    	
    	
    	double playPercentage = (1 / (double) publicState.getPlayerCount()) * AGRESSIVE_FACTOR;
        preFlopChart.setPlayPercentage(playPercentage);
    	
        
        Vector<Card> myCards = publicState.getOwnCards();
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
        	boolean should = preFlopChart.shouldPlay(myCards);
        	
        	if (DEBUG) System.out.print(getClass() . getSimpleName() + "> PREFLOP: " + myCards + " (Rank: " + preFlopChart.getHandRank(myCards) + ") -> ");
        	if(should){
        		if (DEBUG) System.out.println("RAISE");
        		sendRaise();
        	}
        	else {
        		if (DEBUG) System.out.println("FOLD");
        		sendFold();
        	}
    	}
    	
    	else {

    		FullCombo fc = new FullCombo(myCards.toArray(new Card[0]), publicState.getBoardCards().toArray(new Card[0]));
        	Combination c = fc.getBestCombo();

    		
    		
    		try {
//    			gStats.runSimulation(myCards, publicState.getBoardCards(), publicState.getPlayersInHand());
//    	   		double winProp = gStats.getWinPropability();
    			
    			sim.reInit(publicState.getPlayersInHand() - 1, myCards, publicState.getBoardCards());
    			sim.runSimulations(Config.NUM_SIMULATIONS, true);
    			double winProp = sim.getWinPercentage();

        		if (DEBUG) System.out.print(getClass().getSimpleName() + "> POSTFLOP: " + c + " (WinProp:" + winProp + ")-> ");
        		
        		if (winProp * AGRESSIVE_FACTOR > (1/(double) publicState.getPlayersInHand())) {
        			if (DEBUG) System.out.println("RAISE");
            		sendRaise();
        		}
        		else {
        			if (DEBUG) System.out.println("FOLD");
            		sendFold();       			
        		}

    		}
    		catch (Exception e) {
    			if (DEBUG) System.out.print(getClass().getSimpleName() + "> ERROR: " + e);
    			sendCall();
    		}
     		
    	}
    		

    	System.out.println(getClass().getSimpleName() + "> " + (System.currentTimeMillis() - time) + " ms taken.");

    }

    
    public MBot(){
      super();
      publicState = new GameSituation();
      preFlopChart = new PreFlopChart();
      gStats = new GameStatistics();
      sim = new ShowdownSimulator();
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        MBot rpc = new MBot();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
    
}
