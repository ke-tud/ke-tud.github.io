package bot.test;

import java.util.Vector;

import bot.learner.BayesianLearner;
import bot.learner.LearnerTools;
import bot.pokertools.PreFlopChart;
import bot.pokertools.PreFlopChart2;
import bot.utils.Card;
import bot.utils.GameSituation;
import bot.utils.ShowdownSimulator;

public class Test_Preflop {


	public static void main(String[] args) {

		PreFlopChart pfc = new PreFlopChart();
		pfc.setPlayPercentage(0.16666 * 1.3);
		pfc.printRanks();
		
		System.out.println(pfc.getRank("QT"));
		pfc.setPlayPercentage(0.16666 * 1.3);
		Vector<Card> myC = new Vector<Card>();
		myC.add(new Card("Td"));
		myC.add(new Card("Qs"));
		System.out.println(pfc.getRank(myC));
		
//		BayesianLearner bl = new BayesianLearner(new int[] {LearnerTools.COMBINATION_BUCKETS, LearnerTools.RAISE_BUCKETS} );
//		bl.printAllClasses();
		
//		for (double i=0; i<=1; i+=0.01) {
//			System.out.println(i + ": " + ShowdownSimulator.simValToRank(i, 6, 3));
//		}
	}

}
