package bot.test;

import bot.pokertools.PreFlopChart;
import bot.pokertools.PreFlopChart2;
import bot.utils.Card;
import bot.utils.GameSituation;

public class Test_CardParser {


	public static void main(String[] args) {

		GameSituation gs = new GameSituation();
//		gs.updateSituation("MATCHSTATE:1:0:cc/cc/cc/cc:6sKs|QcTc/8h5c5h/9c/7d");
		long time = System.currentTimeMillis();
		gs.updateSituation("MATCHSTATE:1:0:ccrfrrc/cc/cc/cc:6sKs|QcTc|/8h5c5h/9c/7d");
		System.out.println((System.currentTimeMillis()-time));
		System.out.println(gs);
	}

}
