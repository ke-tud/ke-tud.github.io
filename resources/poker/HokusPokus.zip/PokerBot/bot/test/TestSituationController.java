package bot.test;

import java.util.Vector;

import bot.opponent.SituationStoreController;
import bot.utils.GameSituation;
import bot.utils.Player;
import bot.utils.ResultsMatchStateConverter;

public class TestSituationController {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			String ms = ResultsMatchStateConverter.convertResultToMatchState("Random5|Random3|TBot|Random4|Random1|Random2:0:frrcccrccfc/ccrcfc/crcrcc/ccrrrcc:9cKh|Tc6s|Ad9s|7s7h|AsQd|7c4d/3h5c5d/Qh/Ac:-6|-8|0|-30|74|-30", "TBot");
			
			GameSituation gs = new GameSituation();
			gs.updateSituation(ms);
			
			System.out.println(gs);
			
			SituationStoreController sitCon = new SituationStoreController();
			sitCon.addObservation(gs);
			
			Vector<Player> players = gs.getPlayers();
			
			for(Player p : players) {
				System.out.println("Statistics for Player: " + p.getName());
				p.getSituationStore().print();
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
