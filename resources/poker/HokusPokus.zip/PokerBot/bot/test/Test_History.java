package bot.test;

import java.io.File;
import java.io.FileReader;

import bot.pokertools.PreFlopChart;
import bot.pokertools.PreFlopChart2;
import bot.utils.Card;
import bot.utils.GameSituation;
import bot.utils.PartyPokerConverter;

public class Test_History {


	public static void main(String[] args) {
		try {
			PartyPokerConverter pcc = new PartyPokerConverter();
			
			File f = new File("bot/data/histories/pp");
			File[] files = f.listFiles();
			for (int i=0; i<files.length; i++) {
				System.out.println("# " + files[i].getName());
				pcc.convertFile("bot/data/histories/pp/" + files[i].getName(), "bot/data/histories/ms/data.ms");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}


}
