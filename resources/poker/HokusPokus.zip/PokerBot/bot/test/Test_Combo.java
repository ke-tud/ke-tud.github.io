package bot.test;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.learner.LearnModule;
import bot.learner.LearnerTools;
import bot.learner.history.HistoryStatistics;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.ResultsMatchStateConverter;
import bot.utils.ShowdownSimulator;
import bot.utils.analyzer.Combination;

public class Test_Combo {
	public static void main(String args[]) {
		Vector<Card> myCards = new Vector<Card>();
		myCards.add(new Card("As"));
		myCards.add(new Card("Td"));
		
		Vector<Card> myCards2 = new Vector<Card>();
		myCards2.add(new Card("As"));
		myCards2.add(new Card("7d"));
		
		Vector<Card> boardCards = new Vector<Card>();
		boardCards.add(new Card("Ac"));
		boardCards.add(new Card("Tc"));
		boardCards.add(new Card("7s"));
		boardCards.add(new Card("Ah"));
		boardCards.add(new Card("2d"));

		FullCombo fc = new FullCombo(myCards.toArray(new Card[0]), boardCards.toArray(new Card[0]));
		Combination c = fc.getBestCombo();
		
		System.out.println(c);
		
		FullCombo fc2 = new FullCombo(myCards2.toArray(new Card[0]), boardCards.toArray(new Card[0]));
		Combination c2 = fc2.getBestCombo();
		
		System.out.println(c2 + " " + c2.isHigherThan(c));
		
		System.out.println(LearnerTools.getUsedHoleCards(myCards, boardCards));
		System.out.println(LearnerTools.getUsedHoleCards(myCards2, boardCards));
	}

}
