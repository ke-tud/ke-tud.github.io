package bot.test;

import java.util.Vector;

import bot.opponent.HandSorter;
import bot.opponent.HandStrength;
import bot.opponent.OutsCalculator;
import bot.utils.Card;

public class Test_HandRange {
	
	public static void main(String[] args) {
		HandStrength hS = new HandStrength();
		OutsCalculator oC = new OutsCalculator();
		
		Vector<Card> boardcards = new Vector<Card>();
		Vector<Card> holeCards = new Vector<Card>();
		Vector<Card> holeCards2 = new Vector<Card>();
		
		boardcards.add(new Card(Card.HEART, Card.N3));
		boardcards.add(new Card(Card.CLUB, Card.N4));
		boardcards.add(new Card(Card.HEART, Card.NJ));
		boardcards.add(new Card(Card.DIAMOND, Card.NK));
		boardcards.add(new Card(Card.DIAMOND, Card.N7));
		
		holeCards.add(new Card(Card.SPADE, Card.NK));
		holeCards.add(new Card(Card.CLUB, Card.NT));
		
		holeCards2.add(new Card(Card.SPADE, Card.NA));
		holeCards2.add(new Card(Card.CLUB, Card.NQ));
		
		long timer = System.currentTimeMillis();
		System.out.print(hS.getHandStrength(holeCards, boardcards));
		timer = System.currentTimeMillis() - timer;
		System.out.println(" - in " + timer + " Sekunden");
		
		timer = System.currentTimeMillis();
		System.out.print(hS.getHandStrength(holeCards, boardcards));
		timer = System.currentTimeMillis() - timer;
		System.out.println(" - in " + timer + " Sekunden");
	
		timer = System.currentTimeMillis();
		System.out.print(hS.getHandStrength(holeCards2, boardcards));
		timer = System.currentTimeMillis() - timer;
		System.out.println(" - in " + timer + " Sekunden");
		
		HandSorter hSorter = new HandSorter(hS, oC);
		
		timer = System.currentTimeMillis();
		hSorter.initCombinations(boardcards);
		timer = System.currentTimeMillis() - timer;
		System.out.println(" - in " + timer + " Sekunden");
		
	}
}
