package bot.test;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.learner.LearnModule;
import bot.learner.history.HistoryStatistics;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.ResultsMatchStateConverter;

public class Test_Converter {
	public static void main(String args[]) {
		
		// MATCHSTATE:1:0:crc/rc/rc/rc:KsJh|3h6s/Qc9hTs/4s/9d
		HistoryStatistics hstat = new HistoryStatistics("bot/data/histories/ms/test.ms");
		try {
//			hstat.getPlayerStatistics("Bot");
			hstat.printStatistics();
		}
		catch (Exception e) {
			e.printStackTrace();
		}

//		m.printState();
		
//		try {
//			LineReader lr = new LineReader("bot/data/histories/ms/test.ms");
//			String line = "";
//			
//			while ((line = lr.readLine()) != null) {
//				
//				System.out.println("LN: ." + line + ".");
//			}
//		}
//		catch (Exception e) {
//			e.printStackTrace();
//		}
	}

}
