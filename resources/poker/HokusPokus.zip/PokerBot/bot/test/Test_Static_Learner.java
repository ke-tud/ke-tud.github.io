package bot.test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.learner.BayesianLearner;
import bot.learner.LearnModule;
import bot.learner.LearnModule_PostFlop;
import bot.learner.LearnModule_PostFlop2;
import bot.learner.LearnModule_PreFlop;
import bot.learner.history.HistoryStatistics;
import bot.learner.history.ModuleHistoryLearner;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.ResultsMatchStateConverter;
import bot.utils.ShowdownSimulator;
import bot.utils.analyzer.Combination;

public class Test_Static_Learner {

	public static void main(String args[]) {
//		LearnModule pF = new LearnModule_PostFlop();
//		ModuleHistoryLearner.learnStaticFile("bot/data/histories/ms/test.ms", "Bot", pF);
//		
//		pF.printState();
		
		LearnModule preF = new LearnModule_PreFlop("pf");
//		ModuleHistoryLearner.learnStaticFile("bot/data/histories/ms/test.ms", "Bot", preF);
		
//		preF.writeLearner("bot/test/test.ser");
		
//		preF.readLearner(System.getenv(""));
//		preF.printState();
		
		System.out.println(System.getenv());
		char c = System.getenv("TEMP").contains("\\") ? '\\' : '/';
		java.sql.Date d = new Date(System.currentTimeMillis());
		
		System.out.println(System.getenv("TEMP") + c + d + "_preflop.ser");
		
		
		


	}
	
}
