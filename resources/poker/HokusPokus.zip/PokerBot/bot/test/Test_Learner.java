package bot.test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.learner.BayesianLearner;
import bot.learner.Instance;
import bot.learner.LearnModule;
import bot.learner.LearnModule_PostFlop;
import bot.learner.LearnModule_PostFlop2;
import bot.learner.LearnModule_PreFlop;
import bot.learner.LearnModule_PreFlop3;
import bot.learner.LearnerTools;
import bot.learner.history.HistoryStatistics;
import bot.learner.history.ModuleHistoryLearner;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.ResultsMatchStateConverter;
import bot.utils.ShowdownSimulator;
import bot.utils.analyzer.Combination;

public class Test_Learner {

	public static void main(String args[]) {

		LearnModule preF = new LearnModule_PreFlop3("pf");

		for (int n1=2; n1<=14; n1++) {
			for (int n2=n1; n2<=14; n2++) {
				for (int c1=0; c1<=3; c1++) {
					for (int c2=0; c2<=3; c2++) {
						
						if (c1 == c2 && n1 == n2) 
							continue;

						Vector<Card> myCards = new Vector<Card>();
						myCards.add(new Card(c1,n1));
						myCards.add(new Card(c2,n2));

						int number1 = LearnerTools.getNumberBucket(myCards.get(0));
						int number2 = LearnerTools.getNumberBucket(myCards.get(1));
						int pair = LearnerTools.getPairBucket(myCards);
						int suited = LearnerTools.getSuitedBucket(myCards);
						
						if (number1 != number2 && pair == 1)
							System.out.println("# " + myCards);
						
						boolean outcome = Math.random() > 0.5 ? true : false;
						
						preF.getLearner().learnInstance(new Instance(new int[] {number1, number2, pair, suited }, outcome ));
						
					}	
				}	
			}	
		}
		
		preF.printState();

	}
	
}
