package bot.test;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.utils.LineReader;

public class LogChecker {
	
//	private Hashtable<String, String> playerMoney;
	private Vector<String> rounds;
	private Vector<String> rounds2;
	
	public void readFile(String filename) {
		try {
			// Init
//			playerMoney = new Hashtable<String, Vector<Integer>>();
			rounds2 = new Vector<String>();
			
			LineReader lr = new LineReader(filename);
			String line = "";
//			
//			while ((line = lr.readLine()) != null) {
//				if (line.charAt(0) != '#')
//					break;
//			}
//			lr.close();
//			
//			String[] players = line.split(":")[0].replace("|", ":").split(":");
//			for (int i=0; i<players.length; i++) {
//				playerMoney.put(players[i], new Vector<Integer>());
//			}
//			
//			lr.close();
			
			lr = new LineReader(filename);
			
			while ((line = lr.readLine()) != null) {
				if (line.charAt(0) == '#')
					continue;
				
				
				rounds2.add(line.split(":")[4]);

			}
			
//			System.out.println(playerMoney);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void readFile2(String filename) {
		try {
			// Init
//			playerMoney = new Hashtable<String, Vector<Integer>>();
			rounds = new Vector<String>();
			
			LineReader lr = new LineReader(filename);
			String line = "";
//			
//			while ((line = lr.readLine()) != null) {
//				if (line.charAt(0) != '#')
//					break;
//			}
//			lr.close();
//			
//			String[] players = line.split(":")[0].replace("|", ":").split(":");
//			for (int i=0; i<players.length; i++) {
//				playerMoney.put(players[i], new Vector<Integer>());
//			}
//			
//			lr.close();
			
			lr = new LineReader(filename);
			
			while ((line = lr.readLine()) != null) {
				if (line.charAt(0) == '#')
					continue;
				
				
				rounds.add(line);

			}
			
//			System.out.println(playerMoney);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void compare() {
		for (int i=0; i<rounds.size(); i++) {
			if (!rounds.get(i).equals(rounds2.get(i))) {
				System.out.println("Fehler in Runde " + i + ": " + rounds.get(i) + " - " + rounds2.get(i));
			}
		}
	}
	
	public void print() {
		for (int i=0; i<rounds.size(); i++) {
			System.out.println(i + ": " + rounds.get(i) + " " + rounds2.get(i));
		}
	}
	
	public static void main(String args[]) {
		LogChecker lc = new LogChecker();
		lc.readFile("bot/test/test2.log");
		lc.readFile2("bot/test/test2.out");
		lc.print();
		lc.compare();
	}

}
