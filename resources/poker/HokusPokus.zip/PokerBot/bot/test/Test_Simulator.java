package bot.test;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.learner.LearnModule;
import bot.learner.history.HistoryStatistics;
import bot.opponent.SituationStoreController;
import bot.stats.GameStatistics;
import bot.utils.Card;
import bot.utils.GameSituation;
import bot.utils.LineReader;
import bot.utils.ResultsMatchStateConverter;
import bot.utils.ShowdownSimulator;

public class Test_Simulator {
	public static void main(String args[]) {
		try {
			Vector<Card> myCards = new Vector<Card>();
			myCards.add(new Card("Ad"));
			myCards.add(new Card("Qh"));
			
			Vector<Card> boardCards = new Vector<Card>();
			boardCards.add(new Card("6h"));
			boardCards.add(new Card("Tc"));
			boardCards.add(new Card("Ks"));
			boardCards.add(new Card("9d"));

			long time = System.currentTimeMillis();

			ShowdownSimulator ss = new ShowdownSimulator(5,myCards,boardCards);
			GameSituation gs = new GameSituation();
			gs.updateSituation(ResultsMatchStateConverter.convertResultToMatchState("MathFair|MathFair2|Bot2|Bot|BaseBot2_v3|BaseBot_v3:0:ffffcc/cc/cc/cc:2c2d|7c9s|4d8c|2s6h|Ah9c|5dQd/AdJhKd/6c/4h:2|-2|0|0|0|0", "Bot"));
			SituationStoreController ssc = new SituationStoreController();
			ssc.addObservation(gs);
//			System.out.println(gs);
			ss.setGameSituation(gs);

			
//			Vector<Vector<Card>> enemy1Range = new Vector<Vector<Card>>();
//			Vector<Card> c1 = new Vector<Card>(); c1.add(new Card("Ac")); c1.add(new Card("As")); enemy1Range.add(c1);
//			Vector<Card> c2 = new Vector<Card>(); c2.add(new Card("Ac")); c2.add(new Card("Ah")); enemy1Range.add(c2);
//			Vector<Card> c3 = new Vector<Card>(); c3.add(new Card("Ac")); c3.add(new Card("Ad")); enemy1Range.add(c3);
//			Vector<Card> c4 = new Vector<Card>(); c4.add(new Card("As")); c4.add(new Card("Ah")); enemy1Range.add(c4);
//			Vector<Card> c5 = new Vector<Card>(); c5.add(new Card("As")); c5.add(new Card("Ad")); enemy1Range.add(c5);
//			Vector<Card> c6 = new Vector<Card>(); c6.add(new Card("Ah")); c6.add(new Card("Ad")); enemy1Range.add(c6);
			

//			ss.setPlayerCardRange(0, enemy1Range);
			
			ss.runSimulations(1000, true);
			System.out.println(ss.getWinPercentage());
			System.out.println(ss.getTiePercentage());
			System.out.println(ss.getLoosePercentage());
			System.out.println(ss.getAverageWinAmount());
			
			
			System.out.println((System.currentTimeMillis() - time));

		}
//		boardCards.add(new Card("4d"));
		catch (Exception e) {
			e.printStackTrace();
		}
//		ss.runSimulations(1000, true);
		
		
	}

}
