package bot;


import java.io.*;
import java.net.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import bot.utils.GameSituation;


public class CopyOfB2Bot extends BaseBot {
	
	protected Vector<WinStat> wins = new Vector<WinStat>();
	
//	protected int decisionPre = DECISION_CHART;
//	protected int decisionPost = DECISION_SIM;
//	protected boolean preflopPlayed = false;
	protected boolean postflopPlayed = false;
//	
//	protected boolean decisionRandom = true;
//	
	protected static final int DECISION_LEARNER_PREFLOP = 0,
								DECISION_CHART = 1,
								DECISION_LEARNER_POSTFLOP = 2,
								DECISION_SIM = 3,
								DECISION_BLUFF = 4;
	
	protected static final int DECISION_COUNT = 5;
	
	protected double[] weights = new double[DECISION_COUNT];
	protected double[] decisions = new double[DECISION_COUNT];
	
	
    public void getDecision() throws IOException, SocketException {
    	decisions[DECISION_CHART] = chartRank;
    	decisions[DECISION_LEARNER_PREFLOP] = learnerRank;
    	decisions[DECISION_SIM] = simRank;
    	decisions[DECISION_LEARNER_POSTFLOP] = learnerRank;

    	double rank = 0;
    	
    	if (publicState.getState() == GameSituation.STATE_PREFLOP) {
    		rank = decisions[DECISION_CHART] * weights[DECISION_CHART] + decisions[DECISION_LEARNER_PREFLOP] * weights[DECISION_LEARNER_PREFLOP];
    	}
    	else {
    		rank = decisions[DECISION_SIM] * weights[DECISION_SIM] + decisions[DECISION_LEARNER_POSTFLOP] * weights[DECISION_LEARNER_POSTFLOP];
    		postflopPlayed = true;
    	}
    	
    	System.out.print(getClass().getSimpleName() + "> DECISIONS: ");
    	for (int i=0; i<DECISION_COUNT; i++) 
    		System.out.print(getDecString(i) + "(" + round(weights[i]) + ")" + "->" + round(decisions[i]) + " ");
    	System.out.println("=> " + round(rank));
    	
    	
    	if (rank < 0.4)
    		sendFold();
    	else if (rank < 0.6)
    		sendCall();
    	else 
    		sendRaise();
    	
    	
    
    }



    
    public void handleNewRound() {
    	super.handleNewRound();
    	
    	postflopPlayed = false;

    	if (bluffing) {
    		weights[DECISION_CHART] = 0;
    		weights[DECISION_SIM] = 0;
    		weights[DECISION_LEARNER_POSTFLOP] = 0;
    		weights[DECISION_LEARNER_PREFLOP] = 0;
    		weights[DECISION_BLUFF] = 1;
    	}
    	else if (publicState.getRound() < roundsToPlay/5) {
    		weights[DECISION_CHART] = 1;  
    		weights[DECISION_SIM] = 1;
    		weights[DECISION_LEARNER_POSTFLOP] = 0;
    		weights[DECISION_LEARNER_PREFLOP] = 0;
    		weights[DECISION_BLUFF] = 0;
    	}
    	else  {
			double chart = getAverageWin(DECISION_CHART);
			double learnerPre = getAverageWin(DECISION_LEARNER_PREFLOP);
			
			
			double minPre = chart;
			if (learnerPre < minPre) minPre = learnerPre;

			
			double correctedChart = chart - minPre + Math.abs(minPre);
			double correctedLearnerPre = learnerPre - minPre + Math.abs(minPre);
			
			double correctedSumPre = correctedChart + correctedLearnerPre;
			
//			System.out.println(getClass().getSimpleName() + "> Decisions [PREFLOP]: Chart=" + round(chart) + "(" + round(correctedChart) + ")" + " Learner=" + round(learnerPre) + "(" + round(correctedLearnerPre) + ")");

			
			

			double sim = getAverageWin(DECISION_SIM);
			double learnerPost = getAverageWin(DECISION_LEARNER_POSTFLOP);
			
			double minPost = sim;
			if (learnerPost < minPost) minPost = learnerPost;
			
			double correctedSim = sim - minPost + Math.abs(minPost);
			double correctedLearnerPost = learnerPost - minPost + Math.abs(minPost);
			
			double correctedSumPost = correctedSim + correctedLearnerPost;
			
//			System.out.println(getClass().getSimpleName() + "> Decisions [POSTFLOP]: Sim=" + round(sim) + "(" + round(correctedSim) + ")" + " Learner=" + round(learnerPost) + "(" + round(correctedLearnerPost) + ")");

			
			
			weights[DECISION_CHART] = correctedChart / correctedSumPre;
    		weights[DECISION_SIM] =  correctedSim / correctedSumPost;
    		weights[DECISION_LEARNER_POSTFLOP] = correctedLearnerPost / correctedSumPost;
    		weights[DECISION_LEARNER_PREFLOP] =  correctedLearnerPre / correctedSumPre;
    		weights[DECISION_BLUFF] = 0;
			
    	}
    	
    	
    	printWeights();
    	
    }
    
    public void printWeights() {
    	System.out.print(getClass().getSimpleName() + "> WEIGHTS: ");
    	for (int i=0; i<DECISION_COUNT; i++)
    		System.out.print(getDecString(i) + "->" + round(weights[i]) + " ");
    	
    	System.out.println();
    }
    

    
    public void handleHandFinished() {
		super.handleHandFinished();
		

		updateWeights(DECISION_BLUFF);
		
		updateWeights(DECISION_CHART);
		updateWeights(DECISION_LEARNER_PREFLOP);
		
		if (postflopPlayed) {
			updateWeights(DECISION_SIM);
			updateWeights(DECISION_LEARNER_POSTFLOP);
		}

		
		
		if (publicState.getRound() % 1 == 0) {
			printWin();
		}
			
    }
    
    protected void updateWeights(int i) {
    	WinStat ws = wins.get(i);
    	WinStat ws2 = new WinStat(ws.who, ws.amount + publicState.getMyPlayer().getWinAtRound(publicState.getRound()) * weights[i], ws.howMuch + weights[i]);
    	
    	wins.set(i, ws2);
    }
   
    
    
    
    public double getAverageWin(int dec) {
    	return wins.get(dec).getAverage();
    }
    
    public void printWin() {
    	for (int i=0; i<DECISION_COUNT; i++) {
    		System.out.println(getClass().getSimpleName() + "> " + getDecString(wins.get(i).who) + "\twon " + round(wins.get(i).amount) + "\tused " + round(wins.get(i).howMuch) + "\taverage " + round(wins.get(i).getAverage()) + ".");
    	}
    }
    
    
	public static String getDecString(int dec) {
		if (dec == DECISION_BLUFF) return "BLUFF";
		if (dec == DECISION_CHART) return "CHART";
		if (dec == DECISION_LEARNER_POSTFLOP) return "L_POST";
		if (dec == DECISION_LEARNER_PREFLOP) return "L_PRE";
		if (dec == DECISION_SIM) return "SIM";
		
		return dec + "";
		
	}
    
    public CopyOfB2Bot(){
      super();
      
      for (int i=0; i<6; i++)
    	  wins.add(new WinStat(i,0,0));
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        CopyOfB2Bot rpc = new CopyOfB2Bot();
//        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
//        System.out.println("Successful connection!");
        rpc.run();
    }
    
    
    public class WinStat {
    	public int who;
    	public double amount;
    	public double howMuch;
    	
    	public double getAverage() {
    		if (howMuch == 0)
    			return 0;
    		
    		return amount/howMuch;
    	}
    	
    	public WinStat(int who, double amount, double howMuch) {
    		this.who = who;
    		this.amount = amount;
    		this.howMuch = howMuch;
    	}
    	
    	public String toString() {
    		return getDecString(who) + " -> " + amount + "(" + howMuch + ")";
    	}
    	

    }
    
}