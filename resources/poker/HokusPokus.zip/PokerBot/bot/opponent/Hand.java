package bot.opponent;

import java.util.Vector;

import bot.BaseBot;
import bot.utils.Card;

public class Hand implements Comparable<Hand> {
	
	private Vector<Card> hand;
	private float handStrength = 0;
	private float weight = 0;
	private float normalizedWeight = 0;
	
	
	public Hand(Vector<Card> hand) {
		this.hand = hand;
	}
		
	public Vector<Card> getHand() {
		return hand;
	}
	
	public void setHandStrength(float handStrength) {
		this.handStrength = handStrength;
	}
	
	public float getHandStrength() {
		return handStrength;
	}
	
	public void setWeight(float weight) {
		this.weight = weight;
	}
	
	public float getWeight() {
		return this.weight;
	}
	
	public void setNormWeight(float weight) {
		this.normalizedWeight= weight;
	}
	
	public float getNormWeight() {
		return this.normalizedWeight;
	}

	public int compareTo(Hand hand) {
		if(this.weight < hand.weight) return 1;
		else if(this.weight > hand.weight) return -1;
		
//		if(this.handStrength < hand.handStrength) return 1;
//		else if(this.handStrength > hand.handStrength) return -1;
		
		return 0;
	}
	
	public String toString() {
		return hand.get(0).toString() + "|" + hand.get(1).toString();
	}
	
	public boolean equals(Hand h) {
		if (h.getHand().get(0).getColor() != this.hand.get(0).getColor() || h.getHand().get(1).getColor() != this.hand.get(1).getColor())
			return false;
		if (h.getHand().get(0).getNumber() != this.hand.get(0).getNumber() || h.getHand().get(1).getNumber() != this.hand.get(1).getNumber())
			return false;
		
		return true;
	}

}
