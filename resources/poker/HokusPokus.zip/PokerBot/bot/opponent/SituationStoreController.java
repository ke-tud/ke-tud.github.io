package bot.opponent;

import java.util.HashMap;
import java.util.Vector;

import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;

public class SituationStoreController {
	
	public void addObservation(GameSituation gs) {
		
		HashMap<String, Integer> betsToCall = new HashMap<String, Integer>();
		HashMap<String, Integer> previousAction = new HashMap<String, Integer>();
		HashMap<String, Integer> previousBetsToCall = new HashMap<String, Integer>();
		
		Vector<Player> players = gs.getPlayers();
		for(Player p : players) {
			if(gs.getBigBlindPlayer() == p) { // TODO ändern mit SB
				betsToCall.put(p.getName(), 0);
			}
			else {
				betsToCall.put(p.getName(), 1);
			}
			previousAction.put(p.getName(), 0);
			previousBetsToCall.put(p.getName(), 0);
		}
		
		Vector<GameAction> actions = gs.getActions();
		
		int round = gs.STATE_PREFLOP;
		for(GameAction a : actions) {
			
			if(a.getSituation() != round) {
				round = a.getSituation();
				for(Player p : players) {
					betsToCall.put(p.getName(), 0);
				}
			}
			
			String pname = a.getPlayer().getName();
			a.getPlayer().getSituationStore().addObservation(round, betsToCall.get(pname).intValue(), previousAction.get(pname).intValue(), previousBetsToCall.get(pname).intValue(), a.getType());
			
//			if(a.getType() == 0) {
//				betsToCall.remove(pname);
//				previousAction.remove(pname);
//				previousBetsToCall.remove(pname);
//			}
			if(a.getType() == 1) {
				if(betsToCall.get(pname).intValue() == 0) {
					previousBetsToCall.put(pname, 0);
				}
				else {
					previousBetsToCall.put(pname, 1);
				}
				previousAction.put(pname, 0);
				betsToCall.put(pname, 0);
			}
			else if(a.getType() == 2) {
				if(betsToCall.get(pname).intValue() == 0) {
					previousBetsToCall.put(pname, 0);
				}
				else {
					previousBetsToCall.put(pname, 1);
				}
				previousBetsToCall.put(pname, betsToCall.get(pname).intValue());
				previousAction.put(pname, 1);
				
				//BetsToCall für die anderen Spieler anpassen
				for(Player p : players) {
					betsToCall.put(p.getName(), betsToCall.get(p.getName()).intValue() + 1);
				}
				
				//BetsToCall für den eigenen Spieler wieder auf 0 setzen
				betsToCall.put(pname, 0);
			}
		}
	}
}
