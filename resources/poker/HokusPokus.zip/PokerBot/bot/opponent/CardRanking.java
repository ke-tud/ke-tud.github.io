package bot.opponent;

import java.util.Collections;
import java.util.Vector;

import bot.utils.Card;

public class CardRanking {
	
	private Vector<Card> ranking = new Vector<Card>();
	
	
	public void rankCards(int bettingRound, Vector<Card> board) {
		Collections.sort(ranking);
	}
}
