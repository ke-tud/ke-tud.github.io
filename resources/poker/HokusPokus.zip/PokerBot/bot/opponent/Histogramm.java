package bot.opponent;

public class Histogramm {
	
	private int[] histogramm = new int[10];
	private int observationCounter = 0;
	
	public void addObservation(float strength) {
		int pos = (int) (strength * 10);
		histogramm[pos]++;
		observationCounter++;
	}
	
	public float getWinProbability(float ownStrength) {
		int pos = (int) (ownStrength * 10);
		int lowerCounter = 0;
		
		for(int i = 0; i < pos; i++) {
			lowerCounter = lowerCounter + histogramm[i];
		}
		
		return lowerCounter / observationCounter;
	}
	
	public float getLooseProbability(float ownStrength) {
		int pos = (int) (ownStrength * 10);
		int higherCounter = 0;
		
		for(int i = 9; i > pos; i--) {
			higherCounter = higherCounter + histogramm[i];
		}
		
		return higherCounter / observationCounter;
	}
	
	public float getDrawProbability(float ownStrength) {
		int pos = (int) (ownStrength * 10);
		
		return histogramm[pos] / observationCounter;
	}

}
