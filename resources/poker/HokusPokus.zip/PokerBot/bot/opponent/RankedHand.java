package bot.opponent;

import java.util.Vector;

import bot.utils.Card;

public class RankedHand extends Hand {
	
	private long rank = 0;
	
	public RankedHand(Vector<Card> hand) {
		super(hand);
	}
	
	public void setHandRank(long rank) {
		this.rank = rank;
	}
	
	public long getHandRank() {
		return rank;
	}
	
	public int compareTo(RankedHand hand) {
		if(this.rank < hand.rank) return 1;
		else if(this.rank > hand.rank) return -1;
				
		return 0;
	}
	
}
