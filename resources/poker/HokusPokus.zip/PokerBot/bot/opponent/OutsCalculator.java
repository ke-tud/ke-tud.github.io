package bot.opponent;

import java.util.Vector;

import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.analyzer.Combination;
import bot.utils.analyzer.Flush;
import bot.utils.analyzer.FullHouse;
import bot.utils.analyzer.RoyalFlush;
import bot.utils.analyzer.Straight;
import bot.utils.analyzer.StraightFlush;
import bot.utils.analyzer.Triplet;

public class OutsCalculator {
	
	public float getPotential(Vector<Card> holeCards, Vector<Card> board) {
		int outs = 0;
		
//		for(int a=0; a<=1081; a++) {
		for(int i=Card.N2; i<=Card.NA; i++) {
			for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
				Card out = new Card(j,i);
				
				if(holeCards.get(0).equals(out) || holeCards.get(1).equals(out)) {
					continue;
				}
				boolean isOnBoard = false;
				for(Card c : board) {
					if(c.equals(out)) isOnBoard=true;
				}
				if(isOnBoard) continue;
				
				board.add(out);
				
				FullCombo f2 = new FullCombo(holeCards.toArray(new Card[0]), board.toArray(new Card[0]));
				Combination c2 = f2.getBestCombo();
				
				if(c2 instanceof Triplet) {
					outs++;
				}
				else if(c2 instanceof Straight) {
					outs++;
				}
				else if(c2 instanceof Flush) {
					outs++;
				}
				else if(c2 instanceof FullHouse) {
					outs++;
				}
				else if(c2 instanceof StraightFlush) {
					outs++;
				}
				else if(c2 instanceof RoyalFlush) {
					outs++;
				}
				board.remove(board.lastElement());
			}
		}
//		}
		return (float) (outs*4) / 100;
	}	
}
