package bot.opponent;

import java.util.Collections;
import java.util.Vector;


import bot.externHandEvaluator.CardSet;
import bot.externHandEvaluator.HandEval;
import bot.utils.Card;
import bot.utils.FullCombo;
import bot.utils.Player;
import bot.utils.analyzer.Combination;

public class HandStrength {
	
//	HandEvaluator he;
	private OutsCalculator outsC = new OutsCalculator();
	private boolean cached = false;
	private Vector<RankedHand> hands = new Vector<RankedHand>();

	public float getHandStrength(Vector<Card> holeCards, Vector<Card> boardcards) {
		
		CardSet cs = new CardSet();
		for(Card c : boardcards) {
			cs.add(getExternCard(c));
		}
		
		if(cached == false) {
		
			for(int i=Card.N2; i<=Card.NA; i++) {
				for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
					for(int k=i; k<=Card.NA; k++) {
						for(int l=Card.DIAMOND; l<=Card.CLUB; l++) {
							
							//Bedingungen für ungültige oder nicht benötigte Karten des Gegners
							Vector<Card> cards2 = getCardVector(i, j, k, l);	
							if(cards2.get(0).getNumber() == cards2.get(1).getNumber()) {
								if(cards2.get(0).getColor() >= cards2.get(1).getColor()) {
									continue;
								}
							}
							boolean isOnBoard = false;
							for(Card c : boardcards) {
								if(c.equals(cards2.get(0)) || c.equals(cards2.get(1))) isOnBoard=true;
							}
							if(isOnBoard) continue;

							//Evaluation der Gegnerischen Hand
							bot.externHandEvaluator.Card card1 = getExternCard(cards2.get(0));
							bot.externHandEvaluator.Card card2 = getExternCard(cards2.get(1));
							cs.add(card1);
							cs.add(card2);
							int rank = 0;
							if(cs.size() == 5) {
								rank = HandEval.hand5Eval(HandEval.encode(cs));
							}
							else if(cs.size() == 6) {
								rank = HandEval.hand6Eval(HandEval.encode(cs));
							}
							else if(cs.size() == 7) {
								rank = HandEval.hand7Eval(HandEval.encode(cs));
							}
							cs.remove(card1);
							cs.remove(card2);
							
							RankedHand h = new RankedHand(cards2);
							h.setHandRank(rank);
							hands.add(h);
						}	
					}
				}
			}
			
//			Collections.sort(hands);
			cached = true;
		}
				
		int ahead = 0;
		int tied = 0;
		int behind = 0;
		
		bot.externHandEvaluator.Card card1 = getExternCard(holeCards.get(0));
		bot.externHandEvaluator.Card card2 = getExternCard(holeCards.get(1));
		cs.add(card1);
		cs.add(card2);
		int rank = 0;
		if(cs.size() == 5) {
			rank = HandEval.hand5Eval(HandEval.encode(cs));
		}
		else if(cs.size() == 6) {
			rank = HandEval.hand6Eval(HandEval.encode(cs));
		}
		else if(cs.size() == 7) {
			rank = HandEval.hand7Eval(HandEval.encode(cs));
		}
		cs.remove(card1);
		cs.remove(card2);
		
		for(RankedHand h : hands) {
			if(holeCards.get(0).equals(h.getHand().get(0)) || holeCards.get(0).equals(h.getHand().get(1)) || holeCards.get(1).equals(h.getHand().get(0)) || holeCards.get(1).equals(h.getHand().get(1))) {
				continue;
			}
			if(rank > h.getHandRank()) {
				ahead++;
			}
			else if(rank == h.getHandRank()) {
				tied++;
			}
			else if(rank < h.getHandRank()) {
				behind++;
			}
		}
		
//		System.out.println(ahead + " " + tied + " " + behind);
		return (float) (ahead + tied / 2) / (ahead + tied + behind);
	}
	
	public float calculateOwnHandStrenth(Vector<Card> holeCards,Vector<Card> boardcards, HandRange handrange, int playersInHand) {
		
//		System.out.println("HANDRANGE: " + handrange.getHandrange());
		//Rang für die eigene Hand bestimmen
		CardSet cs = new CardSet();
		bot.externHandEvaluator.Card holeCard1 = getExternCard(holeCards.get(0));
		bot.externHandEvaluator.Card holeCard2 = getExternCard(holeCards.get(1));
		cs.add(holeCard1);
		cs.add(holeCard2);
		
		for(Card c : boardcards) {
			cs.add(getExternCard(c));
		}
		long rank1 = 0;
		if(cs.size() == 5) {
			rank1 = HandEval.hand5Eval(HandEval.encode(cs));
		}
		else if(cs.size() == 6) {
			rank1 = HandEval.hand6Eval(HandEval.encode(cs));
		}
		else if(cs.size() == 7) {
			rank1 = HandEval.hand7Eval(HandEval.encode(cs));
		}
		
		cs.remove(holeCard1);
		cs.remove(holeCard2);
		
		float ahead = 0;
		float tied = 0;
		float behind = 0;
		long rank2 = 0;
		
		
		Vector<Hand> opponentHandrange = handrange.getHandrange();
		for(Hand hand : opponentHandrange) {
					
			//Evaluation der Gegnerischen Hand
			bot.externHandEvaluator.Card opponentCard1 = getExternCard(hand.getHand().get(0));
			bot.externHandEvaluator.Card opponentCard2 = getExternCard(hand.getHand().get(1));
			cs.add(opponentCard1);
			cs.add(opponentCard2);
			rank2 = 0;
			if(cs.size() == 5) {
				rank2 = HandEval.hand5Eval(HandEval.encode(cs));
			}
			else if(cs.size() == 6) {
				rank2 = HandEval.hand6Eval(HandEval.encode(cs));
			}
			else if(cs.size() == 7) {
				rank2 = HandEval.hand7Eval(HandEval.encode(cs));
			}
			cs.remove(opponentCard1);
			cs.remove(opponentCard2);

			if(rank1 > rank2) {
				ahead = ahead + hand.getWeight();
			}
			else if(rank1 == rank2) {
				tied = tied + hand.getWeight();
			}
			else if(rank1 < rank2) {
				behind = behind + hand.getWeight();
			}
		}
		float hs = (ahead + tied / 2) / (ahead + tied + behind);
		float potential = outsC.getPotential(holeCards, boardcards);
		return ((float)Math.pow(hs, playersInHand)) + ((1-hs)*potential);
	}
	
//	public float getHandStrengthWeigth(Vector<Card> holeCards, Vector<Card> boardcards, Vector<Player> players) {
//		float ahead = 0;
//		float tied = 0;
//		float behind = 0;
//		
//		FullCombo f1 = new FullCombo(holeCards.toArray(new Card[0]), boardcards.toArray(new Card[0]));
//		Combination c1 = f1.getBestCombo();
//		
//		for(int i=2; i<=14; i++) {
//			for(int j=0; j<=3; j++) {
//				for(int k=2; k<=14; k++) {
//					for(int l=0; l<=3; l++) {
//						FullCombo f2 = new FullCombo(getCardVector(i, j, k, l).toArray(new Card[0]), boardcards.toArray(new Card[0]));
//						Combination c2 = f2.getBestCombo();
//						if(c1.isHigherThan(c2) == -1) {
//							float tmp = 0;
//							for(Player p : players) {
//								tmp += p.getWeightTable().getWeight(getCardVector(i, j, k, l));
//							}
//							ahead += tmp/players.size();
//						}
//						else if(c1.isHigherThan(c2) == 0) {
//							float tmp = 0;
//							for(Player p : players) {
//								tmp += p.getWeightTable().getWeight(getCardVector(i, j, k, l));
//							}
//							tied += tmp/players.size();
//						}
//						else if(c1.isHigherThan(c2) == 1) {
//							float tmp = 0;
//							for(Player p : players) {
//								tmp += p.getWeightTable().getWeight(getCardVector(i, j, k, l));
//							}
//							behind += tmp/players.size();
//						}
//					}	
//				}
//			}
//		}
//		return (float) (ahead + tied / 2) / (ahead + tied + behind);
//	}
	
	private Vector<Card> getCardVector(int number1, int color1, int number2, int color2) {
		Vector<Card> v = new Vector<Card>();
		v.add(new Card(color1, number1));
		v.add(new Card(color2, number2));
		return v;
	}
	
//	public HandStrength(HandEvaluator he) {
//		this.he  =he;
//	}
	
	public bot.externHandEvaluator.Card getExternCard(Card c) {
		int number = c.getNumber() - 2;
		int suit = (c.getColor() + 1) % 4;
		bot.externHandEvaluator.Card.Rank[] ranks = bot.externHandEvaluator.Card.Rank.values();
		bot.externHandEvaluator.Card.Suit[] suits = bot.externHandEvaluator.Card.Suit.values();
		
		return new bot.externHandEvaluator.Card(ranks[number],suits[suit]);
	}

	public void reinit() {
		cached = false;
		hands.clear();
	}
	
}
