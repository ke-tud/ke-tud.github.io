package bot.opponent;

import bot.utils.GameAction;
import bot.utils.GameSituation;
import bot.utils.Player;

public class MoveGuesser {
	
	public static OpponentMove guessMove(GameSituation gs, Player p) {
		
		int state = gs.getState();
		int bets = gs.getAmountToCallFromPlayer(p);
		
		if(gs.isPlayerInGame(p)){
			double f = p.getSituationStore().getFrequency(state, bets, 2, 2, GameAction.ACTION_FOLD);
			double c = p.getSituationStore().getFrequency(state, bets, 2, 2, GameAction.ACTION_CALL);
			double r = p.getSituationStore().getFrequency(state, bets, 2, 2, GameAction.ACTION_RAISE);
			
			return new OpponentMove(f,c,r);
		}else{
			return new OpponentMove(1.0,0.0,0.0);
		}
	}
	
	public static OpponentMove guessMove(GameSituation gs, Player p, int bets) {
		int state = gs.getState();
		
		if(gs.isPlayerInGame(p)){
			double f = p.getSituationStore().getFrequency(state, bets, 2, 2, GameAction.ACTION_FOLD);
			double c = p.getSituationStore().getFrequency(state, bets, 2, 2, GameAction.ACTION_CALL);
			double r = p.getSituationStore().getFrequency(state, bets, 2, 2, GameAction.ACTION_RAISE);
			
			return new OpponentMove(f,c,r);
		}else{
			return new OpponentMove(1.0,0.0,0.0);
		}
		
		
		
	}
	
}
