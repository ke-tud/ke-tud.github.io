package bot.opponent;

import java.util.Collections;
import java.util.HashMap;
import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.utils.Card;

public class HandSorter {
	
	private HashMap<String, Float> hands = new HashMap<String, Float>();
//	private Vector<Vector<Card>> handRange = new Vector<Vector<Card>>();
//	private PreFlopChart pChart = new PreFlopChart();
	private HandStrength hsC; 
	private OutsCalculator oC; 
	
	public HashMap<String, Float> getHandRange() {
		return hands;
	}
	
//	public void sort(Vector<Card> boardCards, Vector<Vector<Card>> handRange) {
//		
//		for(Vector<Card> h : handRange) {
//			this.hands.add(new Hand(h));
//		}
//		
//		for(Hand h : hands) {
//			float hS = hsC.getHandStrength(h.getHand(), boardCards);
//			float potential = oC.getPotential(h.getHand(), boardCards);
//			
//			float ehs = hS + ((1-hS) * potential);
//			h.setHandStrength(ehs);
//		}
//		Collections.sort(hands);
//		
//		handRange.clear();
//		for(Hand h : hands) {
//			handRange.add(h.getHand());
//		}
//	}
	
	public HandSorter(HandStrength hsC, OutsCalculator oC) {
		this.hsC = hsC;
		this.oC = oC;
	}
	
	public HandSorter() {
		hsC = new HandStrength();
		oC = new OutsCalculator();
	}
	
	public void initCombinations(Vector<Card> boardcards) {
		
		hands.clear();
		hsC.reinit();
		
		if(hands.size() == 0) {
			for(int i=Card.N2; i<=Card.NA; i++) {
				for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
					for(int k=i; k<=Card.NA; k++) {
						for(int l=Card.DIAMOND; l<=Card.CLUB; l++) {
							
							//Bedingungen für ungültige oder nicht benötigte Karten des Gegners
							Vector<Card> cards2 = getCardVector(i, j, k, l);	
							if(cards2.get(0).getNumber() == cards2.get(1).getNumber()) {
								if(cards2.get(0).getColor() >= cards2.get(1).getColor()) {
									continue;
								}
							}
							
							boolean isOnBoard = false;
							for(Card c : boardcards) {
								if(c.equals(cards2.get(0)) || c.equals(cards2.get(1))) isOnBoard=true;
							}
							if(isOnBoard) continue;
							
							Hand h = new Hand(cards2);
							float hS = hsC.getHandStrength(cards2, boardcards);
							float potential = 0;//oC.getPotential(cards2, boardcards);
							float ehs = hS + ((1-hS) * potential);
							h.setHandStrength(ehs);
							
							hands.put(h.toString(), h.getHandStrength());
													
						}
					}
				}
			}
		}
		
//		for(Hand h : hands) {
//			//System.out.println("Handstärke aufrufen");
//			float hS = hsC.getHandStrength(h.getHand(), boardcards);
//			//System.out.println("Potential aufrufen");
//			float potential = oC.getPotential(h.getHand(), boardcards);
//			
//			float ehs = hS + ((1-hS) * potential);
//			h.setHandStrength(ehs);
//		}
//		Collections.sort(hands);
		
//		handRange.clear();
//		for(Hand h : hands) {
//			handRange.add(h.getHand());
//		}
		
//		System.out.println(handRange);
//		System.out.println(handRange.size());
	}
	
	private Vector<Card> getCardVector(int number1, int color1, int number2, int color2) {
		Vector<Card> v = new Vector<Card>();
		v.add(new Card(color1, number1));
		v.add(new Card(color2, number2));
		return v;
	}
	

}
