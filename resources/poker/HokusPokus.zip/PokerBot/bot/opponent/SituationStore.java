package bot.opponent;

import java.util.Arrays;

import bot.utils.GameSituation;

public class SituationStore {
	
	//Beschreibung der Stellem in den Arrays
	//1. Stelle: Setzrunde (0 = Pre-Flop, 1 = Flop, 2 = Turn, 3 = River)
	//2. Stelle: Anzahl der Bets um zu callen (0 = 0, 1 = 1, 2 = >1, 3 = unwichtig)
	//3. Stelle: vorherige Aktion (0 = kein Bet/Raise, 1 = Bet/Raise, 2 = unwichtig)
	//4. Stelle: vorherige Bets zum callen (0, 1 = >= 1, 2 = unwichtig)
	//5. Stelle: Aktion (0 = fold, 1 = check/call, 2 bet/raise, 3 = gibt es bei observations und bedeutet da unwichtig)

	//Prozentuale Wahrscheinlichkeiten
	float[][][][][] frequencies = new float[4][4][3][3][3];
	
	//Beobachtungen pro Abstraktionsstufe
	int[][][][][] observations = new int[4][4][3][3][4];
	
	
	//Histogramme
	Histogramm[][][][][] histogramms = new Histogramm[4][4][3][3][3];
	
	//Treshhold ab dem Beobachtungen in Betracht gezogen werden
	final int treshhold = 100;
	
	public void addObservation(int bettingRound, int betsToCall, int previousAction, int previousBetsToCall, int action) {
		if(betsToCall >= 2 ) betsToCall = 2;
		if(previousBetsToCall >= 1) previousBetsToCall = 1;
		
		observations[bettingRound][3][2][2][3]++;
		observations[bettingRound][betsToCall][2][2][3]++;
		observations[bettingRound][betsToCall][previousAction][2][3]++;
		observations[bettingRound][betsToCall][previousAction][previousBetsToCall][3]++;
		
		observations[bettingRound][3][2][2][action]++;
		observations[bettingRound][betsToCall][2][2][action]++;
		observations[bettingRound][betsToCall][previousAction][2][action]++;
		observations[bettingRound][betsToCall][previousAction][previousBetsToCall][action]++;
			
		//Häufigkeiten anpassen
		for(action=0;action<3;action++) {
			frequencies[bettingRound][3][2][2][action] = ((float) observations[bettingRound][3][2][2][action]) / (float) getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall,3);
			frequencies[bettingRound][betsToCall][2][2][action] = (float) (observations[bettingRound][betsToCall][2][2][action])  / (float) getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall,2);
			frequencies[bettingRound][betsToCall][previousAction][2][action] = (float) (observations[bettingRound][betsToCall][previousAction][2][action]) / (float) getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall,1);
			frequencies[bettingRound][betsToCall][previousAction][previousBetsToCall][action] = (float) (observations[bettingRound][betsToCall][previousAction][previousBetsToCall][action]) / (float) getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall,0);
		}
	}
	
	public float getFrequency(int bettingRound, int betsToCall, int previousAction, int previousBetsToCall, int action) {
		if(betsToCall >= 2 ) betsToCall = 2;
		if(previousBetsToCall >= 1) previousBetsToCall = 1;
		
		if(getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall, 0) >= treshhold) {
			return frequencies[bettingRound][betsToCall][previousAction][previousBetsToCall][action];
		}
		else if(getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall, 1) >= treshhold) {
			return frequencies[bettingRound][betsToCall][previousAction][2][action];
		}
		else if(getObservationCount(bettingRound, betsToCall, previousAction, previousBetsToCall, 2) >= treshhold) {
			return frequencies[bettingRound][betsToCall][2][2][action];
		}
		else {
			return frequencies[bettingRound][3][2][2][action];
		}
	}
	
	private int getObservationCount(int bettingRound, int betsToCall, int previousAction, int previousBetsToCall, int abstractionNiveau) {
		if(abstractionNiveau == 0) {
			return observations[bettingRound][betsToCall][previousAction][previousBetsToCall][3];
		}
		else if(abstractionNiveau == 1) {
			return observations[bettingRound][betsToCall][previousAction][2][3];
		}
		else if(abstractionNiveau == 2) {
			return observations[bettingRound][betsToCall][2][2][3];
		}
		else {
			return observations[bettingRound][3][2][2][3];
		}
	}
	
	public void print() {
		System.out.println("Frequenzen:");
		
		for(int a=0;a<4;a++) {
			for(int b=0;b<4;b++) {
				for(int c=0;c<3;c++) {
					for(int d=0;d<3;d++) {
						for(int e=0;e<3;e++) {
							if(frequencies[a][b][c][d][e] != 0) {
								if(a==0) {
									System.out.print("Pre-Flop|");
								}
								else if(a==1) {
									System.out.print("Flop|");
								}
								else if(a==2) {
									System.out.print("Turn|");
								}
								else if(a==3) {
									System.out.print("River|");
								}
								
								if(b==0) {
									System.out.print("Bets to call = 0|");
								}
								else if(b==1) {
									System.out.print("Bets to call = 1|");
								}
								else if(b==2) {
									System.out.print("Bets to call > 1|");
								}
								else if(b==3) {
									System.out.print("unwichtig|");
								}
								
								if(c==0) {
									System.out.print("vorherige Aktion: kein Raise|");
								}
								else if(c==1) {
									System.out.print("vorherige Aktion: Raise|");
								}
								else if(c==2) {
									System.out.print("unwichtig|");
								}
								
								if(d==0) {
									System.out.print("Previous Bets to Call = 0|");
								}
								else if(d==1) {
									System.out.print("Previous Bets to Call >= 1|");
								}
								else if(d==2) {
									System.out.print("unwichtig|");
								}
								
								if(e==0) {
									System.out.print("Fold -> ");
								}
								else if(e==1) {
									System.out.print("Check/Call -> ");
								}
								else if(e==2) {
									System.out.print("Raise -> ");
								}
								
								System.out.println(frequencies[a][b][c][d][e]);
							}
						}
					}
				}
			}
		}
		
		System.out.println("Beobachtungen:");
		
		for(int a=0;a<4;a++) {
			for(int b=0;b<4;b++) {
				for(int c=0;c<3;c++) {
					for(int d=0;d<3;d++) {
						for(int e=0;e<4;e++) {
							if(observations[a][b][c][d][e] != 0) {
								if(a==0) {
									System.out.print("Pre-Flop|");
								}
								else if(a==1) {
									System.out.print("Flop|");
								}
								else if(a==2) {
									System.out.print("Turn|");
								}
								else if(a==3) {
									System.out.print("River|");
								}
								
								if(b==0) {
									System.out.print("Bets to call = 0|");
								}
								else if(b==1) {
									System.out.print("Bets to call = 1|");
								}
								else if(b==2) {
									System.out.print("Bets to call > 1|");
								}
								else if(b==3) {
									System.out.print("unwichtig|");
								}
								
								if(c==0) {
									System.out.print("vorherige Aktion: kein Raise|");
								}
								else if(c==1) {
									System.out.print("vorherige Aktion: Raise|");
								}
								else if(c==2) {
									System.out.print("unwichtig|");
								}
								
								if(d==0) {
									System.out.print("Previous Bets to Call = 0|");
								}
								else if(d==1) {
									System.out.print("Previous Bets to Call >= 1|");
								}
								else if(d==2) {
									System.out.print("unwichtig|");
								}
								
								if(e==0) {
									System.out.print("Fold -> ");
								}
								else if(e==1) {
									System.out.print("Check/Call -> ");
								}
								else if(e==2) {
									System.out.print("Raise -> ");
								}
								else if(e==3) {
									System.out.print("unwichtig -> ");
								}
								
								System.out.println(observations[a][b][c][d][e]);
							}
						}
					}
				}
			}
		}	
	}
}
