package bot.opponent;

public class OpponentMove {
	public double foldProp;
	public double callProp;
	public double raiseProp;


	public OpponentMove(double f, double c, double r) {
		foldProp = f;
		callProp = c;
		raiseProp = r;
	}
	
	public String toString(){
		return "foldProp.:" + foldProp + "  |  callProp.:" + callProp + "  |  raiseProp.:" + raiseProp;
	}
}