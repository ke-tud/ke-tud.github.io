package bot.opponent;

import java.util.Collections;
import java.util.HashMap;
import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.utils.Card;
import bot.utils.GameAction;
import bot.utils.GameSituation;

public class HandRange {
	
	private PreFlopChart pChart = new PreFlopChart();
	private Vector<Hand> handrange = new Vector<Hand>();
	private boolean preFlopRangeInitiated = false;
	private final float correctationParameter = 1.5f;
	private final int preflopVariance = 10;
	private final int variance = 10;
	private final float postFlopVariance = 0.1f;
	public double remove_threshold = 0.02;
	private float formerRaiseFrequency = 1;
	private float formerCallFrequency = 1;
	private boolean raisedBefore = false;

	public HandRange(PreFlopChart pChart, HandSorter hS) {
		this.pChart = pChart;
//		this.hS = hS;
	}
	
	public HandRange() {
		
	}
	
	public void reinit() {
		preFlopRangeInitiated = false;
		formerCallFrequency = 1;
		formerRaiseFrequency = 1;
		raisedBefore = false;
		handrange.clear();
	}
	
	public void setPreFlopChart(PreFlopChart pChart) {
		this.pChart = pChart;
	}
	
//	public void setHandSorter(HandSorter hS) {
//		this.hS = hS;
//	}
//	
	public Vector<Hand> getHandrange() {
		return handrange;
	}
	
	
	
	
	// Timo
	public void weigthPreFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action) {
		if(action == GameAction.ACTION_FOLD) {
			return;
		}
		
		int raisesTillRank = (int) (169 * raiseFrequency * formerRaiseFrequency);
		int callsTillRank = (int) (169 * callFrequency * formerCallFrequency);
		
		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
		formerCallFrequency = callFrequency * formerRaiseFrequency;
		
		if(!preFlopRangeInitiated) {
			preFlopRangeInitiated = true;
			handrange.clear();
			
			for(int i=Card.N2; i<=Card.NA; i++) {
				for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
					for(int k=i; k<=Card.NA; k++) {
						for(int l=Card.DIAMOND; l<=Card.CLUB; l++) {
							
							//Bedingungen für ungültige oder nicht benötigte Karten des Gegners
							Hand cards2 = new Hand(getCardVector(i, j, k, l));	
							if(cards2.getHand().get(0).getNumber() == cards2.getHand().get(1).getNumber()) {
								if(cards2.getHand().get(0).getColor() >= cards2.getHand().get(1).getColor()) {
									continue;
								}
							}
							if(holeCards.get(0).equals(cards2.getHand().get(0)) || holeCards.get(0).equals(cards2.getHand().get(1)) || holeCards.get(1).equals(cards2.getHand().get(0)) || holeCards.get(1).equals(cards2.getHand().get(1))) {
								continue;
							}
							
							if(action == GameAction.ACTION_RAISE) {
								raisedBefore = true;
								
								if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - preflopVariance) {
									cards2.setWeight(1f);
								}
								else if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank + preflopVariance) {
									int step = 2 * preflopVariance + 1;
									int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - preflopVariance);
									cards2.setWeight((float) (1 - ((float) above/step)));
								}
								else {
									cards2.setWeight(0.01f);
								}

							}
							else if(action == GameAction.ACTION_CALL) {
								if (pChart.getHandRank(cards2.getHand()) <= raisesTillRank) {
									cards2.setWeight(0.5f);
								}
								else if (pChart.getHandRank(cards2.getHand()) <= callsTillRank - preflopVariance) {
									cards2.setWeight(1f);
								}
								else if (pChart.getHandRank(cards2.getHand()) <= callsTillRank + preflopVariance) {
									int step = 2 * preflopVariance + 1;
									int above = pChart.getHandRank(cards2.getHand()) - (callsTillRank - preflopVariance);
									cards2.setWeight((float) (1 - ((float) above/step)));
								}
								else {
									cards2.setWeight(0.01f);
								}
							}
							
							handrange.add(cards2);
						}
					}
				}
			}
		}
		else {
			if(action == GameAction.ACTION_RAISE) {
				for(Hand h: handrange) {
					Hand cards2 = h;
					
					if (pChart.getHandRank(cards2.getHand()) <= raisesTillRank - preflopVariance) {
						cards2.setWeight(cards2.getWeight() * 1.0f);
					}
					else if (pChart.getHandRank(cards2.getHand()) <= raisesTillRank + preflopVariance) {
						int step = 2 * preflopVariance + 1;
						int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - preflopVariance);
						cards2.setWeight((float) (1 - ((float) above/step)));
					}
					else {
						cards2.setWeight(cards2.getWeight() * 0.1f);
					}
				}
			}
			else {
				for(Hand h: handrange) {
					Hand cards2 = h;
				
					if (pChart.getHandRank(cards2.getHand()) <= raisesTillRank) {
						cards2.setWeight(cards2.getWeight() * 0.5f);
					}
					else if (pChart.getHandRank(cards2.getHand()) <= callsTillRank - preflopVariance) {
						cards2.setWeight(cards2.getWeight() * 1f);
					}
					else if (pChart.getHandRank(cards2.getHand()) <= callsTillRank + preflopVariance) {
						int step = 2 * preflopVariance + 1;
						int above = pChart.getHandRank(cards2.getHand()) - (callsTillRank - preflopVariance);
						cards2.setWeight((float) (1 - ((float) above/step)));
					}
					else {
						cards2.setWeight(cards2.getWeight() * 0.1f);
					}
	
				}	
			}
		}
		
		Vector<Hand> remove = new Vector<Hand>();
		for (Hand h : handrange) {
			if (h.getWeight() < remove_threshold)
				remove.add(h);
		}
		
		for (Hand h : remove) {
			handrange.remove(h);
		}
		
		Collections.sort(handrange);
	}

	
	
	
	// LArs
//	public void weigthPreFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action) {
//		if(action == GameAction.ACTION_FOLD) {
//			return;
//		}
//		
//		int raisesTillRank = (int) (169 * raiseFrequency * formerRaiseFrequency);
//		int callsTillRank = (int) (169 * callFrequency * formerCallFrequency);
//		
//		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
//		formerCallFrequency = callFrequency * formerRaiseFrequency;
//		
//		if(!preFlopRangeInitiated) {
//			preFlopRangeInitiated = true;
//			handrange.clear();
//			
//			for(int i=Card.N2; i<=Card.NA; i++) {
//				for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
//					for(int k=i; k<=Card.NA; k++) {
//						for(int l=Card.DIAMOND; l<=Card.CLUB; l++) {
//							
//
//							
//							//Bedingungen für ungültige oder nicht benötigte Karten des Gegners
//							Hand cards2 = new Hand(getCardVector(i, j, k, l));	
//							if(cards2.getHand().get(0).getNumber() == cards2.getHand().get(1).getNumber()) {
//								if(cards2.getHand().get(0).getColor() >= cards2.getHand().get(1).getColor()) {
//									continue;
//								}
//							}
//							if(holeCards.get(0).equals(cards2.getHand().get(0)) || holeCards.get(0).equals(cards2.getHand().get(1)) || holeCards.get(1).equals(cards2.getHand().get(0)) || holeCards.get(1).equals(cards2.getHand().get(1))) {
//								continue;
//							}
//							
//							if(action == GameAction.ACTION_RAISE) {
//								raisedBefore = true;
//								
//								if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//									cards2.setWeight(1);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) > raisesTillRank + variance) {
//									cards2.setWeight(0.01f);
//								}
//								else {
//									int step = 2 * variance + 1;
//									int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//									cards2.setWeight((float) (1 - ((float) above/step)));
//								}
//							}
//							else if(action == GameAction.ACTION_CALL) {
//								if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//									// TODO nachschauen
//									if (!raisedBefore)
//										cards2.setWeight(0.01f);
//									else
//										cards2.setWeight(1f);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank + variance) {
//									int step = 2 * variance + 1;
//									int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//									cards2.setWeight((float) above/step);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) <= callsTillRank - variance) {
//									cards2.setWeight(1);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) > callsTillRank + variance) {
//									cards2.setWeight(0.01f);
//								}
//								else {
//									int step = 2 * variance + 1;
//									int above = pChart.getHandRank(cards2.getHand()) - (callsTillRank - variance);
//									cards2.setWeight((float) ((float)1 - (above/step)));
//								}
//							}
//							
//							handrange.add(cards2);
//						}
//					}
//				}
//			}
//		}
//		else {
//			if(action == GameAction.ACTION_RAISE) {
//				for(Hand h: handrange) {
//					Hand cards2 = h;
//					
//					if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//						cards2.setWeight(cards2.getWeight() * 1);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) > raisesTillRank + variance) {
//						cards2.setWeight(cards2.getWeight() * 0.01f);
//					}
//					else {
//						int step = 2 * variance + 1;
//						int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//						cards2.setWeight(cards2.getWeight() * ((float) (1 - ((float) above/step))));
//					}
//				}
//			}
//			else {
//				for(Hand h: handrange) {
//					Hand cards2 = h;
//				
//					if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//						if (!raisedBefore)
//							cards2.setWeight(cards2.getWeight() * 0.01f);
//						else
//							cards2.setWeight(cards2.getWeight() * 1f);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank + variance) {
//						int step = 2 * variance + 1;
//						int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//						cards2.setWeight(cards2.getWeight() * (float) above/step);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) <= callsTillRank - variance) {
//						cards2.setWeight(cards2.getWeight() * 1);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) > callsTillRank + variance) {
//						cards2.setWeight(cards2.getWeight() * 0.01f);
//					}
//					else {
//						int step = 2 * variance + 1;
//						int above = pChart.getHandRank(cards2.getHand()) - (callsTillRank - variance);
//						cards2.setWeight(cards2.getWeight() * ((float) ((float)1 - (above/step))));
//					}		
//				}	
//			}
//		}
////		Collections.sort(handrange);
//	}

	
	
	
	// Lars
	
//	public void weigthPreFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action) {
//		if(action == GameAction.ACTION_FOLD) {
//			return;
//		}
//		
//		int raisesTillRank = (int) (169 * raiseFrequency * formerRaiseFrequency);
//		int callsTillRank = (int) (169 * callFrequency * formerCallFrequency);
//		
//		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
//		formerCallFrequency = callFrequency * formerRaiseFrequency;
//		
//		if(!preFlopRangeInitiated) {
//			preFlopRangeInitiated = true;
//			handrange.clear();
//			
//			for(int i=Card.N2; i<=Card.NA; i++) {
//				for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
//					for(int k=i; k<=Card.NA; k++) {
//						for(int l=Card.DIAMOND; l<=Card.CLUB; l++) {
//							
//							//Bedingungen für ungültige oder nicht benötigte Karten des Gegners
//							Hand cards2 = new Hand(getCardVector(i, j, k, l));	
//							if(cards2.getHand().get(0).getNumber() == cards2.getHand().get(1).getNumber()) {
//								if(cards2.getHand().get(0).getColor() >= cards2.getHand().get(1).getColor()) {
//									continue;
//								}
//							}
//							if(holeCards.get(0).equals(cards2.getHand().get(0)) || holeCards.get(0).equals(cards2.getHand().get(1)) || holeCards.get(1).equals(cards2.getHand().get(0)) || holeCards.get(1).equals(cards2.getHand().get(1))) {
//								continue;
//							}
//							
//							if(action == GameAction.ACTION_RAISE) {
//								raisedBefore = true;
//								
//								if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//									cards2.setWeight(1);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) > raisesTillRank + variance) {
//									cards2.setWeight(0.01f);
//								}
//								else {
//									int step = 2 * variance + 1;
//									int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//									cards2.setWeight((float) (1 - ((float) above/step)));
//								}
//							}
//							else if(action == GameAction.ACTION_CALL) {
//								if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//									// TODO nachschauen
//									if (!raisedBefore)
//										cards2.setWeight(0.01f);
//									else
//										cards2.setWeight(1f);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank + variance) {
//									int step = 2 * variance + 1;
//									int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//									cards2.setWeight((float) above/step);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) <= callsTillRank - variance) {
//									cards2.setWeight(1);
//								}
//								else if(pChart.getHandRank(cards2.getHand()) > callsTillRank + variance) {
//									cards2.setWeight(0.01f);
//								}
//								else {
//									int step = 2 * variance + 1;
//									int above = pChart.getHandRank(cards2.getHand()) - (callsTillRank - variance);
//									cards2.setWeight((float) ((float)1 - (above/step)));
//								}
//							}
//							
//							handrange.add(cards2);
//						}
//					}
//				}
//			}
//		}
//		else {
//			if(action == GameAction.ACTION_RAISE) {
//				for(Hand h: handrange) {
//					Hand cards2 = h;
//					
//					if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//						cards2.setWeight(cards2.getWeight() * 1);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) > raisesTillRank + variance) {
//						cards2.setWeight(cards2.getWeight() * 0.01f);
//					}
//					else {
//						int step = 2 * variance + 1;
//						int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//						cards2.setWeight(cards2.getWeight() * ((float) (1 - ((float) above/step))));
//					}
//				}
//			}
//			else {
//				for(Hand h: handrange) {
//					Hand cards2 = h;
//				
//					if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank - variance) {
//						if (!raisedBefore)
//							cards2.setWeight(cards2.getWeight() * 0.01f);
//						else
//							cards2.setWeight(cards2.getWeight() * 1f);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) <= raisesTillRank + variance) {
//						int step = 2 * variance + 1;
//						int above = pChart.getHandRank(cards2.getHand()) - (raisesTillRank - variance);
//						cards2.setWeight(cards2.getWeight() * (float) above/step);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) <= callsTillRank - variance) {
//						cards2.setWeight(cards2.getWeight() * 1);
//					}
//					else if(pChart.getHandRank(cards2.getHand()) > callsTillRank + variance) {
//						cards2.setWeight(cards2.getWeight() * 0.01f);
//					}
//					else {
//						int step = 2 * variance + 1;
//						int above = pChart.getHandRank(cards2.getHand()) - (callsTillRank - variance);
//						cards2.setWeight(cards2.getWeight() * ((float) ((float)1 - (above/step))));
//					}		
//				}	
//			}
//		}
////		Collections.sort(handrange);
//	}

	
	
//	public void calcPreFlopHandRange(float observedFrequency, Vector<Card> holeCards) {
//		if(preFlopRangedCalculated)
//			return;
//		else
//			preFlopRangedCalculated = true;
//		
//		preFlopFrequency = observedFrequency;
//		handrange = new Vector<Vector<Card>>();
//		
//		playsTillHandRank = (int) (169 * observedFrequency);
////		System.out.println(playsTillHandRank);
////		System.out.println(playsTillHandRank);
//		
//		for(int i=Card.N2; i<=Card.NA; i++) {
//			for(int j=Card.DIAMOND; j<=Card.CLUB; j++) {
//				for(int k=i; k<=Card.NA; k++) {
//					for(int l=Card.DIAMOND; l<=Card.CLUB; l++) {
//						
//						//Bedingungen für ungültige oder nicht benötigte Karten des Gegners
//						Vector<Card> cards2 = getCardVector(i, j, k, l);	
//						if(cards2.get(0).getNumber() == cards2.get(1).getNumber()) {
//							if(cards2.get(0).getColor() >= cards2.get(1).getColor()) {
//								continue;
//							}
//						}
//						if(holeCards.get(0).equals(cards2.get(0)) || holeCards.get(0).equals(cards2.get(1)) || holeCards.get(1).equals(cards2.get(0)) || holeCards.get(1).equals(cards2.get(1))) {
//							continue;
//						}
//						
//						if(pChart.getHandRank(cards2) <= playsTillHandRank + variance) {
//							handrange.add(cards2);
//						}
//					}
//				}
//			}
//		}
//		
////		System.out.println(handrange);
//	}
	
//	public void calcPostFlopHandRange(float observedFrequency, Vector<Card> holeCards, Vector<Card> boardcards) {
//		
//		for(int i=0;i<handrange.size();i++) {
//			boolean isOnBoard = false;
//			for(Card c : boardcards) {
//				if(c.equals(handrange.get(i).get(0)) || c.equals(handrange.get(i).get(1))) isOnBoard=true;
//			}
//			if(isOnBoard) {
//				handrange.remove(i);
//				i--;
//			}
//		}
//		
//		hS.sort(boardcards, handrange);
//		int hrSize = handrange.size();
//		int playsTo = (int) (hrSize * observedFrequency);
//		
//		for(int i = hrSize-1;i>playsTo;i--) {
//			handrange.remove(i);
//		}
//		
//		//System.out.println(handrange);
//	}
	
	
	
	
	// Timo
//	public void weigthPostFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action, HashMap<String,Float> strengthTable) {
//		if(action == GameAction.ACTION_FOLD)
//			return;
//		
//		
//		formerCallFrequency = 1;
//		formerRaiseFrequency = 1;
//		float raisingStrength = 1 - (raiseFrequency * formerRaiseFrequency) * correctationParameter;
//		float callingStrength = 1 - (raiseFrequency * formerRaiseFrequency + callFrequency * formerCallFrequency) * correctationParameter;
//		
////		System.out.println("RF: " + raiseFrequency + " RS: " + raisingStrength);
////		System.out.println("CF: " + callFrequency + " CS: " + callingStrength);
//		
//		
//		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
//		formerCallFrequency = callFrequency * formerRaiseFrequency;
//		
//		Vector<Hand> removeVector = new Vector<Hand>();
//		
//		if(action == GameAction.ACTION_RAISE) {
//		for(Hand h : handrange) {
//			if(strengthTable.get(h.toString()) == null) {
//				removeVector.add(h);
//				continue;
//			}
//			float strength = strengthTable.get(h.toString());
////			System.out.print("Strength="+strength);
//			if(strength >= raisingStrength + postFlopVariance) {
////				System.out.println(" => 1");
//				h.setWeight(h.getWeight() * 1f);
//			}
//			else if(strength < raisingStrength - postFlopVariance) {
////				System.out.println(" => 0.01");
//				h.setWeight(h.getWeight() * 0.1f);
//			}
//			else {
//				
//				float max = raisingStrength + postFlopVariance;
//				float min = raisingStrength - postFlopVariance;
//				
//				float correct = (strength-min) / (max-min);
//				
//				
//				
////				System.out.println(" => " + min + " " + max + " " + correct);
//				h.setWeight(h.getWeight() * correct);
//			}
//			h.setHandStrength(strength);
//		}
//	}
//	else {
//		for(Hand h : handrange) {
//			if(strengthTable.get(h.toString()) == null) {
//				removeVector.add(h);
//				continue;
//			}
//			
//			float strength = strengthTable.get(h.toString());
//			if(strength >= raisingStrength) {
//				h.setWeight(h.getWeight() * 0.5f);
//			}
//			else if(strength >= callingStrength + preflopVariance){
//				h.setWeight(h.getWeight() * 1f);
//			}
//			else if(strength < callingStrength - postFlopVariance) {
//				h.setWeight(h.getWeight() * 0.1f);
//			}
//			else {
//				
//				float max = callingStrength + postFlopVariance;
//				float min = callingStrength - postFlopVariance;
//				
//				float correct = (strength-min) / (max-min);
//				
//				
//				
////				System.out.println(" => " + min + " " + max + " " + correct);
//				h.setWeight(h.getWeight() * correct);
//			}
//			h.setHandStrength(strength);
//		}
//	}
//		
//		for(Hand h : removeVector) {
//			handrange.remove(h);
//		}
//		Collections.sort(handrange);
//	}
	

	// Lars
	public void weigthPostFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action, HashMap<String,Float> strengthTable) {
		if(action == GameAction.ACTION_FOLD)
			return;
		
		
		formerCallFrequency = 1;
		formerRaiseFrequency = 1;
		float raisingStrength = 1 - (raiseFrequency * formerRaiseFrequency) * correctationParameter;
		float callingStrength = 1 - (raiseFrequency * formerRaiseFrequency + callFrequency * formerCallFrequency) * correctationParameter;
		
//		System.out.println("RF: " + raiseFrequency + " RS: " + raisingStrength);
//		System.out.println("CF: " + callFrequency + " CS: " + callingStrength);
		
		
		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
		formerCallFrequency = callFrequency * formerRaiseFrequency;
		
		Vector<Hand> removeVector = new Vector<Hand>();
		
		if(action == GameAction.ACTION_RAISE) {
			for(Hand h : handrange) {
				if(strengthTable.get(h.toString()) == null) {
					removeVector.add(h);
					continue;
				}
				float strength = strengthTable.get(h.toString());
//				System.out.print("Strength="+strength);
				if(strength >= raisingStrength) {
//					System.out.println(" => 1");
					h.setWeight(h.getWeight() * 1);
				}
				else if(strength < raisingStrength - postFlopVariance) {
//					System.out.println(" => 0.01");
					h.setWeight(h.getWeight() * 0.01f);
				}
				else {
					
					float max = raisingStrength;
					float min = raisingStrength - postFlopVariance;
					
					float correct = (strength-min) / (max-min);
					
					
					
//					System.out.println(" => " + min + " " + max + " " + correct);
					h.setWeight(h.getWeight() * correct);
				}
				h.setHandStrength(strength);
			}
		}
		else {
			for(Hand h : handrange) {
				if(strengthTable.get(h.toString()) == null) {
					removeVector.add(h);
					continue;
				}
				
				float strength = strengthTable.get(h.toString());
				if(strength >= raisingStrength) {
					h.setWeight(h.getWeight() * 0.7f);
				}
				else if(strength >= callingStrength){
					h.setWeight(h.getWeight() * 1);
				}
				else if(strength < callingStrength - postFlopVariance) {
					h.setWeight(h.getWeight() * 0.01f);
				}
				else {
					
					float max = callingStrength;
					float min = callingStrength - postFlopVariance;
					
					float correct = (strength-min) / (max-min);
					
					
					
//					System.out.println(" => " + min + " " + max + " " + correct);
					h.setWeight(h.getWeight() * correct);
				}
				h.setHandStrength(strength);
			}
		}
		
		for(Hand h : removeVector) {
			handrange.remove(h);
		}
		Collections.sort(handrange);
	}

	
//	public void weigthPostFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action, HashMap<String,Float> strengthTable) {
//		if(action == GameAction.ACTION_FOLD)
//		return;
//	
//		float raisingStrength = /*(1 - raiseFrequency * formerRaiseFrequency) + correctationParameter;*/ 0.5f;
//		float callingStrength = /*(1 - raiseFrequency * formerRaiseFrequency - callFrequency * formerCallFrequency) + correctationParameter;*/ 0.2f;
//		
//		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
//		formerCallFrequency = callFrequency * formerRaiseFrequency;
//		
//		Vector<Hand> removeVector = new Vector<Hand>();
//
//		for(Hand h : handrange) {
//			if(strengthTable.get(h.toString()) == null) {
//				removeVector.add(h);
//				continue;
//			}
//			
//			
//			float strength = strengthTable.get(h.toString());
//			
//			if (strength >0.5)
//				h.setWeight(1);
//			else
//				h.setWeight(0);
//		}
//		
//		for(Hand r : removeVector) {
//			handrange.remove(r);
//		}
//		Collections.sort(handrange);
//		
//	}

	
//	public void calcPostFlopHandRange(float observedFrequency, Vector<Card> holeCards, Vector<Vector<Card>> handrange, int street) {
//		if(street == GameSituation.STATE_FLOP) {
//			if(flopRangeCalculated)
//				return;
//			else 
//				flopRangeCalculated = true;
//		}
//		else if(street == GameSituation.STATE_TURN) {
//			if(turnRangeCalculated) 
//				return;
//			else 
//				turnRangeCalculated = true;
//		}
//		else if(street == GameSituation.STATE_RIVER) {
//			if(riverRangeCalculated) 
//				return;
//			else 
//				riverRangeCalculated = true;
//		}
//		
//		for(int i=0;i<handrange.size();i++) {
//			boolean isOnHand = false;
//			if(holeCards.get(0).equals(handrange.get(i).get(0)) || holeCards.get(0).equals(handrange.get(i).get(1)) || holeCards.get(1).equals(handrange.get(i).get(0)) || holeCards.get(1).equals(handrange.get(i).get(1))) {
//				isOnHand = true;
//			}
//			
//			if(isOnHand) {
//				handrange.remove(i);
//				i--;
//			}
//			else if(pChart.getHandRank(handrange.get(i)) > playsTillHandRank + variance) {
//				handrange.remove(i);
//				i--;
//			}
//		}
//				
//		int playsTill = (int) (this.handrange.size() * observedFrequency);
//	
//		for(int i=handrange.size()-1;i>playsTill;i--) {
//			handrange.remove(i);
//		}
//		this.handrange = handrange;
////		System.out.println(handrange);
//	}

	
	// Parabel
//	public void weigthPostFlopHandRange(float raiseFrequency, float callFrequency, Vector<Card> holeCards, int action, HashMap<String,Float> strengthTable) {
//		if(action == GameAction.ACTION_FOLD)
//			return;
//		
//		
//		formerCallFrequency = 1;
//		formerRaiseFrequency = 1;
//		float raisingStrength = 1 - (raiseFrequency * formerRaiseFrequency) * correctationParameter;
//		float callingStrength = 1 - (raiseFrequency * formerRaiseFrequency + callFrequency * formerCallFrequency) * correctationParameter;
//		
//		formerRaiseFrequency = raiseFrequency * formerRaiseFrequency;
//		formerCallFrequency = callFrequency * formerRaiseFrequency;
//		
//		Vector<Hand> removeVector = new Vector<Hand>();
//		
//		if(action == GameAction.ACTION_RAISE) {
//			for(Hand h : handrange) {
//				if(strengthTable.get(h.toString()) == null) {
//					removeVector.add(h);
//					continue;
//				}
//				float strength = strengthTable.get(h.toString());
//				
//				// -1/($E$2-$H$2)*(A3-$E$2)^2+1
//				
//				double w = -1 / (raisingStrength - callingStrength) * Math.pow(strength - raisingStrength, 2) + 1;
//				
//				w = Math.min(1, Math.max(0, w));
//				
//				h.setWeight((float)(h.getWeight() * w));
//
//				h.setHandStrength(strength);
//			}
//		}
//		else {
//			for(Hand h : handrange) {
//				if(strengthTable.get(h.toString()) == null) {
//					removeVector.add(h);
//					continue;
//				}
//				
//				float strength = strengthTable.get(h.toString());
//
//				double w = -1 / (raisingStrength - callingStrength) * Math.pow(strength - callingStrength, 2) + 1;
//				
//				w = Math.min(1, Math.max(0, w));
//				
//				h.setWeight((float)(h.getWeight() * w));
//
//				h.setHandStrength(strength);
//			}
//		}
//		
//		for(Hand h : removeVector) {
//			handrange.remove(h);
//		}
//		Collections.sort(handrange);
//	}

	
	
	private Vector<Card> getCardVector(int number1, int color1, int number2, int color2) {
		Vector<Card> v = new Vector<Card>();
		v.add(new Card(color1, number1));
		v.add(new Card(color2, number2));
		return v;
	}

}
