//Varianz muss noch hinzugefügt werden

package bot.opponent;

import java.util.Vector;

import bot.pokertools.PreFlopChart;
import bot.utils.Card;

public class WeightTable {
	
//	private float[][][][] weights = new float[13][4][13][4];
//	private PreFlopChart pChart;
//	private HandStrength hs = new HandStrength();
//	
//	public float getWeight(Vector<Card> cards) {
//		return weights[cards.get(0).getNumber()-2][cards.get(0).getColor()][cards.get(1).getNumber()-2][cards.get(1).getColor()];
//	}
//		
//	public void init(float percentage) {
//		int playsTillHandRank = (int) (169 * percentage);
//		
//		for(int i=0; i<weights.length; i++) {
//			for(int j=0; j<weights[1].length; j++) {
//				for(int k=0; k<weights[1][1].length; k++) {
//					for(int l=0; l<weights[1][1][1].length; l++) {
//						if(pChart.getHandRank(getCardVector(i, j, k, l)) >= playsTillHandRank) {
//							weights[i][j][k][l] = 1;
//						}
//						else {
//							weights[i][j][k][l] = 0.01f;
//						}
//					}
//				}
//			}
//		}
//	}
//	
//	public void reweight(float percentage, Vector<Card> boardcards) {	
//		for(int i=0; i<weights.length; i++) {
//			for(int j=0; j<weights[1].length; j++) {
//				for(int k=0; k<weights[1][1].length; k++) {
//					for(int l=0; l<weights[1][1][1].length; l++) {
//						System.out.println("Jetzt wird die Handstärke bestimmt");
//						if(hs.getHandStrength(getCardVector(i, j, k, l), boardcards) >= percentage) {
//							System.out.println("Fertig -> stark genug " + percentage);
//							weights[i][j][k][l] = weights[i][j][k][l] * 1;
//						}
//						else {
//							System.out.println("Fertig -> zu schwach " + percentage);
//							weights[i][j][k][l] = weights[i][j][k][l] * 0.01f;
//						}
//					}
//				}
//			}
//		}
//	}
//	
//	private Vector<Card> getCardVector(int number1, int color1, int number2, int color2) {
//		Vector<Card> v = new Vector<Card>();
//		v.add(new Card(color1, number1 + 2));
//		v.add(new Card(color2, number2 + 2));
//		return v;
//	}
//	
//	public WeightTable(PreFlopChart pChart) {
//		this.pChart = pChart;
//	}
}
