#!/bin/bash
java -Xms512m -Xmx2048m -cp lib/pokerserver.jar:AKI-Real.jar player.RealPlayer $1 $2
