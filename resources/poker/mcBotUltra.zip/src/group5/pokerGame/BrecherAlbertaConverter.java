package group5.pokerGame;

import java.util.HashMap;
import java.util.Map;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.CardSet;
import com.stevebrecher.poker.Card.Rank;
import com.stevebrecher.poker.Card.Suit;

/**
 * This class provides methods to convert cards from alberta to brecher.
 *  
 * @author amittelbach
 */
public class BrecherAlbertaConverter {

	/**
	 * Store the instance 
	 */
	private static BrecherAlbertaConverter instance = null;
	
	/**
	 * Store the map that is used to convert ranks
	 */
	protected static Map<ca.ualberta.cs.poker.free.dynamics.Card.Rank, Rank> rankConverter;
	
	/**
	 * Store the map that is used to convert suits
	 */
	protected static Map<ca.ualberta.cs.poker.free.dynamics.Card.Suit, Suit> suitConverter;
	
	/**
	 * Implements the singleton pattern
	 */
	protected BrecherAlbertaConverter(){
		generateRankConverter();
		generateSuitConverter();
	}
	
	/**
	 * 
	 * @return An instance of the converter
	 */
	public static BrecherAlbertaConverter getInstance(){
		if(null == instance)
			instance = new BrecherAlbertaConverter();
		return instance;
	}
	
	/**
	 * 
	 */
	private void generateSuitConverter(){
		suitConverter = new HashMap<ca.ualberta.cs.poker.free.dynamics.Card.Suit, Suit>();
		
		suitConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Suit.CLUBS, Suit.CLUB);
		suitConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Suit.HEARTS, Suit.HEART);
		suitConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Suit.DIAMONDS, Suit.DIAMOND);
		suitConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Suit.SPADES, Suit.SPADE);
	}
	
	/**
	 * 
	 */
	private void generateRankConverter(){
		rankConverter = new HashMap<ca.ualberta.cs.poker.free.dynamics.Card.Rank, Rank>();
		
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.ACE, Rank.ACE);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.KING, Rank.KING);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.QUEEN, Rank.QUEEN);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.JACK, Rank.JACK);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.TEN, Rank.TEN);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.NINE, Rank.NINE);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.EIGHT, Rank.EIGHT);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.SEVEN, Rank.SEVEN);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.SIX, Rank.SIX);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.FIVE, Rank.FIVE);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.FOUR, Rank.FOUR);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.THREE, Rank.THREE);
		rankConverter.put(ca.ualberta.cs.poker.free.dynamics.Card.Rank.TWO, Rank.TWO);
	}
	
	public CardSet getCardset(Card[] cards){
		CardSet set = new CardSet();
		for(Card c : cards)
			set.add(c);
		
		return set;
	}
	
	
	/**
	 * 
	 * @param cards
	 * @return
	 */
	public CardSet getConvertedCardset(ca.ualberta.cs.poker.free.dynamics.Card[] cards){
		Card[] converted = getConvertedCards(cards);
		
		CardSet set = new CardSet();
		for(Card c : converted)
			set.add(c);
		
		return set;
	}
	
	/**
	 * 
	 * @param cards
	 * @return
	 */
	public Card[] getConvertedCards(ca.ualberta.cs.poker.free.dynamics.Card[] cards){
		Card[] converted = new Card[cards.length];
		for(int i = 0; i < converted.length; i++)
			converted[i] = getConvertedCard(cards[i]);
		return converted;
	}
	
	/**
	 * 
	 * @param card
	 * @return
	 */
	public Card getConvertedCard(ca.ualberta.cs.poker.free.dynamics.Card card) {
		return new Card(rankConverter.get(card.rank), suitConverter.get(card.suit));
	}
	
}
