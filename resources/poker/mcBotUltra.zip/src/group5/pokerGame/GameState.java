package group5.pokerGame;



import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.CardSet;
import com.stevebrecher.poker.HandEval;
import com.stevebrecher.poker.Card.Rank;

/**
 * Models a game state.
 * 
 * @author Michael, Arno
 *
 */
public class GameState implements Cloneable {
	
	/**
	 * The Game Round
	 */
	public static final int PREFLOP = 1;
	public static final int FLOP = 2;
	public static final int TURN = 3;
	public static final int RIVER = 4;
	
	public static final int EARLY = 1;
	public static final int MIDDLE = 2;
	public static final int LATE = 3;
	public static final int BLIND = 4;
	
	public static final int SMALL_BET = 2;
	
	
	
	/**
	 * Counts the actions made by the players in the actual round.
	 */
	protected int actionsSeenInActualRound = 0;
	
	/**
	 * Stores the actual game round.
	 */
	protected int round = GameState.PREFLOP;
	
	/**
	 * The amount of player i in the pot.
	 */
	protected int[] inPot;
	
	/**
	 * The actual number of raises seen in this round.
	 */
	protected int numberOfRaisesSeenThisRound = 0;
	
	/**
	 * The number of raises allowed in a certain betting round.
	 */
	public static final int maxNumberOfRaisesAllowed = 4;
		
	/**
	 * Stores for every player an boolean to determine whether he is in the game or not.
	 */
	protected boolean[] activePlayers;
	
    /**
     * player[i] is the player in seat i
     */
    public int[] seatToPlayer;
    
	/**
	 * Stores the cards from every player.
	 */
	protected Card[][] playerCards;
	
	/**
	 * Stores the actual board cards.
	 */
	protected Card[] board = new Card[5];
	
	protected int numberOfPlayersThatCalled = 0;
	
	/**
	 * The player who has to make an action.
	 */
	protected int currentPlayer;
		
	protected CardDeck deck = new CardDeck();
	protected boolean gameFinished = false;
	
	private static final int NUMBER_OF_PLAYERS = 6;
	
	/**
	 * Stores the raises by player
	 */
	private int[] raisesByPlayer;
	
	public GameState(){
		raisesByPlayer = new int[NUMBER_OF_PLAYERS];
		for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			raisesByPlayer[player] = 0;
	}
	
	
	/**
	 * 
	 * @return the current round
	 */
	public int getRound() {
		return round;
	}

	/**
	 * 
	 * @param round the current round
	 */
	public void setRound(int round) {
		this.round = round;
	}

	/**
	 * 
	 * @param player
	 * @return The amount player has in the pot
	 */
	public int getInPotForPlayer(int player) {
		return inPot[player];
	}
	
	/**
	 * 
	 * @return The inPot array
	 */
	public int[] getInPot(){
		return inPot;
	}

	/**
	 * 
	 * @param potSize
	 */
	public void setInPot(int[] potSize) {
		this.inPot = potSize;
	}
	
	/**
	 * 
	 * @param player 
	 * @return The pot odds for player. (0.3 means, that the player has to win 2/3)
	 */
	public double getPotOddsForPlayer(int player){
		return getAmountToCall(player)/(double) getPot(); 
	}

	/**
	 * 
	 * @return The number of players that called
	 */
	public int getNumberOfPlayersThatCalled(){
		return numberOfPlayersThatCalled;
	}
	
	/**
	 * 
	 * @return The number of raises that were played this betting round
	 */
	public int getNumberOfRaisesSeenThisRound() {
		return numberOfRaisesSeenThisRound;
	}

	/**
	 * 
	 * @param numberOfRaisesSeenThisRound
	 */
	public void setNumberOfRaisesSeenThisRound(int numberOfRaisesSeenThisRound) {
		this.numberOfRaisesSeenThisRound = numberOfRaisesSeenThisRound;
	}

	/**
	 * 
	 * @return The player that has to act
	 */
	public int getCurrentPlayer() {
		return currentPlayer;
	}

	/**
	 * 
	 * @param currentPlayer
	 */
	public void setCurrentPlayer(int currentPlayer) {
		this.currentPlayer = currentPlayer;
	}
	
	/**
	 * 
	 * @param player
	 * @return The raises of the submitted player
	 */
	public int getRaisesByPlayer(int player){
		return raisesByPlayer[player];
	}

	/**
	 * @return Counts the number of active players in the game and gives it back.
	 */
	public int getNumberOfActivePlayers() {
		int numberOfPlayersLeft = 0;
		
		for (boolean player : activePlayers)
			if (player)
				numberOfPlayersLeft++;
		
		return numberOfPlayersLeft;
	}

	/**
	 * initialize the active players
	 * @param activePlayers
	 */
	public void setActivePlayers(boolean[] activePlayers) {
		this.activePlayers = activePlayers;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean[] getActivePlayers(){
		return activePlayers;
	}

	/**
	 * 
	 * @return
	 */
	public Card[] getBoard() {
		return board;
	}

	/**
	 * 
	 * @param board
	 */
	public void setBoard(Card[] board) {
		this.board = board;
	}
	
	/**
	 * Don' call this function before setActivePlayers() was called.
	 * 
	 * @param cards
	 * @param player
	 */
	public void setCardsForPlayer(Card[] cards, int player) {
		if(null == this.playerCards)
			this.playerCards = new Card[NUMBER_OF_PLAYERS][2];
		
		this.playerCards[player] = cards;
	}
	
	/**
	 * if removeCards is set the submitted cards are removed from the deck.
	 * 
	 * @see setCardsForPlayer
	 * 
	 * @param cards
	 * @param player
	 * @param removeCards
	 */
	public void setCardsForPlayer(Card[] cards, int player, boolean removeCards) {
		setCardsForPlayer(cards, player);
		
		if (removeCards)
			for(Card card : cards)
				deck.removeCard(card);
	}
	
	
	/**
	 * 
	 * @param player
	 * @return the player's hand
	 */
	public Card[] getCardsForPlayer (int player) {
		return this.playerCards[player];
	}

	/**
	 * 
	 * @return The deck
	 */
	public CardDeck getDeck() {
		return deck;
	}
	
	@Override
	public GameState clone() {
		GameState clonedGameState = new GameState();
		clonedGameState.setActivePlayers(this.activePlayers.clone());
		clonedGameState.setCurrentPlayer(currentPlayer);
		clonedGameState.setInPot(inPot.clone());
		clonedGameState
				.setNumberOfRaisesSeenThisRound(numberOfRaisesSeenThisRound);
		clonedGameState.setRound(round);
		clonedGameState.setSeatToPlayer(seatToPlayer.clone());

		Card[][] newPlayerCards = new Card[NUMBER_OF_PLAYERS][2];
		for (int i = 0; i < NUMBER_OF_PLAYERS; i++) {
			if(null == playerCards[i][0])
				continue;
			
			newPlayerCards[i][0] = new Card(playerCards[i][0].rankOf(),
					playerCards[i][0].suitOf());
			newPlayerCards[i][1] = new Card(playerCards[i][1].rankOf(),
					playerCards[i][1].suitOf());
		}
		clonedGameState.setPlayerCards(newPlayerCards);

		Card[] newBoard = new Card[5];
		for (int i = 0; i < 5; i++) {
			if (null != board[i]) {
				newBoard[i] = new Card(board[i].rankOf(), board[i].suitOf());
			}
		}
		clonedGameState.setBoard(newBoard);
		
		clonedGameState.setDeck(this.deck.clone());
		
		return clonedGameState;
	} 
	
	/**
	 * 
	 * @param deck
	 */
	protected void setDeck(CardDeck deck) {
		this.deck = deck;
	}

	/**
	 * 
	 * @param newPlayerCards
	 */
	protected void setPlayerCards(Card[][] newPlayerCards) {
		playerCards = newPlayerCards;
		
	}
	
	/**
	 * @return whether or not we can still raise
	 */
	public boolean canRaise(){
		return numberOfRaisesSeenThisRound < maxNumberOfRaisesAllowed;
	}


	/**
	 * The current player raises.
	 */
	public void playerRaises() {
		if(numberOfRaisesSeenThisRound >= maxNumberOfRaisesAllowed){
			playerCalls();
			return;
		}
		
		actionsSeenInActualRound++;
		
		raisesByPlayer[currentPlayer]++;
		
		numberOfRaisesSeenThisRound++;
		
		numberOfPlayersThatCalled = 0;
		
		if (FLOP == round || PREFLOP == round)
			inPot[currentPlayer] += (getAmountToCall(currentPlayer) + SMALL_BET);
		else
			inPot[currentPlayer] += (getAmountToCall(currentPlayer) + 2*SMALL_BET);
		
		
		gotoNextPlayer();
	}
	
	/**
	 * The current player calls.
	 */
	public void playerCalls() {
		numberOfPlayersThatCalled++;
		actionsSeenInActualRound++;
		
		inPot[currentPlayer] += getAmountToCall(currentPlayer);
		
		gotoNextPlayer();
	}
	
	/**
	 * The current player folds
	 */
	public void playerFolds() {
		if(getAmountToCall(currentPlayer) == 0){
			playerCalls();
			return;
		}
			
		
		activePlayers[currentPlayer] = false;
		gotoNextPlayer();
	}

	/**
	 * 
	 * sets currentPlayer to next player
	 */
	protected void gotoNextPlayer() {
		currentPlayer = getNextPlayer();
	}
	
	/**
	 * 
	 * @return The next player without setting currentplayer
	 */
	protected int getNextPlayer(){
		int numberOfPlayers = getNumberOfPlayers();
		int nextPlayer = seatToPlayer[(playerToSeat(currentPlayer) + 1) % numberOfPlayers];
		
		while (! isPlayerActive(nextPlayer)) {
			nextPlayer = seatToPlayer[(playerToSeat(nextPlayer) + 1) % numberOfPlayers];
		}
		
		return nextPlayer;
	}
	
	/**
	 * 
	 * @return The number of players
	 */
	public int getNumberOfPlayers() {
		return NUMBER_OF_PLAYERS;
	}

	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean isPlayerActive (int player) {
		return activePlayers[player];
	}

	/**
	 * If the current player is the player which raised then
	 * the round is over.
	 * 
	 * @return Whether the betting round is over or not.
	 */
	public boolean isBettingRoundOver() {
		return (getNumberOfActivePlayers() == 1) || (numberOfPlayersThatCalled == (getNumberOfActivePlayers() - 1));
	}
	
	/**
	 * Maps a given player to his seat.
	 *  
	 * @param player The player of interest.
	 * @return The seat the player sit on.
	 */
	public int playerToSeat (int player) {
		for (int i=0; i<seatToPlayer.length; i++ )
			if (seatToPlayer[i] == player)
				return i;
		
		return 0;
	}
	
	/**
	 * Determines the amount a player has to call, to stay in the game.
	 * 
	 * @param player A Player of interest.
	 * @return The amount to call.
	 */
	public int getAmountToCall (int player) {
		int maxBetValue = 0;
		for (int value : inPot)
			if (maxBetValue < value)
				maxBetValue = value;
		
		return maxBetValue - getInPotForPlayer(player);
	}

	/**
	 * 
	 * @return
	 */
	public boolean isGameFinished() {
		return (getNumberOfActivePlayers() == 1) || gameFinished;
	}

	/**
	 * Sets everything recommend to go to the next round.
	 */
	public void gotoNextRound() {
		actionsSeenInActualRound = 0;
		numberOfPlayersThatCalled = 0;
		numberOfRaisesSeenThisRound = 0;
		for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			raisesByPlayer[player] = 0;
		if(round != RIVER)
			round++;
		else
			gameFinished  = true;
		// set button as current player
		currentPlayer = seatToPlayer[getNumberOfPlayers() - 1];
		gotoNextPlayer();
	}

	/**
	 * Adds a card to the board dynamically.
	 * 
	 * @param card The card to add.
	 */
	public void addCardToBoard(Card card) {
		for (int i=0; i<board.length; i++) {
			if (null == board[i]) {
				board[i] = card;
				return;
			}
		}
	}
	
	/**
	 * @return Private cards of all players that are left in the game.
	 */
	public Card[][] getCardsOfActivePlayers() {
		Card[][] cardsOfActivePlayers = new Card[getNumberOfActivePlayers()][2];
		
		int idx = 0;
		for (int i=0; i<NUMBER_OF_PLAYERS; i++) {
			if (activePlayers[i]) {
				cardsOfActivePlayers[idx] = getCardsForPlayer(i);
				idx++;
			}
		}

		return cardsOfActivePlayers;
	}
	
	public boolean[] determineWinners(){
		// if number of active players == 1 then this is the winner
		if(this.getNumberOfActivePlayers() == 1)
			return activePlayers;
		
		boolean[] winners = new boolean[activePlayers.length];
		for(int i = 0; i < winners.length; i++)
			winners[i] = false;
		
		CardSet winnersCards = null;
		CardSet contestantCards = null;
		int bestValue = 0;
		
		for (int i = 0; i < activePlayers.length; i++) {
			if (activePlayers[i]) {
				if(null == winnersCards){
					winnersCards = new CardSet();
					for(Card c : getAllCardsForPlayer(i))
						winnersCards.add(c);
					
					bestValue = HandEval.hand7Eval(HandEval.encode(winnersCards));
					winners[i] = true;
				} else {
					contestantCards = new CardSet();
					for(Card c : getAllCardsForPlayer(i))
						contestantCards.add(c);
					
					int contestantValue = HandEval.hand7Eval(HandEval.encode(contestantCards));
					if(contestantValue > bestValue){
						// reset winners
						for(int j = 0; j < i; j++)
							winners[j] = false;
						winners[i] = true;
						
						// switch values
						bestValue = contestantValue;
						winnersCards = contestantCards;
					} else if(contestantValue == bestValue){
						winners[i] = true;
					} 
				}
			}
		}
		
		return winners;
	}
	

	public int getPot() {
		int sum = 0;
		
		for (int value : inPot)
			sum += value;
		
		return sum;
	}

	public void setSeatToPlayer(int[] seatToPlayer) {
		this.seatToPlayer = seatToPlayer;
	}

	/**
	 * Returns an array consisting of the player's and the board's cards.
	 * @param player
	 * @return
	 */
	public Card[] getAllCardsForPlayer(int player) {

		int numberOfCards = 0;
		if (round == PREFLOP)
			numberOfCards = 2;
		else if (round == FLOP)
			numberOfCards = 5;
		else if (round == TURN)
			numberOfCards = 6;
		else if (round == RIVER)
			numberOfCards = 7;
			
		Card[] cards = new Card[numberOfCards];

		for(int i = 0; i < 2; i++)
			cards[i] = getCardsForPlayer(player)[i];
		
		for(int i = 0; i < (numberOfCards-2); i++)
			cards[i+2] = board[i];
		
		return cards;
	}

	public int getPositionForPlayer(int player) {
		int seatOfPlayer = playerToSeat(player);
		
		if (2 > seatOfPlayer)
			return BLIND;
		else if (1 == seatOfPlayer)
			return EARLY;
		else if (5 > seatOfPlayer)
			return MIDDLE;
		else
			return LATE;
	}

	public boolean isFirstBettingRound() {
		return actionsSeenInActualRound < getNumberOfActivePlayers();
	}

	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean hasCards(int player) {
		return playerCards[player][0] != null;
	}

	/**
	 * 
	 * @param player
	 * @return Whether the player is small blind
	 */
	public boolean isSmallBlind(int player) {
		return 0 == playerToSeat(player);
	}
	
	/**
	 * 
	 * @param player
	 * @return Whether or not the player is the big blind
	 */
	public boolean isBigBlind(int player) {
		return 1 == playerToSeat(player);
	}

	/**
	 * 
	 * @param player
	 * @return How many people are coming after the player
	 */
	public double getNumberOfUnseenActions(int player) {
		// get seat of next player
		int seat = playerToSeat(player) + 1;
		
		int counter = 0;
		
		for (int i=seat; i<getNumberOfPlayers(); i++) {
			if (isPlayerActive(seatToPlayer[i]))
				counter++;
		}
		
		return counter;
	}

	/**
	 * 
	 * @param player
	 * @return Whether or not the player is small or bigblind
	 */
	public boolean isBlind(int player) {
		return isSmallBlind(player) || isBigBlind(player);
	}


	public Rank getHighestBoardCard() {
		if(null == board[0])
			return null;
		
		Rank current = board[0].rankOf();
		for(int i = 1; i < 5; i++)
			if(null != board[i])
				if(current.compareTo(board[i].rankOf()) < 0)
					current = board[i].rankOf();
		
		return current;
	}
}