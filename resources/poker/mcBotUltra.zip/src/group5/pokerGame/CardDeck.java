package group5.pokerGame;

import group5.mc.Random;

import java.util.ArrayList;
import java.util.List;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.Card.Rank;
import com.stevebrecher.poker.Card.Suit;


public class CardDeck implements Cloneable {
	
	private List<Card> deck;
	
	/**
	 * Creates a new full 52 card deck
	 */
	public CardDeck () {
		deck = new ArrayList<Card>();
		
		for (Rank value : Rank.values()) 
			for (Suit suit : Suit.values()) 
				deck.add(new Card(value, suit));
	}
	
	/**
	 * Initializes the deck by passing a deck that should be used.
	 * 
	 * @param deck
	 */
	public CardDeck (List<Card> deck) {
		this.deck = deck;
	}
	
	public Card takeCard () {
		int randValue = Random.getInstance().generateInt(deck.size());
		
		return deck.remove(randValue);
	}

	/**
	 * 
	 * @return
	 */
	public Card[] getRandomHand(){
		Card cards[] = new Card[2];
		cards[0] = takeCard();
		cards[1] = takeCard();
		return cards;
	}

	
	/**
	 * 
	 * @param takeCard
	 * @return
	 */
	public Card[] getRandomHand(boolean takeCard){
		if(takeCard)
			return getRandomHand();
		else {
			Card[] hand = new Card[2];
			int randValue = Random.getInstance().generateInt(deck.size());
			hand[0] = deck.get(randValue);
			
			int randValue2 = Random.getInstance().generateInt(deck.size());
			while(randValue == randValue2)
				randValue2 = Random.getInstance().generateInt(deck.size());
			hand[1] = deck.get(randValue2);
			
			return hand;
		}
	}

	/**
	 * 
	 * @param perCent
	 * @return
	 */
	public Card[] getHandOutOfTopPercent(double perCent, int numberOfPlayersLeft){
		while(true){
			Card[] cards = GeneralPokerStatistics.getInstance().getRandomHand(perCent, numberOfPlayersLeft);
			if(! ( deck.contains(cards[0]) && deck.contains(cards[1]) ) )
				continue;
			
			deck.remove(cards[0]);
			deck.remove(cards[1]);
			
			return cards;
		}
	}
	
	/**
	 * 
	 * @param low
	 * @param high
	 * @return A random hand with a hand strength between "low" and "high"
	 */
	public Card[] getHandOutOfPercentRange(double low, double high, int numberOfPlayersLeft){
		while(true){
			Card[] cards = GeneralPokerStatistics.getInstance().getHandOutOfPercentRange(low, high, numberOfPlayersLeft);
			if(! ( deck.contains(cards[0]) && deck.contains(cards[1]) ) )
				continue;
			
			deck.remove(cards[0]);
			deck.remove(cards[1]);
			
			return cards;
		}
	}
	
	/**
	 * 
	 * @param low
	 * @param high
	 * @param noise
	 * @return
	 */
	public Card[] getHandOutOfPercentRange(double low, double high, double noise, int numberOfPlayersLeft){
		if( Random.getInstance().generateRandomNumber() > noise)
			return getHandOutOfPercentRange(low, high, numberOfPlayersLeft);
		
		return getRandomHand();
	}
	
	/**
	 * 
	 * @param perCent
	 * @param takeCard
	 * @return
	 */
	public Card[] getHandOutOfTopPercent(double perCent, int numberOfPlayersLeft, boolean takeCard){
		if(takeCard)
			return getHandOutOfTopPercent(perCent, numberOfPlayersLeft);
		else {
			while(true){
				Card[] cards = GeneralPokerStatistics.getInstance().getRandomHand(perCent, numberOfPlayersLeft);
				if(! ( deck.contains(cards[0]) && deck.contains(cards[1]) ) )
					continue;
				
				return cards;
			}
		}
	}
		
	/**
	 * 
	 * @param card
	 */
	public void removeCard(Card card) {
		deck.remove(card);
	}
	
	public void removeHand(Card[] hand){
		removeCard(hand[0]);
		removeCard(hand[1]);
	}
	
	/**
	 * Checks if the card is still in the deck and returns it.
	 * 
	 * @param aCard A card to check.
	 * @return The card.
	 */
	public Card takeSpecificCard (Card aCard) {
		this.deck.remove(aCard);
		return aCard;
	}
	
	@Override
	public CardDeck clone() {
		List<Card> newDeck = new ArrayList<Card>();
		for (Card card : deck)
			newDeck.add(new Card(card.rankOf(),card.suitOf()));
		
		return new CardDeck(newDeck);
	}

	/**
	 * 
	 * @param perCent
	 * @param noise
	 * @return
	 */
	public Card[] getHandOutOfTopPercent(double perCent, double noise, int numberOfPlayersLeft) {
		if( Random.getInstance().generateRandomNumber() > noise)
			return getHandOutOfTopPercent(perCent, numberOfPlayersLeft);
		
		return getRandomHand();
	}
	
	/**
	 * 
	 * @param perCent
	 * @param noise
	 * @param takeCard
	 * @return
	 */
	public Card[] getHandOutOfTopPercent(double perCent, double noise, int numberOfPlayersLeft, boolean takeCard) {
		if( Random.getInstance().generateRandomNumber() > noise)
			return getHandOutOfTopPercent(perCent, numberOfPlayersLeft, takeCard );
		
		return getRandomHand(takeCard);
	}
}
