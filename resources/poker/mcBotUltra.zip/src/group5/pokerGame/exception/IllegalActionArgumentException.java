package group5.pokerGame.exception;

public class IllegalActionArgumentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7671001092959732743L;

}
