package group5.weka;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;


public class WekaTest {
	
	public static void main(String[] args) {
		DataSource trainSource;
		DataSource testSource;
		
		try {
			// load train data
			trainSource = new DataSource("lib/weka-3-5-7/data/weather.arff");
			Instances trainData = trainSource.getDataSet();
			
			// load test data
			testSource = new DataSource("lib/weka-3-5-7/data/weather_test.arff");
			Instances testData = testSource.getDataSet();
			
			// setting class attribute if the data format does not provide this information
			// E.g., the XRFF format saves the class attribute information as well
			if (trainData.classIndex() == -1)
				  trainData.setClassIndex(trainData.numAttributes() - 1);
			if (testData.classIndex() == -1)
				  testData.setClassIndex(testData.numAttributes() - 1);
			
			// build and train classifier
			Classifier cls = new J48();
			cls.buildClassifier(trainData);

			// evaluate classifier and print some statistics
			Evaluation eval = new Evaluation(trainData);
			eval.evaluateModel(cls, testData);
			System.out.println(eval.toSummaryString("\nResults\n=======\n", false));


			System.out.println("correct " + eval.correct());
			System.out.println(cls.classifyInstance(trainData.firstInstance()));
			
			// create a new instance and add to actual train data
			Instance aInst = new Instance(5);

			aInst.setDataset(trainData);
			aInst.setValue(0, "sunny");
			aInst.setValue(1, 85);
			aInst.setValue(2, 85);
			aInst.setValue(3, "FALSE");
			aInst.setValue(4, "yes");

			trainData.add(aInst);

			// retrain classifier
			cls.buildClassifier(trainData);
			
			// evaluate classifier and print some statistics
//			eval = new Evaluation(trainData);
			eval.evaluateModel(cls, testData);
			
			System.out.println(eval.toSummaryString("\nResults\n=======\n", false));
			
			System.out.println("correct " + eval.correct());
			System.out.println(cls.classifyInstance(aInst));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
