package group5.weka.test;

import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class SimplePreFlopTester {
	DataSource trainSource;
	DataSource testSource;
	
	
	
	public static void main (String[] args) {
		try {
			// load train data
			DataSource trainSource = new DataSource("weka_data/preFlop.arff");
			Instances trainData = trainSource.getDataSet();

			DataSource testSource = new DataSource("weka_data/preFlopTest.arff");
			Instances testData = testSource.getDataSet();
			
			// setting class attribute if the data format does not provide this information
			// E.g., the XRFF format saves the class attribute information as well
			if (trainData.classIndex() == -1)
				  trainData.setClassIndex(trainData.numAttributes() - 1);
			if (testData.classIndex() == -1)
				  testData.setClassIndex(testData.numAttributes() - 1);
			
			// build and train classifier
			Classifier cls = new J48();

			// create a new instance and add to actual train data
//			Instance aInst = new Instance(3);
	
//			aInst.setDataset(trainData);
//			aInst.setValue(0, 4);
//			aInst.setValue(1, "FALSE");
//			aInst.setValue(2, "LATE");
//			aInst.setValue(3, "FALSE");
	
//			testData.add(aInst);
	
			// retrain classifier
			cls.buildClassifier(trainData);
			
			double[] fDistribution = cls.distributionForInstance(testData.firstInstance());

			System.out.println(fDistribution[0]);
			System.out.println(fDistribution[1]);
			System.out.println(fDistribution[2]);
			
			
			// evaluate classifier and print some statistics
//			eval = new Evaluation(trainData);
//			eval.evaluateModel(cls, testData);
			
//			System.out.println(eval.toSummaryString("\nResults\n=======\n", false));
			
//			System.out.println("correct " + eval.correct());
//			System.out.println(cls.classifyInstance(aInst));
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
}