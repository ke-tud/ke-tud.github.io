package group5.statistics;

import group5.bot.Bot;
import group5.dynamics.ClientRingDynamics;
import group5.pokerGame.BrecherAlbertaConverter;
import ca.ualberta.cs.poker.free.dynamics.Card;

import com.stevebrecher.poker.HandEval;

/**
 * This class provides statistics for all players.
 * 
 * @author amittelbach
 *
 */
public class Statistics {

	/**
	 * Classifications for players
	 */
	public static final int LOOSE = 1;
	public static final int TIGHT = 1;

	// simplification
	public static final int NUMBER_OF_PLAYERS = 6;
	
	/**
	 * Stores a bot instance
	 */
	private Bot bot;
	
	/**
	 * Stores a dynamics instance
	 */
	private ClientRingDynamics dynamics;
	
	/**
	 * Stores the number of hands we have played
	 */
	private int numberOfHandsPlayed = 0;
	
	/**
	 * Stores the number of games played by each player
	 */
	private int[] numberOfHandsPlayedByPlayer;
	
	/**
	 * Stores the number of games the player was on the turn
	 */
	private int[] numberOfTurnsSeenByPlayer;
	
	/**
	 * Stores the number of games the player was on the river
	 */
	private int[] numberOfRiversSeenByPlayer;
	
	/**
	 * Stores whether we have updated the number of games played by the player
	 */
	private boolean[] playerPlayedThisHand;
	
	/**
	 * Stores whether the player already took an action on the preFlop 
	 */
	private boolean[] tookActionOnPreFlop;
	
	/**
	 * Stores whether the player already took an action on the Flop 
	 */
	private boolean[] tookActionOnFlop;
	
	/**
	 * Stores whether the player already took an action on the Turn 
	 */
	private boolean[] tookActionOnTurn;
	
	/**
	 * Stores whether the player already took an action on the River 
	 */
	private boolean[] tookActionOnRiver;
	
	/**
	 * Stores whether we have seen a call on preflop
	 */
	private boolean[] callSeenPreFlop = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a call on flop
	 */
	private boolean[] callSeenFlop = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a call on turn
	 */
	private boolean[] callSeenTurn = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a call on river
	 */
	private boolean[] callSeenRiver = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores how often a player called on the pre flop
	 */
	private int[] numberOfCallsOnPreFlop = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores how often a player called on the flop
	 */
	private int[] numberOfCallsOnFlop = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores how often a player called on the turn
	 */
	private int[] numberOfCallsOnTurn = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores how often a player called on the river
	 */
	private int[] numberOfCallsOnRiver = new int[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a raise on preflop
	 */
	private boolean[] raiseSeenPreFlop = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a raise on flop
	 */
	private boolean[] raiseSeenFlop = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a raise on turn
	 */
	private boolean[] raiseSeenTurn = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores whether we have seen a raise on river
	 */
	private boolean[] raiseSeenRiver = new boolean[NUMBER_OF_PLAYERS];
	
	/**
	 * Stores how often a player raised on the pre flop
	 */
	private int[] numberOfRaisesOnPreFlop = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores how often a player raised on the flop
	 */
	private int[] numberOfRaisesOnFlop = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores how often a player raised on the turn
	 */
	private int[] numberOfRaisesOnTurn = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores how often a player raised on the river
	 */
	private int[] numberOfRaisesOnRiver = new int[NUMBER_OF_PLAYERS];

	/**
	 * Stores whether someone raised this round
	 */
	private boolean raiseSeenThisGame = false;
	
	/**
	 * Stores who raised this round 0 being player 0
	 */
	private int[] whoRaisedThisRound = new int[NUMBER_OF_PLAYERS];
	
	/**
	 * Keeps track of the times that a player bluffed
	 */
	private int[] numberOfBluffsPerPlayer;
	
	/**
	 * Keeps track of the number of showdowns a player saw
	 */
	private int[] numberOfShowdownsPerPlayer;
	private int weAre;
	
	/**
	 * 
	 * @param bot
	 */
	public Statistics(Bot bot){
		this.bot = bot;
		this.dynamics = bot.getDynamics();
		
		// initialize number of hands played by player array
		 numberOfHandsPlayedByPlayer = new int[NUMBER_OF_PLAYERS];
		 for(int i = 0; i < NUMBER_OF_PLAYERS; i++)
			 numberOfHandsPlayedByPlayer[i] = 0;
		 playerPlayedThisHand = new boolean[NUMBER_OF_PLAYERS];
		 for(int i = 0; i < NUMBER_OF_PLAYERS; i++)
			 playerPlayedThisHand[i] = false;
		 
		 // initialize number of raises seen
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++){
			 numberOfRaisesOnPreFlop[player] = 0;
			 numberOfRaisesOnFlop[player] = 0;
			 numberOfRaisesOnTurn[player] = 0;
			 numberOfRaisesOnRiver[player] = 0;
		 }
		 
		 // initialize number of calls seen
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++){
			 numberOfCallsOnPreFlop[player] = 0;
			 numberOfCallsOnFlop[player] = 0;
			 numberOfCallsOnTurn[player] = 0;
			 numberOfCallsOnRiver[player] = 0;
		 }
		 
		 // initialize who raised this round
		 whoRaisedThisRound = new int[NUMBER_OF_PLAYERS];
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			 whoRaisedThisRound[player] = 0;
		 
		 // initialize numberOfShowdownsPerPlayer
		 numberOfShowdownsPerPlayer = new int[NUMBER_OF_PLAYERS];
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			 numberOfShowdownsPerPlayer[player] = 0;
		 
		 // initialize numberof bluffs
		 numberOfBluffsPerPlayer = new int[NUMBER_OF_PLAYERS];
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			 numberOfBluffsPerPlayer[player] = 0;
		 
		 // initialize numberof turn
		 numberOfTurnsSeenByPlayer = new int[NUMBER_OF_PLAYERS];
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			 numberOfTurnsSeenByPlayer[player] = 0;

		 // initialize numberof turn
		 numberOfRiversSeenByPlayer = new int[NUMBER_OF_PLAYERS];
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			 numberOfRiversSeenByPlayer[player] = 0;

		 
		 // initialize the action flags
		 tookActionOnPreFlop =  new boolean[NUMBER_OF_PLAYERS];
		 tookActionOnFlop = new boolean[NUMBER_OF_PLAYERS];
		 tookActionOnTurn = new boolean[NUMBER_OF_PLAYERS];
		 tookActionOnRiver = new boolean[NUMBER_OF_PLAYERS];
		 
	}
	
	/**
	 * 
	 * @param clientCards
	 */
	public void newHandStarted(Card[] clientCards){
//		System.out.println("new Hand Started!");
		
		numberOfHandsPlayed++;
		
		resetHandPlayed();
		
		resetActionFlags();
		
		resetRaisesSeen();
		resetCallsSeen();
		
		resetWhoRaisedThisRound();
	}


	/**
	 * Resets the information of who raised this round
	 */
	private void resetWhoRaisedThisRound() {
		 for(int player = 0; player < NUMBER_OF_PLAYERS; player++ )
			 whoRaisedThisRound[player] = 0;
	}

	
	/**
	 * Resets the flags that indicates whether a player already took an action in this round
	 */
	private void resetActionFlags() {
		for(int player = 0; player < NUMBER_OF_PLAYERS; player++){
			tookActionOnPreFlop[player] = false;
			tookActionOnFlop[player] = false;
			tookActionOnTurn[player] = false;
			tookActionOnRiver[player] = false;
		}		
	}

	/**
	 * Resets the flags that indicate various calls by the players
	 */
	private void resetCallsSeen() {
		for(int player = 0; player < NUMBER_OF_PLAYERS; player++){
			callSeenPreFlop[player] = false;
			callSeenFlop[player] = false;
			callSeenTurn[player] = false;
			callSeenRiver[player] = false;
		}		
	}

	/**
	 * Resets the flags that indicate various raises by the players
	 */
	private void resetRaisesSeen() {
		for(int player = 0; player < NUMBER_OF_PLAYERS; player++){
			raiseSeenPreFlop[player] = false;
			raiseSeenFlop[player] = false;
			raiseSeenTurn[player] = false;
			raiseSeenRiver[player] = false;
		}
		
		raiseSeenThisGame = false;
	}

	/**
	 * Reset the flags that indicate that a player played this hand
	 */
	private void resetHandPlayed() {
		// reset updatedHandsPlayedByPlayer
		for(int i = 0; i < playerPlayedThisHand.length; i++)
			 playerPlayedThisHand[i] = false;
	}

	/**
	 * 
	 * @param lastAction
	 * @param lastSeat
	 * @param handOver
	 * @param showdown
	 */
	public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown ){
		int player = dynamics.seatToPlayer(lastSeat);
		
		// System.out.println("action " + lastAction + " by player " + player + " in seat " + lastSeat);
		
		updatePlayedGames(lastAction, player);
		
		updateRaisesSeen(lastAction, player);
		updateCallsSeen(lastAction, player);
		
		
		
		updateWhoRaisedThisRound(lastAction, player);
		
		updateShowdowns(showdown);
		updateBluffFactor(showdown);
		
		// must be updated after calls and raises were updated 
		updateActionFlags(lastAction, player);
	}
	
	/**
	 * This method counts how often a player was in the showdown
	 * @param showdown
	 */
	private void updateShowdowns(boolean showdown){
		if(! showdown)
			return;
		
		for(int seat = 0; seat < NUMBER_OF_PLAYERS; seat++){
			if(dynamics.active[seat]){
				int player = dynamics.seatToPlayer(seat);
				numberOfShowdownsPerPlayer[player]++;
			}
		}
	}
	
	/**
	 * This method tracks how often a player bluffed
	 * @param showdown
	 */
	private void updateBluffFactor(boolean showdown){
		if(! showdown)
			return;
		
		// This is a pair of twos
		long callItABluff = 16908624;
		// test if board is less
		com.stevebrecher.poker.CardSet boardset = BrecherAlbertaConverter.getInstance().getConvertedCardset(dynamics.board);
		int boardvalue = HandEval.hand5Eval(HandEval.encode(boardset));
		callItABluff = Math.max(callItABluff, boardvalue);
		
		for(int seat = 0; seat < NUMBER_OF_PLAYERS; seat++){
			if(dynamics.active[seat]){
				int player = dynamics.seatToPlayer(seat);
				
				Card[] cards = new Card[7];
				cards[0] = dynamics.hole[seat][0];
				cards[1] = dynamics.hole[seat][1];
				cards[2] = dynamics.board[0];
				cards[3] = dynamics.board[1];
				cards[4] = dynamics.board[2];
				cards[5] = dynamics.board[3];
				cards[6] = dynamics.board[4];
				
				com.stevebrecher.poker.CardSet cardset = BrecherAlbertaConverter.getInstance().getConvertedCardset(cards);
				
				// evaluate cards
				int evaled = HandEval.hand7Eval(HandEval.encode(cardset));
				
				// check if the value is less
				if(evaled < callItABluff)
					numberOfBluffsPerPlayer[player]++;
			}
		}
	}
	
	/**
	 * 
	 * @param lastAction
	 * @param player
	 */
	private void updateActionFlags(char lastAction, int player) {
		if(dynamics.isPreflop())
			tookActionOnPreFlop[player] = true;
		else if(dynamics.isFlop())
			tookActionOnFlop[player] = true;
		else if(dynamics.isTurn())
			tookActionOnTurn[player] = true;
		else if(dynamics.isRiver())
			tookActionOnRiver[player] = true;
	}
	
	/**
	 * If there was a raise we increment the raise counter for the submitted player
	 * @param lastAction
	 * @param player
	 */
	private void updateWhoRaisedThisRound(char lastAction, int player){
		if(lastAction == 'r')
			whoRaisedThisRound[player]++;
	}

	/**
	 * Updates whether we have seen a call or not.
	 * 
	 * @param lastAction
	 * @param player
	 */
	private void updateCallsSeen(char lastAction, int player) {
		if(lastAction == 'c'){
			if(dynamics.isPreflop() && ! tookActionOnPreFlop[player]){
				callSeenPreFlop[player] = true;
				numberOfCallsOnPreFlop[player]++;
			} else if (dynamics.isFlop() && ! tookActionOnFlop[player]){
				callSeenFlop[player] = true;
				numberOfCallsOnFlop[player]++;
			} else if(dynamics.isTurn() && ! tookActionOnTurn[player]) {
				callSeenTurn[player] = true;
				numberOfCallsOnTurn[player]++;
			} else if(dynamics.isRiver() && ! tookActionOnRiver[player]) {
				callSeenRiver[player] = true;
				numberOfCallsOnRiver[player]++;
			}
		}
	}

	/**
	 * Updates whether we have seen a raise or not.
	 * 
	 * @param lastAction
	 * @param player
	 */
	private void updateRaisesSeen(char lastAction, int player) {
		if(lastAction == 'r'){
			if(dynamics.isPreflop() && ! tookActionOnPreFlop[player]){
				raiseSeenPreFlop[player] = true;
				numberOfRaisesOnPreFlop[player]++;
			} else if (dynamics.isFlop() && ! tookActionOnFlop[player]){
				raiseSeenFlop[player] = true;
				numberOfRaisesOnFlop[player]++;
			} else if(dynamics.isTurn() && ! tookActionOnTurn[player]){
				raiseSeenTurn[player] = true;
				numberOfRaisesOnTurn[player]++;
			} else if(dynamics.isRiver() && ! tookActionOnRiver[player]){
				raiseSeenRiver[player] = true;
				numberOfRaisesOnRiver[player]++;
			}
			
			/* we have seen a raise */
			raiseSeenThisGame = true;
		}
	}

	/**
	 * updates the statistics how many games a player played
	 */
	private void updatePlayedGames(char lastAction, int player) {
		if(!playerPlayedThisHand[player] && lastAction != 'f'){
			numberOfHandsPlayedByPlayer[player]++;
			playerPlayedThisHand[player] = true;
		}
		
		// turn
		if(!tookActionOnTurn[player] && lastAction != 'f' && dynamics.isTurn())
			numberOfTurnsSeenByPlayer[player]++;
		if(!tookActionOnRiver[player] && lastAction != 'f' && dynamics.isRiver())
			numberOfRiversSeenByPlayer[player]++;
	}

	
	/**
	 * @return Whether someone raised this round.
	 */
	public boolean raiseSeenThisGame(){
		return raiseSeenThisGame;
	}
	
	public boolean raiseSeenThisRound(){
		if(dynamics.isPreflop())
			for(int player = 0; player < NUMBER_OF_PLAYERS; player++)
				if(hasRaisedPreFlop(player))
					return true;
		
		if(dynamics.isFlop())
			for(int player = 0; player < NUMBER_OF_PLAYERS; player++)
				if(hasRaisedFlop(player))
					return true;
		
		if(dynamics.isTurn())
			for(int player = 0; player < NUMBER_OF_PLAYERS; player++)
				if(hasRaisedTurn(player))
					return true;
		
		if(dynamics.isRiver())
			for(int player = 0; player < NUMBER_OF_PLAYERS; player++)
				if(hasRaisedRiver(player))
					return true;
		
		return false;
	}

	
	
	/**
	 * @return the number of hands played
	 */
	public int getNumberOfHandsPlayed(){
		return numberOfHandsPlayed;
	}
	
	
	/**
	 * 
	 * @param player
	 * @return The number of hands played by this player
	 */
	public int getNumberOfHandsPlayedByPlayer(int player){
		return numberOfHandsPlayedByPlayer[player];
	}
	
	/**
	 * @param player
	 * @return The percentage of games played by the specified player
	 */
	public double getPercentageOfHandsPlayedByPlayer(int player){
		return (double) numberOfHandsPlayedByPlayer[player] / (double) numberOfHandsPlayed;
	}
	
	/**
	 * @param player
	 * @return The player's classification
	 */
	public int getPlayersClassification(int player){
		double classification = getPercentageOfHandsPlayedByPlayer(player);
		
		if(classification < 0.2)
			return TIGHT;
		
		return LOOSE;
	}
	
	/**
	 * 
	 * @param player
	 * @return The number of raises by the supplied player
	 */
	public int getNumberOfRaisesForPlayerThisRound(int player){
		return whoRaisedThisRound[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return The number of times a player was in the showdown
	 */
	public int getNumberOfShowdownsForPlayer(int player){
		return numberOfShowdownsPerPlayer[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTurnsSeen(int player){
		return numberOfTurnsSeenByPlayer[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public double getPercentageOfTurnsSeen(int player){
		return numberOfHandsPlayed / (double) numberOfTurnsSeenByPlayer[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfRiversSeen(int player){
		return numberOfRiversSeenByPlayer[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public double getPercentageOfRiversSeen(int player){
		return numberOfHandsPlayed / (double) numberOfRiversSeenByPlayer[player];
	}
	
	
	
	/**
	 * 
	 * @param player
	 * @return The number of times a player bluffed
	 */
	public int getNumberOfTimesPlayerBluffed(int player){
		return numberOfBluffsPerPlayer[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return A percentage of how often a player bluffs
	 */
	public double getPercentagePlayerBluffs(int player){
		return numberOfBluffsPerPlayer[player] / (double) numberOfShowdownsPerPlayer[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return Whether the player raised on the preflop
	 */
	public boolean hasRaisedPreFlop(int player){
		return raiseSeenPreFlop[player];
	}

	
	/**
	 * 
	 * @param player
	 * @return Whether the player raised on the flop
	 */
	public boolean hasRaisedFlop(int player){
		return raiseSeenFlop[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return Whether the player raised on the turn
	 */
	public boolean hasRaisedTurn(int player){
		return raiseSeenTurn[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return Whether the player raised on the river
	 */
	public boolean hasRaisedRiver(int player){
		return raiseSeenRiver[player];
	}
	
	/**
	 * @param player
	 * @return Whether the player has raised
	 */
	public boolean hasRaised(int player){
		return hasRaisedPreFlop(player) || hasRaisedFlop(player) || hasRaisedTurn(player) || hasRaisedRiver(player);
	}

	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerRaisedPreFlop(int player){
		return numberOfRaisesOnPreFlop[player];
	}

	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerRaisedFlop(int player){
		return numberOfRaisesOnFlop[player];
	}

	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerRaisedTurn(int player){
		return numberOfRaisesOnTurn[player];
	}

	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerRaisedRiver(int player){
		return numberOfRaisesOnRiver[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public double getFractionPlayerRaisedPreFlop(int player){
		return (double) numberOfRaisesOnPreFlop[player] / (double) numberOfHandsPlayed;
	}		
	
	public double getFractionPlayerRaisedFlop(int player){
		return (double) numberOfRaisesOnFlop[player] / (double) numberOfHandsPlayed;
	}
	
	public double getFractionPlayerCalledFlop(int player){
		return (double) numberOfCallsOnFlop[player] / (double) numberOfHandsPlayed;
	}
	
	public double getFractionPlayerRaisedTurn(int player){
		return (double) numberOfRaisesOnTurn[player] / (double) numberOfHandsPlayed;
	}
	
	public double getFractionPlayerCalledTurn(int player){
		return (double) numberOfCallsOnTurn[player] / (double) numberOfHandsPlayed;
	}
	
	public double getFractionPlayerRaisedRiver(int player){
		return (double) numberOfRaisesOnRiver[player] / (double) numberOfHandsPlayed;
	}
	
	public double getFractionPlayerCalledRiver(int player){
		return (double) numberOfCallsOnRiver[player] / (double) numberOfHandsPlayed;
	}

	/**
	 * 
	 * @return The number of players that raised preFlop
	 */
	public int getNumberOfPlayersThatRaisedPreFlop() {
		int count = 0;
		for(boolean raised : raiseSeenPreFlop)
			if(raised)
				count++;
		
		return count;
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean hasCalledPreFlop(int player){
		return hasRaisedPreFlop(player) || callSeenPreFlop[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean hasCalledFlop(int player){
		return hasRaisedFlop(player) || callSeenFlop[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean hasCalledTurn(int player){
		return hasRaisedTurn(player) || callSeenTurn[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean hasCalledRiver(int player){
		return hasRaisedRiver(player) || callSeenRiver[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public boolean hasCalled(int player){
		return hasRaised(player) || hasCalledPreFlop(player) || hasCalledFlop(player) || hasCalledTurn(player) || hasCalledRiver(player);
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerCalledPreFlop(int player){
		return numberOfCallsOnPreFlop[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerCalledFlop(int player){
		return numberOfCallsOnFlop[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public double getFractionPlayerCalledPreFlop(int player){
		return (double) numberOfCallsOnPreFlop[player] / (double) numberOfHandsPlayed;
	}	
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerCalledTurn(int player){
		return numberOfCallsOnTurn[player];
	}
	
	/**
	 * 
	 * @param player
	 * @return
	 */
	public int getNumberOfTimesPlayerCalledRiver(int player){
		return numberOfCallsOnRiver[player];
	}
	
	
	/**
	 * 
	 * @return The number of players that called preFlop
	 */
	public int getNumberOfPlayersThatCalledPreFlop() {
		int count = 0;
		for(int i = 0; i < NUMBER_OF_PLAYERS; i++)
			if(hasCalledPreFlop(i))
				count++;
		
		return count;
	}

	/**
	 * 
	 * @param seatToPlayer
	 */
	public void setWhoWeAre(int player) {
		this.weAre = player;
	}
	
	public int whoAreWe(){
		return this.weAre;
	}
}
