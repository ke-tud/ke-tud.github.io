package group5.bot.mc;

import group5.bot.Bot;
import group5.mc.MCSimulator;
import group5.mc.expert.ModularExpert;
import group5.mc.expert.SelfExpert;
import group5.mc.expert.SimpleSelfExpert;
import group5.mc.expert.modules.CardGuesser;
import group5.mc.expert.modules.FlopActionGuesser;
import group5.mc.expert.modules.PreFlopActionGuesser;
import group5.mc.expert.modules.RiverActionGuesser;
import group5.mc.expert.modules.TurnActionGuesser;
import group5.pokerGame.BrecherAlbertaConverter;
import group5.pokerGame.CardDeck;
import group5.pokerGame.GameState;
import group5.statistics.Statistics;
import group5.util.Utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

public class SimpleMcBot extends Bot {
	private ModularExpert expert;
	private Statistics statistics;


	/**
	 * 
	 * @param numPlayers
	 * @param matchtype
	 */
	public SimpleMcBot (int numPlayers, MatchType matchtype) {
		super(numPlayers, matchtype);
		
		/* create statistics */
		this.statistics = new Statistics(this);
		
		/* create expert */
		expert = new ModularExpert(this, statistics);


		/*
		 * Card Guessing
		 */
		//Preflop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_PREFLOP, 200);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_PREFLOP, 1000);

		//flop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_FLOP, 200);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_FLOP, 1000);

		//turn
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_TURN, 200);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_TURN, 1000);

		//river
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_RIVER, 200);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_RIVER, 1000);
		
		
		
		/*
		 * Action Guessing
		 */
		//preflop
		expert.addModule(new PreFlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_PREFLOP, 100);
//		expert.addModule(new SimpleWekaActionGuesser_PreFlop(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_PREFLOP, 1000);

		//flop
		//expert.addModule(new VerySimpleActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_FLOP, 100);
		expert.addModule(new FlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_FLOP, 1000);
		
		//turn
//		expert.addModule(new VerySimpleActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_TURN, 100);
		expert.addModule(new TurnActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_TURN, 1000);
		
		//river
	//	expert.addModule(new VerySimpleActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_RIVER, 100);
		expert.addModule(new RiverActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_RIVER, 1000);
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize, int amountToCall) {
	   GameState gs = builtGameState();

		//expert
		SelfExpert ourExpert = new SimpleSelfExpert();

		MCSimulator mcSim = new MCSimulator(gs, expert, ourExpert);

		double callEV = mcSim.run(1000, MCSimulator.CALL);
		double raiseEV = mcSim.run(1000, MCSimulator.RAISE);

		System.out.println("callEV: " + callEV + " | " + "raiseEV: " + raiseEV +  " | " + "our cards: " + Card.arrayToString(dynamics.getMyHoleCards()) + " | " + "board cards: " + ((null != dynamics.board) ? Card.arrayToString(dynamics.board) : ""));

		try {
			if (callEV < 2.5 && raiseEV < 2.5)
				sendFold();
			else if (callEV > raiseEV)
				sendCall();
			else
				sendRaise();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

   }
   
   public GameState builtGameState() {
		// generate gamestate
		GameState gs = new GameState();
		
		System.out.println("------------");
		
		boolean activePlayers[] = new boolean[dynamics.active.length];
		for( int i = 0; i < activePlayers.length; i++)
			activePlayers[dynamics.seatToPlayer(i)] = dynamics.active[i];
		gs.setActivePlayers(activePlayers);
		//		gs.setActivePlayers(dynamics.active);
		
		System.out.println("active players: ");
		Utils.printArray(activePlayers);
		
		
		gs.setSeatToPlayer(dynamics.getSeatToPlayer());
	
		System.out.println("seat to player: ");
		Utils.printArray(dynamics.getSeatToPlayer());

		gs.setCurrentPlayer(dynamics.seatToPlayer(dynamics.getMySeat()));
		System.out.println("i am: " + dynamics.seatToPlayer(dynamics.getMySeat()));
		
		Card[] cards = dynamics.getMyHoleCards();
		gs.setCardsForPlayer(BrecherAlbertaConverter.getInstance().getConvertedCards(cards), dynamics.seatToPlayer(dynamics.getMySeat()), true);
		
		if (dynamics.isPreflop()) 
			gs.setRound(GameState.PREFLOP);
		else if (dynamics.isFlop()) 
			gs.setRound(GameState.FLOP);
		else if (dynamics.isTurn()) 
			gs.setRound(GameState.TURN);
		else if (dynamics.isRiver()) 
			gs.setRound(GameState.RIVER);
		
		int inPot[] = new int[dynamics.active.length];
		for( int i = 0; i < inPot.length; i++)
			inPot[dynamics.seatToPlayer(i)] = dynamics.inPot[i];
		gs.setInPot(inPot);
		
		System.out.println("in Pot: ");
		Utils.printArray(inPot);
		
//		gs.setInPot(dynamics.inPot);
		
		gs.setNumberOfRaisesSeenThisRound(dynamics.roundBets);
		
		CardDeck deck = gs.getDeck();
		if (null != dynamics.board)
			for (Card aCard : dynamics.board) {
				if (null != aCard)
					gs.addCardToBoard(deck.takeSpecificCard(BrecherAlbertaConverter.getInstance().getConvertedCard(aCard)));
					
			}
		
		return gs;
  }

	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception {
		MatchType matchType = new MatchType(LimitType.LIMIT, false, 8000, 1000); 

		SimpleMcBot myBot = new SimpleMcBot(6, matchType);

		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
		myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.println("Successful connection!");

		myBot.run();
	}

}
