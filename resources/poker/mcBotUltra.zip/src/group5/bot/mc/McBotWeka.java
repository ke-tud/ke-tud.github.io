package group5.bot.mc;

import group5.bot.Bot;
import group5.mc.Random;
import group5.mc.UCTSimulator;
import group5.mc.expert.ModularExpert;
import group5.mc.expert.modules.CardGuesser;
import group5.mc.expert.modules.FlopActionGuesser;
import group5.mc.expert.modules.PreFlopActionGuesser;
import group5.mc.expert.modules.RiverActionGuesser;
import group5.mc.expert.modules.TurnActionGuesser;
import group5.pokerGame.BrecherAlbertaConverter;
import group5.pokerGame.CardDeck;
import group5.pokerGame.GameState;
import group5.statistics.Statistics;
import group5.util.Performance;
import group5.util.Utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

public class McBotWeka extends Bot {
	private ModularExpert expert;
	private Statistics statistics;


	/**
	 * 
	 * @param numPlayers
	 * @param matchtype
	 */
	public McBotWeka (int numPlayers, MatchType matchtype) {
		super(numPlayers, matchtype);
		
		/* create statistics */
		this.statistics = new Statistics(this);
		
		/* create expert */
		expert = new ModularExpert(this, statistics);

		/*
		 * Card Guessing
		 */
		//Preflop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_PREFLOP, 1000);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_PREFLOP, 6000);

		//flop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_FLOP, 1000);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_FLOP, 6000);

		//turn
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_TURN, 1000);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_TURN, 6000);

		//river
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_RIVER, 1000);
//		expert.addModule(new SimpleWekaCardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_RIVER, 6000);
		
		
		
		/*
		 * Action Guessing
		 */
		//preflop
		expert.addModule(new PreFlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_PREFLOP, 100);

		//flop
		expert.addModule(new FlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_FLOP, 1000);
		
		//turn
		expert.addModule(new TurnActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_TURN, 1000);
		
		//river
		expert.addModule(new RiverActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_RIVER, 1000);
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize, int amountToCall) {
	   GameState gs = builtGameState();

		//expert
		Performance.start("run simulation");
	    UCTSimulator sim = new UCTSimulator(gs, expert);
		double[] EV = sim.run();
		Performance.stop();
		double callEV = EV[1];
		double raiseEV = EV[2];
		
		System.out.println("callEV: " + callEV + " | " + "raiseEV: " + raiseEV +  " | " + "our cards: " + Card.arrayToString(dynamics.getMyHoleCards()) + " | " + "board cards: " + ((null != dynamics.board) ? Card.arrayToString(dynamics.board) : ""));
		
		try {
			if (callEV < 0 && raiseEV < 0){
				if(amountToCall == 0)
					if(! statistics.raiseSeenThisGame() && Random.getInstance().generateRandomNumber() <= 0.1 )
						sendRaise();
					else
						sendCall();
				else
					sendFold();
			} else if (callEV > raiseEV){
				if(! statistics.raiseSeenThisGame() )
					sendRaise();
				else
					sendCall();
			}
			else {
				sendRaise();
			}
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

   }
   

   public GameState builtGameState() {
		// generate gamestate
		GameState gs = new GameState();
		
		System.out.println("------------");
		
		boolean activePlayers[] = new boolean[dynamics.active.length];
		for( int i = 0; i < activePlayers.length; i++)
			activePlayers[dynamics.seatToPlayer(i)] = dynamics.active[i];
		gs.setActivePlayers(activePlayers);
		//		gs.setActivePlayers(dynamics.active);
		
		System.out.println("active players: ");
		Utils.printArray(activePlayers);
		
		
		gs.setSeatToPlayer(dynamics.getSeatToPlayer());
	
		System.out.println("seat to player: ");
		Utils.printArray(dynamics.getSeatToPlayer());

		gs.setCurrentPlayer(dynamics.seatToPlayer(dynamics.getMySeat()));
		System.out.println("i am: " + dynamics.seatToPlayer(dynamics.getMySeat()));
		
		Card[] cards = dynamics.getMyHoleCards();
		gs.setCardsForPlayer(BrecherAlbertaConverter.getInstance().getConvertedCards(cards), dynamics.seatToPlayer(dynamics.getMySeat()), true);
		
		if (dynamics.isPreflop()) 
			gs.setRound(GameState.PREFLOP);
		else if (dynamics.isFlop()) 
			gs.setRound(GameState.FLOP);
		else if (dynamics.isTurn()) 
			gs.setRound(GameState.TURN);
		else if (dynamics.isRiver()) 
			gs.setRound(GameState.RIVER);
		
		int inPot[] = new int[dynamics.active.length];
		for( int i = 0; i < inPot.length; i++)
			inPot[dynamics.seatToPlayer(i)] = dynamics.inPot[i];
		gs.setInPot(inPot);
		
		System.out.println("in Pot: ");
		Utils.printArray(inPot);
		
//		gs.setInPot(dynamics.inPot);
		
		gs.setNumberOfRaisesSeenThisRound(dynamics.roundBets);
		
		CardDeck deck = gs.getDeck();
		if (null != dynamics.board)
			for (Card aCard : dynamics.board) {
				if (null != aCard)
					gs.addCardToBoard(deck.takeSpecificCard(BrecherAlbertaConverter.getInstance().getConvertedCard(aCard)));
					
			}
		
		return gs;
   }
   
   @Override
   public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown){
	   expert.actionPerformed(lastAction, lastSeat, handOver, showdown);
   }
   
   @Override
   public void newHandStarted(Card[] clientCards){
	   expert.newHandStarted(clientCards);
   }

	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception {
		MatchType matchType = new MatchType(LimitType.LIMIT, false, 8000, 1000); 
		
		McBotWeka myBot = new McBotWeka(6, matchType);

		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
		myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.println("Successful connection!");

		myBot.run();
	}
}
