package group5.bot.mc;

import group5.bot.Bot;
import group5.mc.Random;
import group5.mc.UCTSimulator;
import group5.mc.expert.ModularExpert;
import group5.mc.expert.modules.CardGuesser;
import group5.mc.expert.modules.FlopActionGuesser;
import group5.mc.expert.modules.PreFlopActionGuesser;
import group5.mc.expert.modules.RiverActionGuesser;
import group5.mc.expert.modules.TurnActionGuesser;
import group5.pokerGame.BrecherAlbertaConverter;
import group5.pokerGame.CardDeck;
import group5.pokerGame.GameState;
import group5.statistics.Statistics;
import group5.timemgmt.TimeKeeper;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

public class McBotUltra extends Bot {
	private ModularExpert expert;
	private Statistics statistics;
	private TimeKeeper timeKeeper;


	/**
	 * 
	 * @param numPlayers
	 * @param matchtype
	 */
	public McBotUltra (int numPlayers, MatchType matchtype) {
		super(numPlayers, matchtype);
		
		/* time management */
		timeKeeper = TimeKeeper.getInstance();
		
		/* create statistics */
		this.statistics = new Statistics(this);
		
		/* create expert */
		expert = new ModularExpert(this, statistics);

		/*
		 * Card Guessing
		 */
		//Preflop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_PREFLOP, 1000);

		//flop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_FLOP, 1000);

		//turn
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_TURN, 1000);

		//river
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_RIVER, 1000);
		
		
		
		/*
		 * Action Guessing
		 */
		//preflop
		expert.addModule(new PreFlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_PREFLOP, 100);

		//flop
		expert.addModule(new FlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_FLOP, 1000);
		
		//turn
		expert.addModule(new TurnActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_TURN, 1000);
		
		//river
		expert.addModule(new RiverActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_RIVER, 1000);
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize, int amountToCall) {
	   timeKeeper.startWork();
	   
	   // tell statistic who we are
	   statistics.setWhoWeAre(dynamics.seatToPlayer(dynamics.getMySeat()));

	   // build game state
	   GameState gs = builtGameState();

		//expert
	    UCTSimulator sim = new UCTSimulator(gs, expert);
	    
	    // we want to check 8 times for an obvious action
	    
	    
	    // use 60.000 simulations on preflop and 40.000 later
    	
    	sim.setSimulationsPerCrossedNode(0);
    	
    	sim.setNumberOfTimesToCheckForObviousAction(10);

    	// 1500 / 75, obvious 4, uct 4was quite good
    	
    	sim.setNumberOfSimulationsPerNode(55);
    	sim.setNumberOfTotalSimulations(1500);
    	sim.setObviousActionFactor(3);	
		sim.setUCTExplorationFactor(4);
    	
    	if(dynamics.isPreflop()){
	    } else if(dynamics.isFlop()) {
	    } else {
	    }
	    
	    // UCT Exploration Factor
	    
	    if(timeKeeper.getPercentageUsed() > 0.9)
			sim.halfNumberOfSimulations();
	    if(timeKeeper.getPercentageUsed() > 0.95)
	    	sim.halfNumberOfSimulations();
		
		double[] EV = sim.run();
		
		double callEV = EV[1];
		double raiseEV = EV[2];
		
//		System.out.println("callEV: " + callEV + " | " + 
//						   "raiseEV: " + raiseEV + " | " + 
//						   "our cards: " + Card.arrayToString(dynamics.getMyHoleCards()) + " | " + 
//						   "board cards: " + ((null != dynamics.board) ? Card.arrayToString(dynamics.board) : "") + ", " + 
//						   "active Players " + gs.getNumberOfActivePlayers() + ", " +
//						   "in Pot" + gs.getPot() + ", we are " + dynamics.seatToPlayer(dynamics.getMySeat()) 
//						   );
		
		// print dot file
//		UCTPlotter plot = new UCTPlotter(sim); 
//		plot.createDotFile("plot_" + Card.arrayToString(dynamics.getMyHoleCards()) + ".dot");
		
		try {
			if (callEV < 0 && raiseEV < 0){
				if(amountToCall == 0)
					sendCall();
				else
					sendFold();
			} else if (callEV > raiseEV) {
				if (( (callEV - 0.4 < raiseEV) && (Random.getInstance().generateRandomNumber() < 0.8)) || (!statistics.raiseSeenThisRound() && (Random.getInstance().generateRandomNumber() < 0.2)))
					sendRaise();
				else
					sendCall();
			}
			else {
				sendRaise();
			}
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		timeKeeper.stopWork();
		
		if(statistics.getNumberOfHandsPlayed() % 50 == 0)
			System.out.println(statistics.getNumberOfHandsPlayed() + " => " + timeKeeper.getPercentageUsed());
		
		// remove reference to simulation and run garbage collector
		sim = null;
		System.gc();
   }
   

   public GameState builtGameState() {
		// generate gamestate
		GameState gs = new GameState();
		
		boolean activePlayers[] = new boolean[dynamics.active.length];
		for( int i = 0; i < activePlayers.length; i++)
			activePlayers[dynamics.seatToPlayer(i)] = dynamics.active[i];
		gs.setActivePlayers(activePlayers);
		//		gs.setActivePlayers(dynamics.active);
		
		gs.setSeatToPlayer(dynamics.getSeatToPlayer());
	
		gs.setCurrentPlayer(dynamics.seatToPlayer(dynamics.getMySeat()));
		
		Card[] cards = dynamics.getMyHoleCards();
		gs.setCardsForPlayer(BrecherAlbertaConverter.getInstance().getConvertedCards(cards), dynamics.seatToPlayer(dynamics.getMySeat()), true);
		
		if (dynamics.isPreflop()) 
			gs.setRound(GameState.PREFLOP);
		else if (dynamics.isFlop()) 
			gs.setRound(GameState.FLOP);
		else if (dynamics.isTurn()) 
			gs.setRound(GameState.TURN);
		else if (dynamics.isRiver()) 
			gs.setRound(GameState.RIVER);
		
		int inPot[] = new int[dynamics.active.length];
		for( int i = 0; i < inPot.length; i++)
			inPot[dynamics.seatToPlayer(i)] = dynamics.inPot[i];
		gs.setInPot(inPot);
		
		gs.setNumberOfRaisesSeenThisRound(dynamics.roundBets);
		
		CardDeck deck = gs.getDeck();
		if (null != dynamics.board)
			for (Card aCard : dynamics.board) {
				if (null != aCard)
					gs.addCardToBoard(deck.takeSpecificCard(BrecherAlbertaConverter.getInstance().getConvertedCard(aCard)));
					
			}

		return gs;
   }
   
   @Override
   public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown){
	   expert.actionPerformed(lastAction, lastSeat, handOver, showdown);
   }
   
   @Override
   public void newHandStarted(Card[] clientCards){
	   expert.newHandStarted(clientCards);
   }

	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception {
		MatchType matchType = new MatchType(LimitType.LIMIT, false, 8000, 1000); 
		
		McBotUltra myBot = new McBotUltra(6, matchType);

		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
		myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.println("Successful connection!");

		myBot.run();
	}
}
