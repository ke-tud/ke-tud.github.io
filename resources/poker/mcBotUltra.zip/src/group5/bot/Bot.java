package group5.bot;

import group5.dynamics.AdvMatchStateMessage;
import group5.dynamics.ClientRingDynamics;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.client.PokerClient;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

/**
 * This class builds the base of an poker bot. It implements some very useful functionality, handles 
 * and the dynamic components of the game and offers different function to overwrite to get a bot 
 * specific behavior.
 * 
 * @author Michael
 *
 */
public class Bot extends PokerClient {
	
	/**
	 * CONSTANTS FOR POSITION
	 */
	public final static int EARLY_POSITION = 0;
	public final static int MIDDLE_POSITION = 1;
	public final static int LATE_POSITION = 2;
	public final static int BLIND_POSITION = 3;
	

	/**
	 * store whether we are in the first betting round of the current round
	 */
	private boolean firstBettingRound = true;
	
	/**
	 * stores the current round
	 */
	private int currentRound = 0;
	
	
	/**
	 * The position of the bot.
	 */
	int position = 0;
	
	/**
	 * The match type object corresponding to the actual played game.
	 */
	private MatchType matchType = null;
	
	/**
	 * Number of players on the table.
	 */
	private int numPlayers;
	
	/**
	 * The object to handle the dynamic actions.
	 */
	protected ClientRingDynamics dynamics;
	
	/**
	 * @param numPlayers The number of players to set.
	 * @param matchType The match type object to set.
	 */
	public Bot (int numPlayers, MatchType matchType) {
		super();
		this.matchType = matchType;
		this.numPlayers = numPlayers;
		
		String[] names = new String[this.numPlayers];

		// give all players some names.
		for (int i = 0; i < this.numPlayers; i++ ) 
			names[i] = "Player " + Integer.toString(i);
		
		// create a dynamics object.
		dynamics = new ClientRingDynamics(this.numPlayers, this.matchType, names);
	}
	
	/**
	 * This method is called whenever a game action happened. The method checks if our bot is on turn,
	 * a new hand was started or any other action was performed (like an other bot raised). 
	 */
    public void handleStateChange() throws IOException, SocketException{

    	AdvMatchStateMessage msm = new AdvMatchStateMessage(currentGameStateString);
    	
       	int seatToAct = this.dynamics.seatToAct;
    	
       	// store position
       	position = dynamics.getMySeat();
       	
       	// new hand?
       	boolean isNewHand = this.dynamics.processStateChange(msm);
       	
       	// make sure everything's fine with tracked state (should never be true)
       	if (!this.dynamics.getMatchState(this.dynamics.getMySeat()).equals(currentGameStateString)) {
          	System.out.println("BADMATCHSTATESTRING: ");
          	System.out.println("     Localstate : " + this.dynamics.getMatchState(this.dynamics.getMySeat()));
          	System.out.println("     From Server: " + currentGameStateString);
       	}
       	
       	// if there is a new hand to play, then force the bot to react.
       	if (isNewHand){
       		firstBettingRound = true;
     	   
      	    // we are in the preflop round
     	    currentRound = 0;
     	    
     	    // tell any derivates that a new hand was started
       		newHandStarted(this.dynamics.getMyHoleCards());
       	}
       		
       		
       	// somebody else must have taken an action...
       	else if(msm.getLastActionChar() == 'f' || msm.getLastActionChar() == 'c' || msm.getLastActionChar() == 'r' )
       		actionPerformed(msm.getLastActionChar(), seatToAct, this.dynamics.handOver, this.dynamics.isShowdown());
       	
       	// force the bot to make a decision if it is his turn.
       	if (!dynamics.handOver && dynamics.isMyTurn()) {
		    
       		// update the firstBettingRound flag
       		if(currentRound != dynamics.roundIndex){
		  		   currentRound = dynamics.roundIndex;
		  		   firstBettingRound = true;
		  	}
       		
       		takeAction(dynamics.canRaise(dynamics.getMySeat()), dynamics.getPotSum(), 
       				dynamics.getAmountToCall(dynamics.getMySeat()));
       		

     	   // we are no longer in first betting round
     	   firstBettingRound = false;
       	}
    }
	
    /**
     * @returns the position (early,middle ...)
     */
    public int getPosition(){
    	if(position == 0 || position == 1)
    		return BLIND_POSITION;
    	
    	if(position == 2)
    		return EARLY_POSITION;
    	
    	if(position == 3 || position == 4)
    		return MIDDLE_POSITION;
    	
    	return LATE_POSITION;
    }
    
    /**
     * @return the bots current cards
     */
    public Card[] getMyCards(){
    	return this.dynamics.getMyHoleCards();
    }
    
    /**
     * @return Whether we are still in the first betting round
     */
    public boolean isFirstBettingRound(){
    	return firstBettingRound;
    }
    
    /**
     * If the bot is to be instanciated 
     * 
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        Bot rpc = new Bot(6, new MatchType(LimitType.LIMIT, false, 8000, 1000));
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }

    /**
     * Defines the reaction of a bot if a new hand was started. 
     */
    public void newHandStarted(Card[] clientCards)
    {}

    /**
     * Defines the reaction of a bot when he is forced to take an action.
     * 
     * @param raiseAllowed Whether the bot is able to raise or not.
     * @param totalPotSize The actual amount of the pot.
     * @param amountToCall The amount to call.
     */
    public void takeAction(boolean raiseAllowed, int totalPotSize, int amountToCall)
    {}

    /**
     * If there was an action done by an opponent, this method is called.
     * 
     * @param lastAction The type of the last action.
     * @param lastSeat The player which performed the action.
     * @param handOver Whether the hand is over or not.
     * @param showdown Whether we are in the show down or not.
     */
    public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown)
    {}

    /**
     * @return The actual pocket cards plus the cards on the board.
     */
	public Card[] getAllCards() {
		return dynamics.getAllCards();
	}
	
	/**
	 * @return the {@link ClientRingDynamics}
	 */
	public ClientRingDynamics getDynamics(){
		return dynamics;
	}
}
