package group5.bot.simple;

import group5.bot.Bot;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

public class FoldBot extends Bot {

	/**
	 * 
	 * @param numPlayers
	 * @param matchtype
	 */
	public FoldBot (int numPlayers, MatchType matchtype) {
		super(numPlayers, matchtype);
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize, int amountToCall) {
	   try {
		  sendFold();
	   } catch (SocketException e) {
		   e.printStackTrace();
	   } catch (IOException e) {
		   e.printStackTrace();
	   }
   }

	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception {
		MatchType matchType = new MatchType(LimitType.LIMIT, false, 8000, 1000); 

		FoldBot myBot = new FoldBot(6, matchType);

		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
		myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.println("Successful connection!");

		myBot.run();
	}

}
