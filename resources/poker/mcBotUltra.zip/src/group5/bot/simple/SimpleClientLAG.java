package group5.bot.simple;

import group5.bot.Bot;
import group5.bot.simple.strategy.PokerStrategy;
import group5.bot.simple.strategy.loose.LoosePreFlopStrategy;
import group5.bot.simple.strategy.tight.TightPostFlopStrategy;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

public class SimpleClientLAG extends Bot {
	/**
	 * Stores the strategy
	 */
	protected PokerStrategy strategy;
	
	/**
	 * 
	 * @param numPlayers
	 * @param matchtype
	 */
	public SimpleClientLAG (int numPlayers, MatchType matchtype) {
		super(numPlayers, matchtype);
		
		// instantiate Strategy
		strategy = new PokerStrategy(this);
		strategy.registerPreFlopStrategy(new LoosePreFlopStrategy());
		
		TightPostFlopStrategy postFlopStrategy = new TightPostFlopStrategy();
		strategy.registerFlopStrategy(postFlopStrategy);
		strategy.registerRiverStrategy(postFlopStrategy);
		strategy.registerTurnStrategy(postFlopStrategy);
		
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize, int amountToCall) {
	  
	   
	   if(dynamics.isPreflop())
	   		takePreFlopAction();
	   else
	   		takePostFlopAction();
	   	
   	}

	private void takePostFlopAction() {
		int round = 0;
		if(dynamics.isFlop())
			round = PokerStrategy.FLOP;
		else if(dynamics.isTurn())
			round = PokerStrategy.TURN;
		else
			round = PokerStrategy.RIVER;
		
		
		try {

			switch(strategy.takeAction(round)){
			case PokerStrategy.CALL:
				sendCall();
				break;
			case PokerStrategy.RAISE:
				sendRaise();
				break;
			default:
				sendFold();
				break;
			}
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Implement a very tight preflop strategy
	 */
	private void takePreFlopAction() {
		try {

			switch(strategy.takeAction(PokerStrategy.PREFLOP)){
			case PokerStrategy.CALL:
				sendCall();
				break;
			case PokerStrategy.RAISE:
				sendRaise();
				break;
			default:
				sendFold();
				break;
			}
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	        
	
	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception {
		MatchType matchType = new MatchType(LimitType.LIMIT, false, 8000, 1000); 

		SimpleClientLAG myBot = new SimpleClientLAG(6, matchType);

		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
		myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.println("Successful connection!");

		myBot.run();
	}

}
