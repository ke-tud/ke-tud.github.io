package group5.bot.simple.strategy;

import group5.bot.Bot;

public interface TurnStrategy {

	public int takeTurnAction(Bot pokerBot);
}
