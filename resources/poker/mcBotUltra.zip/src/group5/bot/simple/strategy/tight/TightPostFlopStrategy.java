package group5.bot.simple.strategy.tight;

import group5.bot.Bot;
import group5.bot.simple.strategy.FlopStrategy;
import group5.bot.simple.strategy.PokerStrategy;
import group5.bot.simple.strategy.RiverStrategy;
import group5.bot.simple.strategy.TurnStrategy;
import group5.dynamics.AdvHandAnalysis;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class TightPostFlopStrategy implements FlopStrategy, TurnStrategy, RiverStrategy{

	private AdvHandAnalysis analysis;
	
	public TightPostFlopStrategy() {
	}
	
	public int takeFlopAction(Bot pokerBot) {
		
		analysis = new AdvHandAnalysis(pokerBot.getAllCards());
		
		int returnValue = PokerStrategy.FOLD;
		
		if (analysis.isFlushDraw() || analysis.isStraightDraw()) {
			returnValue = PokerStrategy.CALL;
		}
		
		if (analysis.isFlush() || analysis.isStraight()) {
			returnValue = PokerStrategy.RAISE;	
		}
		
		if ((AdvHandAnalysis.HandType.PAIR.compareTo(analysis.getHandType()) >= 0)) {
			returnValue = PokerStrategy.RAISE;
		}
		
		if ((AdvHandAnalysis.HandType.PAIR.compareTo(analysis.getHandType()) == 0) && (pokerBot.getMyCards()[0].rank.compareTo(Card.Rank.NINE) < 0) )
			returnValue = PokerStrategy.FOLD;
		
		return returnValue;
	}

	public int takeTurnAction(Bot pokerBot) {
		return takeFlopAction(pokerBot);
	}

	public int takeRiverAction(Bot pokerBot) {
		
		analysis = new AdvHandAnalysis(pokerBot.getAllCards());
		
		int returnValue = PokerStrategy.FOLD;
				
		if (analysis.isFlush() || analysis.isStraight()) {
			returnValue = PokerStrategy.RAISE;	
		}
		
		if ((AdvHandAnalysis.HandType.PAIR.compareTo(analysis.getHandType()) >= 0)) {
			returnValue = PokerStrategy.RAISE;
		}
		
		return returnValue;
	}

}
