package group5.bot.simple.strategy;

import group5.bot.Bot;

/**
 * Defines the interface 
 * 
 * @author Arno
 */
public interface PreFlopStrategy {
	
	public int takePreFlopAction(Bot pokerBot);
	
}
