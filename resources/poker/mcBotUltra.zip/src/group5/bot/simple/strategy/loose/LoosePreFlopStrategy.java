package group5.bot.simple.strategy.loose;

import group5.bot.Bot;
import group5.bot.simple.strategy.PokerStrategy;
import group5.bot.simple.strategy.PreFlopStrategy;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;

public class LoosePreFlopStrategy implements PreFlopStrategy {

	/**
	 * Name Actions
	 */
	public static final int ACTION_FOLD = 1;
	public static final int ACTION_CALL = 2;
	public static final int ACTION_RAISE = 3;
	public static final int ACTION_OPEN = 4;
	
	/**
	 * Name Categories
	 */
	public static final int CATEGORY_1 = 1;
	public static final int CATEGORY_2 = 2;
	public static final int CATEGORY_3 = 3;
	public static final int CATEGORY_4 = 4;
	public static final int CATEGORY_5 = 5;
	public static final int CATEGORY_6 = 6;
	
	private Map<String,Integer> categoryMap;
	private Map<String,Integer> categoryMap_s;

	private Map<Integer, Vector<Integer>> preFlopStrategyA;
	private Map<Integer, Vector<Integer>> preFlopStrategyB;
	private int category;
	

	
	public LoosePreFlopStrategy(){
		fillCategoryMaps();
		fillPreFlopStrategy();
	}
	
	/**
	 * Create our strategy
	 */
	@SuppressWarnings("unchecked")
	private void fillPreFlopStrategy() {
		// instantiate Maps
		preFlopStrategyA = new HashMap<Integer, Vector<Integer>>();
		preFlopStrategyB = new HashMap<Integer, Vector<Integer>>();
		
		// 1 A
		Vector<Integer> strategy = new Vector<Integer>();
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		preFlopStrategyA.put(CATEGORY_1,strategy);
		
		// 1 B
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		preFlopStrategyB.put(CATEGORY_1, strategy);
		
		// 2 A
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		preFlopStrategyA.put(CATEGORY_2, strategy);
		
		// 2 B
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		preFlopStrategyB.put(CATEGORY_2, strategy);
		
		
		// 3 A
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_CALL);
		preFlopStrategyA.put(CATEGORY_3, strategy);
		
		// 3 B
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_RAISE);
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_CALL);
		preFlopStrategyB.put(CATEGORY_3, strategy);
		
		// 4 A
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_RAISE);
		preFlopStrategyA.put(CATEGORY_4, strategy);
		
		// 4 B
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_CALL);
		strategy.add(ACTION_RAISE);
		preFlopStrategyB.put(CATEGORY_4, strategy);
		
		// 5 A
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_OPEN);
		strategy.add(ACTION_CALL);
		preFlopStrategyA.put(CATEGORY_5, strategy);
		
		// 5 B
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_OPEN);
		strategy.add(ACTION_CALL);
		preFlopStrategyB.put(CATEGORY_5, strategy);
		
		// 6 A
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		preFlopStrategyA.put(CATEGORY_6, strategy);
		
		// 6 B
		strategy = (Vector<Integer>) strategy.clone();
		strategy.clear();
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		strategy.add(ACTION_FOLD);
		preFlopStrategyB.put(CATEGORY_6, strategy);
	}

	/**
	 * Fill the category Maps.
	 */
	private void fillCategoryMaps() {
		categoryMap = new HashMap<String, Integer>();
		categoryMap.put(Rank.ACE.toString() + Rank.ACE.toString(), CATEGORY_1);
		categoryMap.put(Rank.KING.toString() + Rank.KING.toString(), CATEGORY_1);
		categoryMap.put(Rank.QUEEN.toString() + Rank.QUEEN.toString(), CATEGORY_1);

		categoryMap.put(Rank.ACE.toString() + Rank.KING.toString(), CATEGORY_2);
		categoryMap.put(Rank.JACK.toString() + Rank.JACK.toString(), CATEGORY_2);
		categoryMap.put(Rank.TEN.toString() + Rank.TEN.toString(), CATEGORY_2);
		
		categoryMap.put(Rank.ACE.toString() + Rank.QUEEN.toString(), CATEGORY_3);
		categoryMap.put(Rank.NINE.toString() + Rank.NINE.toString(), CATEGORY_3);
		categoryMap.put(Rank.EIGHT.toString() + Rank.EIGHT.toString(), CATEGORY_3);
		
		categoryMap.put(Rank.ACE.toString() + Rank.JACK.toString(), CATEGORY_4);
		categoryMap.put(Rank.ACE.toString() + Rank.TEN.toString(), CATEGORY_4);
		categoryMap.put(Rank.SEVEN.toString() + Rank.SEVEN.toString(), CATEGORY_4);
		categoryMap.put(Rank.FIVE.toString() + Rank.FIVE.toString(), CATEGORY_4);
		categoryMap.put(Rank.SIX.toString() + Rank.SIX.toString(), CATEGORY_4);
		
		
		
		categoryMap.put(Rank.ACE.toString() + Rank.NINE.toString(), CATEGORY_5);
		categoryMap.put(Rank.ACE.toString() + Rank.EIGHT.toString(), CATEGORY_5);
		categoryMap.put(Rank.ACE.toString() + Rank.SEVEN.toString(), CATEGORY_5);
		categoryMap.put(Rank.KING.toString() + Rank.QUEEN.toString(), CATEGORY_5);
		categoryMap.put(Rank.FOUR.toString() + Rank.FOUR.toString(), CATEGORY_5);
		categoryMap.put(Rank.THREE.toString() + Rank.THREE.toString(), CATEGORY_5);
		categoryMap.put(Rank.TWO.toString() + Rank.TWO.toString(), CATEGORY_5);
		
		
		
		categoryMap_s = new HashMap<String, Integer>();
		categoryMap_s.put(Rank.ACE.toString() + Rank.KING.toString(), CATEGORY_1);
		
		categoryMap_s.put(Rank.ACE.toString() + Rank.QUEEN.toString(), CATEGORY_2);
		
		categoryMap_s.put(Rank.ACE.toString() + Rank.JACK.toString(), CATEGORY_3);
		categoryMap_s.put(Rank.KING.toString() + Rank.JACK.toString(), CATEGORY_3);
		categoryMap_s.put(Rank.QUEEN.toString() + Rank.JACK.toString(), CATEGORY_3);
		categoryMap_s.put(Rank.ACE.toString() + Rank.TEN.toString(), CATEGORY_3);
		
		categoryMap_s.put(Rank.NINE.toString() + Rank.EIGHT.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.EIGHT.toString() + Rank.SEVEN.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.SEVEN.toString() + Rank.SIX.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.SIX.toString() + Rank.FIVE.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.FIVE.toString() + Rank.FOUR.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.FOUR.toString() + Rank.THREE.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.THREE.toString() + Rank.TWO.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.ACE.toString() + Rank.NINE.toString(), CATEGORY_4);
		categoryMap_s.put(Rank.ACE.toString() + Rank.EIGHT.toString(), CATEGORY_4);
		
		categoryMap_s.put(Rank.ACE.toString() + Rank.SEVEN.toString(), CATEGORY_5);
		categoryMap_s.put(Rank.ACE.toString() + Rank.SIX.toString(), CATEGORY_5);
		categoryMap_s.put(Rank.ACE.toString() + Rank.FIVE.toString(), CATEGORY_5);
		categoryMap_s.put(Rank.ACE.toString() + Rank.FOUR.toString(), CATEGORY_5);
		categoryMap_s.put(Rank.ACE.toString() + Rank.THREE.toString(), CATEGORY_5);
		categoryMap_s.put(Rank.ACE.toString() + Rank.TWO.toString(), CATEGORY_5);
		
		
	}
	
	/**
	 * @return the category we are in
	 */
	private int getCategory(Card[] clientCards){
		// sort cards
		if(clientCards[0].rank.compareTo(clientCards[1].rank) < 0){
			Card tmp = clientCards[0];
			clientCards[0] = clientCards[1];
			clientCards[1] = tmp;
		}
		
		// create key
		String key = clientCards[0].rank.toString() + clientCards[1].rank.toString();
		
		if(clientCards[0].suit == clientCards[1].suit) // suited
			if(categoryMap_s.containsKey(key))
				return categoryMap_s.get(key);
		
		// unsuited
		if(categoryMap.containsKey(key))
			return categoryMap.get(key);
		
		
		return CATEGORY_6;
	}
	
	
	
	public int takePreFlopAction(Bot pokerBot) {
		category = getCategory(pokerBot.getMyCards());
		
		int action = 0;
		
		switch(pokerBot.getPosition()){
		case Bot.EARLY_POSITION:
			action = 0;
			break;
		case Bot.MIDDLE_POSITION:
			action = 1;
			break;
		case Bot.LATE_POSITION:
			action = 2;
			break;
		default:
			action = 3;
			break;
		}
		
		// strategy
		Vector<Integer> strategy;
		if(pokerBot.isFirstBettingRound())
			strategy = preFlopStrategyA.get(category);
		else
			strategy = preFlopStrategyB.get(category);
		
	
		switch ( strategy.get(action) ) {
		case ACTION_CALL:
			return PokerStrategy.CALL;
		case ACTION_RAISE:
			return PokerStrategy.RAISE;
		case ACTION_OPEN:
			return PokerStrategy.CALL;
		default:
			return PokerStrategy.FOLD;
		}
	}

}
