package group5.bot.simple.strategy;

import group5.bot.Bot;

/**
 * Defines an interface that can be used with simple poker bots
 * to give them a more or less static strategy.
 * 
 * 
 * @author Arno
 */
public class PokerStrategy {

	/**
	 * Define constants that are send back to the client to
	 * tell it what action to take.
	 */
	public final static int CALL = 1;
	public final static int RAISE = 2;
	public final static int FOLD = 3;
	
	/**
	 * Define the different rounds
	 */
	public final static int PREFLOP = 1;
	public final static int FLOP = 2;
	public final static int TURN = 3;
	public final static int RIVER = 4;
	
	/**
	 * stores the strategies
	 */
	protected PreFlopStrategy preflopStrategy;
	protected FlopStrategy flopStrategy;
	protected TurnStrategy turnStrategy;
	protected RiverStrategy riverStrategy;
	
	/**
	 * stores the pokerBot 
	 */
	protected Bot pokerBot;
	 
	/**
	 * Initializes the strategy.
	 * @param pokerBot
	 */
	public PokerStrategy(Bot pokerBot){
		this.pokerBot = pokerBot;
	}
	
	
	/**
	 * @return The pokerBot
	 */
	public Bot getPokerBot(){
		return pokerBot;
	}
	
	/**
	 * 
	 * @param strategy The PreFlop Strategy
	 */
	public void registerPreFlopStrategy(PreFlopStrategy strategy){
		this.preflopStrategy = strategy;
	}
	
	/**
	 * 
	 * @param strategy The Flop Strategy
	 */
	public void registerFlopStrategy(FlopStrategy strategy){
		this.flopStrategy = strategy;
	}
	
	/**
	 * 
	 * @param strategy The Turn Strategy
	 */
	public void registerTurnStrategy(TurnStrategy strategy){
		this.turnStrategy = strategy;
	}
	
	/**
	 * 
	 * @param strategy The River Strategy
	 */
	public void registerRiverStrategy(RiverStrategy strategy){
		this.riverStrategy = strategy;
	}
	
	/**
	 * The bot can ask its fellow strategy object what action it should
	 * take.
	 * 
	 * @param round
	 * @return
	 */
	public int takeAction(int round){
		switch (round) {
		case PREFLOP:
			return preflopStrategy.takePreFlopAction(pokerBot);
		case FLOP:
			return flopStrategy.takeFlopAction(pokerBot);
		case TURN:
			return turnStrategy.takeTurnAction(pokerBot);
		case RIVER:
			return riverStrategy.takeRiverAction(pokerBot);
		default:
			System.out.println("unknown round!");
			return FOLD;
		}
	}
	
}
