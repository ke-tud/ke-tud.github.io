package group5.bot.simple.strategy;

import group5.bot.Bot;

public interface FlopStrategy {

	public int takeFlopAction(Bot pokerBot);
}
