package group5.bot.simple.strategy;

import group5.bot.Bot;

public interface RiverStrategy {

	public int takeRiverAction(Bot pokerBot);
}
