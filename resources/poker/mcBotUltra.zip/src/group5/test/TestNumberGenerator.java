package group5.test;

import junit.framework.TestCase;

import org.uncommons.maths.random.MersenneTwisterRNG;

public class TestNumberGenerator extends TestCase {

	
	public void testLala(){
		MersenneTwisterRNG rng = new MersenneTwisterRNG();
		
		for(int i = 0; i < 1000; i++)
			System.out.println(rng.nextInt(25));
	}
}
