package group5.test;

import group5.pokerGame.CardDeck;
import junit.framework.TestCase;


public class DeckTest extends TestCase {

	public void testGivenCards () {
		CardDeck deck = new CardDeck();
		
//		for (int i=0; i<52; i++)
//			System.out.println(deck.takeCard().toString());
	}
	
	public void testGetHandOutOf(){
		CardDeck deck = new CardDeck();
		
//		for(int i=0; i < 20; i++)
//			System.out.println(Card.arrayToString(deck.getHandOutOfTopPercent(0.05)));
	}
}
