package group5.test;

import junit.framework.TestCase;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.CardSet;
import com.stevebrecher.poker.HandEval;
import com.stevebrecher.poker.Card.Rank;
import com.stevebrecher.poker.Card.Suit;


public class TestBrecher extends TestCase {

	
	public void testBrecher(){
		Card c1 = new Card(Rank.TWO, Suit.CLUB);
		Card c2 = new Card(Rank.TWO, Suit.DIAMOND);
		Card c3 = new Card(Rank.TEN, Suit.HEART);
		Card c4 = new Card(Rank.SIX, Suit.SPADE);
		Card c5 = new Card(Rank.EIGHT, Suit.CLUB);
		
		CardSet set = new CardSet();
		set.add(c1);
		set.add(c2);
		set.add(c3);
		set.add(c4);
		set.add(c5);
		
		long encoded = HandEval.encode(set);
		int evaled = HandEval.hand5Eval(encoded);
		
		int category = (evaled & 0x0F000000)>>24;
		int rankTwoPair = (evaled & 0x00F00000)>>20;
		int rankEverythingElse = (evaled & 0x000F0000)>>16;
		
		System.out.println((encoded));
		System.out.println((evaled));
		System.out.println(category);
		
		
	}
}
