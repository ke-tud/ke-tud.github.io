/**
 * 
 */
package group5.test;

import group5.pokerGame.GeneralPokerStatistics;

import org.junit.Test;

/**
 * @author amittelbach
 *
 */
public class TestRankStatistics {

	/**
	 * Test method for {@link group5.pokerGame.GeneralPokerStatistics#getRandomHand(double)}.
	 */
	@Test
	public void testGetRandomHand() {
//		System.out.println( Card.arrayToString( RankStatistics.getInstance().getRandomHand(0.3) ) );
	}

	/**
	 * Test method for {@link group5.pokerGame.GeneralPokerStatistics#getScore(ca.ualberta.cs.poker.free.dynamics.Card[])}.
	 */
	@Test
	public void testGetScore() {
		System.out.println( GeneralPokerStatistics.getInstance().getScore( GeneralPokerStatistics.getInstance().getRandomHand(0.3, 4) ) );
	}

}
