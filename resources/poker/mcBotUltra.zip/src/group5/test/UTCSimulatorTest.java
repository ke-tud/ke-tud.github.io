package group5.test;

import group5.bot.mc.SimpleMcBot;
import group5.mc.UCTSimulator;
import group5.mc.expert.ModularExpert;
import group5.mc.expert.modules.CardGuesser;
import group5.mc.expert.modules.FlopActionGuesser;
import group5.mc.expert.modules.PreFlopActionGuesser;
import group5.mc.expert.modules.RiverActionGuesser;
import group5.mc.expert.modules.TurnActionGuesser;
import group5.pokerGame.GameState;
import group5.statistics.Statistics;
import group5.util.Performance;

import org.junit.Test;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.Card.Rank;
import com.stevebrecher.poker.Card.Suit;

public class UTCSimulatorTest {

	@Test
	public void testRun() {
		
		/* create statistics */
		Statistics statistics = new Statistics(new SimpleMcBot(0, null));
		
		/* create expert */
		ModularExpert expert = new ModularExpert(new SimpleMcBot(0, null), statistics);


		/*
		 * Card Guessing
		 */
		//Preflop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_PREFLOP, 200);
		//flop
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_FLOP, 200);
		//turn
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_TURN, 200);
		//river
		expert.addModule(new CardGuesser(), ModularExpert.GUESS_CARDS_MODULE, ModularExpert.ROUND_RIVER, 200);
		
		
		/*
		 * Action Guessing
		 */
		//preflop
		expert.addModule(new PreFlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_PREFLOP, 100);

		//flop
		expert.addModule(new FlopActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_FLOP, 1000);
		
		//turn
		expert.addModule(new TurnActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_TURN, 100);
		
		//river
		expert.addModule(new RiverActionGuesser(), ModularExpert.GUESS_ACTION_MODULE, ModularExpert.ROUND_RIVER, 100);
		
		
		GameState gs = new GameState();
		

		boolean[] activePlayers = {true, true, true, true, false, true};
		gs.setActivePlayers(activePlayers);
		
		int[] seatToPlayer = {0,1,2,3,4,5};
		gs.setSeatToPlayer(seatToPlayer);
		
		gs.setCurrentPlayer(5);
		Card[] cards = new Card[2];
		cards[0] = new Card(Rank.FOUR, Suit.CLUB);
		cards[1] = new Card(Rank.FIVE, Suit.CLUB);
		gs.setCardsForPlayer(cards, 5, true);
		
		gs.setRound(GameState.PREFLOP);
		
//		gs.setLastRaisePlayer(3);
		
		int[] inPot = { 1, 2, 2, 2, 0, 0 };
		gs.setInPot(inPot);
		
		gs.setNumberOfRaisesSeenThisRound(3);
		
		
		
		//sim
		UCTSimulator sim = new UCTSimulator(gs, expert);
		
		Performance.start("Simulation");
		double[] ev = sim.run();
		
		System.out.println("f: " + ev[0]);
		System.out.println("c: " + ev[1]);
		System.out.println("r: " + ev[2]);
		
		Performance.stop();
		
		
		// print dot file
//		UCTPlotter plot = new UCTPlotter(sim);
//		plot.createDotFile("tmp/plot.dot");
	}

}
