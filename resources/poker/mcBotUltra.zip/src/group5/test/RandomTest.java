package group5.test;

import group5.mc.Random;
import junit.framework.TestCase;

public class RandomTest extends TestCase {

	public void testSingleRandomNumber () {
		Random rnd = Random.getInstance();
		
		for (int i=0; i<52; i++)
			System.out.println(rnd.generateInt(52));
	}
}
