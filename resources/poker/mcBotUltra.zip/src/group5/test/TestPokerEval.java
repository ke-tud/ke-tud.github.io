package group5.test;

import group5.util.Performance;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TestPokerEval {

    public static String expert = "python /Users/amittelbach/Documents/TU-Darmstadt/Semester6/PokerChallenge/poker_challenge/python/test.py";
    public static int debug_level = 1;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
    	String out = "";
    	
    	
	  
		try {
     		
     		String line;
     		Performance.start("test poker eval");
     		
 		    for(int i = 0; i < 50; i++){
 		    	Process p = Runtime.getRuntime().exec(expert + " " + "AhKh:2h/4c/Js");
 	     		
 	     		BufferedReader input = null;
 	     		BufferedReader error = null;
 	     		
 		    	input = new BufferedReader(new InputStreamReader(p.getInputStream() ));
	     		error = new BufferedReader(new InputStreamReader(p.getErrorStream() ));
	     		
	     		while ((line = input.readLine()) != null) {     			
	     			out = out + line;
	     		}
	     		
	     		input.close();
	      		error.close();

	     		p.getInputStream().close();
	     		p.getErrorStream().close();
	      		
	     		p.destroy();
     		}
 		    
     		
 		    
 	     	Performance.stop();

    	}
    		
     	catch (Exception err) {
     		err.printStackTrace();
     	}     
	}
}
