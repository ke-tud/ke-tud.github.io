package group5.mc;

import group5.mc.expert.ExpertKnowledge;
import group5.pokerGame.CardDeck;
import group5.pokerGame.GameState;

import com.stevebrecher.poker.Card;

public class UCTNode{

	/**
	 * Stores how many times this gameState has been simulated
	 */
	private int numberOfSimulations = 0;
	
	/**
	 * Stores this node's level 
	 */
	private int level = 0;
	
	/**
	 * Stores the tree's height
	 */
	private static int treeHeight = 0;
	
	/**
	 * Stores the expectatinValues
	 */
	private double expectationValues[];
	
	/**
	 * Stores the active player (the one that is active at the beginning of this gameState)
	 */
	private int currentPlayerAtStartOfSimulation = 0;
	
	/**
	 * stores the active player
	 */
	
	/**
	 * Store the children
	 */
	private UCTNode childFold;
	private UCTNode childRaise;
	private UCTNode childCall;
	
	/**
	 * Store the parent
	 */
	private UCTNode parent;

	/**
	 * Store this nodes gameState
	 */
	private GameState gameState;

	/**
	 * Stores the expert
	 */
	private ExpertKnowledge expert;

	/**
	 * Stores a reference to the simulator object
	 */
	private UCTSimulator simulator;
	
	
	private boolean finished = false;

	
	/**
	 * initialize node
	 * @param GameState
	 */
	public UCTNode(GameState gameState, ExpertKnowledge expert, UCTSimulator simulator) {
		this.gameState = gameState;
		this.expert = expert;
		this.simulator = simulator;
	}
	
	public int getCurrentPlayerAtStartOfSimulation(){
		return currentPlayerAtStartOfSimulation;
	}

	/**
	 * 
	 */
	public GameState getGameState(){
		return gameState;
	}
	
	/**
	 * @return The nodes value
	 */
	public double getValue(){
		return this.expectationValues[currentPlayerAtStartOfSimulation] / (double) numberOfSimulations;
	}
	
	public double[] getExpectationValues(){
		return expectationValues;
	}
	
	public double[] getNormalizedValues(){
		double[] normalized = this.expectationValues.clone();
		for(int i = 0; i < normalized.length; i++)
			normalized[i] = normalized[i] / (double) numberOfSimulations;
		
		return normalized;
	}
	
	/**
	 * 
	 * @return The parent node
	 */
	public UCTNode getParent(){
		return parent;
	}
	
	/**
	 * 
	 * @return The child for call action
	 */
	public UCTNode getChildCall() {
		return childCall;
	}
	
	/**
	 * 
	 * @param childCall 
	 */
	public void setChildCall(UCTNode childCall) {
		this.childCall = childCall;
	}
	
	/**
	 * 
	 * @return The child for fold action
	 */
	public UCTNode getChildFold() {
		return childFold;
	}
	
	/**
	 * 
	 * @param childFold
	 */
	public void setChildFold(UCTNode childFold) {
		this.childFold = childFold;
	}
	
	/**
	 * 
	 * @return The child for raise action
	 */
	public UCTNode getChildRaise() {
		return childRaise;
	}
	
	/**
	 * 
	 * @param childRaise 
	 */
	public void setChildRaise(UCTNode childRaise) {
		this.childRaise = childRaise;
	}
	
	/**
	 * 
	 * @return The number of times this game state has been simulated
	 */
	public int getNumberOfSimulations() {
		return numberOfSimulations;
	}
	
	/**
	 * 
	 * @param numberOfSimulations The number of times this game state has been simulated
	 */
	public void setNumberOfSimulations(int numberOfSimulations) {
		this.numberOfSimulations = numberOfSimulations;
	}
	
	/**
	 * 
	 * @param int level
	 */
	private void setLevel(int level){
		this.level = level;
	}
	
	public int getLevel(){
		return level;
	}
	
	public UCTNode getRoot(){
		return simulator.getRoot();
	}
	
	/**
	 * @param UCTNode the parent node
	 */
	public void setParent(UCTNode parent){
		this.parent = parent;
		
		// current player
		currentPlayerAtStartOfSimulation = parent.getGameState().getCurrentPlayer();
		// tell expert
		expert.setPlayerThisSimulationIsFor(currentPlayerAtStartOfSimulation);
		
		// level
		setLevel(parent.getLevel() + 1);
		
		// update height
		if(treeHeight < getLevel())
			treeHeight = getLevel();
	}
	
	/**
	 * @return Whether this node is at the leaf node
	 */
	public boolean isLeaf(){
		return null == childCall || finished;
	}
	
	/**
	 * @return Whether this node is the root node
	 */
	public boolean isRoot(){
		return null == parent;
	}
	
	/**
	 * 
	 */
	public void setIsFinished(){
		finished = true;
	}
	
	public boolean isFinished(){
		return finished;
	}

	
	/**
	 * Expands the node. Childnodes are created
	 *
	 */
	public void expand() {
		GameState callGS = gameState.clone();
		callGS.playerCalls();
		childCall = new UCTNode(callGS, expert, simulator);
		childCall.setParent(this);
		if(callGS.isGameFinished())
			childCall.setIsFinished();
		if(callGS.isBettingRoundOver())
			callGS.gotoNextRound();
		
		if(gameState.canRaise()){
			GameState raiseGS = gameState.clone();
			raiseGS.playerRaises();
			childRaise = new UCTNode(raiseGS, expert, simulator);
			childRaise.setParent(this);
			if(raiseGS.isGameFinished())
				childRaise.setIsFinished();
			if(raiseGS.isBettingRoundOver())
				raiseGS.gotoNextRound();
		}
		
		// do not simulate fold for ourself
		if(gameState.getCurrentPlayer() != simulator.getPlayerThisSimulationIsFor()){
			GameState foldGS = gameState.clone();
			foldGS.playerFolds();
			childFold = new UCTNode(foldGS, expert, simulator);
			childFold.setParent(this);
			if(foldGS.isGameFinished())
				childFold.setIsFinished();
			if(foldGS.isBettingRoundOver())
				foldGS.gotoNextRound();
		}
	}
	
	
	/**
	 * Simulates the children
	 */
	public void simulateChildren() {
		if(null != childCall)
			childCall.simulate();
		
		if(null != childRaise)
			childRaise.simulate();
		
		if(null != childFold)
			childFold.simulate();
	}

	/**
	 * 
	 * Simulate the current node
	 */
	public void simulate() {
		GameState gs = gameState.clone();
		
		guessCards(gs);
		while(!gs.isGameFinished()){
			while (!gs.isBettingRoundOver())
				expert.guessPlayersNextAction(gs.getCurrentPlayer(), gs);
			
			gs.gotoNextRound();
			generateNecessaryCards(gs);
		}
		
		double[] EV = getExpectationValues(gs);

		/* update value */
		updateValue(EV);
	}
	
	

	private void updateValue(double[] EV) {
		numberOfSimulations++;

		if(null == this.expectationValues){
			this.expectationValues = EV;
		} else {
			for(int i = 0; i < EV.length; i++){
				this.expectationValues[i] = this.expectationValues[i] + EV[i];
			}
		}
		
		if(! this.isRoot())
			parent.updateValue(getNormalizedValues());
	}
	
	/**
	 * 
	 * @return The tree's height
	 */
	public int getTreeHeight(){
		return treeHeight;
	}

	/**
	 * 
	 * @param node
	 */
	private void generateNecessaryCards(GameState myGameState) {
		CardDeck currentDeck = myGameState.getDeck();

		switch (myGameState.getRound()) {
		case GameState.FLOP:
			myGameState.addCardToBoard(currentDeck.takeCard());
			myGameState.addCardToBoard(currentDeck.takeCard());
			myGameState.addCardToBoard(currentDeck.takeCard());
			break;
		case GameState.TURN:
			myGameState.addCardToBoard(currentDeck.takeCard());
			break;
		case GameState.RIVER:
			myGameState.addCardToBoard(currentDeck.takeCard());
			break;
		}
	}

	private void guessCards(GameState myGameState) {
		// are we in some round and the cards are not drawn?
		CardDeck currentDeck = myGameState.getDeck();
		Card[] board = myGameState.getBoard();
		if(myGameState.getRound() == GameState.FLOP ){
			for(int i = 0; i < 3; i++ )
				if(null == board[i])
					myGameState.addCardToBoard(currentDeck.takeCard());
		} else if(myGameState.getRound() == GameState.TURN ){
			for(int i = 0; i < 4; i++ )
				if(null == board[i])
					myGameState.addCardToBoard(currentDeck.takeCard());
		} else if(myGameState.getRound() == GameState.RIVER ){
			for(int i = 0; i < 5; i++ )
				if(null == board[i])
					myGameState.addCardToBoard(currentDeck.takeCard());
		}

		// now guess player's cards
		for (int player = 0; player < myGameState.getNumberOfPlayers(); player++)
			if(! myGameState.hasCards(player))
				expert.guessCardsForPlayer(player, myGameState);
	}


	/**
	 * 
	 * @param myGameState
	 * @return
	 */
	private double[] getExpectationValues(GameState myGameState) {
		double[] EV = new double[myGameState.getNumberOfPlayers()];
		
		/* get winners */
		boolean[] winners = myGameState.determineWinners();
		int numberOfWinners = 0;
		for (boolean winner: winners)
			if(winner)
				numberOfWinners++;

		/* calculate vector */
		for(int player = 0; player < myGameState.getNumberOfPlayers(); player++ ){
			//int input = (myGameState.getInPotForPlayer(player) - gameState.getInPotForPlayer(player));
			int input = (myGameState.getInPotForPlayer(player) - getRoot().getGameState().getInPotForPlayer(player));

	
			// is the current player still active?
			if (!myGameState.isPlayerActive(player)){ 
				EV[player] = -1 * input;
				continue;
			}
			
			if(winners[player]) {
				if( numberOfWinners == 1)
					EV[player] = myGameState.getPot() - input;
				else
					EV[player] = (myGameState.getPot() - input) / (double) numberOfWinners;
			}
			else
				EV[player] = -1 * input;
		}

		return EV;
	}
	
	
}
