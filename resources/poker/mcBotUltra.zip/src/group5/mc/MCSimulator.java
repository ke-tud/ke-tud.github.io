package group5.mc;

import group5.mc.expert.ExpertKnowledge;
import group5.mc.expert.SelfExpert;
import group5.pokerGame.CardDeck;
import group5.pokerGame.GameState;

public class MCSimulator {
	
	public static final int CALL = 1;
	public static final int RAISE = 2;
	
	private GameState gameState;
	
	private ExpertKnowledge expert;
	
	private SelfExpert ourExpert;
	
	private int me;
	
	public MCSimulator(GameState gameState, ExpertKnowledge expert, SelfExpert ourExpert) {
		this.gameState = gameState;
		this.expert = expert;
		this.ourExpert = ourExpert;
		
		me = gameState.getCurrentPlayer();
	}
	
	public double run (int numberOfSimulations, int action) {
		int EV = 0;
		
		for( int i = 0; i< numberOfSimulations; i++){
			GameState myGameState = (GameState) gameState.clone();
			
			guessCards(myGameState);
			
			if (CALL == action)
				myGameState.playerCalls();
			else
				myGameState.playerRaises();
			
			while(!myGameState.isGameFinished()){
				while (!myGameState.isBettingRoundOver())
					//if (myGameState.getCurrentPlayer() != me)
						expert.guessPlayersNextAction(myGameState.getCurrentPlayer(), myGameState);
					//else
						//ourExpert.guessOurNextAction(myGameState.getCurrentPlayer(), myGameState);
				
				myGameState.gotoNextRound();
				generateNecessaryCards(myGameState);
			}
			
			EV += evaluateGameResult(myGameState);
		}		

		return EV / (double)numberOfSimulations;
	}
	
	/**
	 * After a simulation ends the result must be evaluated.
	 * 
	 * @param myGameState the current game state.
	 * @return The amount won or lost.
	 */
	private double evaluateGameResult(GameState myGameState) {
		int me = gameState.getCurrentPlayer();
		
		int ourInput = (myGameState.getInPotForPlayer(me) - gameState.getInPotForPlayer(me));
		
		if (!myGameState.isPlayerActive(me)) 
			return -1 * ourInput;
		
		boolean[] winners = myGameState.determineWinners();
		
		if(winners[me]) {
			int numberOfWinners = 0;
			for (boolean winner: winners)
				if(winner)
					numberOfWinners++;
			
			if( numberOfWinners == 1)
//				return myGameState.getPot() - gameState.getPot() - ourInput;
				return myGameState.getPot() - ourInput;
			else
//				return (myGameState.getPot() - gameState.getPot() - ourInput) / numberOfWinners;
				return (myGameState.getPot() - ourInput) / (double) numberOfWinners;
		}
		else
			return -1 * ourInput;
		
	}

	/**
	 * Coresponding to the game round new random cards will be added to the board.
	 * 
	 * @param myGameState The actual game state.
	 */
	private void generateNecessaryCards(GameState myGameState) {
		CardDeck currentDeck = myGameState.getDeck();
		
		switch(myGameState.getRound()) {
		case GameState.FLOP:
			myGameState.addCardToBoard(currentDeck.takeCard());
			myGameState.addCardToBoard(currentDeck.takeCard());
			myGameState.addCardToBoard(currentDeck.takeCard());
			break;
		case GameState.TURN:
			myGameState.addCardToBoard(currentDeck.takeCard());
			break;
		case GameState.RIVER:
			myGameState.addCardToBoard(currentDeck.takeCard());
			break;
		}
	}

	private void guessCards(GameState myGameState) {
		for (int player = 0; player < myGameState.getNumberOfPlayers(); player++) 
			if(!myGameState.hasCards(player))
				expert.guessCardsForPlayer(player, myGameState);
	}

}
