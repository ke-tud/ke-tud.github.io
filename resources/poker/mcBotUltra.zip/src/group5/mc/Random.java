package group5.mc;

import org.uncommons.maths.random.MersenneTwisterRNG;

public class Random {

	private static Random instance;
	private MersenneTwisterRNG secRandom;
	
	protected Random () {
//		try {
//			secRandom = SecureRandom.getInstance("SHA1PRNG");
//		} catch (NoSuchAlgorithmException e) {
//			e.printStackTrace();
//		}
		secRandom = new MersenneTwisterRNG();
	}
	
	public static Random getInstance() {
		if (null == instance)
			instance = new Random();
		
		return instance;
	}
	
	
	public double generateRandomNumber() {
		return secRandom.nextDouble();
	}
	
	public int generateInt (int value) {
		return secRandom.nextInt(value);
//		double [] array = new double[value];
//		
//		double doubleValue = 1/(double)value;
//		for (int i=0; i < value; i++) {
//			array [i] = doubleValue;
//		}
//		
//		return generateAction(array);
	}
	
	public int generateAction(double[] probabilities) {
		double randomValue = this.generateRandomNumber();
		
		double sumValue = 0.0;
		for (int i=0; i< probabilities.length; i++) {
			sumValue += probabilities[i];
			
			if (sumValue > randomValue)
				return i;
		}
		
		return probabilities.length - 1;
	}

	/**
	 * 
	 * @param low
	 * @param high
	 * @return a random integer between low and high
	 */
	public int generateIntBetween(int low, int high) {
		double [] array = new double[high];
		int difference = high - low;
		
		double doubleValue = 1/(double)difference;
		for (int i=0; i < low; i++)
			array [i] = 0;
		for (int i=low; i < high; i++)
			array [i] = doubleValue;
		
		return generateAction(array);
	}
	
	
}
