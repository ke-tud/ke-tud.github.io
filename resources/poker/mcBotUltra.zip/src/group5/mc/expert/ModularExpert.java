package group5.mc.expert;

import group5.bot.Bot;
import group5.mc.expert.modules.ExpertKnowledgeModule;
import group5.pokerGame.GameState;
import group5.statistics.Statistics;

import java.util.LinkedList;
import java.util.List;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * This class provides a modular approach to the expert knowledge interface
 * @author amittelbach
 *
 */
public class ModularExpert implements ExpertKnowledge {

	public static final int GUESS_CARDS_MODULE = 0;
	public static final int GUESS_ACTION_MODULE = 1;
	
	public static final int ROUND_PREFLOP = 0;
	public static final int ROUND_FLOP = 1;
	public static final int ROUND_TURN = 2;
	public static final int ROUND_RIVER = 3;
	
	/**
	 * store the statistics object
	 */
	private Statistics statistics;
	
	/**
	 * Store the bot
	 */
	private Bot bot;
	
	/**
	 * store the list of modules
	 */
	private List<ExpertKnowledgeModule> modulesForCardGuessingPreFlop = new LinkedList<ExpertKnowledgeModule>();
	private List<ExpertKnowledgeModule> modulesForCardGuessingFlop = new LinkedList<ExpertKnowledgeModule>();
	private List<ExpertKnowledgeModule> modulesForCardGuessingTurn = new LinkedList<ExpertKnowledgeModule>();
	private List<ExpertKnowledgeModule> modulesForCardGuessingRiver = new LinkedList<ExpertKnowledgeModule>();

	/**
	 * store the list of modules (action)
	 */
	private List<ExpertKnowledgeModule> modulesForActionGuessingPreFlop = new LinkedList<ExpertKnowledgeModule>();
	private List<ExpertKnowledgeModule> modulesForActionGuessingFlop = new LinkedList<ExpertKnowledgeModule>();
	private List<ExpertKnowledgeModule> modulesForActionGuessingTurn = new LinkedList<ExpertKnowledgeModule>();
	private List<ExpertKnowledgeModule> modulesForActionGuessingRiver = new LinkedList<ExpertKnowledgeModule>();
	
	/**
	 * stores the module that is currently in use for card guessing
	 */
	private ExpertKnowledgeModule currentModuleForCardGuessingPreFlop = null;
	private ExpertKnowledgeModule currentModuleForCardGuessingFlop = null;
	private ExpertKnowledgeModule currentModuleForCardGuessingTurn = null;
	private ExpertKnowledgeModule currentModuleForCardGuessingRiver = null;
	
	/**
	 * stores the module that is currently in use for action guessing
	 */
	private ExpertKnowledgeModule currentModuleForActionGuessingPreFlop = null;
	private ExpertKnowledgeModule currentModuleForActionGuessingFlop = null;
	private ExpertKnowledgeModule currentModuleForActionGuessingTurn = null;
	private ExpertKnowledgeModule currentModuleForActionGuessingRiver = null;
	
	/**
	 * stores the number of hands that we have played
	 */
	private int numberOfHandsPlayed = 0;
	
	/**
	 * 
	 * @param bot
	 */
	public ModularExpert(Bot bot, Statistics statistics){
		this.bot = bot;
		this.statistics = statistics;
	}
	
	/**
	 * 
	 * @param clientCards
	 */
	public void newHandStarted(Card[] clientCards){
		// pass information on to statistics
		statistics.newHandStarted(clientCards);
		
		// increment the number of hands we have played
		numberOfHandsPlayed++;
		
		// check if we have to use a new module for card guessing
		try {
			if(currentModuleForCardGuessingPreFlop.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForCardGuessingPreFlop = modulesForCardGuessingPreFlop.get(modulesForCardGuessingPreFlop.indexOf(currentModuleForCardGuessingPreFlop) + 1);
			}
		} catch(IndexOutOfBoundsException e){}
		try {
			if(currentModuleForCardGuessingFlop.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForCardGuessingFlop = modulesForCardGuessingFlop.get(modulesForCardGuessingFlop.indexOf(modulesForCardGuessingFlop) + 1);
			}
		} catch(IndexOutOfBoundsException e){}
		try {
			if(currentModuleForCardGuessingTurn.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForCardGuessingTurn = modulesForCardGuessingTurn.get(modulesForCardGuessingTurn.indexOf(currentModuleForCardGuessingTurn) + 1);
			}
		} catch(IndexOutOfBoundsException e){}
		try {
			if(currentModuleForCardGuessingRiver.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForCardGuessingRiver = modulesForCardGuessingRiver.get(modulesForCardGuessingRiver.indexOf(currentModuleForCardGuessingRiver) + 1);
			}
		} catch(IndexOutOfBoundsException e){}

		
		// check if we have to use a new module for action  guessing
		try {
			if(currentModuleForActionGuessingPreFlop.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForActionGuessingPreFlop = modulesForActionGuessingPreFlop.get(modulesForActionGuessingPreFlop.indexOf(currentModuleForActionGuessingPreFlop) + 1);
			}
		} catch(IndexOutOfBoundsException e){}
		try {
			if(currentModuleForActionGuessingFlop.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForActionGuessingFlop = modulesForActionGuessingFlop.get(modulesForActionGuessingFlop.indexOf(currentModuleForActionGuessingFlop) + 1);
			}
		} catch(IndexOutOfBoundsException e){}
		try {
			if(currentModuleForActionGuessingTurn.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForActionGuessingTurn = modulesForActionGuessingTurn.get(modulesForActionGuessingTurn.indexOf(currentModuleForActionGuessingTurn) + 1);
			}
		} catch(IndexOutOfBoundsException e){}
		try {
			if(currentModuleForActionGuessingRiver.getNumberOfHands() < numberOfHandsPlayed ){
				currentModuleForActionGuessingRiver = modulesForActionGuessingRiver.get(modulesForActionGuessingRiver.indexOf(currentModuleForActionGuessingRiver) + 1);
			}
		} catch(IndexOutOfBoundsException e){}

		
		// tell modules that are currently in use that a new hand started
		for(ExpertKnowledgeModule module : modulesForActionGuessingPreFlop)
			module.newHandStarted();
		for(ExpertKnowledgeModule module : modulesForActionGuessingFlop)
			module.newHandStarted();
		for(ExpertKnowledgeModule module : modulesForActionGuessingTurn)
			module.newHandStarted();
		for(ExpertKnowledgeModule module : modulesForActionGuessingRiver)
			module.newHandStarted();
		
		
		for(ExpertKnowledgeModule module : modulesForCardGuessingPreFlop)
			module.newHandStarted();
		for(ExpertKnowledgeModule module : modulesForCardGuessingFlop)
			module.newHandStarted();
		for(ExpertKnowledgeModule module : modulesForCardGuessingTurn)
			module.newHandStarted();
		for(ExpertKnowledgeModule module : modulesForCardGuessingRiver)
			module.newHandStarted();
	}
	
	/**
	 * 
	 * @param lastAction
	 * @param lastSeat
	 * @param handOver
	 * @param showdown
	 */
	public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown ){
		statistics.actionPerformed(lastAction, lastSeat, handOver, showdown);
		
		// tell modules
		for(ExpertKnowledgeModule module : modulesForActionGuessingPreFlop)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		for(ExpertKnowledgeModule module : modulesForActionGuessingFlop)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		for(ExpertKnowledgeModule module : modulesForActionGuessingTurn)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		for(ExpertKnowledgeModule module : modulesForActionGuessingRiver)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		
		
		for(ExpertKnowledgeModule module : modulesForCardGuessingPreFlop)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		for(ExpertKnowledgeModule module : modulesForCardGuessingFlop)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		for(ExpertKnowledgeModule module : modulesForCardGuessingTurn)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		for(ExpertKnowledgeModule module : modulesForCardGuessingRiver)
			module.actionPerformed(lastAction, lastSeat, handOver, showdown);
		
	}
	
	/**
	 * 
	 * @param module
	 * @param type
	 * @param numberOfHands
	 */
	public void addModule(ExpertKnowledgeModule module, int type, int round, int numberOfHands){
		switch(type){
		case GUESS_ACTION_MODULE:
			addActionModule(module, round);
			break;
		case GUESS_CARDS_MODULE:
			addCardModule(module, round);
			break;
		}
		
		// give module access to statistics
		module.setStatistcs(statistics);
		module.setBot(bot);
		module.setNumberOfHands(numberOfHands);
		
		// initialize module
		module.initialize();
	}
	
	private void addCardModule(ExpertKnowledgeModule module, int round) {
		switch(round){
		case ROUND_PREFLOP:
			modulesForCardGuessingPreFlop.add(module);
			if(null == currentModuleForCardGuessingPreFlop)
				currentModuleForCardGuessingPreFlop = module;
			break;
		case ROUND_FLOP:
			modulesForCardGuessingFlop.add(module);
			if(null == currentModuleForCardGuessingFlop)
				currentModuleForCardGuessingFlop = module;
			break;
		case ROUND_TURN:
			modulesForCardGuessingTurn.add(module);
			if(null == currentModuleForCardGuessingTurn)
				currentModuleForCardGuessingTurn = module;
			break;
		case ROUND_RIVER:
			modulesForCardGuessingRiver.add(module);
			if(null == currentModuleForCardGuessingRiver)
				currentModuleForCardGuessingRiver = module;
			break;
		}
		
	}

	private void addActionModule(ExpertKnowledgeModule module, int round) {
		switch(round){
		case ROUND_PREFLOP:
			modulesForActionGuessingPreFlop.add(module);
			if(null == currentModuleForActionGuessingPreFlop)
				currentModuleForActionGuessingPreFlop = module;
			break;
		case ROUND_FLOP:
			modulesForActionGuessingFlop.add(module);
			if(null == currentModuleForActionGuessingFlop)
				currentModuleForActionGuessingFlop = module;
			break;
		case ROUND_TURN:
			modulesForActionGuessingTurn.add(module);
			if(null == currentModuleForActionGuessingTurn)
				currentModuleForActionGuessingTurn = module;
			break;
		case ROUND_RIVER:
			modulesForActionGuessingRiver.add(module);
			if(null == currentModuleForActionGuessingRiver)
				currentModuleForActionGuessingRiver = module;
			break;
		}
		
	}

	/**
	 * 
	 */
	public void guessCardsForPlayer(int player, GameState gameState) {
		switch(gameState.getRound()){
		case GameState.PREFLOP:
			currentModuleForCardGuessingPreFlop.guessCardsForPlayer(player, gameState);
			break;
		case GameState.FLOP:
			currentModuleForCardGuessingFlop.guessCardsForPlayer(player, gameState);
			break;
		case GameState.TURN:
			currentModuleForCardGuessingTurn.guessCardsForPlayer(player, gameState);
			break;
		case GameState.RIVER:
			currentModuleForCardGuessingRiver.guessCardsForPlayer(player, gameState);
			break;
		}
	}

	/**
	 * 
	 */
	public void guessPlayersNextAction(int player, GameState gameState) {
		switch(gameState.getRound()){
		case GameState.PREFLOP:
			currentModuleForActionGuessingPreFlop.guessPlayersNextAction(player, gameState);
			break;
		case GameState.FLOP:
			currentModuleForActionGuessingFlop.guessPlayersNextAction(player, gameState);
			break;
		case GameState.TURN:
			currentModuleForActionGuessingTurn.guessPlayersNextAction(player, gameState);
			break;
		case GameState.RIVER:
			currentModuleForActionGuessingRiver.guessPlayersNextAction(player, gameState);
			break;
		}
	}

	public void uctSimulationIsAboutToStart(GameState rootGameState) {
		/* tell all currently active modules that a simulation is about to be started */
		currentModuleForActionGuessingPreFlop.uctSimulationIsAboutToStart(rootGameState);
		currentModuleForActionGuessingFlop.uctSimulationIsAboutToStart(rootGameState);
		currentModuleForActionGuessingTurn.uctSimulationIsAboutToStart(rootGameState);
		currentModuleForActionGuessingRiver.uctSimulationIsAboutToStart(rootGameState);
		
		currentModuleForCardGuessingPreFlop.uctSimulationIsAboutToStart(rootGameState);
		currentModuleForCardGuessingFlop.uctSimulationIsAboutToStart(rootGameState);
		currentModuleForCardGuessingTurn.uctSimulationIsAboutToStart(rootGameState);
		currentModuleForCardGuessingRiver.uctSimulationIsAboutToStart(rootGameState);
	}

	public void setPlayerThisSimulationIsFor(int player) {
		/* tell all currently active modules who the simulation is for */
		currentModuleForActionGuessingPreFlop.setPlayerThisSimulationIsFor(player);
		currentModuleForActionGuessingFlop.setPlayerThisSimulationIsFor(player);
		currentModuleForActionGuessingTurn.setPlayerThisSimulationIsFor(player);
		currentModuleForActionGuessingRiver.setPlayerThisSimulationIsFor(player);
		
		currentModuleForCardGuessingPreFlop.setPlayerThisSimulationIsFor(player);
		currentModuleForCardGuessingFlop.setPlayerThisSimulationIsFor(player);
		currentModuleForCardGuessingTurn.setPlayerThisSimulationIsFor(player);
		currentModuleForCardGuessingRiver.setPlayerThisSimulationIsFor(player);
	}

}
