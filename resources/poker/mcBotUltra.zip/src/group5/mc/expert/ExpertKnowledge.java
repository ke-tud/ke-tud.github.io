package group5.mc.expert;

import group5.pokerGame.GameState;

public interface ExpertKnowledge {

	/**
	 * Sets the player this simulation is for
	 * 
	 * @param int player
	 */
	public void setPlayerThisSimulationIsFor(int player);
	
	/**
	 * Sets cards for player.
	 * 
	 * @param player The actual player.
	 * @param gameState The stored game state
	 */
	public void guessCardsForPlayer (int player, GameState gameState);
	
	/**
	 * Tries to guess the next action a player will probably choose.
	 * 
	 * @param player
	 * @param gameState
	 */
	public void guessPlayersNextAction (int player, GameState gameState);

	/**
	 * We are told by the framework that a new simulation is about to be started.
	 * 
	 * <p>
	 *  This information can for example be used to precalculate information to speed up
	 *  the simulation since the crucial parts are still the experts knowledge!
	 * </p>
	 * @param rootGameState 
	 */
	public void uctSimulationIsAboutToStart(GameState rootGameState);
	
}
