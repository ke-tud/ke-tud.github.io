package group5.mc.expert;

import group5.mc.Random;
import group5.pokerGame.GameState;

public class SimpleSelfExpert implements SelfExpert {

	public void guessOurNextAction(int player, GameState gameState) {
		double[] probabilities = {0.53, 0.33, 0.33};
		
		switch (Random.getInstance().generateAction(probabilities)) {
		case 0:
			gameState.playerCalls();
			break;
		case 1:
			gameState.playerRaises();
			break;
		case 2:
			gameState.playerFolds();
			break;
		}

	}

}
