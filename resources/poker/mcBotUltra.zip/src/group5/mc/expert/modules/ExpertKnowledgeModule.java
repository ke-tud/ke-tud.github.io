package group5.mc.expert.modules;

import group5.bot.Bot;
import group5.dynamics.ClientRingDynamics;
import group5.pokerGame.GameState;
import group5.statistics.Statistics;


public abstract class ExpertKnowledgeModule {

	/**
	 * Stores the statistics object
	 */
	protected Statistics statistics;
	
	/**
	 * Store the bot 
	 */
	protected Bot bot;
	
	/**
	 * Store a dynamics
	 */
	protected ClientRingDynamics dynamics;
	
	/**
	 * Store the number of hands for that we should use this module
	 */
	private int useForHands = 0;

	private int playerThisSimulationIsFor;
	
	/**
	 * Stores the statistics object
	 * @param stat
	 */
	public void setStatistcs(Statistics statistics){
		this.statistics = statistics;
	}
	
	/**
	 * @return The statistics object
	 */
	public Statistics getStatistics(){
		return statistics;
	}
	
	/**
	 * 
	 * @param hands
	 */
	public void setNumberOfHands(int hands){
		this.useForHands = hands;
	}
	
	public int getNumberOfHands(){
		return this.useForHands;
	}
	
	/**
	 * @param bot 
	 */
	public void setBot(Bot bot){
		this.bot = bot;
		this.dynamics = bot.getDynamics();
	}
	/**
	 * This method is called after the module was added
	 */
	public void initialize(){
		
	}
	
	/**
	 * This method is called if a new hand started
	 */
	public void newHandStarted(){
		
	}
	
	public void actionPerformed(char lastAction, int lastSeat, boolean handOver, boolean showdown ){
		
	}
	
	/**
	 * Sets cards for player.
	 * 
	 * @param player The actual player.
	 * @param gameState The stored game state
	 */
	public void guessCardsForPlayer (int player, GameState gameState){
		gameState.setCardsForPlayer(gameState.getDeck().getRandomHand(true), player);
	}
	
	public void guessPlayersNextAction (int player, GameState gameState){
		gameState.playerFolds();
	}

	/**
	 * We are told by the framework that a new simulation is about to be started.
	 * 
	 * <p>
	 *  This information can for example be used to precalculate information to speed up
	 *  the simulation since the crucial parts are still the experts knowledge!
	 * </p>
	 */
	public void uctSimulationIsAboutToStart(GameState rootGameState) {		
	}
	
	/**
	 * Sets the player this simulation is for
	 * 
	 * @param int player
	 */
	public void setPlayerThisSimulationIsFor(int player){
		this.playerThisSimulationIsFor = player;
	}
	
	/**
	 * 
	 * @return The player this simulation is for
	 */
	public int getPlayerThisSimulationIsFor(){
		return this.playerThisSimulationIsFor;
	}
}
