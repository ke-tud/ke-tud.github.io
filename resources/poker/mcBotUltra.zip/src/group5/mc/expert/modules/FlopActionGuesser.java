package group5.mc.expert.modules;

import group5.mc.Random;
import group5.pokerGame.GameState;
import group5.pokerGame.GeneralPokerStatistics;

public class FlopActionGuesser extends ExpertKnowledgeModule {

	public static final double FACTOR_HANDSTRENGTH = 1.6;
	public static final double FACTOR_NUMBER_OF_PLAYERS_RAISED = 2;
	public static final double FACTOR_POSITION = 0.05;
	
	public static final int LEARNING_PERIOD = 50;
	
	public void guessPlayersNextAction (int player, GameState gameState){
		double handStrength = GeneralPokerStatistics.getInstance().getFiveCardScore(gameState.getAllCardsForPlayer(player));
		handStrength = 1 - ( (double) 1 / Math.pow(3, handStrength) );
		
		double hs = Math.pow(FACTOR_HANDSTRENGTH, handStrength) - 1;

		int numberOfRaises = gameState.getNumberOfRaisesSeenThisRound() - gameState.getRaisesByPlayer(player);
		double rs = (Math.log( Math.min(1, numberOfRaises ) ) / Math.log(FACTOR_NUMBER_OF_PLAYERS_RAISED));

		double ps = FACTOR_POSITION * (gameState.getNumberOfUnseenActions(player));
		
		//double looseTightIndex = statistics.getNumberOfHandsPlayed() < 100 ? 0 : 0.15 - (statistics.getFractionPlayerCalledFlop(player) + statistics.getFractionPlayerRaisedFlop(player));
		double raiseIndex = statistics.getNumberOfHandsPlayed() < LEARNING_PERIOD ? 0 : 0.075 - statistics.getFractionPlayerRaisedPreFlop(player);
		double callIndex = statistics.getNumberOfHandsPlayed() < LEARNING_PERIOD ? 0 : 0.075 - statistics.getFractionPlayerCalledPreFlop(player);
		
		double potOddsFactor = 0.25 - gameState.getPotOddsForPlayer(player);
		
		double raise = hs + potOddsFactor - rs - ps - raiseIndex;
		double call = hs + potOddsFactor - rs - (0.75)*ps - callIndex;
		
		// Bluff Factor
		if(Random.getInstance().generateRandomNumber() < statistics.getPercentagePlayerBluffs(player))
			raise += 1;
		
//		System.out.println("flop: " + BrecherAlbertaConverter.getInstance().getCardset(gameState.getAllCardsForPlayer(player)) + " -> raise: " + raise + ", -> call: " + call);		
		
		double[] probTriple = {raise, call, 1 - raise - call};
		switch (Random.getInstance().generateAction(probTriple)) {
		case 0:
			gameState.playerRaises();
			break;
		case 1:
			gameState.playerCalls();
			break;
		default:
			if(this.getPlayerThisSimulationIsFor() == player) // && Random.getInstance().generateRandomNumber() < 0.8)
				gameState.playerCalls();
			else
				gameState.playerFolds();

			break;
		}
	}
}
