package group5.mc.expert.modules;

import group5.mc.Random;
import group5.pokerGame.CardDeck;
import group5.pokerGame.GameState;
import group5.pokerGame.GeneralPokerStatistics;
import group5.util.Utils;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.Card.Rank;

public class CardGuesser extends ExpertKnowledgeModule {

	/**
	 * Stores the percentage that we give a player on the preflop
	 */
	private double[] percentageForPreflopGuessing = new double[6];
	
	/**
	 * Stores the number of hands that a player can choose from 
	 */
	private int[] numberOfCardsToChooseFromForFlop = new int[6];
	private int[] numberOfCardsToChooseFromForTurn = new int[6];
	private int[] numberOfCardsToChooseFromForRiver = new int[6];
	
	/**
	 * Stores the percentage of games a player played
	 */
	private double[] percentageOfHandsPlayedByPlayer = new double[6];
	
	private double postFlopNoiseFactor = 0.3;
	
	private double aRandomNumber = 0.4;
	
	/**
	 * Store root game state
	 */
	private GameState rootGameState;
	
	@Override
	public void uctSimulationIsAboutToStart(GameState rootGameState){
		this.rootGameState = rootGameState;
		
		/* determine the percentage for pre flop card guessing */
		precalculatePercentageForPreFlopGuessing(rootGameState);
		
		/* determine the number of cards a player may choose from */
		precalculateNumberOfCardsForPostFlopGuessing(rootGameState);
		
		/* determine the percentage of games played by player */
		precalculatePercentageOfGamesPlayed(rootGameState);
		
		precalculatePostFlopNoiseFactor(rootGameState);
		
		/* generate a random number */
		aRandomNumber = Random.getInstance().generateRandomNumber();
	}
	
	private void precalculatePostFlopNoiseFactor(GameState rootGameState) {
		postFlopNoiseFactor = 0.3;
		
		try{
			if(rootGameState.getRound() > GameState.PREFLOP){
				Rank biggest = rootGameState.getHighestBoardCard();
				if(biggest.compareTo(Rank.NINE) < 0){
					postFlopNoiseFactor = 0.5;
				} else if(biggest.compareTo(Rank.TEN) < 0){
					postFlopNoiseFactor = 0.4;
				}
			}
		} catch(NullPointerException e){}
	}

	/**
	 * Determines the percentage of hands a player played.   
	 * 
	 * @param rootGameState
	 */
	private void precalculatePercentageOfGamesPlayed(GameState rootGameState) {
		for(int player = 0; player < rootGameState.getNumberOfPlayers(); player++){
			double percentage = statistics.getPercentageOfHandsPlayedByPlayer(player);
			if(percentage < 0.08)
				percentage = 0.08;
			percentageOfHandsPlayedByPlayer[player] = percentage;
		}
	}

	/**
	 * 
	 * @param rootGameState
	 */
	private void precalculateNumberOfCardsForPostFlopGuessing(
			GameState rootGameState) {
		for (int player = 0; player < rootGameState.getNumberOfPlayers(); player++) {

			int flopCardAdjust = (statistics.hasRaisedFlop(player) ? 1 : 0); // + (statistics.hasRaisedPreFlop(player) ? 1: 0);
			int turnCardAdjust = statistics.hasRaisedTurn(player) ? 1 : 0;
			int riverCardAdjust = statistics.hasRaisedRiver(player) ? 2 : 0;
			
			// Flop
			int adjustedNumberOfHands = adjustNumberOfHandsForPlayer(player,
					1 + flopCardAdjust, rootGameState, GameState.FLOP);
			numberOfCardsToChooseFromForFlop[player] = adjustedNumberOfHands;

			// turn
			adjustedNumberOfHands = adjustNumberOfHandsForPlayer(player, 
					1 + turnCardAdjust, rootGameState, GameState.TURN);
			numberOfCardsToChooseFromForTurn[player] = adjustedNumberOfHands;

			// river
			adjustedNumberOfHands = adjustNumberOfHandsForPlayer(player, 
					1 + turnCardAdjust + riverCardAdjust, rootGameState, GameState.RIVER);
			numberOfCardsToChooseFromForRiver[player] = adjustedNumberOfHands;
			
			// did we start on preflop?
//			if(riverCardAdjust + flopCardAdjust + turnCardAdjust > 0)
//				System.out.println("flopadjust: " + flopCardAdjust + ", turn:" + turnCardAdjust + ", river: " + riverCardAdjust );
		}
		
//		System.out.println("Number of Hands Flop: ");
//		Utils.printArray(numberOfCardsToChooseFromForFlop);
//		System.out.println("Number of Hands Turn: ");
//		Utils.printArray(numberOfCardsToChooseFromForTurn);
//		System.out.println("Number of Hands River: ");
//		Utils.printArray(numberOfCardsToChooseFromForRiver);
	}
	
	private int adjustNumberOfHandsForPlayer(int player, int numberOfHandsToChooseFrom, GameState gameState, int round){
		if (statistics.getNumberOfHandsPlayed() < 50)
			return numberOfHandsToChooseFrom;
		
		/* get the number of hands played according to the actual round */
		double percentageOfGamesPlayed = 0.1;
		switch(round){
		case GameState.FLOP:
			percentageOfGamesPlayed = statistics.getPercentageOfHandsPlayedByPlayer(player) - statistics.getPercentageOfHandsPlayedByPlayer(statistics.whoAreWe());
			break;
		case GameState.TURN:
			percentageOfGamesPlayed = statistics.getPercentageOfTurnsSeen(player) - statistics.getPercentageOfTurnsSeen(statistics.whoAreWe());
			break;
		default:
			percentageOfGamesPlayed = statistics.getPercentageOfRiversSeen(player) - statistics.getPercentageOfRiversSeen(statistics.whoAreWe());	
		}
		
		//numberOfHandsToChooseFrom -= Math.floor(percentageOfGamesPlayed * numberOfHandsToChooseFrom);
		
		// adjust hands
		if(percentageOfGamesPlayed > 0.25)
			numberOfHandsToChooseFrom--;
		if(percentageOfGamesPlayed > 0.15)
			numberOfHandsToChooseFrom--;
		if(percentageOfGamesPlayed > 0.05)
			numberOfHandsToChooseFrom--;
		
		if(percentageOfGamesPlayed < -0.05)
			numberOfHandsToChooseFrom++;
		if(percentageOfGamesPlayed < -0.15)
			numberOfHandsToChooseFrom++;
		if(percentageOfGamesPlayed < -0.25)
			numberOfHandsToChooseFrom++;
		

		if( Random.getInstance().generateRandomNumber() < Math.min(0.4, statistics.getPercentagePlayerBluffs(player)) )
			numberOfHandsToChooseFrom = 1;
		
		if(numberOfHandsToChooseFrom < 1)
			numberOfHandsToChooseFrom = 1;
		
		return numberOfHandsToChooseFrom;
	}

	/**
	 * The following algorithm is used to determine what cards to give this player:
	 * 
	 * <p>
	 * If the player called: We'll give him the sum of the times he called and raised
	 * <p>
	 * <p>
	 * If the player raised: We'll give him the fraction of the times he raised
	 * <p>
	 * <p>
	 * else: let's give him a constant that is slightly better than 1.
	 * <p>
	 * 
	 * @param rootGameState
	 */
	private void precalculatePercentageForPreFlopGuessing(GameState rootGameState) {
		for(int player = 0; player < rootGameState.getNumberOfPlayers(); player++){
			double percentage = 0;
			if (statistics.getNumberOfHandsPlayed() < 50) {
				if(statistics.hasCalled(player))
					percentage = 0.4;
				if(statistics.hasRaised(player))
					percentage = 0.2;
				else 
					percentage = 1;
			}
			else {
				if(statistics.hasCalled(player))
					percentage = statistics.getFractionPlayerCalledPreFlop(player) + statistics.getFractionPlayerRaisedPreFlop(player);
				else if(statistics.hasRaised(player))
					percentage = statistics.getFractionPlayerRaisedPreFlop(player);
				else {
					percentage = 1;
				}
			}

			percentageForPreflopGuessing[player] = Math.min(1, percentage);
		}
		
//		System.out.println("Percentage for Preflop Guessing");
//		Utils.printArray(percentageForPreflopGuessing);
	}

	@Override
	public void guessCardsForPlayer(int player, GameState gameState) {
		if(gameState.getRound() == GameState.PREFLOP)
			guessPreFlopCards(player, gameState);
		else
			guessPostFlopCards(player, gameState);
	}

	/**
	 * 
	 * @param player
	 * @param gameState
	 */
	private void guessPreFlopCards(int player, GameState gameState) {
		CardDeck deck = gameState.getDeck();

		/* percentage is precalculated */
		double percentage = percentageForPreflopGuessing[player];
//		Card[] cards = deck.getHandOutOfTopPercent(percentage,0.3);
		Card[] cards = deck.getHandOutOfTopPercent(percentage,0.2, 6 );
		
		gameState.setCardsForPlayer(cards, player);
	}

	/**
	 * 
	 * @param player
	 * @param gameState
	 */
	private void guessPostFlopCards(int player, GameState gameState) {
		/* how many cards to choose from? */
		int numberOfHandsToChooseFrom = 0;
		
		if(this.rootGameState.getRound() == GameState.PREFLOP)
			numberOfHandsToChooseFrom = statistics.hasRaisedPreFlop(player) && (1 - percentageOfHandsPlayedByPlayer[player]) > aRandomNumber ? 2 : 1;
		if(this.rootGameState.getRound() == GameState.FLOP)
			numberOfHandsToChooseFrom = numberOfCardsToChooseFromForFlop[player];
		else if(this.rootGameState.getRound() == GameState.TURN)
			numberOfHandsToChooseFrom = numberOfCardsToChooseFromForTurn[player];
		else
			numberOfHandsToChooseFrom = numberOfCardsToChooseFromForRiver[player];
		
		/* what is the percentage the player played up to now */
		double percentageOfGamesPlayed = percentageOfHandsPlayedByPlayer[player];
		
		Card[] board = gameState.getBoard();
		
		/* generate the needed number of hands */
		CardDeck deck = gameState.getDeck();
		Card[] cards = new Card[2];
		
		// this will be used to test the cards
		Card[] fullHand = new Card[7];
		for(int j = 0; j < 5; j++)
			fullHand[j+2] = board[j];
		
		double bestValue = -1;
		for(int i = 0; i < numberOfHandsToChooseFrom; i++){
			Card[] hand = deck.getHandOutOfTopPercent(percentageOfGamesPlayed, postFlopNoiseFactor, 6, false);
			
			fullHand[0] = hand[0];
			fullHand[1] = hand[1];
			
			double value = 0;
			if(gameState.getRound() == GameState.FLOP)
				value = GeneralPokerStatistics.getInstance().getFiveCardScore(fullHand);
			else if(gameState.getRound() == GameState.TURN)
				value = GeneralPokerStatistics.getInstance().getSixCardScore(fullHand);
			else
				value = GeneralPokerStatistics.getInstance().getSevenCardScore(fullHand);
			
			if(value > bestValue){
				bestValue = value;
				cards = hand;
			} 
		}
		
		//remove cards from deck
		deck.removeHand(cards);
		
		gameState.setCardsForPlayer(cards, player);
		
	}
}
