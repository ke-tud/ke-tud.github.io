package group5.mc.expert;

import group5.pokerGame.GameState;

public interface SelfExpert {

	public void guessOurNextAction (int player, GameState gameState);
}
