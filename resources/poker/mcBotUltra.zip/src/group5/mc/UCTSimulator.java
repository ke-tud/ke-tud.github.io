package group5.mc;

import group5.mc.expert.ExpertKnowledge;
import group5.pokerGame.GameState;

public class UCTSimulator {

	private int NUMBER_OF_SIMULATIONS_TOTAL = 20000;
	private int NUMBER_OF_SIMULATIONS_PER_NODE = 1;
	private int NUMBER_OF_SIMULATIONS_PER_CROSSED_NODE = 0;
	
	/**
	 * Tells how often we are to check for an obvious action
	 */
	private int NUMBER_OF_TIMES_TO_CHECK_FOR_OBVIOUS_ACTION = 1;
	
	/**
	 * Determines what an obvious action is
	 */
	private double OBVIOUS_ACTION_FACTOR = 4;
	
	/**
	 * Is used to always have positive expectation values while selecting the next node 
	 */
	private int MINUS_COMPENSATION_SUMMAND = 100;

	/**
	 * Determines how curious UCT is
	 */
	private static double UCT_EXPLORATION_FACTOR = 10;
	
	
	/**
	 * Stores the root 
	 */
	private GameState rootGameState;
	
	/**
	 * Stores the expert
	 */
	private ExpertKnowledge expert;

	/**
	 * The root node
	 */
	private UCTNode root;
	
	/**
	 * store the player, that this simulation is for
	 */
	private int player;

	/**
	 * Initialize the simulator
	 * @param gameState
	 * @param expert
	 */
	public UCTSimulator(GameState gameState, ExpertKnowledge expert){
		this.rootGameState = gameState;
		this.expert = expert;
		
		/* who is this simulation for */
		this.player = gameState.getCurrentPlayer();
		
		/* tell expert */
		expert.setPlayerThisSimulationIsFor(this.player);
		
		/* create root node */
		root = new UCTNode(this.rootGameState, expert, this);
	}
	
	/**
	 * 
	 * @return The player that this simulation is for
	 */
	public int getPlayerThisSimulationIsFor(){
		return player;
	}
	
	public void setSimulationsPerCrossedNode(int simulations){
		NUMBER_OF_SIMULATIONS_PER_CROSSED_NODE = simulations;
	}
	
	public void setUCTExplorationFactor(double factor){
		UCT_EXPLORATION_FACTOR = factor;
	}

	
	public void halfNumberOfSimulations(){
		NUMBER_OF_SIMULATIONS_TOTAL /= 2;
		NUMBER_OF_SIMULATIONS_PER_NODE /= 2;
	}
	
	public void setNumberOfTimesToCheckForObviousAction(int check){
		NUMBER_OF_TIMES_TO_CHECK_FOR_OBVIOUS_ACTION = check;
	}
	
	public void setObviousActionFactor(double factor){
		OBVIOUS_ACTION_FACTOR = factor;
	}
	
	/**
	 * Sets the number of simulations in total
	 * @param simulations
	 */
	public void setNumberOfTotalSimulations(int simulations){
		NUMBER_OF_SIMULATIONS_TOTAL = simulations;
	}
	
	/**
	 * Sets the number of simulations that are executed for each newly created child node
	 * @param simulations
	 */
	public void setNumberOfSimulationsPerNode(int simulations){
		NUMBER_OF_SIMULATIONS_PER_NODE = simulations;
	}
	
	
	
	/**
	 * 
	 * @return The root node
	 */
	public UCTNode getRoot() {
		return root;
	}
	
	
	public double[] run(){
		/* we tell our expert that we are about to simulate a situation */
		expert.uctSimulationIsAboutToStart(rootGameState);

		// initialize number of simulations
		int numberOfSimulationsMade = 0;
		
		//adjust number of total simulations
		int totalNumberOfSimulations = NUMBER_OF_SIMULATIONS_TOTAL / NUMBER_OF_TIMES_TO_CHECK_FOR_OBVIOUS_ACTION;
		
		// how often are we to check for an obvious action
		for(int checked = 1; checked <= NUMBER_OF_TIMES_TO_CHECK_FOR_OBVIOUS_ACTION; checked++){			
			/* while there are still simulations to do */
			while(numberOfSimulationsMade < totalNumberOfSimulations){
				/* select the next node to simulate */
				UCTNode node = selectNode();
				
				if(! node.isFinished()){
					/* expand the node */
					node.expand();
				
					/* simulate children */
					for(int i = 0; i < NUMBER_OF_SIMULATIONS_PER_NODE; i++)
						node.simulateChildren();
				} else {
					node.simulate();
				}
				
				/* increase number of simulations made */
				numberOfSimulationsMade++;
			}

			/* check for obvious action */
			double[] obviousEV = {
					0, 
					root.getChildCall() != null ? root.getChildCall().getValue() : Double.NEGATIVE_INFINITY, 
					root.getChildRaise() != null ? root.getChildRaise().getValue() : Double.NEGATIVE_INFINITY
			};
			
			// if raise and call are < OBVIOUS_ACTION_FACTOR
			if(obviousEV[1] < 0 && obviousEV[2] < 0){ 
				if(obviousEV[1] + OBVIOUS_ACTION_FACTOR < 0 && obviousEV[2] + OBVIOUS_ACTION_FACTOR < 0){
					System.out.println("obvious1 after: " + checked);
					return obviousEV;
				}
			// if call > 4 and call > raise + 4
			} else if(obviousEV[1] > obviousEV[2]) {
				if(obviousEV[2] + OBVIOUS_ACTION_FACTOR < obviousEV[1] && OBVIOUS_ACTION_FACTOR < obviousEV[1]){
					System.out.println("obvious2 after: " + checked);
					return obviousEV;
				}
			// if raise > 4 and raise > call + 4
			} else {
				if(obviousEV[1] + OBVIOUS_ACTION_FACTOR < obviousEV[2] && OBVIOUS_ACTION_FACTOR < obviousEV[2]){
					System.out.println("obvious3 after: " + checked);
					return obviousEV;
				}
			}
			
			
			// reset numberOfSimulationsMade
			numberOfSimulationsMade = 0;
		}
		
		// fold is zero
		double[] EV = {		
				0, 
				root.getChildCall() != null ? root.getChildCall().getValue() : Double.NEGATIVE_INFINITY, 
				root.getChildRaise() != null ? root.getChildRaise().getValue() : Double.NEGATIVE_INFINITY
		};
		
		return EV;
	}


	/**
	 * Selects a new node that is to be expanded and simulated
	 * @return The new gameState
	 */
	private UCTNode selectNode() {
		UCTNode node = root;
		
		/* find a leaf node */
		while(! node.isLeaf() ){
			
			UCTNode child1 = node.getChildFold();
			UCTNode child2 = node.getChildCall();
			UCTNode child3 = node.getChildRaise();
			
			double k1, k2, k3 = 0;
			if(node.isRoot() || null == child1)
				k1 = Double.NEGATIVE_INFINITY;
			else
				k1 = child1.getValue() + MINUS_COMPENSATION_SUMMAND + 
					UCT_EXPLORATION_FACTOR * Math.sqrt(Math.log(node.getNumberOfSimulations())/(double)child1.getNumberOfSimulations());
			
			if(null == child2)
				k2 = Double.NEGATIVE_INFINITY;
			else
				k2 = child2.getValue() + MINUS_COMPENSATION_SUMMAND + 
					UCT_EXPLORATION_FACTOR * Math.sqrt(Math.log(node.getNumberOfSimulations())/(double)child2.getNumberOfSimulations());
			
			if(null == child3)
				k3 = Double.NEGATIVE_INFINITY;
			else
				k3 = child3.getValue() + MINUS_COMPENSATION_SUMMAND + 
					UCT_EXPLORATION_FACTOR * Math.sqrt(Math.log(node.getNumberOfSimulations())/(double)child3.getNumberOfSimulations());

			if(k1 > k2 && k1 > k3){
				node = child1;
			} else if( k2 > k3) {
				node = child2;
			} else {
				node = child3;
			}
			
			/* simulate the selected node */
			for(int i = 0; i < NUMBER_OF_SIMULATIONS_PER_CROSSED_NODE; i++)
				node.simulate();
		}
		
		/* return the leaf node */
		return node;
	}


}
