package group5.mc.evaluate;

import group5.mc.UCTNode;
import group5.mc.UCTSimulator;
import group5.pokerGame.GameState;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 * Takes a UCTSimulator object and creates a nice looking dotfile
 * @author amittelbach
 *
 */
public class UCTPlotter {

	/**
	 * 
	 */
	private UCTSimulator sim;

	/**
	 * 
	 * @param sim The simulator object
	 */
	public UCTPlotter(UCTSimulator sim){
		this.sim = sim;
	}
	
	/**
	 * Creates the dot file
	 * @param file
	 */
	public void createDotFile(String file){
		  try {
			// Create file 
			FileWriter fstream = new FileWriter(file);
			BufferedWriter out = new BufferedWriter(fstream);
			
			// write first lines
			out.write("digraph graphname\n");
			out.write("{\n");
			
			drawChildren(sim.getRoot(), out,"_");
			
			out.write("}");
			
			
			
			
			//Close the output stream
			out.close();
		} catch (Exception e) {//Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	/**
	 * Recursive method that draws all children
	 * @param root
	 * @param out
	 */
	private void drawChildren(UCTNode node, BufferedWriter out, String name) throws Exception{
		// take care of node
		String label = "Player" + node.getGameState().getCurrentPlayer() + "\\n";
		//pot
		label += "Pot: [";
		for(int money : node.getGameState().getInPot())
			label += money + ",";
		label += "]\\n";
		//active
		label += "Active: [";
		for(boolean active : node.getGameState().getActivePlayers())
			label += (active ? "1" : "0" ) + ",";
		label += "]\\n";
		//round
		switch(node.getGameState().getRound()){
		case GameState.PREFLOP:
			label += "PREFLOP\\n";
			break;
		case GameState.FLOP:
			label += "FLOP\\n";
			break;
		case GameState.TURN:
			label += "TURN\\n";
			break;
		default:
			label += "RIVER\\n";
			break;
		}
		//nr of simulatiosn
		label += "Anzahl Sim: " + node.getNumberOfSimulations() + "\\n";
		//EVs
		label += "EV: [";
		for(double ev : node.getExpectationValues())
			label += ev + ",";
		label += "]\\n";
		
		label += "EV-norm: [";
		for(double ev : node.getNormalizedValues())
			label += ev + ",";
		label += "]\\n";
		
		//value
		label += "Wert: " + node.getValue();


		out.write(name + "[shape=box,label=\"" + label + "\"]; \n");
		
		
		
		// go to children
		if(! node.isLeaf() ){
			UCTNode fold = node.getChildFold();
			UCTNode call = node.getChildCall();
			UCTNode raise = node.getChildRaise();
			
			int mostVisited = 0;
			if(null != fold)
				if(fold.getNumberOfSimulations() > call.getNumberOfSimulations() && fold.getNumberOfSimulations() > raise.getNumberOfSimulations())
					mostVisited = 0;
			else if(call.getNumberOfSimulations() > fold.getNumberOfSimulations() && call.getNumberOfSimulations() > raise.getNumberOfSimulations())
				mostVisited = 1;
			else 
				mostVisited = 2;
			
			if(null != fold)
				out.write(name + " -> " + name + "f [label=\"f\"" + (mostVisited == 0 && ! fold.isLeaf() ? ",color=red" : "") + "];\n");
			out.write(name + " -> " + name + "c [label=\"c\"" + (mostVisited == 1 && ! call.isLeaf() ? ",color=red" : "") + "];\n");
			out.write(name + " -> " + name + "r [label=\"r\"" + (mostVisited == 2 && ! raise.isLeaf() ? ",color=red" : "") + "];\n");
			
			// call ourself
			if(null != fold)
				drawChildren(fold, out, name + "f");
			drawChildren(call, out, name + "c");
			drawChildren(raise, out, name + "r");
		}
	}
}
