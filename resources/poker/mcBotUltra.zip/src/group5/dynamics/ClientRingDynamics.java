package group5.dynamics;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 * This class extends the RingDynamics class to handle the game dynamics by a poker bot.
 * 
 * @author Michael
 *
 */
public class ClientRingDynamics extends RingDynamics {

	/**
	 * The current seat of the poker
	 */
	private int currentSeat;
	
	/**
	 * The number of players which are active at the moment.
	 */
	private int playersActive;

	/**
	 * @param numPlayers Number of players which begin the game.
	 * @param info The info element corresponding to the current game.
	 * @param botNames Names of the opponent players.
	 */
	public ClientRingDynamics(int numPlayers, MatchType info, String[] botNames) {
		super(numPlayers, info, botNames);

	}

	/**
	 * If a action on the game happened this method helps to handle the action.
	 * 
	 * @param msm An encapsulated MatchStateObject.
	 * @return If there is a new hand to play or not.
	 */
	public boolean processStateChange(AdvMatchStateMessage msm) {
		// check if there is a new hand to play
		boolean isNewHand = (hole == null || handOver);

		// start a new hand
		if (isNewHand) 
			nextHand();
		
		// find out the bot's actual seat, delivered by the framework.
		this.currentSeat = msm.seatTaken;
		
		// now set cards as given by matchstate (these are at least our own)
		this.setCardsFromMSM(msm);
		
		// In the next step we will locally redo last player's action.
		// This is necessary for keeping track of the stack sizes and allowed actions. 
		char lastAction = msm.getLastActionChar();
		if (lastAction != '\0') 
			this.handleAction(lastAction);
			
		return isNewHand;
	}

	
	private void nextHand() {
	   	if (hole!=null){
     	  setHandNumber(handNumber+1);
     	  nextSeats();
     	}
     	initializeBets();
	}

	/**
	 * Stores all card informations given by a msm. Such like own hole cards, other players
	 * hole cards and the board cards.
	 * 
	 * @param msm The actual match state message.
	 */
	private void setCardsFromMSM(AdvMatchStateMessage msm) {
		// how many players are left in the game.
		playersActive = msm.hole.length;

		this.hole = new Card[playersActive][];

		// store all known hole cards. At least our owns.
		for (int i = 0; i < playersActive; i++) {
			if (msm.hole[i] != null && !(msm.hole[i].length() == 0))
				this.hole[i]= Card.toCardArray(msm.hole[i]);
			else
				this.hole[i]= null;
		}

		// store the board cards
		if (msm.board != null && !(msm.board.length() == 0))
			this.board = Card.toCardArray(msm.board);
		else
			this.board = null;
	}
	
	/**
	 * @return If actual round is the showdown.
	 */
	public boolean isShowdown() {
		return (roundIndex == 4);
	}
	
	/**
	 * @return If actual round is river
	 */
	public boolean isRiver(){
		return (roundIndex == 3);
	}
	
	/**
	 * @return If actual round is turn
	 */
	public boolean isTurn(){
		return (roundIndex == 2);
	}
	
	/**
	 * @return If actual round is flop
	 */
	public boolean isFlop(){
		return (roundIndex == 1);
	}
	
	/**
	 * @return If actual round is preflop
	 */
	public boolean isPreflop(){
		return (roundIndex == 0);
	}
	
	/**
	 * 
	 * @return if actual round is flop, turn or river.
	 */
	public boolean isPostFlop() {
		return roundIndex >= 1;
	}
	
	

	/**
	 * Returns the sum of all contributions to the pot (that is: the pot size).
	 * @return the pot size.
	 */
	public int getPotSum() {
		int potSum = 0;
		for (int i = 0; i < this.playersActive; i++)   
			potSum += inPot[i];

		return potSum;
	}
	
	/* ****************************************************************************
	 * From here on, we define some functions for the client to call to obtain some 
	 * personalized game state info.
	 * ****************************************************************************
	 * */

	/**
	 * @return The hole cards of our bot.
	 */
	public Card[] getMyHoleCards() {
		return this.hole[currentSeat];
	}

	/**
	 * @return Whether our bot is on turn or not.
	 */
	public boolean isMyTurn() {
		// seatToAct is from super class, currentSeat is from actual class
		return (currentSeat == seatToAct);
	}

	/**
	 * @return The stack size of the current bot.
	 */
	public int getMyStackSize() {
		return stack[seatToPlayer(currentSeat)];
	}

	/**
	 * @return The actual seat of our bot.
	 */
	public int getMySeat() {
		return currentSeat;
	}
	
	
	/**
	 * @return Returns the actual board cards.
	 */
	public Card[] getBoard() {
		return this.board;
	}
	
	public Card[] getAllCards () {
		Card[] allCards = new Card[board.length + 2];

		allCards[0] = this.hole[currentSeat][0];
		allCards[1] = this.hole[currentSeat][1];
		
		for (int i=0; i<board.length; i++) {
			allCards[i+2] = board[i];
		}
		
		return allCards;
	}
	
	public int [] getSeatToPlayer () {
		int numberOfPlayers = botNames.length;
		int[] player = new int[numberOfPlayers];
		
		for (int i=0; i < numberOfPlayers;i++) {
			player[i] = playerToSeat(i);
		}
		
		return player;
	}

}
