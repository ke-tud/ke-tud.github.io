package group5.dynamics;

import ca.ualberta.cs.poker.free.dynamics.MatchStateMessage;

/**
 * This class overloads the setCards method and can offer some extra functionality. 
 * 
 * @author Michael
 *
 */
public class AdvMatchStateMessage extends MatchStateMessage {
	
	public AdvMatchStateMessage (String message)
	{
		super(message);
	}

	/**
	 * @return Returns the last character which was added to the game string. Like 'c', 'r' or 'f'.
	 */
    public char getLastActionChar(){

        if (bettingSequence.length()==0){
            return '\0';
        }
        char lastChar = bettingSequence.charAt((endOfStage()) ? (bettingSequence.length()-2) : (bettingSequence.length()-1));

        return lastChar;
    }

    /**
     * This function is assumed from an fellow student which said that this is better.
     */
    @Override
    public void setCards(String cardSequence)
    {
 		String[] cards = cardSequence.split("/");
		if (cards.length >= 2) flop = cards[1]; else flop = null;
		if (cards.length >= 3) turn = cards[2]; else turn = null;
		if (cards.length >= 4) river = cards[3]; else river = null;
		hole = cards[0].split("\\|", -1); // -1 for splitting empty entries

		board = flop;
		if (turn != null) board += turn;
		if (river != null) board += river;
   }
}
