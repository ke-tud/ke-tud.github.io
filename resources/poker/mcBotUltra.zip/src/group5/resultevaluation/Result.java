package group5.resultevaluation;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * Represents a result object.
 * 
 * @author Arno
 *
 */
public class Result {

	/**
	 * stores the results name
	 */
	private String name;
	
	/**
	 * stores all lines
	 */
	private List<ResultEntry> entries = new LinkedList<ResultEntry>();
	
	
	/**
	 * 
	 * @param name
	 * @throws FileNotFoundException 
	 */
	public Result(String name) throws FileNotFoundException{
		this.name = name;
		
		load();
	}

	/**
	 * reads in the result data
	 * @throws FileNotFoundException 
	 */
	private void load() throws FileNotFoundException {
		File f = new File(ResultEvaluation.PATH_TO_RESULT_FILES + "/" + name + ".log");
	    Scanner scanner = new Scanner(f);;
		try {
	      //first use a Scanner to get each line
	      while ( scanner.hasNextLine() ){
	        String line = scanner.nextLine();
	        if(line.charAt(0) != '#')
	        	entries.add(new ResultEntry(line));
	      }
	    }
	    finally {
	      //ensure the underlying stream is always closed
	      scanner.close();
	    }
	}
	
	/**
	 * returns the entries
	 */
	public List<ResultEntry> getEntries(){
		return entries;
	}

	/**
	 * 
	 * @return The results name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * @return A list with all player names (in random order)
	 */
	public List<String> getPlayerNames(){
		return entries.get(0).getPlayerNames();
	}

	/**
	 * 
	 * @return The number of hands that were player
	 */
	public int getNumberOfHands() {
		return entries.size();
	}


}
