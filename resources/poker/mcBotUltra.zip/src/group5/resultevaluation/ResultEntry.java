package group5.resultevaluation;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Represents a Result entry 
 * (Random5|Hallo1|Random4|Random2|Random6|Random3:3:rrrccccc/crcrfcrrcccc/rrccrrccfc/crrrrccc:3cTs|Ks6d|JsQh|KdKc|8s7c|Jc4s/7h5dTh/8c/5s:176|-48|-48|-24|-8|-48)
 * @author Arno
 *
 */
public class ResultEntry {

	/**
	 * Constants specifying the different rounds
	 */
	public final static int PREFLOP = 0;
	public final static int FLOP = 1;
	public final static int TURN = 2;
	public final static int RIVER = 3;
	public final static int SHOWDOWN = 4;
	
	
	/**
	 * Describes where players are still active
	 */
	private final static int PLAYER_ACTIVE_ON_FLOP = 1;
	private final static int PLAYER_ACTIVE_ON_TURN = 2;
	private final static int PLAYER_ACTIVE_ON_RIVER = 4;
	private final static int PLAYER_ACTIVE_ON_SHOWDOWN = 8;
	private Map<String,Integer> playerActiveInRound = new HashMap<String, Integer>();	
	
	/**
	 * 
	 */
	private String line;

	/**
	 * Stores a list of all player names
	 */
	private List<String> playerNames = new LinkedList<String>();

	/**
	 * Stores the preFlop
	 */
	private String preFlop;

	/**
	 * Stores the Flop
	 */
	private String flop;

	/**
	 * Stores the Turn
	 */
	private String turn;

	/**
	 * Stores the river
	 */
	private String river;
	
	/**
	 * stores the profits
	 */
	private Map<String, Integer> profits = new HashMap<String, Integer>();
	
	/**
	 * stores the winner
	 */
	private String winner;
	
	
	/**
	 * stores all cards 
	 */
	private String allCards;
	private String[] bettingSequence;
	private String bettingSequenceLine;
	private String profitsLine;
	
	/**
	 * 
	 * @param line
	 */
	public ResultEntry(String line){
		this.line = line;
		processLine();
	}
	
	/**
	 * 
	 */
	private void processLine(){
		String[] parts = line.split(":");
		
		// playernames
		for(String name : parts[0].split("\\|"))
			playerNames.add(name);
		
		// preflop, flop, turn, river
		bettingSequenceLine = parts[2];
		bettingSequence = parts[2].split("/");
		preFlop = bettingSequence[0];
		if(bettingSequence.length > 1)
			flop = bettingSequence[1];
		if(bettingSequence.length > 2)
			turn = bettingSequence[2];
		if(bettingSequence.length > 3)
			river = bettingSequence[3];
		
		// calculate if players are still active
		calculateActivePlayers();
		
		// calculate profits
		profitsLine = parts[4];
		String[] individualProfits = parts[4].split("\\|");
		for(int i = 0; i < playerNames.size(); i++)
			profits.put(playerNames.get(i), Integer.parseInt(individualProfits[i]));
		
		// calculate the winner
		winner = playerNames.get(0);
		int winnersProfit = profits.get(winner);
		for(String player : playerNames)
			if(winnersProfit < profits.get(player)){
				winnersProfit = profits.get(player);
				winner = player;
			}
		
		// store all Cards
		allCards = parts[3];
	}

	
	public String[] getBettingSequences(){
		return bettingSequence;
	}
	
	public String getBettingSequence(){
		return bettingSequenceLine;
	}
	
	public String getProfitsLine(){
		return profitsLine;
	}

	/**
	 * parses the betting sequence and fills the playerActiveInRound map
	 */
	private void calculateActivePlayers() {
		// instantiate Map
		for(String player : playerNames )
			playerActiveInRound.put(player, 0);
		
		// instantiate private Map
		Map<String, Boolean> playerStillActive = new HashMap<String, Boolean>();
		for(String player : playerNames )
			playerStillActive.put(player, true);
		
		
		// parse preFlop
		String currentPlayer = getUnderTheGun();
		calculateActivePlayersInRound(preFlop, playerStillActive, currentPlayer, PLAYER_ACTIVE_ON_FLOP);

		// parse flop
		if(null!=flop){
			currentPlayer = getFirstToActIn(FLOP);
			calculateActivePlayersInRound(flop, playerStillActive, currentPlayer, PLAYER_ACTIVE_ON_TURN);
		}
		
		// parse turn
		if(null!=turn){
			currentPlayer = getFirstToActIn(TURN);
			calculateActivePlayersInRound(turn, playerStillActive, currentPlayer, PLAYER_ACTIVE_ON_RIVER);
		}

		// parse river
		if(null!=river){
			currentPlayer = getFirstToActIn(RIVER);
			calculateActivePlayersInRound(river, playerStillActive, currentPlayer, PLAYER_ACTIVE_ON_SHOWDOWN);
		}
	}
	
	/**
	 * helper method for calculateActivePlayers
	 */
	private void calculateActivePlayersInRound(String bettingRound, Map<String, Boolean> playerStillActive, String currentPlayer, int bitValueForRound){
		for(int i = 0; i < bettingRound.length(); i++ ){
			if(bettingRound.charAt(i) == 'f')
				playerStillActive.put(currentPlayer, false);
			
			// get next player
			currentPlayer = getNextPlayer(currentPlayer);
			
			// get next player if player is inactive
			while(! playerStillActive.get(currentPlayer))
				currentPlayer = getNextPlayer(currentPlayer);
		}
		
		// update Map
		for(String player : playerNames)
			if(playerStillActive.get(player))
				playerActiveInRound.put(player, playerActiveInRound.get(player) | bitValueForRound);

	}

	/**
	 * 
	 * @param round
	 * @return the player that is first to act in the submitted round.
	 */
	private String getFirstToActIn(int round) {
		if(round == PREFLOP)
			return getUnderTheGun();
		
		String player = getButton();
		return getNextPlayer(player,round);
	}

	/**
	 * 
	 * @param player
	 * @return The player that is sitting next to me
	 */
	private String getNextPlayer(String player){
		return playerNames.get((playerNames.indexOf(player) + 1) % getNumberOfPlayers());
	}
	
	/**
	 * 
	 * @param player
	 * @param round
	 * @return The player that is sitting next to the player and that is still active 
	 */
	private String getNextPlayer(String player, int round){
		int activeInRoundConstant = 0;
		switch(round){
		case SHOWDOWN:
			activeInRoundConstant = PLAYER_ACTIVE_ON_SHOWDOWN;
			break;
		case RIVER:
			activeInRoundConstant = PLAYER_ACTIVE_ON_RIVER;
			break;
		case TURN:
			activeInRoundConstant = PLAYER_ACTIVE_ON_TURN;
			break;
		case FLOP:
		default:
			activeInRoundConstant = PLAYER_ACTIVE_ON_FLOP;
		}
		
		String nextPlayer = getNextPlayer(player);
		
		while((playerActiveInRound.get(nextPlayer) & activeInRoundConstant) == 0)
			nextPlayer = getNextPlayer(nextPlayer);
		
		return nextPlayer;
	}
	
	/**
	 * @return The button
	 */
	public String getButton(){
		return playerNames.get(playerNames.size()-1);
	}
	
	
	
	
	
	/**
	 * 
	 * @return The player that is under the gun
	 */
	public String getUnderTheGun() {
		if(getNumberOfPlayers() > 2)
			return playerNames.get(2);
		
		return playerNames.get(0);
	}
	
	/**
	 * 
	 * @return The Bigblind
	 */
	public String getBigBlind() {
		return playerNames.get(1);
	}

	/**
	 * 
	 * @return The Bigblind
	 */
	public String getSmallBlind() {
		return playerNames.get(0);
	}


	/**
	 * @return the rounds winner
	 */
	public String getWinner(){
		return winner;
	}
	
	
	/**
	 * 
	 * @return A List with all player names
	 */
	public List<String> getPlayerNames() {
		return playerNames;
	}
	
	/**
	 * @return the full line
	 */
	public String getLine(){
		return line;
	}
	
	/**
	 * @return the players position
	 */
	public int getPlayersPosition(String player){
		int numberOfPlayers = getNumberOfPlayers();
		int pos = numberOfPlayers - 2;
		
		for(String thePlayer : playerNames)
			if(thePlayer.equals(player))
				break;
			else
				pos = (pos + 1) % numberOfPlayers;
		
		return pos + 1;
	}
	
	/**
	 * @return the Number of players
	 */
	public int getNumberOfPlayers(){
		return playerNames.size();
	}
	
	/**
	 * @return the preFlop
	 */
	public String getPreFlop(){
		return preFlop;
	}
	
	/**
	 * @return the flop
	 */
	public String getFlop(){
		return flop;
	}
	
	/**
	 * @return the Turn
	 */
	public String getTurn(){
		return turn;
	}
	
	/**
	 * @return the River
	 */
	public String getRiver(){
		return river;
	}
	
	/**
	 * @return The round, the game ended in
	 */
	public int getRoundGameEndedIn(){
		if(gameEndedOnPreFlop())
			return PREFLOP;
		if(gameEndedOnFlop())
			return FLOP;
		if(gameEndedOnTurn())
			return TURN;
		if(gameEndedOnRiver())
			return RIVER;
		
		return SHOWDOWN;
	}

	/**
	 * 
	 * @param player
	 * @return True if player was still active on flop
	 */
	public boolean playerSawFlop(String player) {
		return (playerActiveInRound.get(player) & PLAYER_ACTIVE_ON_FLOP) == PLAYER_ACTIVE_ON_FLOP;
	}
	
	/**
	 * 
	 * @param player
	 * @return True if player was still active on turn
	 */
	public boolean playerSawTurn(String player) {
		return (playerActiveInRound.get(player) & PLAYER_ACTIVE_ON_TURN) == PLAYER_ACTIVE_ON_TURN;
	}
	
	/**
	 * 
	 * @param player
	 * @return True if player was still active on river
	 */
	public boolean playerSawRiver(String player) {
		return (playerActiveInRound.get(player) & PLAYER_ACTIVE_ON_RIVER) == PLAYER_ACTIVE_ON_RIVER;
	}
	
	/**
	 * 
	 * @param player
	 * @return True if player was still active on showdown
	 */
	public boolean playerWasInShowDown(String player) {
		return (playerActiveInRound.get(player) & PLAYER_ACTIVE_ON_SHOWDOWN) == PLAYER_ACTIVE_ON_SHOWDOWN;
	}
	
	/**
	 * 
	 * @param player
	 * @return The player's profit
	 */
	public int getPlayersProfit(String player){
		return profits.get(player);
	}
	
	/**
	 * @return Whether the GameEnded on preFlop
	 */
	public boolean gameEndedOnPreFlop(){
		return null == flop;
	}
	
	/**
	 * @return Whether the game ended on flop
	 */
	public boolean gameEndedOnFlop(){
		return null == turn;
	}
	
	/**
	 * @return Whether the GameEnded on the turn
	 */
	public boolean gameEndedOnTurn(){
		return null == river;
	}
	
	/**
	 * @return Whether the game ended on the river
	 */
	public boolean gameEndedOnRiver(){
		return null != river && ! gameEndedInShowdown();
	}
	
	/**
	 * @return Whether game ended in Showdown
	 */
	public boolean gameEndedInShowdown(){
		int i = 0;
		for(String player : playerNames)
			if((playerActiveInRound.get(player) & PLAYER_ACTIVE_ON_SHOWDOWN) == PLAYER_ACTIVE_ON_SHOWDOWN)
				i++;
		
		return i >= 2;
	}
	
	/**
	 * @return all cards
	 */
	public String getAllCards(){
		return allCards;
	}

	public boolean isBigBlind(String player) {
		return getBigBlind().equals(player);
	}
	
	public boolean isSmallBlind(String player){
		return getSmallBlind().equals(player);
	}
}
