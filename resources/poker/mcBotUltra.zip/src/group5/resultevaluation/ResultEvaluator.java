package group5.resultevaluation;


/**
 * Defines the interface that is used by ResultEvaluation
 * 
 * @author Arno
 *
 */
public abstract class ResultEvaluator {

	/**
	 * Stores the result object
	 */
	protected Result result;
	
	/**
	 * 
	 */
	public ResultEvaluator(){
	}
	
	/**
	 * sets the result object
	 * @param result 
	 */
	public void setResult(Result result){
		this.result = result;
	}
	
	/**
	 * Recieves a list of all relevant lines and 
	 * @return an HTML snippet
	 */
	public abstract String processResult();
}
