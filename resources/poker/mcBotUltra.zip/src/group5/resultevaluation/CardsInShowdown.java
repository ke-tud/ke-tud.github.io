package group5.resultevaluation;

public class CardsInShowdown extends ResultEvaluator {

	@Override
	public String processResult() {
		String output = "<h1>Hände bei denen es zum Showdown kam</h1>";
		
		for(ResultEntry entry: result.getEntries())
			if(entry.gameEndedInShowdown()){
				output += "<p>";
				for(String player : entry.getPlayerNames())
					output += player + "|";
				
				output += "<br/>" + entry.getAllCards() + "<br/>Gewinner: " + entry.getWinner() + "<br/>";
				output += "Teilnehmer: ";
				for(String player : entry.getPlayerNames())
					if(entry.playerWasInShowDown(player))
						output += player + ", ";
				
				output += "<br/>";
				output += entry.getBettingSequence();
				
				output += "<br/>" + entry.getProfitsLine();
				
				
				
				output += "</p>";
			}
		
		return output;
	}

}
