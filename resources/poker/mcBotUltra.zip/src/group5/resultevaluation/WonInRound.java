package group5.resultevaluation;


public class WonInRound extends ResultEvaluator{

	@Override
	public String processResult() {
		String thePlayer = "McBotUltra";
		
		int profitsPreFlop = 0;
		int profitsFlop = 0;
		int profitsTurn = 0;
		int profitsRiver = 0;
		int profitsShowdown = 0;
		
		for(ResultEntry entry: result.getEntries()){
			if(entry.gameEndedOnPreFlop() || ! entry.playerSawFlop(thePlayer))
				profitsPreFlop += entry.getPlayersProfit(thePlayer);
			else if(entry.gameEndedOnFlop() || ! entry.playerSawTurn(thePlayer))
				profitsFlop += entry.getPlayersProfit(thePlayer);
			else if(entry.gameEndedOnTurn() || ! entry.playerSawRiver(thePlayer))
				profitsTurn += entry.getPlayersProfit(thePlayer);
			else if(entry.gameEndedOnRiver() || ! entry.playerWasInShowDown(thePlayer))
				profitsRiver += entry.getPlayersProfit(thePlayer);
			else if(entry.gameEndedInShowdown() )
				profitsShowdown += entry.getPlayersProfit(thePlayer);
		}
		
		String output = "<h1>Geld pro Runde (" + thePlayer + ")</h1>";
		output += "PreFlop: " + profitsPreFlop + "</br>";
		output += "Flop: " + profitsFlop + "</br>";
		output += "Turn: " + profitsTurn + "</br>";
		output += "River: " + profitsRiver + "</br>";
		output += "Showdown: " + profitsShowdown + "</br>";
		
		
		return output;
	}

}
