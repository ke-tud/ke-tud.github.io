package group5.resultevaluation;

import java.util.HashMap;
import java.util.Map;

public class ShowdownsWon extends ResultEvaluator {

	@Override
	public String processResult() {
		Map<String, Integer> nrInShowdown = new HashMap<String, Integer>();
		Map<String, Integer> nrShowdownsWon = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames()){
			nrInShowdown.put(player, 0);
			nrShowdownsWon.put(player, 0);
		}
		for(ResultEntry entry : result.getEntries())
			for(String player : result.getPlayerNames())
				if(entry.playerWasInShowDown(player)){
					nrInShowdown.put(player,nrInShowdown.get(player) + 1);
					if(entry.getWinner().equals(player))
						nrShowdownsWon.put(player,nrShowdownsWon.get(player) + 1);
				}
				
		String output = "<h1>Anzahl gewonnener Showdowns</h1>";
		
		for(String player : result.getPlayerNames()){
			if(nrInShowdown.get(player) != 0)
				output += player + "(" + nrInShowdown.get(player) + "/" +  nrShowdownsWon.get(player) + ")" + " gewann " + nrShowdownsWon.get(player)*100/nrInShowdown.get(player) + "% seiner Showdowns<br/>";
			else
				output += player + " nahm an keinem Showdown teil!!<br/>";
		}
		
		return output;
	}

}
