package group5.resultevaluation;

import java.util.HashMap;
import java.util.Map;

public class FoldStatistics extends ResultEvaluator {

	@Override
	public String processResult() {
		// how often did a player fold on the preflop
		Map<String, Integer> foldOnPreFlop = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			foldOnPreFlop.put(player, 0);
		for(ResultEntry entry : result.getEntries())
			for(String player : result.getPlayerNames())
				if(! entry.playerSawFlop(player) && !player.equals(entry.getWinner()))
					foldOnPreFlop.put(player, foldOnPreFlop.get(player) + 1);
		

		
		// how often did a player fold on the flop
		Map<String, Integer> foldOnFlop = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			foldOnFlop.put(player, 0);
		for(ResultEntry entry : result.getEntries())
			if(! entry.gameEndedOnPreFlop())
				for(String player : result.getPlayerNames())
					if( entry.playerSawFlop(player) && ! entry.playerSawTurn(player) && !player.equals(entry.getWinner()))
						foldOnFlop.put(player, foldOnFlop.get(player) + 1);



		// how often did a player fold on the turn
		Map<String, Integer> foldOnTurn = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			foldOnTurn.put(player, 0);
		for(ResultEntry entry : result.getEntries())
			if(! entry.gameEndedOnFlop())
				for(String player : result.getPlayerNames())
					if( entry.playerSawTurn(player) && ! entry.playerSawRiver(player) && !player.equals(entry.getWinner()))
						foldOnTurn.put(player, foldOnTurn.get(player) + 1);

		
		// how often did a player fold on the river
		Map<String, Integer> foldOnRiver = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			foldOnRiver.put(player, 0);
		for(ResultEntry entry : result.getEntries())
			if(! entry.gameEndedOnTurn() )
				for(String player : result.getPlayerNames())
					if( entry.playerSawRiver(player) && ! entry.playerWasInShowDown(player) && !player.equals(entry.getWinner()))
						foldOnRiver.put(player, foldOnRiver.get(player) + 1);
		
		
		// prepare Output
		String output = "<h1>Fold Statistiken</h1>";

		output += "<h3>Wie häufig foldet ein Spieler auf dem PreFlop</h3>";
		for(String player : result.getPlayerNames())
			output += player + ": " + foldOnPreFlop.get(player) + "<br/>";
			
		output += "<h3>Wie häufig foldet ein Spieler auf dem Flop</h3>";
		for(String player : result.getPlayerNames())
			output += player + ": " + foldOnFlop.get(player) + "<br/>";
			
		output += "<h3>Wie häufig foldet ein Spieler auf dem Turn</h3>";
		for(String player : result.getPlayerNames())
			output += player + ": " + foldOnTurn.get(player) + "<br/>";
			
		output += "<h3>Wie häufig foldet ein Spieler auf dem River</h3>";
		for(String player : result.getPlayerNames())
			output += player + ": " + foldOnRiver.get(player) + "<br/>";
		
		return output;
	}

}
