package group5.resultevaluation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NumberOfGamesPlayed extends ResultEvaluator {


	
	
	@Override
	public String processResult() {
		// initialize map
		Map<String, Integer> gamesPlayed = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			gamesPlayed.put(player,0);
		
		// fill map
		for(ResultEntry entry : result.getEntries())
			for(String player : result.getPlayerNames())
				if(entry.playerSawFlop(player))
					gamesPlayed.put(player, gamesPlayed.get(player) + 1);
		
		String output = "<h1>Anzahl gespielter Spiele pro Bot</h1>";
		
		for(String player : result.getPlayerNames())
			output += player + " spielte: " + gamesPlayed.get(player) + " Spiele<br/>";
		
		// build goole chart
		String url = "http://chart.apis.google.com/chart?cht=bhs&chs=400x200&&chxt=x,y&chxp=0,0,100";
		
		// datavalues
		String dataValues = "&chd=t:";
		for(String player : result.getPlayerNames())
			dataValues += gamesPlayed.get(player) + ",";
		url += dataValues.substring(0,dataValues.length() - 1);
		
		// axis
		String axis = "&chxl=1:";
		List<String> playerNames = result.getPlayerNames(); 
		for(int i = playerNames.size() - 1; i >= 0; i--) // in reverse order
			axis +=  "|" + playerNames.get(i);
		axis += "|0:|0|" + String.valueOf(result.getNumberOfHands()) + "|" ;
		url += axis;
		
		// min and max
		url += "&chds=0," + String.valueOf(result.getNumberOfHands());
		
		// create imate
		output += "<img src=\"" + url + "\" />";
		
		return output;
	}

}
