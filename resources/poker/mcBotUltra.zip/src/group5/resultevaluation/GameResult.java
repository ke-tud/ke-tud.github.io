package group5.resultevaluation;

import java.util.HashMap;
import java.util.Map;

public class GameResult extends ResultEvaluator {

	@Override
	public String processResult() {
		// instantiate map
		Map<String, Integer> profit = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			profit.put(player, 0);
			
		for(ResultEntry entry : result.getEntries()){
			for(String player : result.getPlayerNames())
				profit.put(player, profit.get(player) + entry.getPlayersProfit(player));
		}
		
		String output = "<h1>Gesammtgewinn pro Spieler</h1>";
		
		for(String player : result.getPlayerNames())
			output += player + " gewinnt " + profit.get(player) + "<br/>";
		
		return output;
	}

}
