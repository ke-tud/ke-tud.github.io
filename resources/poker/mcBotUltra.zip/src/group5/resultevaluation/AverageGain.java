package group5.resultevaluation;

import java.util.HashMap;
import java.util.Map;

public class AverageGain extends ResultEvaluator {

	@Override
	public String processResult() {
		// instantiate map
		Map<String, Integer> profit = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			profit.put(player, 0);
			
		for(ResultEntry entry : result.getEntries()){
			for(String player : result.getPlayerNames())
				profit.put(player, profit.get(player) + entry.getPlayersProfit(player));
		}
		
		String output = "<h1>Durschnittlicher Gewinn pro Spieler</h1>";
		
		for(String player : result.getPlayerNames())
			output += player + " gewinnt " + profit.get(player) / (double) result.getNumberOfHands() + " im Durschnitt pro Hand<br/>";
		
		return output;
	}

}
