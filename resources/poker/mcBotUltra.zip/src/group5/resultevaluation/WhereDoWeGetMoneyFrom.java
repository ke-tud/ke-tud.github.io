package group5.resultevaluation;

import java.util.HashMap;
import java.util.Map;

public class WhereDoWeGetMoneyFrom extends ResultEvaluator {

	@Override
	public String processResult() {
		String thePlayer = "McBotUltra";
		
		Map<String, Integer> profits = new HashMap<String, Integer>();
		for(String player : result.getPlayerNames())
			if(!thePlayer.equals(player))
				profits.put(player, 0);
		
		for(ResultEntry entry: result.getEntries()){
			if(entry.getPlayersProfit(thePlayer) > 0){
				for(String player : result.getPlayerNames())
					if(!thePlayer.equals(player))
						profits.put(player, profits.get(player) + (-1*entry.getPlayersProfit(player)));
			} else if(entry.getPlayersProfit(thePlayer) < 0){
				profits.put(entry.getWinner(), profits.get(entry.getWinner()) + entry.getPlayersProfit(thePlayer));
			}
		}
		
		String output = "<h1>Von wem bekommen wir (" + thePlayer + ") Geld?</h1>";
		
		for(String player : result.getPlayerNames())
			if(!thePlayer.equals(player))
				output += player + ": " + profits.get(player) + "</br>";
		
		return output;
	}

}
