package group5.resultevaluation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

/**
 * Creates various statistics of all result files in data/results
 * @author Arno
 *
 */
public class ResultEvaluation {

	/**
	 * stores the path to the result files
	 */
	public final static String PATH_TO_RESULT_FILES = "data/results";
	
	/**
	 * 
	 */
	public final static String PATH_TO_ANALYSIS_RESULTS = "analysisresults";
	
	/**
	 * stores the path to the config file
	 */
	public final static String CONFIG_FILE = "src/resultevaluation.properties";
	
	/**
	 * Stores the config data
	 */
	private Properties properties;
	
	/**
	 * Stores the List with Evaluators
	 */
	private List<ResultEvaluator> evaluators = new LinkedList<ResultEvaluator>();
	
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) {
		ResultEvaluation eval = new ResultEvaluation();
		try {
			eval.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Performs the evaluation
	 * @throws Exception 
	 */
	public void run() throws Exception{
		loadConfig();
		loadEvaluators();
		clearAnalysisDirectory();
		
		// for each result file
		File results = new File(PATH_TO_RESULT_FILES);
		if(! results.isDirectory() )
			throw new Exception(PATH_TO_RESULT_FILES + " should be a directory." );
		for(File file : results.listFiles()){
			String[] fileParts = file.getName().split("\\.");
			String name = fileParts[0];
			for(int i = 1; i < fileParts.length - 1; i++)
				name += "." + fileParts[i];
			
			if(! fileParts[fileParts.length - 1].equals("log"))
				continue;
			
			// load result
			System.out.println("Analyse " + name);
			Result result = new Result(name);
			
			// loop over evaluators
			String output = "<html><head><title>" + name + "</title></head><body>";
			for(ResultEvaluator evaluator : evaluators){
				evaluator.setResult(result);
				output += evaluator.processResult();
			}
			output += "</body></html>";
			
			writeResult(output, result);
		}
		
		//
		System.out.println("analysis finished");
	}

	/**
	 * Removes all files from the directory
	 * @throws Exception 
	 */
	private void clearAnalysisDirectory() throws Exception {
		File f = new File(PATH_TO_ANALYSIS_RESULTS);
		if(! f.isDirectory())
			throw new Exception( PATH_TO_ANALYSIS_RESULTS + " should be a directory" );
		
		for(File file : f.listFiles())
			file.delete();
	}

	/**
	 * Writes the analysis to the specified position
	 * @param output
	 * @param result
	 * @throws IOException 
	 */
	private void writeResult(String output, Result result) throws IOException {
	    //use buffering
		File f = new File(PATH_TO_ANALYSIS_RESULTS + "/" + result.getName() + ".html");
	    Writer writer = new BufferedWriter(new FileWriter(f));
	    try {
	      //FileWriter always assumes default encoding is OK!
	    	writer.write( output );
	    }
	    finally {
	    	writer.close();
	    }
	}

	/**
	 * create the Result Evaluators
	 * @throws ClassNotFoundException 
	 * @throws NoSuchMethodException 
	 * @throws SecurityException 
	 * @throws InvocationTargetException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws IllegalArgumentException 
	 */
	private void loadEvaluators() throws ClassNotFoundException, SecurityException, NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
		String[] classes = properties.getProperty("evaluators").split(",");
		for(String className : classes){
			Class<ResultEvaluator> c = (Class<ResultEvaluator>) Class.forName("group5.resultevaluation." + className);
			Constructor<ResultEvaluator> constructor = c.getConstructor();
			evaluators.add(constructor.newInstance());
		}
	}

	/**
	 * loads the properties file
	 */
	private void loadConfig() {
		properties = new Properties();
		try {
			properties.load(new FileInputStream(CONFIG_FILE));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
