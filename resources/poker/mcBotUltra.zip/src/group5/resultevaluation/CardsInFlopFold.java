package group5.resultevaluation;

public class CardsInFlopFold extends ResultEvaluator {

	@Override
	public String processResult() {
		String thePlayer = "McBotUltra";
		
		String output = "<h1>Wir folden ab Flop??</h1>";
		
		for(ResultEntry entry: result.getEntries())
			if(entry.playerSawFlop(thePlayer)){
				if(entry.getPlayersProfit(thePlayer) <= -10)
					output += "<p style=\"background-color: #ce2222\">";
				else if(entry.getPlayersProfit(thePlayer) >= 10)
					output += "<p style=\"background-color: #22ce22\">";
				else
					output += "<p>";
				for(String player : entry.getPlayerNames())
					output += player + (entry.isBigBlind(player) ? "(bb)" : "" ) + (entry.isSmallBlind(player) ? "(sb)" : "" ) + "|";
				output += "<br/>" + entry.getAllCards() + "<br/>Gewinner: " + entry.getWinner() + "<br/>";
				if(! entry.getWinner().equals(thePlayer) && ! entry.playerWasInShowDown(thePlayer))
					output += "Wir folden auf: " + (entry.playerSawTurn(thePlayer) ? entry.playerSawRiver(thePlayer) ? "River" : "Turn" : "Flop") + "<br/>";
				output += entry.getBettingSequence();
				
				output += "<br/>" + entry.getProfitsLine();
				output += "</p>";
			} else if( entry.gameEndedOnPreFlop() ){
				output += "<p>";
				output += "Wir verlieren auf preflop.<br/>";
				for(String player : entry.getPlayerNames())
					output += player + (entry.isBigBlind(player) ? "(bb)" : "" ) + (entry.isSmallBlind(player) ? "(sb)" : "" ) + "|";
				output += "<br/>" + entry.getAllCards() + "<br/>Gewinner: " + entry.getWinner() + "<br/>";
				output += entry.getBettingSequence();
				output += "<br/>" + entry.getProfitsLine();
				output += "</p>";
			}
		
		return output;
	}

}
