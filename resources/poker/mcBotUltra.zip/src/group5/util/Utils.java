package group5.util;

public class Utils {

	public static void printArray(boolean[] a){
		System.out.print("[");
		for(boolean d : a)
			System.out.print(d ? "1," : "0,");
		System.out.println("]");
	}
	
	
	
	public static void printArray(int[] a){
		System.out.print("[");
		for(int d : a)
			System.out.print(d + ",");
		System.out.println("]");
	}
	
	public static void printArray(double[] a){
		System.out.print("[");
		for(double d : a)
			System.out.print(d + ",");
		System.out.println("]");
	}
}
