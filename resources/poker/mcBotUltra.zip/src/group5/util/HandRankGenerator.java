package group5.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

public class HandRankGenerator {

	static int i = 0;
	
	public static void main (String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new FileReader("etc/handorder.txt")); 

		String zeile;

	       while((zeile = in.readLine()) != null)
	    	   generateHandsForLine(zeile);
	}

	private static void generateHandsForLine(String zeile) {
		char[] charArray = zeile.toCharArray();
	
		
		if (charArray.length > 2) {
			for(Suit suit: Suit.values()){
				System.out.println("cardRank[" + i + "][0] = new Card( Rank." + getRank(charArray[0]) + ", Suit." + suit.name() + ");");
				System.out.println("cardRank[" + i + "][1] = new Card( Rank." + getRank(charArray[1]) + ", Suit." + suit.name() + ");");
				i++;
			}
		}
		else if (charArray[0] == charArray[1]) {
			for(Suit suit: Suit.values()){
				for(Suit suit2: Suit.values()){
					if(suit.compareTo(suit2) > 0){
						System.out.println("cardRank[" + i + "][0] = new Card( Rank." + getRank(charArray[0]) + ", Suit." + suit.name() + ");");
						System.out.println("cardRank[" + i + "][1] = new Card( Rank." + getRank(charArray[1]) + ", Suit." + suit2.name() + ");");
						i++;
					}
				}
			}
		}
		else {
			for(Suit suit: Suit.values()){
				for(Suit suit2: Suit.values()){
					if(suit.compareTo(suit2) != 0){
						System.out.println("cardRank[" + i + "][0] = new Card( Rank." + getRank(charArray[0]) + ", Suit." + suit.name() + ");");
						System.out.println("cardRank[" + i + "][1] = new Card( Rank." + getRank(charArray[1]) + ", Suit." + suit2.name() + ");");
						i++;
					}
				}
			}
		}
	}

	private static String getRank(char c) {
		switch(c){
		case '2':
			return "TWO";
		case '3':
			return "THREE";
		case '4':
			return "FOUR";
		case '5':
			return "FIVE";
		case '6':
			return "SIX";
		case '7':
			return "SEVEN";
		case '8':
			return "EIGHT";
		case '9':
			return "NINE";
		case 'T':
			return "TEN";
		case 'J':
			return "JACK";
		case 'Q':
			return "QUEEN";
		case 'K':
			return "KING";
		default:
			return "ACE";
		}
	}
}
