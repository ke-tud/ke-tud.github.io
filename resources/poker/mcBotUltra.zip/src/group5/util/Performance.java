package group5.util;

import java.util.Stack;

public class Performance {
	
	private static Stack<Double> time = new Stack<Double>();
	
	private static Stack<String> names = new Stack<String>();
	
	public static void start(String name){
		time.push(new Double(System.currentTimeMillis()));
		names.push(name);
	}
	
	public static void stop(){
		Double t = System.currentTimeMillis() - time.pop();
		String n = names.pop();
		
		System.out.println(n + " --- " + t + "ms");
	}
}
