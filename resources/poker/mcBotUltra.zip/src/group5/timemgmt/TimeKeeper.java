package group5.timemgmt;

public class TimeKeeper {

	private static TimeKeeper instance;
	
	private long timeLeft;
	private long timeUsed = 0;
	
	private long stopWatch = 0;
	
	protected TimeKeeper(){
		timeLeft = 6000*7*1000;
	}
	
	public static TimeKeeper getInstance(){
		if(null == instance)
			instance = new TimeKeeper();
		
		return instance;
	}
	
	public void startWork(){
		stopWatch = System.currentTimeMillis();
	}
	
	public void stopWork(){
		long result = (System.currentTimeMillis() - stopWatch);
		timeLeft -= result;
		timeUsed += result;
	}
	
	public long getTimeLeft(){
		return timeLeft;
	}
	
	public long getTimeUsed(){
		return timeUsed;
	}
	
	public double getPercentageUsed(){
		return ((double) this.timeUsed)/ (double)(6000*7*1000);
	}
	
	public String toString(){
		return "\nTime left: " + timeLeft + "\nTime used: " + timeUsed + " (" + 100*((double) this.timeUsed)/ (double)(6000*7*1000) + "%)";
	}
}
