package ca.ualberta.cs.poker.free.graph;

public interface TestConnection<A,B>{
  public boolean canConnect(A a, B b);
}
