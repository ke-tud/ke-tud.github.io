/*
 * AdvancedPokerClient.java
 *
 * Created on April 19, 2006, 10:19 AM
 */

package ca.ualberta.cs.poker.free.client;

import group5.bot.Bot;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;

import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

/**
 * An extension of PokerClient that contains a reference to a reproduction of what is happening on 
 * the server side (state).
 * Can overload takeAction() (instead of handleStateChange()) to only receive messages when it is
 * your turn to act.
 *
 * As before, actions can be taken with sendFold, sendCall(), and sendRaise()
 * @author Martin Zinkevich
 */
public class HalloPokerClient extends Bot {

    public String expert = "python pypoker/poker.py";
    public int debug_level = 1;
    public HalloPokerClient(int numPlayers, MatchType matchtype)
    {
 	   super(numPlayers, matchtype);
    }

    /*
     * Do what expert tells you to do
     */
    public void takeAction(boolean raiseAllowed, int totalPotSize, int amountToCall, long timeRemaining)
    {

    	
        try{
        	String answer_string = request(currentGameStateString);
        
        	
        	if (answer_string.equals("fold")) {
        		sendFold();
        	}
        	
        	if (answer_string.equals("call")){
        		sendCall();
        	}
        	
        	if (answer_string.equals("raise")){
        		sendRaise();
        	}
        	
        } catch (Exception e){
            System.out.println(e);
        }
    }
 
    /*
     * Ask expert what to do
     */
    public String request(String query) {

    	String out = "";
    	
    	try {
     		
     		String line;
     		Process p = Runtime.getRuntime().exec(expert + " " + query);
     		
     		BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream() ));
     		BufferedReader error = new BufferedReader(new InputStreamReader(p.getErrorStream() ));
     		
     		while ((line = input.readLine()) != null) {     			
     			out = out + line;
     		}
     		
     		if (debug_level > 0) {
     		
     			while ( ((line = error.readLine()) != null)) {
     				System.out.print("nene: ");
     				System.out.println(line);
     			}
     			
     		}
     		input.close();
      		error.close();

     		p.getInputStream().close();
     		p.getErrorStream().close();
      		
     		p.destroy();
    	}
    		
     	catch (Exception err) {
     		err.printStackTrace();
     	}     
     	return out;
     }
    
     
    public static void main(String[] args) throws Exception{
    	MatchType mt = new MatchType (LimitType.LIMIT, false, 8000, 1000); 
        HalloPokerClient hpc = new HalloPokerClient(6,mt);
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        hpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("HalloClient made a successful connection!");
        hpc.run();
    }
   
}