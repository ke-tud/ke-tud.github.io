###### RUN Verzeichnis #######

Hier liegen nützliche Skripte und Konfigurationsdateien

Ausführbare Skripte:
compile_bot.sh 		       - Compiliert den Bot in /src/ , generiert ein Tar Archiv und stellt es ins bots Verzeichnis
compile_halloclient.sh         - Compiliert den halloclient aus /bots/halloclient
compile_simple_player.sh/.bat  - Compiliert den SimpleBot aus dem /src/ Verzeichnis
run_pokerserver.sh/.bat        - Startet ein lokales Turnier mit 3 Bots, für Konfiguration siehe unten


Konfigurationsdateien:
match_config_..          - In dieser Datei werden die Bots definiert, die an einem Match teilnehmen sollen.    
                           Die Expansions Verzeichnisse sind temporäre Verzeichnisse die zur Laufzeit eines Spieles generiert werden.
                           In diesen Verzeichnissen werden Instanzen der Bots gestartet und hier sind auch die stdout und error Ausgaben 
                           der Bots zu finden (out.txt und err.txt).
                            
                           Neben der Pfadanpassungen sollten in der Regel nur eine Anpassung in den letzten Zeilen nötig sein, in denen
                           die teilnehmenden Bots definiert sind. Neben den bereits dokumentierten Angaben wird darauf hingewiesen, dass
                           mit <locationintarfile> der relative Pfad zum startme.sh/bat Skript gemeint ist. 

seating_order.txt        - Hier werden die Sitzplatzverteilungen der Bots festgelegt. Jede Nummer steht fuer ein Bot, dass nach der ersten
                           Verbindung zum Server festgelegt wird. Jede Zeile steht dabei für ein einzelnes Match mit der vorgegebenen 
                           Sitzplatzverteilung. 

