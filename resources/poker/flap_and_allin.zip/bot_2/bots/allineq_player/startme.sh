java -cp build:lib/pokerserver.jar mysrc.client.allineq.AllInEqPlayer  $1 $2


