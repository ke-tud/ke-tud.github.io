java -cp build:pokerserver.jar mysrc.client.allinpimp.AllInPIMP  $1 $2


