java -cp build:lib/pokerserver.jar flapyourwings.Client  $1 $2


