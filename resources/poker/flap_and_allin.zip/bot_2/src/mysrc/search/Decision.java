package mysrc.search;

public enum Decision {

	FOLD, CHECK_CALL, BET_RAISE;
}
