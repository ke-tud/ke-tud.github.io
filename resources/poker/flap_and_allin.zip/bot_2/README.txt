########### TUD Computer Poker Challenge 2009 ############

Dieses Verzeichnis enthält alle benötigen Dateien 
für die TUD Computer Poker Challenge 2009 im SS09.

In den folgenden Unterverzeichnissen sind enthalten:
run  -  Skripte für die Pokerserver- und Bot-Compilierung sowie
        für das Starten des Servers und Konfigurationsdateien

bots -  Sourcecode vom AKI-Bot, der Gewinner des letztjährigen 
        Praktikums und zweitplatzierter in der AAAI Competition 2008

doc  -  Dokumentation

lib  -  Der offizielle Pokerserver2.3.1 Sourcecode für 
        die Annual Computer Poker Competition.

src  -  Ein Basis-Framework eines Poker-Bots, dass 
        um nützliche Features aus der TUD Computer 
        Poker Challenge 2008 erweitert wurde.


Links:
https://www.ke.informatik.tu-darmstadt.de/students-wiki
http://www.ke.informatik.tu-darmstadt.de/lehre/ss09/challenge/
http://www.cs.ualberta.ca/~pokert/2009/

Stand: 24.03.09

