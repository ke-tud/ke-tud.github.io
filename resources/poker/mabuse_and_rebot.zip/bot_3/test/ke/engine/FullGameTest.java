package ke.engine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.junit.Test;

/**
 * Run a full test game
 */
public class FullGameTest {

	private File resultDir = new File(
			System.getProperty("user.dir") + 
			System.getProperty("file.separator")+
			"server" + 
			System.getProperty("file.separator")+
			"data" + 
			System.getProperty("file.separator") + 
			"results" + 
			System.getProperty("file.separator")
	);

	private File runDir = new File(
			System.getProperty("user.dir") + 
			System.getProperty("file.separator")+
			"run"
	);
	
	private File statusFile = new File(
			System.getProperty("user.dir") + 
			System.getProperty("file.separator")+
			"server" + 
			System.getProperty("file.separator")+
			"status.txt"
	);

	@Test
	public void runFullGame() throws IOException{
		
		System.out.print("Type 'p' to play a new game and see the results. Press 'enter' to see the results of the last game: ");
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in) );
		int s = in.read();
		if (s == Integer.valueOf('p')||s == Integer.valueOf('P')){
			if (System.getProperty("os.name").toLowerCase().contains("linux"))
				runOnLinux();
			else if(System.getProperty("os.name").toLowerCase().contains("windows"))
				runOnWindows();
			else{
				System.out.println("os not supported");
				System.exit(0);
			}
		}
		showResults();
	}

	private void showResults() {
		
		File[] resultFilesAll = this.resultDir.listFiles(new FileFilter(){
			@Override
			public boolean accept(File pathname) {
				return pathname.getName().endsWith(".res");
			}

		});
		
		Arrays.sort(resultFilesAll);
		/* i only need to get the last 6 files */
		File[] resultFiles = Arrays.copyOfRange(resultFilesAll, resultFilesAll.length - 6, resultFilesAll.length );
		
		BufferedReader br;
		StringBuffer sBuf = new StringBuffer();
		System.out.println("Resultfiles:");
		for (File f : resultFiles){
			try {
				System.out.println(f);
				br = new BufferedReader(new FileReader(f));
				sBuf.append(br.readLine());
				sBuf.append("\n");
				sBuf.append(br.readLine());
				sBuf.append("\n");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("\nResults:");
		System.out.println(sBuf);
		// only three players are supported
		int tempWin[] = new int[3];
		String tempName[] = new String[3];
		StringTokenizer st = new StringTokenizer(sBuf.toString(),"|\n");
		int winner = -1;
		int win;
		Map<String, Integer> absoluteWins= new HashMap<String, Integer>();
		
		while(st.hasMoreTokens()){
			// first three tokens should be integers
			tempWin[0] = Integer.parseInt(st.nextToken());
			tempWin[1] = Integer.parseInt(st.nextToken());
			tempWin[2] = Integer.parseInt(st.nextToken());
			// next three tokens should be Strings
			tempName[0] = st.nextToken();
			tempName[1] = st.nextToken();
			tempName[2] = st.nextToken();
			/* determine the winner */
			win = Math.max(tempWin[0], Math.max(tempWin[1], tempWin[2]));
			for (int i = 0; i < tempWin.length; i++){
				if (win == tempWin[i]) 
					winner = i;
				/*add the names to the map if it doesn't contains it yet*/
				if (!absoluteWins.containsKey(tempName[i]))
					absoluteWins.put(tempName[i], 0);
			}
			absoluteWins.put(tempName[winner], absoluteWins.get(tempName[winner]) + 1);
		}
		System.out.println("Wins: ");
		for (String s : absoluteWins.keySet())
			System.out.print(s + ": " + absoluteWins.get(s) + "\t");
		System.out.println("");
	}
	
	private void runOnLinux(){
		ProcessBuilder pb = new ProcessBuilder(this.runDir + System.getProperty("file.separator") + "run_tournament.py");
		String pOuts;
		Process p;
		long start = 0, end = 0;
		try {
			start = System.currentTimeMillis();
			System.out.println("Process started.");
			p = pb.start();
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			/* TODO: if possoible print the content of the status.txt to stdout
			BufferedReader in = new BufferedReader(new FileReader(this.statusFile));
			*/
			/* output is not exactly the same like in the shell 
			 * (i don't really know why but i think this is because 
			 * the script runs other processes and so on) 
			 */
			while ((pOuts = in.readLine()) != null){
				System.out.println(pOuts);
			}
			p.waitFor();
			System.out.println("Process ended.");
			end = System.currentTimeMillis();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		long timeNeeded = (end-start);
		long ms = timeNeeded % 100;
		long s = (timeNeeded / 1000) % 60;
		long m = (timeNeeded / 1000 / 60) % 60;
		long h = (timeNeeded / 1000 / 60 / 60);
		System.out.println("\n\nProcess ended. Time needed: "
				+ h  + "h "+
				+ m  + "m "+
				+ s  + "s "+
				+ ms  + "ms\n"
		);
	}

	private void runOnWindows(){
		System.out.println("not yet implemented");
		System.exit(0);
	}
	
}
