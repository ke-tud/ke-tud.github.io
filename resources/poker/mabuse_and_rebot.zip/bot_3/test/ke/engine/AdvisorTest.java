package ke.engine;

import static org.junit.Assert.assertSame;

import java.io.BufferedReader;
import java.io.StringReader;

import ke.data.Action;
import ke.data.ClientRingDynamics;
import ke.engine.strategies.CautiousOddsAdvisor;
import ke.engine.strategies.IStrategy;
import ke.engine.strategies.OddsAdvisor;
import ke.engine.strategies.OracleAdvisor;
import ke.engine.strategies.SimulatingOracleAdvisor;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;

import org.junit.Before;
import org.junit.Test;

import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;


/**
 *
 */
public class AdvisorTest {

	private final int playerId = 0;
	private ClientRingDynamics clientDynamics;
	private BufferedReader cardReader;
	/** cards to play 10 (random) hands */
	private final String cards = 
		"Kd2sKcQd5h8d5cAh5s3h6d" + "\n" +
		"Tc8s8dKd9cJcKc8cAs8h4d" + "\n" +
		"Ac7hKdJc9c2cQhKh5d3d9s" + "\n" +
		"KcTh4d4sTsTc6h4c7hKd8s" + "\n" +
		"6cTh5s7s5c6sAsAh4cTc4s" + "\n" +
		"9h8h3s2d4s5cAh8cQc8sAs" + "\n" +
		"5hQsTcQhJs3c8h6h2c3h4h" + "\n" +
		"Kc4s7s7d8h2dQd8d5cAc6h" + "\n" +
		"9d8h9sQh2s6c8c5s3cJs6d" + "\n" +
		"As6h4d8sAc9dQc2s8d9cAh"; 

	/**
	 * 
	 */
	@Before
	public void setUpNewGame() {

		this.cardReader = new BufferedReader(new StringReader(this.cards));

		final MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000);
		this.clientDynamics = new ClientRingDynamics(3, mt, null);
		this.clientDynamics.startHand(this.cardReader);
		this.clientDynamics.seatTaken = this.clientDynamics.playerToSeat(this.playerId);
		while(this.clientDynamics.seatToAct != this.clientDynamics.seatTaken)
			this.clientDynamics.handleCall();
	}

	/**
	 * everybody calls in this round
	 */
	private void nextRound(){
		/* my action */
		this.clientDynamics.handleCall();
	
		if(this.clientDynamics.handOver){
			this.clientDynamics.nextHand(this.cardReader);
			this.clientDynamics.seatTaken = this.clientDynamics.playerToSeat(this.playerId);
		}
		
		/* players action */
		while(this.clientDynamics.seatToAct != this.clientDynamics.playerToSeat(this.playerId) && !this.clientDynamics.handOver){
			this.clientDynamics.handleCall();
		}
		
		if(this.clientDynamics.handOver){
			this.clientDynamics.nextHand(this.cardReader);
			this.clientDynamics.seatTaken = this.clientDynamics.playerToSeat(this.playerId);
			/* players action */
			while(this.clientDynamics.seatToAct != this.clientDynamics.playerToSeat(this.playerId) && !this.clientDynamics.handOver)
				this.clientDynamics.handleCall();
		}
	}

	/**
	 * 
	 */
//	@Test
	public void nextRoundTest(){
		this.clientDynamics.handleCall();

		String after;

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);

		nextRound();
		after = this.clientDynamics.getMatchState(this.clientDynamics.seatToPlayer(this.playerId));
		System.out.println(after);
	}

	/**
	 * 
	 */
	@Test
	public void testOracleAdvisor(){
		final IStrategy rebot = new OracleAdvisor();
		rebot.evaluateSituation(new RingDynamicsState(this.clientDynamics));
		for (int i = 1; i < (8 * 5); i++){
			nextRound();
			rebot.evaluateSituation(new RingDynamicsState(this.clientDynamics));			
		}
	}
	
	/**
	 * 
	 */
//	@Test
	public void testRebotsExpert(){
		final IStrategy rebot = new CautiousOddsAdvisor();
		rebot.evaluateSituation(new RingDynamicsState(this.clientDynamics));
		for (int i = 1; i < (8 * 5); i++){
			nextRound();
			rebot.evaluateSituation(new RingDynamicsState(this.clientDynamics));			
		}
	}
	
	/**
	 * 
	 */
//	@Test
	public void testOddsAdvisor(){
		final IStrategy o = new OddsAdvisor();
		o.evaluateSituation(new RingDynamicsState(this.clientDynamics));
		for (int i = 1; i < (8 * 5); i++){
			nextRound();
			o.evaluateSituation(new RingDynamicsState(this.clientDynamics));			
		}
	}

	/**
	 * 
	 */
//	@Test
	public void testSimulatingOracleAdvisor(){
		final IStrategy sim = new SimulatingOracleAdvisor(null);		
		sim.evaluateSituation(new RingDynamicsState(this.clientDynamics));
		for (int i = 1; i < (8 * 5); i++){
			nextRound();
			sim.evaluateSituation(new RingDynamicsState(this.clientDynamics));
		}
	}
}
