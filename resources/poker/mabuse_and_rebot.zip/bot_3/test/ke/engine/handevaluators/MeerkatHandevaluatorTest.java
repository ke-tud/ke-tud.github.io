package ke.engine.handevaluators;

import org.junit.Test;

import poker.HandPotential;

import ke.engine.handevaluators.MeerkatHandevaluator;

import java.util.ArrayList;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class MeerkatHandevaluatorTest{

	private static final int UPN = 2;
//	@Test
	public void testEvaluation20(){
		
		System.out.println("\nTest Meerkat 2.0 Handevaluation with " + UPN + " unknwown opponent(s).");
		poker.Card c1 = new poker.Card(AllHandEvaluatorTests.getHoleCards().get(0).toString());
		poker.Card c2 = new poker.Card(AllHandEvaluatorTests.getHoleCards().get(1).toString());
		poker.Card c3 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(0).toString());
		poker.Card c4 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(1).toString());
		poker.Card c5 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(2).toString());
		poker.Card c6 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(3).toString());
		poker.Card c7 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(4).toString());

		poker.Hand h = new poker.Hand();

		poker.HandEvaluator hEval = new poker.HandEvaluator();
		long start,end, timeNeeded;
		double prBestHand; 

		System.out.println("");
		start = System.nanoTime();
		prBestHand = hEval.handRank(c1,c2, h,UPN);
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + prBestHand);
		System.out.println("Time hole Cards: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");

		/* Flop */
		h.addCard(c3);
		h.addCard(c4);
		h.addCard(c5);

		System.out.println("");
		start = System.nanoTime();
		prBestHand = hEval.handRank(c1,c2, h,UPN);
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + prBestHand);
		System.out.println("Time hole Cards and Flop: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");

		/* Turn */
		h.addCard(c6);

		System.out.println("");
		start = System.nanoTime();
		prBestHand = hEval.handRank(c1,c2, h,UPN);
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + prBestHand);
		System.out.println("Time hole Cards Flop and Turn: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");

		/* River */
		h.addCard(c7);

		System.out.println("");
		start = System.nanoTime();
		prBestHand = hEval.handRank(c1,c2, h,UPN);
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + prBestHand);
		System.out.println("Time hole Cards Flop, Turn and River: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");
	}

	@Test
	public void testWrappedEvaluation20(){
		System.out.println("\nTest Wrapped Meerkat 2.0 Handevaluation with " + UPN + " unknwown opponent(s).");
		
		IHandEvaluator handEval = new MeerkatHandevaluator();
		((MeerkatHandevaluator)handEval).setNumOpponents(UPN);

		long start, end, timeNeeded;
		double probBestHand = 0;
		
		System.out.println("");
		start = System.nanoTime();
		probBestHand = handEval.evaluateHand(AllHandEvaluatorTests.getHoleCards(), new ArrayList<Card>());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + probBestHand);
		System.out.println("Time for just hole Cards: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");

		System.out.println("");
		start = System.nanoTime();
		probBestHand = handEval.evaluateHand(AllHandEvaluatorTests.getHoleCards(), AllHandEvaluatorTests.getFlopBoardCards());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + probBestHand);
		System.out.println("Time hole Cards and Flop: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");
		
		System.out.println("");
		start = System.nanoTime();
		probBestHand = handEval.evaluateHand(AllHandEvaluatorTests.getHoleCards(), AllHandEvaluatorTests.getTurnBoardCards());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + probBestHand);
		System.out.println("Time hole Cards, Flop and Turn: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");
		
		System.out.println("");
		start = System.nanoTime();
		probBestHand = handEval.evaluateHand(AllHandEvaluatorTests.getHoleCards(), AllHandEvaluatorTests.getRiverBoardCards());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + probBestHand);
		System.out.println("Time hole Cards, Flop Turn and River: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");
		
	}

	/*
	//	@Test //Nullpointerexception... why??
	public void testEvaluation25(){
		System.out.println("\nTest Meerkat Handevaluation: ");
		com.biotools.meerkat.Card c1 = new com.biotools.meerkat.Card();
		com.biotools.meerkat.Card c2 = new com.biotools.meerkat.Card(com.biotools.meerkat.Card.ACE, com.biotools.meerkat.Card.CLUBS);

		com.biotools.meerkat.Card c3 = new com.biotools.meerkat.Card(com.biotools.meerkat.Card.ACE, com.biotools.meerkat.Card.SPADES);
		com.biotools.meerkat.Card c4 = new com.biotools.meerkat.Card(com.biotools.meerkat.Card.ACE, com.biotools.meerkat.Card.HEARTS);
		com.biotools.meerkat.Card c5 = new com.biotools.meerkat.Card(com.biotools.meerkat.Card.KING, com.biotools.meerkat.Card.DIAMONDS);
		com.biotools.meerkat.Card c6 = new com.biotools.meerkat.Card(com.biotools.meerkat.Card.QUEEN, com.biotools.meerkat.Card.DIAMONDS);
		com.biotools.meerkat.Card c7 = new com.biotools.meerkat.Card(com.biotools.meerkat.Card.JACK, com.biotools.meerkat.Card.DIAMONDS);

		com.biotools.meerkat.Hand h = new com.biotools.meerkat.Hand();
		//		h.addCard(c1);
		//		h.addCard(c2);
		h.addCard(c3);
		h.addCard(c4);
		h.addCard(c5);
		h.addCard(c6);
		h.addCard(c7);

		long start = System.nanoTime();
		double hrn = com.biotools.meerkat.HandEvaluator.handRank(c1, c2, h, 1);
		long end = System.nanoTime();

		System.out.println(hrn);
		System.out.println("Time Needed: " + (end-start));
	}
	*/
	
	@Test
	public void testHandpotential(){
		boolean full = true;
//		testHandPotential(full);
		full = false;
		testHandPotential(full);
		
	}
	 private void testHandPotential(boolean full){
			System.out.println("\nTest Meerkat 2.0 Handpotential.");
			poker.Card c1 = new poker.Card(AllHandEvaluatorTests.getHoleCards().get(0).toString());
			poker.Card c2 = new poker.Card(AllHandEvaluatorTests.getHoleCards().get(1).toString());
			poker.Card c3 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(0).toString());
			poker.Card c4 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(1).toString());
			poker.Card c5 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(2).toString());
			poker.Card c6 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(3).toString());
			poker.Card c7 = new poker.Card(AllHandEvaluatorTests.getRiverBoardCards().get(4).toString());

			poker.Hand h = new poker.Hand();
			double potential, potential2;
			HandPotential hp = new HandPotential();
			
			h.addCard(c3);
			h.addCard(c4);
			h.addCard(c5);
			
			potential = hp.ppot_raw(c1,c2, h,false);
			potential2 = hp.ppot_raw(c1, c2, h, full);
			System.out.println("Assuming i am behind now there's a crude " + potential*100 + "% chance i will be ahead as more board cards are dealt." );
			System.out.println("Assuming i am behind now there's a raw " + potential2*100 + "% chance i will be ahead as more board cards are dealt." );
			System.out.println(hp.getLastNPot());
			System.out.println(hp.getLastPPot());
			
			h.addCard(c6);
			
			potential = hp.ppot_raw(c1,c2, h,false);
			potential2 = hp.ppot_raw(c1, c2, h, full);
			System.out.println("Assuming i am behind now there's a crude " + potential*100 + "% chance i will be ahead as more board cards are dealt." );
			System.out.println("Assuming i am behind now there's a raw " + potential2*100 + "% chance i will be ahead as more board cards are dealt." );
			System.out.println(hp.getLastNPot());
			System.out.println(hp.getLastPPot());		
			
			h.addCard(c7);
			
			potential = hp.ppot_raw(c1,c2, h,false);
			potential2 = hp.ppot_raw(c1, c2, h, full);
			System.out.println("Assuming i am behind now there's a crude " + potential*100 + "% chance i will be ahead as more board cards are dealt." );
			System.out.println("Assuming i am behind now there's a raw " + potential2*100 + "% chance i will be ahead as more board cards are dealt." );
			System.out.println(hp.getLastNPot());
			System.out.println(hp.getLastPPot());
			
	 }
	
}

