package ke.engine.handevaluators;

import ke.engine.handevaluators.HoldEmShowdownHandEvaluator;

import org.junit.Test;

public class HoldEmShowdownHandevaluatorTest {

//	@Test
//	public void testEvaluation(){
//		Card c1 = new Card(Card.Rank.ACE, Card.Suit.CLUB);
//		Card c2 = new Card(Card.Rank.KING, Card.Suit.SPADE);
//		Card c3 = new Card(Card.Rank.ACE, Card.Suit.HEART);
//		Card c4 = new Card(Card.Rank.QUEEN, Card.Suit.DIAMOND);
//		Card c5 = new Card(Card.Rank.KING, Card.Suit.CLUB);
//		Card c6 = new Card(Card.Rank.EIGHT, Card.Suit.CLUB);
//		Card c7 = new Card(Card.Rank.FIVE, Card.Suit.CLUB);
//		
//		CardSet cs = new CardSet();
//		cs.add(c1);
//		cs.add(c2);
//		cs.add(c3);
//		cs.add(c4);
//		cs.add(c5);
//		cs.add(c6);
//		cs.add(c7);
//		
//		long encodedCs = HandEval.encode(cs);
//		System.out.println(encodedCs);
//		System.out.println(HandEval.hand7Eval(encodedCs));
//		System.out.println(HandEval.ranksMask(encodedCs));
//		System.out.println(HandEval.ranksMaskLo(encodedCs));
//		System.out.println("WTF???");
//		
//	}
	
	@Test
	public void testWrappedEvaluation(){
		System.out.println("\nTest Wrapped HoldEmShowndown Handevaluation with 1 unknwown opponent.");
		IHandEvaluator e = new HoldEmShowdownHandEvaluator();
		
		long start, end, timeNeeded;
		double chanceToWin = 0;
		
		System.out.println("");
		start = System.nanoTime();
//		chanceToWin = e.evaluate(AllHandEvaluatorTests.getHoleCards(), new ArrayList<Card>());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + chanceToWin);
		System.out.println("Time for just hole Cards: " + timeNeeded/1000000 + "ns  (Takes much to long)");
		
		System.out.println("");
		start = System.nanoTime();
		chanceToWin = e.evaluateHand(AllHandEvaluatorTests.getHoleCards(), AllHandEvaluatorTests.getFlopBoardCards());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + chanceToWin);
		System.out.println("Time hole Cards and Flop: " + timeNeeded/1000000 + "ns = " +((float)timeNeeded / 1000000) + "ms");
		
		System.out.println("");
		start = System.nanoTime();
		chanceToWin = e.evaluateHand(AllHandEvaluatorTests.getHoleCards(), AllHandEvaluatorTests.getTurnBoardCards());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + chanceToWin);
		System.out.println("Time hole Cards, Flop and Turn: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");
		
		System.out.println("");
		start = System.nanoTime();
		chanceToWin = e.evaluateHand(AllHandEvaluatorTests.getHoleCards(), AllHandEvaluatorTests.getRiverBoardCards());
		end = System.nanoTime();
		timeNeeded = end - start;
		System.out.println("Chance to win: " + chanceToWin);
		System.out.println("Time hole Cards, Flop Turn and River: " + timeNeeded + "ns = " +((float)timeNeeded / 1000000) + "ms");
	}
}
