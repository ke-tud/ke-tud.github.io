package ke.engine.handevaluators;



import java.util.ArrayList;
import java.util.List;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import ca.ualberta.cs.poker.free.dynamics.Card;
/**
 * Test all non simple hand-evaluators
 */
@RunWith(Suite.class)
@SuiteClasses(value = {
  HoldEmShowdownHandevaluatorTest.class, MeerkatHandevaluatorTest.class, SimplePreflopHandEvaluatorTest.class
})
public class AllHandEvaluatorTests {

	private static List<Card> hole = new ArrayList<Card>();
	private static List<Card> board = new ArrayList<Card>();
	
	static{
		hole.add(new Card(Card.Rank.SEVEN,Card.Suit.CLUBS));
		hole.add(new Card(Card.Rank.ACE,Card.Suit.CLUBS));
		
		board.add(new Card(Card.Rank.QUEEN,Card.Suit.SPADES));
		board.add(new Card(Card.Rank.ACE,Card.Suit.DIAMONDS));
		board.add(new Card(Card.Rank.JACK,Card.Suit.CLUBS));
		board.add(new Card(Card.Rank.ACE,Card.Suit.HEARTS));
		board.add(new Card(Card.Rank.QUEEN,Card.Suit.DIAMONDS));
	}
	
	public static List<Card> getHoleCards(){
		return hole;
	}
	
	public static List<Card> getFlopBoardCards(){
		return board.subList(0, 3);
	}
	
	public static List<Card> getTurnBoardCards(){
		return board.subList(0, 4);
	}
	
	public static List<Card> getRiverBoardCards(){
		return board;
	}
	

	
}
