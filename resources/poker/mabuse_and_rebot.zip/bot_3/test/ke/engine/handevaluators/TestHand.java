package ke.engine.handevaluators;

import static org.junit.Assert.*;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

import ke.engine.handevaluators.Hand;
import ke.engine.handevaluators.Hand.Rank;

import org.junit.Test;

import ca.ualberta.cs.poker.free.dynamics.Card;


public class TestHand {
	private static String[] decks = new String[] {
		"3s2s4s5s6s", // smallest straight flush
		"2s5s2c9h9c2h2d", // four of a kind (2)
		"ThTs2dTdAsAc6s2c", // full house (T-T-T-A-A)
		"6c2s2dTs6h6d", // full house (6-6-6-2-2)
		"9s5s2c9h9c2h2d9d", // four of a kind (2)
		"As3dAd9s2c7sTs6cKs", // Flush (s)
		"Js9cTd2d3h7c8d7c9s", // straight (7-8-9-T-J)
		"4h3s3h8s3cAs", // three of a kind (3)
		"Ts2s2h4dAsAd6d", // two pairs (2, A)
		"2h3hTd5dTsAs" // pair (T)
	};
	
	@Test
	public void testFullDeck() {
		System.out.println("Performance test on full deck:");
		Card[] cardArr = Card.getAllCards();
		Collection<Card> cards = new ArrayList<Card>(Arrays.asList(cardArr));
		Hand hand = Hand.forCards(cards);
		assertEquals(Rank.STRAIGHT_FLUSH, hand.getRank());
		
		long before = System.currentTimeMillis();
		int iterations = 10000;
		for(int i=0; i<iterations; i++) 
			hand = Hand.forCards(cards);
		
		System.out.println("Took "
				+(System.currentTimeMillis()-before)/(double) iterations
				+" milliseconds per iteration.");
		System.out.println();
	}
	
	@Test
	public void testSomeCards() {
		System.out.println("Testing given decks:");
		for(String deck : decks) {
			List<Card> cards = Arrays.asList(Card.toCardArray(deck));
			Collections.shuffle(cards); // Just for fun ;-)
			System.out.println(cards+" : "+Hand.forCards(cards));
		}
		
		System.out.println();
		System.out.println("Performance test on random decks:");
		int iterations = 10000;
		Hand hand = null;
		
		List<Collection<Card>> cards = new ArrayList<Collection<Card>>(iterations);
		for(int i=0; i<iterations; i++) 
			cards.add(Arrays.asList(Card.dealNewArray(new SecureRandom(), 5)));
		
		long before = System.currentTimeMillis();
		
		for(int i=0; i<iterations; i++) 
			hand = Hand.forCards(cards.get(i));
		
		System.out.println("Took "
				+(System.currentTimeMillis()-before)/(double) iterations
				+" milliseconds per iteration.");
		System.out.println();
		System.out.println("Probabilities: ");
		
		EnumMap<Hand.Rank, Integer> probs 
			= new EnumMap<Hand.Rank, Integer>(Hand.Rank.class);
		
		for(Hand.Rank rank : Hand.Rank.values())
			probs.put(rank,0);
		
		for(int i=0; i<iterations; i++) {
			hand = Hand.forCards(cards.get(i));
			probs.put(hand.getRank(),probs.get(hand.getRank())+1);
		}
		
		for(Hand.Rank rank : Hand.Rank.values())
			System.out.println(rank + ": "+probs.get(rank) / (double) iterations * 100 + " %");
	}
}
