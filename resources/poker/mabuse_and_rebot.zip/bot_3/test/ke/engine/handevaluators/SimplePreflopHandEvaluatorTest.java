package ke.engine.handevaluators;

import ke.engine.strategies.SimplePreflopAdvisor;

import org.junit.Test;

import ca.ualberta.cs.poker.free.dynamics.Card;


public class SimplePreflopHandEvaluatorTest {

	@Test
	public void testHandEvaluator(){
		SimplePreflopAdvisor advisor = new SimplePreflopAdvisor();
		
		advisor.evaluateHand(AllHandEvaluatorTests.getHoleCards().get(0), AllHandEvaluatorTests.getHoleCards().get(0));
		
		advisor.evaluateHand(new Card("As"), new Card("2s"));
		
		advisor.evaluateHand(new Card("As"), new Card("4d"));
		
		advisor.evaluateHand(new Card("2s"), new Card("As"));
		
		advisor.evaluateHand(new Card("2s"), new Card("Ad"));
		
		advisor.evaluateHand(new Card("Ks"), new Card("5d"));
		
		advisor.evaluateHand(new Card("Ac"), new Card("Qh"));
		
	}
	
}
