package ke.engine.handevaluators;

import java.util.ArrayList;

import org.junit.Test;


public class ConversionTests {

	
//	@Test
//	public void testMeerkatCards(){
//		/* print the string representations for the meerkat card objects */
//		System.out.println("\nCards from Meerkat:");
//		for (int i = 0; i < 13; i++){
//			for (int j = 0; j < 4; j++)
//				System.out.println(i + ":  ["+com.biotools.meerkat.Card.getRankChar(i)+com.biotools.meerkat.Card.getSuitChar(j)+"]");
//		}	
//	}
//	

//	@Test
//	public void testMeerkatHand(){
//		/* print the string representations for the meerkat card objects */
//		System.out.println("\nHand from Meerkat:");
//		com.biotools.meerkat.Hand hand = new com.biotools.meerkat.Hand();
//		hand.addCard(new com.biotools.meerkat.Card("3s"));
//		System.out.println(hand.getFirstCard());
//		System.out.println(hand.size());
//			
//	}
	
	
	@Test
	public void testSteveBrecherCards(){
		/* print the string representations for the meerkat card objects */
		System.out.println("\nCards from Steve Brecher:");
		com.stevebrecher.poker.Card.Rank[] r = com.stevebrecher.poker.Card.Rank.values();
		com.stevebrecher.poker.Card.Suit[] s = com.stevebrecher.poker.Card.Suit.values();
		for (com.stevebrecher.poker.Card.Rank rank : r){
			for (com.stevebrecher.poker.Card.Suit suit : s)
				System.out.println(rank.toChar() + "" + suit.toChar());
		}
	}
	
	
	public void testAlbertaCards(){
		/* print the string representations for the meerkat card objects */
		System.out.println("\nCards from Alberta:");
		for (int i = 0; i < 52; i++){
				System.out.println(i + ":  ["+ca.ualberta.cs.poker.free.dynamics.Card.getCardFromIndexRankMajor(i)+"]");
		}
	}
	
	@Test
	public void anotherTest(){
		System.out.println("\nAnd anotherTest:");
		int counter = 0;
		Integer[] ints = new Integer[5];
		ints[0] = 42; ints[3] = 815;
		for (Integer i : ints){
			System.out.println(i);
			if (i == null)
				continue;
			counter++;
		}
		System.out.println("sum: "+counter);
		ca.ualberta.cs.poker.free.dynamics.Card card = new ca.ualberta.cs.poker.free.dynamics.Card("Qs");
		System.out.println(ca.ualberta.cs.poker.free.dynamics.Card.Rank.ACE.index);
		System.out.println(card.rank.index);
	}
	
	@Test
	public void meerkatWrappedConversion(){
		MeerkatHandevaluator h = new MeerkatHandevaluator();
		long start = System.currentTimeMillis();
		ArrayList<ca.ualberta.cs.poker.free.dynamics.Card> holeCards = new ArrayList<ca.ualberta.cs.poker.free.dynamics.Card>(AllHandEvaluatorTests.getHoleCards());
		poker.Card hole1 = new poker.Card(holeCards.get(0).toString());
		poker.Card hole2 = new poker.Card(holeCards.get(1).toString());

		poker.Hand handBoard = new poker.Hand();
		for(ca.ualberta.cs.poker.free.dynamics.Card card : AllHandEvaluatorTests.getRiverBoardCards()){
			if (card == null)
				continue;
			handBoard.addCard(new poker.Card(card.toString()));
		}
		long end = System.currentTimeMillis();
		System.out.println((double)(end-start));
	}
}
