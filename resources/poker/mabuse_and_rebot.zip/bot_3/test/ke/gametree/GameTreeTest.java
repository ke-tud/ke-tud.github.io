package ke.gametree;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import ke.data.Action;
import ke.data.ClientRingDynamics;
import ke.data.Round;
import ke.gametree.GameTreeBuilder.ExpandNavigator;
import ke.gametree.GameTreeIterators.Path;
import ke.gametree.IGameTree.INavigator;
import ke.gametree.montecarlo.Factory;
import ke.gametree.montecarlo.IAgent;
import ke.gametree.montecarlo.MonteCarloSimulator;
import ke.gametree.montecarlo.MonteCarloState;
import ke.gametree.montecarlo.SimpleMonteCarloSimulator;
import ke.gametree.montecarlo.UCTSimulator;
import ke.gametree.montecarlo.Factory.ConsistencyError;
import ke.timermgmt.TimedLoop;
import ke.utils.DOTWriter;
import ke.utils.Utils;

import org.junit.Before;
import org.junit.Test;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

public class GameTreeTest {
	
	private static final int SEATTOACT = 1;

	private class IntState implements IGameState<IntState> {
		private final int val;
		public IntState(int val) {
			super();
			this.val = val;
		}

		@Override
		public IntState progress(Action action) {
			return new IntState(this.val+1);
		}		
		
		public int getVal() {
			return val;
		}

		@Override
		public ke.gametree.IGameState.ISeat getCurrentSeat() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public int getNumberActiveSeats() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int getNumberSeatLeftToAct() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int getNumberSeats() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public Round getRound() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public ke.gametree.IGameState.ISeat getSeat(int index) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Collection<Card> getBoard() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void dealRandomCards(Round round,
				int seatTaken) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public int getCurrentPotSize() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int getRoundBets() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public int getCurrentHandNumber() {
			// TODO Auto-generated method stub
			return 0;
		}



	}

	private IGameTree<IntState> tree;
	private IGameTree<RingDynamicsState> dynamicsTree;
	
	@Before
	public void setup() {
		IntState rootState = new IntState(0);
		GameTreeBuilder<IntState> tree = new GameTreeBuilder<IntState>(rootState);
		GameTreeBuilder<IntState>.ExpandNavigator navigator = tree.navigator();
		navigator.expand(Action.CALL);
		navigator.transit(Action.CALL);
		navigator.expand(Action.FOLD);
		navigator.transit(Action.FOLD);
		navigator.expand(Action.RAISE);
		this.tree = tree;
		
		RingDynamicsState dynRootState = new RingDynamicsState(GameStateTest.DYNAMICS);
		GameTreeBuilder<RingDynamicsState> dynamicsTree 
			= new GameTreeBuilder<RingDynamicsState>(dynRootState);
		GameTreeBuilder<RingDynamicsState>.ExpandNavigator 
			dynamicsNavigator = dynamicsTree.navigator();
		dynamicsNavigator.expand(Action.CALL);
		this.dynamicsTree = dynamicsTree;
	}
	
	@Test
	public void testRoot() {
		assertEquals(0, tree.getRoot().getVal());
	}

	@Test
	public void testGet() {
		List<Action> path = new ArrayList<Action>();
		path.add(Action.CALL);
		path.add(Action.FOLD);
		path.add(Action.RAISE);
		
		assertEquals(3, tree.get(path).getVal());
	}
	
	@Test
	public void testNavigator() {
		System.out.println(tree);
		ke.gametree.IGameTree.INavigator<IntState> navigator = tree.navigator();
		assertEquals(0, navigator.getCurrent().getVal());
		navigator.transit(Action.CALL);
		assertEquals(1, navigator.getCurrent().getVal());
//		assertFalse(navigator.transit(Action.RAISE));
		navigator.transit(Action.FOLD);
		assertEquals(2, navigator.getCurrent().getVal());
	}
	
	@Test
	public void testRingGame() {
		System.out.println(dynamicsTree);
	}
	
	@Test
	public void testSimulation() throws ConsistencyError {
		while(GameStateTest.DYNAMICS.seatToAct!=SEATTOACT)
			GameStateTest.DYNAMICS.handleRaise();
		test();
		GameStateTest.DYNAMICS.handleCall();
		while(GameStateTest.DYNAMICS.seatToAct!=SEATTOACT)
			GameStateTest.DYNAMICS.handleCall();
		test();
		GameStateTest.DYNAMICS.handleCall();
		while(GameStateTest.DYNAMICS.seatToAct!=SEATTOACT)
			GameStateTest.DYNAMICS.handleCall();
		test();
	}

	private void test() throws ConsistencyError {
		RingDynamicsState dynRootState = new RingDynamicsState(GameStateTest.DYNAMICS);
		final RandomAgent opponent = new RandomAgent(0.2d,0.5d,0.3d);
		final RandomAgent me = new RandomAgent(0.1d,0.5d,0.5d);
		
		final List<IAgent> agents = Arrays.asList(new IAgent[] {
				opponent,me,opponent});
		
	
		final GameTreeBuilder<MonteCarloState> tree = 
			Factory.createMonteCarloTree(dynRootState, 500, agents, SEATTOACT);
		
		final List<Action> callAction = Collections.singletonList(Action.CALL);
		final List<Action> raiseAction = Collections.singletonList(Action.RAISE);
		final List<Action> foldAction = Collections.singletonList(Action.FOLD);
		
		INavigator<MonteCarloState> navigator = tree.navigator();
		
		System.out.println("My cards: "+Arrays.toString(GameStateTest.DYNAMICS.hole[SEATTOACT]));
		System.out.println("On board: "+Arrays.toString(GameStateTest.DYNAMICS.board));
		System.out.println();
		System.out.println("Without UCT: ");
		System.out.println("------------");
		
		System.out.println("CALL "
				+(tree.get(callAction)!=null ? tree.get(callAction).
				getRatio() +" ("
				+tree.get(callAction).getRewards()+", "+tree.get(callAction).getValue()+")" : "unknown"));
		
		System.out.println("RAISE "
				+(tree.get(raiseAction)!=null ? tree.get(raiseAction).
				getRatio()+" ("
				+tree.get(raiseAction).getRewards()+", "+tree.get(raiseAction).getValue()+")" : "unknown"));
		
		System.out.println("FOLD "
				+(tree.get(foldAction)!=null ? tree.get(foldAction).
				getRatio()+" ("
				+tree.get(foldAction).getRewards()+", "+tree.get(foldAction).getValue()+")" : "unknown"));

		System.out.println();
		Path<?> bestIterator = new GameTreeIterators.BestValuePath(tree);
		Path<?> randomGoodIterator = new GameTreeIterators.RandomGoodValuePath(tree,GameTreeIterators.DEFENSIVE_QUANTIFIER);
		
		System.out.println("You should: "+ bestIterator.getNextAction()+"(best action)");
		System.out.println("You should: "+ randomGoodIterator.getNextAction()+"(random good action)");
		System.out.println();
		
		UCTSimulator improver1 = new UCTSimulator(tree, SEATTOACT,
				agents, 42);
		UCTSimulator improver2 = new UCTSimulator(tree, SEATTOACT,
				agents, 1);
		
		Collection<Runnable> tasks = Arrays.asList(new Runnable[] {improver1, improver2});
//		TimedLoop.fromRunnable(improver1).run(500);
		TimedLoop.fromRunnable(tasks).run(500);
		
		System.out.println("With UCT: ");
		System.out.println("------------");
		
		System.out.println("CALL "
				+(tree.get(callAction)!=null ? tree.get(callAction).
				getRatio() +" ("
				+tree.get(callAction).getRewards()+", "+tree.get(callAction).getValue()+")" : "unknown"));
		
		System.out.println("RAISE "
				+(tree.get(raiseAction)!=null ? tree.get(raiseAction).
				getRatio()+" ("
				+tree.get(raiseAction).getRewards()+", "+tree.get(raiseAction).getValue()+")" : "unknown"));
		
		System.out.println("FOLD "
				+(tree.get(foldAction)!=null ? tree.get(foldAction).
				getRatio()+" ("
				+tree.get(foldAction).getRewards()+", "+tree.get(foldAction).getValue()+")" : "unknown"));
		System.out.println();
		
		System.out.println();
		bestIterator = new GameTreeIterators.BestValuePath(tree);
		randomGoodIterator = new GameTreeIterators.RandomGoodRatioPath(tree);
		
		System.out.println("You should: "+ bestIterator.getNextAction()+"(best action)");
		System.out.println("You should: "+ randomGoodIterator.getNextAction()+"(random good action)");
		System.out.println();
		
	}

}
