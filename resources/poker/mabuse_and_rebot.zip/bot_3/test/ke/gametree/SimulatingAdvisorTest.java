package ke.gametree;


import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumMap;

import ke.client.ClientRingStateParser;
import ke.data.Action;
import ke.data.ClientRingDynamics;
import ke.engine.strategies.IStrategy;
import ke.engine.strategies.SimulatingOracleAdvisor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

@RunWith(Parameterized.class)
public class SimulatingAdvisorTest {
	private final String cards;
	private final int seat;
	
	@Parameters
	public static Collection<Object[]> data() {
		return Arrays.asList(
				
				new Object[][] {
						{ "Kd2sKcQd5h8d5cAh5s3h6d", Integer.valueOf(1) },
						{ "Kd2sKcQd5h8d5cAh5s3h6d", Integer.valueOf(0) }
				}
				);
	}

	public SimulatingAdvisorTest(final String cards, final int seat) {
		super();
		this.cards = cards;
		this.seat = seat;
	}
	
	private static ClientRingDynamics getClientRingDynamics(
			final String cards, final int seat) {
		BufferedReader cardReader = 
			new BufferedReader(new StringReader(cards));
		MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000);
		RingDynamics globalDynamics = 
			new RingDynamics(3,mt,new String[]{"ich","du","er"});
		globalDynamics.startHand(cardReader);
		
		ClientRingStateParser crsp = new ClientRingStateParser();
		ClientRingDynamics result = new ClientRingDynamics(3, mt, crsp);
		result.setFromMatchStateMessage(
				globalDynamics.getMatchState(seat));
		
		return result;
	}
	
	private void results(final ClientRingDynamics dynamics) {
		EnumMap<Action, Integer> actions 
		= new EnumMap<Action, Integer>(Action.class);
	
	for(Action action : Action.values())
		actions.put(action, Integer.valueOf(0));

		for(int i=0; i<5; i++) {
			// Shut up for a moment
			PrintStream out = System.out;
			System.setOut(new PrintStream(new ByteArrayOutputStream()));
			IStrategy advisor = new SimulatingOracleAdvisor(null);
			advisor.evaluateSituation(new RingDynamicsState(dynamics));
			System.setOut(out);
			final Action action = advisor.getAction();
			final int number = actions.get(action).intValue();
			actions.put(action, Integer.valueOf(number+1));
		}
		
		for(Action action : actions.keySet())
			System.out.println(action+": "+actions.get(action));
	}
	
	
	@Test
	public void testAdvisor() {
		ClientRingDynamics dynamics = 
			getClientRingDynamics(this.cards, this.seat);
		
		while(dynamics.roundIndex<3) {
			System.out.println();
			System.out.println("Round: "+dynamics.roundIndex);
			System.out.println("Cards in hole: "+
					Arrays.toString(dynamics.hole[this.seat]));
			System.out.println("Cards in board: "+
					Arrays.toString(dynamics.board));
			System.out.println();
			
			results(dynamics);
			while(dynamics.seatTaken!=dynamics.seatToAct)
				dynamics.handleCall();
			dynamics.handleCall();
		}
	}
}
