package ke.gametree;

import java.io.BufferedReader;
import java.io.StringReader;
import java.security.SecureRandom;

import ke.data.Action;
import ke.data.Round;

import org.junit.Before;
import org.junit.Test;

import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;


public class GameStateTest {
	private RingDynamicsState state;
	/** cards to play 10 (random) hands */
	private final static String CARDS =
//			"AcKc4dQhJs3cQcJcTc9c8c" + "\n" +
			"Kd2sKcQc5h8d5cAhTs3h6d" + "\n" +
			"Tc8s8dKd9cJcKc8cAs8h4d" + "\n" +
			"Ac7hKdJc9c2cQhKh5d3d9s" + "\n" +
			"KcTh4d4sTsTc6h4c7hKd8s" + "\n" +
			"6cTh5s7s5c6sAsAh4cTc4s" + "\n" +
			"9h8h3s2d4s5cAh8cQc8sAs" + "\n" +
			"5hQsTcQhJs3c8h6h2c3h4h" + "\n" +
			"Kc4s7s7d8h2dQd8d5cAc6h" + "\n" +
			"9d8h9sQh2s6c8c5s3cJs6d" + "\n" +
			"As6h4d8sAc9dQc2s8d9cAh";
	private final static BufferedReader 
		CARDREADER = new BufferedReader(new StringReader(CARDS));
	public final static RingDynamics DYNAMICS = new RingDynamics(3,	new MatchType(LimitType.LIMIT, false, 8000, 1000),
			new String[] {"Hans","Peter","Franz","John"});
	static {
		DYNAMICS.startHand(CARDREADER);
	}

	
	
	@Before
	public void setup() {
		state = new RingDynamicsState(DYNAMICS);
	}
	
	@Test
	public void testProgress() {
		System.out.println(state.getCurrentSeat());
		RingDynamicsState newState = state.progress(Action.FOLD);
		System.out.println(newState.getCurrentSeat());
		newState = newState.progress(Action.FOLD);
		System.out.println(newState.getCurrentSeat());
	}
	
	@Test
	public void testRound(){
		for(Round r : Round.values()){
			System.out.println(r + "-->" + r.getNextRound());
			System.out.println(r + ": " + r.getLimitBet());
		}
	}
}
