package ke.gametree;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import ke.gametree.montecarlo.IAgent;
import ke.gametree.montecarlo.MonteCarloSimulator;
import ke.gametree.montecarlo.MonteCarloState;
import ke.gametree.montecarlo.SimpleMonteCarloSimulator;
import ke.utils.DOTWriter;

import org.junit.Test;

public class WriteSampleDOT {
	
	private static final int SEATTAKEN = 0;
	
	public static void main(String[] args) throws IOException {
		
		while(GameStateTest.DYNAMICS.seatToAct!=SEATTAKEN)
			GameStateTest.DYNAMICS.handleCall();
		
		GameStateTest.DYNAMICS.handleCall();
		
		while(GameStateTest.DYNAMICS.seatToAct!=SEATTAKEN)
			GameStateTest.DYNAMICS.handleCall();		
		RingDynamicsState dynRootState = new RingDynamicsState(GameStateTest.DYNAMICS);
		final RandomAgent opponent = new RandomAgent(1d,0d,0d);
		final RandomAgent me = new RandomAgent(0d,1d,0d);
		
		final List<IAgent> agents = new ArrayList<IAgent>();
		for(int i=0; i<3; i++)
			
			if(i==SEATTAKEN) {
				agents.add(me);
			} else
				agents.add(opponent);

		GameTreeBuilder<MonteCarloState> tree 
		= new GameTreeBuilder<MonteCarloState>(new MonteCarloState(dynRootState));
		
		MonteCarloSimulator simulator = new SimpleMonteCarloSimulator(tree, SEATTAKEN,
				agents);
//		UCTSimulator simulator = new UCTSimulator(tree, SEATTOACT,
//				agents,42);
		for(int i=0; i<10; i++)
			simulator.run();
		
		final Writer writer = new FileWriter("test.dot");
		DOTWriter.writeTree(tree, SEATTAKEN, writer);
		
	}
}
