package ke.timermgmt;

import java.security.SecureRandom;
import ke.data.Action;
import ke.data.GameState;
import org.junit.Test;


/**
 *
 */
public class TimeManagerTest {

	/**
	 * @throws InterruptedException 
	 * 
	 */
	@Test
	public void test() throws InterruptedException{

		SecureRandom rand = new SecureRandom();

		TimeManager t = TimeManager.getInstance();

		GameState gs = GameState.PREFLOP;

		for(int i = 0; i < 10; i++){

			System.out.println("--------"+gs+"--------------");
			t.startTurn();
			t.stateChanged(gs);
			t.startTurn();
			t.newHand();
			final int requests = rand.nextInt(3)+1;
			for (int c=0; c < requests; c++){
				t.startTurn();
				t.incrementRequests();
				Thread.sleep(t.getRecDuration());
			}

			t.incrementRequests();
			System.out.println("recommended duration:" + t.getRecDuration());
			Thread.sleep(t.getRecDuration());
			t.reCalculateRemainingTimes();

			if (gs.nextState().equals(GameState.SHOWDOWN)){
				t.roundFinished(0, 0, null, null, null, null);
				gs = GameState.PREFLOP;
			}
			else{
				gs = gs.nextState();
			}

			for (int j = 0; j < 3; j++){
				System.out.println("--------"+gs+"--------------");
				t.startTurn();
				t.stateChanged(gs);
				final int requests0 = rand.nextInt(3)+1;
				for (int c=0; c < requests0; c++){
					t.startTurn();
					t.incrementRequests();
					Thread.sleep(t.getRecDuration());
				}
				t.startTurn();
				t.incrementRequests();
				System.out.println("recommended duration:" + t.getRecDuration());
				Thread.sleep(t.getRecDuration());
				t.reCalculateRemainingTimes();

				if (gs.nextState().equals(GameState.SHOWDOWN)){
					t.roundFinished(0, 0, null, null, null, null);
					gs = GameState.PREFLOP;
				}
				else{
					gs = gs.nextState();
				}
			}

			t.startTurn();
			t.roundFinished(0, 0,null,null,null, null);
		}
	}
}
