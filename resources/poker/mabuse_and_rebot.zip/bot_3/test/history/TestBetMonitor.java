package history;

import ke.data.Action;
import ke.data.GameState;
import ke.history.BetMonitor;

import org.junit.Test;

public class TestBetMonitor {

	@Test
	public void test(){
		
		BetMonitor b = BetMonitor.getInstance();
		
		b.stateChanged(GameState.PREFLOP);
		
		b.actionPerformed(0, 0, Action.RAISE);
		
		b.stateChanged(GameState.FLOP);
		
		b.actionPerformed(0, 0, Action.RAISE);
		
		System.out.println(b.getWindowData().getAvgBetsOverall());
		
		b.roundFinished(0,0,null,null,null,null);
		
		b.stateChanged(GameState.PREFLOP);
		
		b.actionPerformed(0, 0, Action.RAISE);
		
		b.stateChanged(GameState.FLOP);
		
		b.actionPerformed(0, 0, Action.RAISE);
		
		b.roundFinished(0,0,null,null,null,null);
		
		System.out.println(b.getWindowData().getAvgBetsOverall());
	}
	
}
