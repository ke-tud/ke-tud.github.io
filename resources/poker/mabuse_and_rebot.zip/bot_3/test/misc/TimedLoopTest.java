package misc;

import org.junit.Test;

import ke.timermgmt.TimedLoop;

public class TimedLoopTest {
	private static class TestLoop extends TimedLoop {
		private int i=0;
		@Override
		protected void task() {
			
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if((i%10)==0)
			System.out.println(i++);
		}
		
	}
	private TimedLoop loop;
	
	@Test
	public void test() {
		this.loop = new TestLoop();
		loop.run(500);
	}
}
