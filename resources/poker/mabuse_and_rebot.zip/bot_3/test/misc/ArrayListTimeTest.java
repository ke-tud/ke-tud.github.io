package misc;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;

import ca.ualberta.cs.poker.free.dynamics.Card;


public class ArrayListTimeTest {

	@Test
	public void testConvertion(){
		Card[] testArray = new Card[1000];
		
		for(int i = 0; i < testArray.length; i++){
			if (i % 5 == 0)
				continue;
			else
				testArray[i] = new Card("As");
		}
		
		long start = System.nanoTime();
		
		for (Card card : testArray){
			continue;
		}
		
		long end = System.nanoTime();
		float timeNeeded1 = end-start;
		
		System.out.println("Time needed for Array: " + timeNeeded1 + " ns");
		
		start = System.nanoTime();
		
		Collection<Card> testArrayList = Arrays.asList(testArray); 
		
		for (Card card : testArrayList){
			continue;
		}
		
		end = System.nanoTime();
		
		float timeNeeded2 = end-start;
		System.out.println("Time needed for ArrayList: " + timeNeeded2 + " ns");
		System.out.println("Faster: " + ((Math.min(timeNeeded1, timeNeeded2) == timeNeeded1) ? "Array" : "ArrayList"));
		System.out.println("Difference: " + (timeNeeded2 - timeNeeded1) + " ns");
		System.out.println("Difference in ms: " + (timeNeeded2 - timeNeeded1)/1000000 + " ms");
		
	}
	
}
