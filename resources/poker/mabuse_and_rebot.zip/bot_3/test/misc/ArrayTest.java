package misc;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class ArrayTest {

	private static Card[] cards = Card.getAllCards();
	
	private static void test1(Card[] array) {
		for(Card card : array) {
			card = null;
		}
			
	}
	
	private static void test2(List<Card> list) {
		for(Card card : list) {
			card = null;
		}
	}
	
	public static void main(String[] args) {
		long before = System.currentTimeMillis();
		List<Card> cardList = null;
		int iterations = 1000;
		for(int i=0; i<iterations; i++) 
			cardList = Arrays.asList(cards);
		
		System.out.println("Took "
				+(System.currentTimeMillis()-before)/(double) iterations
				+" milliseconds per iteration.");
		
		before = System.currentTimeMillis();
		
		for(int i=0; i<iterations; i++) 
			test1(cards);
		
		System.out.println("Took "
				+(System.currentTimeMillis()-before)/(double) iterations
				+" milliseconds per iteration.");

		before = System.currentTimeMillis();
		
		for(int i=0; i<iterations; i++) 
			test2(cardList);
		
		System.out.println("Took "
				+(System.currentTimeMillis()-before)/(double) iterations
				+" milliseconds per iteration.");
	}

}
