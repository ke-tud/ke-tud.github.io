java -cp build:lib/pokerserver.jar:lib/meerkat-api-2.0.jar: ke.client.rebot.RebotPlayer  $1 $2 simpleoracle
