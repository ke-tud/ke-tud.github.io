java -cp build:lib/pokerserver.jar ke.client.simple.SimplePlayer  $1 $2


