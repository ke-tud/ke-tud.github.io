java -cp build:lib/pokerserver.jar ke.client.timed.TimedPlayer  $1 $2


