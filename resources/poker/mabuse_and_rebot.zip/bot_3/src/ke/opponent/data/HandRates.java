package ke.opponent.data;

import java.util.EnumMap;

import ke.data.Round;

/**
 * This is a counter implementation for
 * a single hand with separated values for
 * each round.
 */
public class HandRates {
	/* The number of a specific action per round */
	private final EnumMap<Round, Integer> rates
	= new EnumMap<Round, Integer>(Round.class);
	{
		for(final Round round : Round.values())
			this.rates.put(round, Integer.valueOf(0));
	}

	/**
	 * Increases the action counter for the
	 * given round.
	 * 
	 * @param round round to modify
	 */
	public void increase(final Round round) {
		Integer old = this.rates.get(round);
		if(old==null) old = Integer.valueOf(0);

		this.rates.put(round, Integer.valueOf(old.intValue()+1));
	}

	/**
	 * Checks, if the given round is available.
	 * 
	 * @param round round to check availability
	 * @return true, if round data is available; false, if not
	 */
	public boolean available(final Round round) {
		return (this.rates.get(round)!=null);
	}

	/**
	 * Gets the number of actions took in the
	 * given round.
	 * 
	 * @param round given round
	 * @return number of actions, or -1, if no
	 * data exists.
	 */
	public int getRate(final Round round) {
		final Integer result = this.rates.get(round);
		if(result==null) return -1;

		return result.intValue();
	}
}
