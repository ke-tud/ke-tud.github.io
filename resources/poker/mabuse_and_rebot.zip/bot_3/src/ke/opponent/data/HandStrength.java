package ke.opponent.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

import ke.data.GameState;
import ke.data.Round;
import ke.engine.handevaluators.IHandEvaluator;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.history.EliminationMonitor;
import ke.utils.Utils;
import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * The HandStrength describes the strength (winning
 * probability) of a certain hand in the specific
 * betting rounds.
 */
public class HandStrength {
	private final EnumMap<Round, Double> strength
	= new EnumMap<Round, Double>(Round.class);

	/**
	 * Creates a new hand strength table evaluating
	 * the given cards.
	 * 
	 * @param evaluator evaluator to evaluate cards
	 * @param hole hole cards
	 * @param board board cards
	 */
	public HandStrength(final IHandEvaluator evaluator,
			final Collection<Card> hole, final Collection<Card> board) {
		final List<Card> boardList = new ArrayList<Card>(board);
		for(final Round round : Round.values())
			if(round!=Round.SHOWDOWN) { // Showdown rounds will not be evaluated
				Collection<Card> subBoard = null;
				if(round==Round.PREFLOP)
					subBoard = Collections.emptyList(); // No cards on board
				else {
					final int numberCards = round.getIndex() + 2;
					if(boardList.size()>=numberCards) // Sufficient cards?
						if(boardList.get(numberCards-1)!=null) {// Last card must not be null
							subBoard = new ArrayList<Card>();
							for(int i=0; i<boardList.size(); i++)
								subBoard.add(boardList.get(i));

						}
				}
				if(subBoard!=null) {
					GameState state = Utils.roundToGameState(round);
					int numActive = 
						EliminationMonitor.getInstance().getGlobalData().getNumberActivePLayersInStateLastRound(
							state);
					((MeerkatHandevaluator)evaluator).setNumOpponents(numActive - 1);
					double handValue = evaluator.evaluateHand(hole, subBoard);
					final double[] potentials = evaluator.evaluatePotential(hole, subBoard, false);
					handValue += potentials[0]-potentials[1];
					handValue = Math.max(0, Math.min(1, handValue));

					this.strength.put(round, Double.valueOf(handValue));
				}
			}
	}

	/**
	 * Returns the strength of this hand in the given
	 * round.
	 * 
	 * @param round given betting round (street)
	 * @return the strength
	 */
	public double getStrength(final Round round) {
		final Double result = this.strength.get(round);
		if(result==null) return -1;

		return result.doubleValue();
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		for(final Round round : this.strength.keySet())
			builder.append(round+": "+this.strength.get(round)+"\n");
		return builder.toString();
	}
}
