package ke.opponent.data;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;

import ke.data.Round;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 * This class represents a table associating the number of
 * bets with the hand strength of an opponent. This implementation
 * should be tolerant to opponent strategy changes but not safe
 * against outlier data.
 */
public class StrengthEstimates {
	protected class RoundData{
		private final HashMap<Integer, Double> estimates =
			new HashMap<Integer, Double>();
		private final HashSet<Integer> actualData =
			new HashSet<Integer>();

		/**
		 * Gets the estimated strength for a given number of
		 * bets.
		 * 
		 * @param numberBets number of bets
		 * @return estimated strength as double, -1 if data is
		 * unavailable or not trustworthy.
		 */
		public double getEstimate(final int numberBets) {
			if(this.estimates.get(Integer.valueOf(numberBets))==null)
				if(!this.actualData.contains(Integer.valueOf(numberBets)))
					return -1;
			return this.estimates.get(Integer.valueOf(numberBets)).doubleValue();
		}

		/**
		 * Adds a new observation to the estimation model.
		 * 
		 * @param numberBets number of bets observed
		 * @param newEstimate strength observed
		 */
		public void addObservation(final int numberBets, final double newEstimate) {
			final double oldEstimate = getEstimate(numberBets);
			final Integer key = Integer.valueOf(numberBets);

			if(oldEstimate==-1) // First one
				this.estimates.put(key, Double.valueOf(newEstimate));
			else {
				this.estimates.put(key,Double.valueOf((oldEstimate+newEstimate)/2d));

				Debug.log(Option.OPP_OBSERVATION, "Old value: "+oldEstimate+", new value: "+newEstimate+"; difference: "+(oldEstimate-newEstimate));

				if(Math.abs(oldEstimate-newEstimate)<0.1) this.actualData.add(key);
				else this.actualData.remove(key);
			}
		}
	}

	private final EnumMap<Round, RoundData> data
	= new EnumMap<Round, RoundData>(Round.class);
	{
		for(final Round round : Round.values())
			this.data.put(round, new RoundData());
	}

	/**
	 * Returns the data for the given round and number of bets.
	 * 
	 * @param round given round
	 * @param numberBets number of bets
	 * @return round data
	 */
	public double getRoundEstimate(final Round round, final int numberBets) {
		return this.data.get(round).getEstimate(numberBets);
	}

	/**
	 * Adds an observed strength to the table.
	 * 
	 * @param rates number of bets in this hand
	 * @param strengths strengths in this hand
	 */
	public void addObservation(final HandRates rates, final HandStrength strengths) {
		for(final Round round : Round.values()) {
			final RoundData roundData = this.data.get(round);
			final int rate = rates.getRate(round);
			final double strength = strengths.getStrength(round);

			if(strength<0) continue;
			if(rate<0) continue;

			roundData.addObservation(rate, strength);
		}
	}
}

