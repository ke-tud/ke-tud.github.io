package ke.opponent;

import java.util.Arrays;
import java.util.HashMap;

import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.GameState;
import ke.data.Round;
import ke.engine.handevaluators.IHandEvaluator;
import ke.gametree.IGameState.ISeat;
import ke.utils.Utils;
import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * This observer (IStateChangeListener) class builds a list
 * of opponents from its observation of incoming events.
 */
public class OpponentBuilder implements IStateChangeListener {

	private final HashMap<Integer, Opponent> opponents;
	private final IHandEvaluator handEvaluator;
	private Round currentRound;

	/** {@inheritDoc} */
	@Override
	public void actionPerformed(final int seat, final int player, final Action action) {
		final Opponent opponent = getOpponent(player);
		if(action==Action.CALL)
			opponent.addCallObservation(this.currentRound);
		else if(action==Action.RAISE)
			opponent.addRaiseObservation(this.currentRound);
	}

	/** {@inheritDoc} */
	@Override
	public void roundFinished(final int ownID, final int playerAtSeatZero, final int[] amountWon,
			final int[] inPot, final Card[][] hole, final Card[] board) {
		final Card[][] playerHole = Utils.sortHoles(hole, playerAtSeatZero);
		for(final Integer player : this.opponents.keySet())
			this.opponents.get(player).endHand(
					this.handEvaluator,
					Arrays.asList(playerHole[player.intValue()]),
					Arrays.asList(board));

	}

	/** {@inheritDoc} */
	@Override
	public void stateChanged(final GameState state) {
		this.currentRound = Utils.gameStateToRound(state);
	}

	/**
	 * Returns the opponent with the given index number.
	 * 
	 * @param player player index number
	 * @return the opponent model for this player index
	 */
	public Opponent getOpponent(final int player) {
		Opponent opponent = this.opponents.get(Integer.valueOf(player));
		if(opponent==null) {
			opponent = new Opponent();
			this.opponents.put(Integer.valueOf(player), opponent);
		}
		return opponent;
	}

	/**
	 * Returns the opponent for the given seat.
	 * 
	 * @param seat seat of the player
	 * @return the opponent model for this seat
	 */
	public Opponent getOpponent(final ISeat seat) {
		return getOpponent(seat.getPlayerIndex());
	}

	/**
	 * Creates a new OpponentBuilder with the given
	 * hand evaluator.
	 * 
	 * @param handEvaluator evaluator for the observed
	 * cards (shown at the end of every hand)
	 */
	public OpponentBuilder(final IHandEvaluator handEvaluator) {
		super();
		this.opponents = new HashMap<Integer, Opponent>();
		this.handEvaluator = handEvaluator;
	}
}