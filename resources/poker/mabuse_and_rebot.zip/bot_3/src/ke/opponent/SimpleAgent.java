package ke.opponent;

import java.util.Arrays;

import ke.data.Action;
import ke.gametree.IGameState;
import ke.gametree.montecarlo.IAgent;
import ke.utils.Debug;
import ke.utils.Utils;
import ke.utils.Debug.Option;

/**
 * A simple opponent model using fold/call/raise ratios
 * for offline knowledge and the probability of the
 * best hand as online knowledge.
 */
public class SimpleAgent implements IAgent {
	private final double[][] ratios;
	private final double probBestHand;

	/*
	 * Calculates an estimated profit with simple pot odds.
	 */
	//	private static double calculateSimplePotOdds(final double prob,
	//			final IGameState<?> dynamics) {
	//		int inPot = dynamics.getCurrentPotSize();
	//
	//		final int nextCall = dynamics.getCurrentSeat().getAmountToCall(); // Costs of another call
	//
	//		final double profit = prob * inPot + (1-prob)*(-nextCall);
	//		return profit;
	//	}

	/**
	 * Creates a new SimpleOpponent instance with the given
	 * parameters.
	 * 
	 * @param ratios call/raise/fold-ratio array with
	 * street in the first and action (indexed 0=raise,
	 * 1=call, 2=fold) in the second dimension.
	 * @param probBestHand probability of this player having
	 * the best cards.
	 */
	public SimpleAgent(final double[][] ratios,
			final double probBestHand) {
		super();
		this.ratios = ratios.clone();
		this.probBestHand = probBestHand;

		Debug.log(Option.GAME_OPPONENT_RATIOS, "Ratios: "+Arrays.deepToString(ratios)
				+ ", Prob. Best Hand: "+probBestHand);
	}

	/** {@inheritDoc} */
	@Override
	public Action getAction(final IGameState<?> state) {
		final double raiseRatio = this.ratios[state.getRound().getIndex()][0];
		final double foldRatio = this.ratios[state.getRound().getIndex()][2];
		final double callRatio = 1 - raiseRatio - foldRatio;

		//		final double profit = calculateSimplePotOdds(this.probBestHand, state);
		//		final

		double foldProb = (1-this.probBestHand) * foldRatio;
		double callProb = this.probBestHand * callRatio;
		double raiseProb = this.probBestHand * raiseRatio;

		final double sum = foldProb + callProb + raiseProb;
		foldProb = foldProb / sum;
		callProb = callProb / sum;
		raiseProb = raiseProb / sum;

		return Utils.getRandomAction(foldProb, callProb, raiseProb);
	}


}
