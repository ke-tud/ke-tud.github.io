package ke.opponent;

import java.util.Collection;

import ke.data.Round;
import ke.engine.handevaluators.IHandEvaluator;
import ke.opponent.data.HandRates;
import ke.opponent.data.HandStrength;
import ke.opponent.data.StrengthEstimates;
import ke.utils.Debug;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * This class provides the observed data of an
 * opponent.
 */
public class Opponent {
	private HandRates callRates
	= new HandRates();
	private HandRates raiseRates
	= new HandRates();
	private final StrengthEstimates callEstimates
	= new StrengthEstimates();
	private final StrengthEstimates raiseEstimates
	= new StrengthEstimates();

	/*
	 * Gets the given rates
	 */
	private int getRates(final Round round, final HandRates rates) {
		if(rates==null) return -1; // No data at all
		return rates.getRate(round);
	}

	/**
	 * Returns the number of calls for this
	 * hand in the given round.
	 * 
	 * @param round given round
	 * @return number of calls in that round
	 */
	public int getCurrentCalls(final Round round) {
		final HandRates rates = this.callRates;
		return getRates(round, rates);
	}

	/**
	 * Returns the number of raises for this
	 * hand in the given round.
	 * 
	 * @param round given round
	 * @return number of raises in that round
	 */
	public int getCurrentRaises(final Round round) {
		final HandRates rates = this.raiseRates;
		return getRates(round, rates);
	}

	/**
	 * Returns the estimated hand strength for the given
	 * number of call actions.
	 * 
	 * @param round betting round
	 * @param numberCalls number of call actions
	 * in that round
	 * @return the estimated hand strength or -1, if
	 * data is unavailable
	 */
	public double getCallEstimates(final Round round, final int numberCalls) {
		return this.callEstimates.getRoundEstimate(round, numberCalls);
	}

	/**
	 * Returns the estimated hand strength for the given
	 * number of raise actions.
	 * 
	 * @param round betting round
	 * @param numberRaises number of raise actions
	 * in that round
	 * @return the estimated hand strength or -1, if
	 * data is unavailable
	 */
	public double getRaiseEstimates(final Round round, final int numberRaises) {
		return this.raiseEstimates.getRoundEstimate(round, numberRaises);
	}

	/**
	 * Increases the CALL counter for the given
	 * round.
	 * 
	 * @param round the round this observation was made
	 */
	public void addCallObservation(final Round round) {
		Debug.log(Option.OPP_OBSERVATION,
				"Observed CALL in round "+round);

		this.callRates.increase(round);

		Debug.log(Option.OPP_OBSERVATION,
				"New value after observation: "+
				this.callRates.getRate(round));
	}

	/**
	 * Increases the RAISE counter for the given
	 * round.
	 * 
	 * @param round the round this observation was made
	 */
	public void addRaiseObservation(final Round round) {
		Debug.log(Option.OPP_OBSERVATION,
				"Observed RAISE in round "+round);

		this.raiseRates.increase(round);

		Debug.log(Option.OPP_OBSERVATION,
				"New value after observation: "+
				this.raiseRates.getRate(round));
	}

	/**
	 * Ends the current hand and stores it to persistent
	 * memory.
	 * 
	 * @param handEvaluator evaluator for showdown cards
	 * @param hole showdown hole
	 * @param board board cards
	 */
	public void endHand(final IHandEvaluator handEvaluator,
			final Collection<Card> hole, final Collection<Card> board) {
		// Skip Useless observation
		if(hole!=null)
			if(!hole.isEmpty()) {
				final HandStrength strengths = new HandStrength(handEvaluator, hole, board);

				Debug.log(Option.OPP_OBSERVATION, strengths);

				this.callEstimates.addObservation(
						this.callRates, strengths);
				this.raiseEstimates.addObservation(
						this.raiseRates, strengths);
			}

		// New hand data
		Debug.log(Option.OPP_OBSERVATION, "Clearing online data");
		this.callRates = new HandRates();
		this.raiseRates = new HandRates();
	}
}
