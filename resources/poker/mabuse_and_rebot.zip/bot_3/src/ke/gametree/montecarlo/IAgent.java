package ke.gametree.montecarlo;

import ke.data.Action;
import ke.gametree.IGameState;

public interface IAgent {
	public Action getAction(final IGameState<?> state);
}
