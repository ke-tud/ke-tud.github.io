/**
 * 
 */
package ke.gametree.montecarlo;

import java.util.Collection;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ke.data.Action;
import ke.data.Round;
import ke.gametree.IGameState;

/**
 *
 */
public class PotExplorerState implements IGameState<PotExplorerState>{

	private long potSize;
	
	private long potCosts;
	
	/**
	 * Constructor
	 * @param base
	 */
	public PotExplorerState(final IGameState<?> base) {
		this.base = base;
		this.potCosts = 0l;
		this.potSize = 0l;
	}
	
	/**
	 * @return average 
	 */
	public double getAvgPotSize(){
		return ((double)this.potSize) / this.iterations;
	}
	
	/**
	 * @return average
	 */
	public double getAvgCosts(){
		return ((double)this.potCosts) / this.iterations;
	}
	
	/**
	 * @param currentPotSize
	 */
	public void addPot(final int currentPotSize){
		this.potSize += currentPotSize;
	}
	
	/**
	 * @param currentCosts
	 */
	public void addCosts(final int currentCosts){
		this.potCosts += currentCosts;
	}
	
	/* The contained base state */
	private final IGameState<?> base;

	/* number of iterations passing this state */
	private int iterations = 0;
	/* number of rewards granted to this state */
	private int rewards = 0;
	/* (utility) value of this state */
	private double value = 0.0d;

	/** {@inheritDoc} **/
	@Override
	public PotExplorerState progress(final Action action) {
		final IGameState<?> baseProgress = this.base.progress(action);

		if(baseProgress==null)
			return null;
		return new PotExplorerState(baseProgress);
	}

	/**
	 * Returns the base state of this
	 * monte carlo state.
	 * 
	 * @return base state
	 */
	public IGameState<?> getBase() {
		return this.base;
	}

	/**
	 * Rewards this state by increasing
	 * reward and iteration counter.
	 */
	public void reward() {
		// FIXME These transition should be atomic
		this.iterations++;
		this.rewards++;
	}

	/**
	 * Passes this state by increasing
	 * only the iteration counter.
	 */
	public void pass() {
		this.iterations++;
	}

	/**
	 * Adds a given addend to this state's
	 * value.
	 * 
	 * @param addend value to be add to the
	 * value
	 */
	public void addValue(final double addend) {
		this.value += addend;
	}

	/**
	 * Returns the value of this state.
	 * 
	 * @return value of this state
	 */
	public double getValue() {
		return this.value / this.iterations;
	}

	/**
	 * Returns the reward/iterations ratio of
	 * this state.
	 * 
	 * @return ratio of this state
	 */
	public double getRatio() {
		return ((double) this.rewards) / this.iterations;
	}

	/**
	 * Returns the number of iterations of
	 * this state.
	 * 
	 * @return number of iterations
	 */
	public int getIterations() {
		return this.iterations;
	}


	/**
	 * Returns the number of rewards of
	 * this state.
	 * 
	 * @return number of rewards
	 */
	public int getRewards() {
		return this.rewards;
	}

	/** {@inheritDoc} **/
	@Override
	public String toString() {
		return this.rewards+"/"+this.iterations+" ("+getValue()+")";
	}

	/** {@inheritDoc} **/
	@Override
	public int getNumberSeatLeftToAct() {
		return this.base.getNumberSeatLeftToAct();
	}

	/** {@inheritDoc} **/
	@Override
	public int getNumberSeats() {
		return this.base.getNumberSeats();
	}

	/** {@inheritDoc} **/
	@Override
	public Round getRound() {
		return this.base.getRound();
	}
	/** {@inheritDoc} */
	@Override
	public int getCurrentPotSize(){
		return this.base.getCurrentPotSize();
	}

	/** {@inheritDoc} **/
	@Override
	public ke.gametree.IGameState.ISeat getSeat(final int index) {
		return this.base.getSeat(index);
	}

	/** {@inheritDoc} **/
	@Override
	public ke.gametree.IGameState.ISeat getCurrentSeat() {
		return this.base.getCurrentSeat();
	}

	/** {@inheritDoc} **/
	@Override
	public int getNumberActiveSeats() {
		return this.base.getNumberActiveSeats();
	}

	/** {@inheritDoc} **/
	@Override
	public Collection<Card> getBoard() {
		return this.base.getBoard();
	}

	/** {@inheritDoc} **/
	@Override
	public void dealRandomCards(Round round,
			int seatTaken) {
		this.base.dealRandomCards(round, seatTaken);
	}
	
	/** {@inheritDoc} **/
	@Override
	public int getRoundBets() {
		return this.base.getRoundBets();
	}
	
	/** {@inheritDoc} **/
	@Override
	public int getCurrentHandNumber() {
		return this.base.getCurrentHandNumber();
	}
}
