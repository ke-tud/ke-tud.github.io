package ke.gametree.montecarlo;

import java.util.List;
import java.util.Random;

import ke.data.Action;
import ke.gametree.GameTreeBuilder;
import ke.gametree.IGameState.ISeat;
import ke.utils.Utils;

public class BayesianSimulator extends MonteCarloSimulator {
	final private Random random = new Random();
	
	private final double probBestHand;
	/* UCT constant */
	private final double UCTK;

	/*
	 * Selects the next action from UCT algorithm.
	 */
	@Override
	protected Action selectAction(final MonteCarloState state) {
		if(state.getCurrentSeat().getIndex()!=getSeatTaken())
			return UCTSelection();
		
		return agentSelection();
	}
	
	private Action agentSelection() {
		// Get a successor action for this state
		final IAgent agent = getAgents().
		get(getNavigator().getCurrent().getBase().getCurrentSeat().getIndex());
		final Action action = agent.getAction(getNavigator().getCurrent());
		
		return action;		
	}
	
	private Action UCTSelection() {
		/*
		 * Based on Valkyria-UCT
		 * (http://senseis.xmp.net/?UCT)
		 */
		double bestUCT = 0.0d;
		Action bestAction = null;
		
		for(final Action action : Action.values()) {
			final MonteCarloState next
			= getNavigator().getNext(action);

			if(next==null) return agentSelection(); // Unexplored node -> expand with agent
			if(next.getIterations()>0) {
				final double ratio = next.getRatio();
				final int currentIterations = getNavigator().getCurrent().getIterations();
				final double uct = this.UCTK*Math.sqrt(Math.log(currentIterations)/(5.0d * next.getIterations()));
				final double uctValue = ratio + uct;

				if(uctValue > bestUCT) {
					bestUCT = uctValue;
					bestAction = action;
				}

			} else return agentSelection();

		}
		
		if(bestAction!=null)
			return bestAction;
		return agentSelection();
	}


	
	public BayesianSimulator(GameTreeBuilder<MonteCarloState> builder,
			int seatTaken, List<IAgent> agents, final double probBestHand,
			final double UCTK) {
		super(builder, seatTaken, agents);
		this.probBestHand = probBestHand;
		this.UCTK = UCTK;
	}

	/* (non-Javadoc)
	 * @see ke.gametree.montecarlo.MonteCarloSimulator#getAmountWon(ke.gametree.IGameState.ISeat)
	 */
	@Override
	protected int getAmountWon(ISeat seat) {
		if(this.random.nextDouble()<this.probBestHand)
			return seat.getStakes();
		
		return -seat.getStakes();
	}
}
