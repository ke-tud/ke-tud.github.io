package ke.gametree.montecarlo;

import java.util.List;

import ke.gametree.GameTreeBuilder;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;
import ke.timermgmt.TimedLoop;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 * Factory class that creates game tree from seeding
 * game states.
 */
public class Factory {

	/**
	 * This error is thrown, if parameter are
	 * inconsistent.
	 */
	public static class ConsistencyError extends Error {
		private static final long serialVersionUID = -3569967342513783882L;

		/**
		 * Creates a new ConsistencyError.
		 */
		public ConsistencyError() {
			super();
		}

		/** {@inheritDoc} **/
		@Override
		public String getMessage() {
			return "Context inconsistency";
		}

	}

	/**
	 * Creates a new monte carlo tree from specific
	 * parameters.
	 * 
	 * @param seed seeding game state (RingDynamics)
	 * @param milliseconds duration of the creation
	 * @param agents models of the simulated seats
	 * @param seatTaken index of the deciding seat
	 * @return a new game tree
	 * @throws ConsistencyError Consistency error, if
	 * parameters are inconsistent (not enough agents
	 * or index greater than number of seats)
	 */
	public static GameTreeBuilder<MonteCarloState> createMonteCarloTree(
			final RingDynamics seed, final long milliseconds,
			final List<IAgent> agents, final int seatTaken)
			throws ConsistencyError {
		return createMonteCarloTree(
				new RingDynamicsState(seed),milliseconds, agents, seatTaken);
	}

	/**
	 * Creates a new monte carlo tree from specific
	 * parameters.
	 * 
	 * @param seed seeding game state
	 * @param milliseconds duration of the creation
	 * @param agents models of the simulated seats
	 * @param seatTaken index of the deciding seat
	 * @return a new game tree
	 * @throws ConsistencyError Consistency error, if
	 * parameters are inconsistent (not enough agents
	 * or index greater than number of seats)
	 */
	public static GameTreeBuilder<MonteCarloState> createMonteCarloTree(
			final IGameState<?> seed, final long milliseconds,
			final List<IAgent> agents, final int seatTaken)
			throws ConsistencyError {

		// Check consistency
		final int numPlayers = agents.size();
		if(numPlayers!=seed.getNumberSeats() || seatTaken >= numPlayers)
			throw new ConsistencyError();

		final GameTreeBuilder<MonteCarloState> builder
		= new GameTreeBuilder<MonteCarloState>(
				new MonteCarloState(seed));


		final MonteCarloSimulator task = 
			new SimpleMonteCarloSimulator(builder, seatTaken, agents);
		TimedLoop.fromRunnable(task).run(milliseconds);

		return builder;
	}

	/**
	 * Creates a new monte carlo tree with UCT simulation
	 * from specific parameters.
	 * 
	 * @param seed seeding game state (RingDynamics)
	 * @param milliseconds duration of the creation
	 * @param agents models of the simulated seats
	 * @param seatTaken index of the deciding seat
	 * @param UCTK UCT constant: greater value for more
	 * exploration
	 * @return a new game tree
	 * @throws ConsistencyError Consistency error, if
	 * parameters are inconsistent (not enough agents
	 * or index greater than number of seats)
	 */
	public static GameTreeBuilder<MonteCarloState> createUCTTree(
			final RingDynamics seed, final long milliseconds,
			final List<IAgent> agents, final int seatTaken, final double UCTK)
			throws ConsistencyError {
		return createUCTTree(
				new RingDynamicsState(seed),milliseconds, agents, seatTaken,UCTK);
	}

	/**
	 * Creates a new monte carlo tree with UCT simulation
	 * from specific parameters.
	 * 
	 * @param seed seeding game state
	 * @param milliseconds duration of the creation
	 * @param agents models of the simulated seats
	 * @param seatTaken index of the deciding seat
	 * @param UCTK UCT constant: greater value for more
	 * exploration
	 * @return a new game tree
	 * @throws ConsistencyError Consistency error, if
	 * parameters are inconsistent (not enough agents
	 * or index greater than number of seats)
	 */
	public static GameTreeBuilder<MonteCarloState> createUCTTree(
			final IGameState<?> seed, final long milliseconds,
			final List<IAgent> agents, final int seatTaken, final double UCTK)
			throws ConsistencyError {

		// Check consistency
		final int numPlayers = agents.size();
		if(numPlayers!=seed.getNumberSeats() || seatTaken >= numPlayers)
			throw new ConsistencyError();

		final GameTreeBuilder<MonteCarloState> builder
		= new GameTreeBuilder<MonteCarloState>(
				new MonteCarloState(seed));


		final MonteCarloSimulator task = new UCTSimulator(builder, seatTaken, agents,UCTK);
		TimedLoop.fromRunnable(task).run(milliseconds);

		return builder;
	}

	/*
	 * Do not instantiate.
	 */
	private Factory() {
		// Empty constructor
	}
}
