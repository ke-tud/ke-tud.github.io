package ke.gametree.montecarlo;

import java.util.List;

import ke.data.Action;
import ke.data.Round;
import ke.gametree.GameTreeBuilder;
import ke.gametree.IGameState.ISeat;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 * Abstract base class of all monte carlo simulators.
 */
public abstract class MonteCarloSimulator implements Runnable {
	/*
	 * Result type of recursion.
	 */
	private static class ResultType {
		private final boolean won;
		private final int amountWon;

		public boolean hasWon() {
			return this.won;
		}

		public int getAmountWon() {
			return this.amountWon;
		}

		public ResultType(final boolean won, final int amountWon) {
			super();
			this.won = won;
			this.amountWon = amountWon;
		}

	}

	/* game tree builder for this simulation */
	protected final GameTreeBuilder<MonteCarloState> builder;
	/* deciding seat in this simulation */
	protected final int seatTaken;
	/* models of seats */
	protected final List<IAgent> agents;

	/* navigator pointing at last state */
	private GameTreeBuilder<MonteCarloState>.
	ExpandNavigator navigator;
	
	private final Round initialRound;

	/*
	 * Returns the game tree builder.
	 */
	protected final GameTreeBuilder<MonteCarloState> getBuilder() {
		return this.builder;
	}

	/*
	 * Returns the deciding seat in this
	 * simulation.
	 */
	protected final int getSeatTaken() {
		return this.seatTaken;
	}

	/*
	 * Returns the seat models in this
	 * simulation.
	 */
	protected final List<IAgent> getAgents() {
		return this.agents;
	}

	/*
	 * Returns the navigator pointing at
	 * the deepest relevant game state.
	 */
	protected final GameTreeBuilder<MonteCarloState>.ExpandNavigator getNavigator() {
		return this.navigator;
	}

	/*
	 * Selects the next action in the given state.
	 */
	protected abstract Action selectAction(MonteCarloState state);

	/*
	 * Gets the amount won by the seat.
	 */
	protected int getAmountWon(final ISeat seat) {
		this.navigator.getCurrent().dealRandomCards(this.initialRound, this.seatTaken);
		
		final int amountWon = seat.getAmountWon();
		return amountWon;
	}

	/*
	 * Recursive method that checks the value in this state
	 * by performing a deep search.
	 */
	private ResultType checkState(final MonteCarloState state) {
		// Get next action
		final Action action = selectAction(state);
		
		Debug.log(Option.MC_MY_ACTION, state.getCurrentSeat().getIndex()+": "+ (state.getCurrentSeat().getIndex()==getSeatTaken() ? action : "-"));
		Debug.log(Option.MC_OPPONENT_ACTION, state.getCurrentSeat().getIndex()+": "+ (state.getCurrentSeat().getIndex()!=getSeatTaken() ? action : "-"));
		
		Debug.log(Option.MC_STREET, state.getRound());
		Debug.log(Option.MC_ACTIVE_SEATS, Integer.valueOf(state.getNumberActiveSeats()));
		
		if((getNavigator().getNext(action)==null)) {
			// Next state is unexplored
			final ISeat seat = state.getSeat(getSeatTaken());
			if((!seat.isActive())
					|| !getNavigator().expand(action)) {
				// Leaf state, calculate values and continue
				Debug.log(Option.MC_SHOWDOWN_CARDS, "Board: "+state.getBoard()+"\n"
						+ "Hole "+state.getSeat(getSeatTaken()).getPlayerIndex()+": "+state.getSeat(getSeatTaken()).getHoles());
				
				final int amountWon = getAmountWon(seat);
				
				Debug.log(Option.MC_WIN, "My amount: "+amountWon);
				
				state.addValue(amountWon);
				if(amountWon>=0) {
					state.reward();
					return new ResultType(true, amountWon);
				}
				state.pass();
				return new ResultType(false, amountWon);
			}
		}

		// Check next state
		getNavigator().transit(action);
		final ResultType nextResult = checkState(getNavigator().getCurrent());
		state.addValue(nextResult.getAmountWon());

		// Backtracking part:
		if(nextResult.hasWon()) {
			// Got reward from next state
			state.reward();
			return new ResultType(true, nextResult.getAmountWon());
		}
		// Didn't get reward
		state.pass();
		return new ResultType(false, nextResult.getAmountWon());
	}

	/** {@inheritDoc} **/
	@Override
	public void run() {
		// Initialize navigator
		this.navigator = this.builder.navigator();
		
		// Initialize start states
		if(this.navigator.getNext(Action.CALL)==null)
			this.navigator.expand(Action.CALL);
		if(this.navigator.getNext(Action.RAISE)==null)
			this.navigator.expand(Action.RAISE);
		if(this.navigator.getNext(Action.FOLD)==null) {
			this.navigator.expand(Action.FOLD);
			initialFold();
		}
		
		Debug.log(Option.MC_INITIAL_CARDS, "Board: "
				+this.navigator.getCurrent().getBoard()+"\n"
				+ "Hole"
				+this.navigator.getCurrent().getSeat(getSeatTaken()).getPlayerIndex()+": "
				+this.navigator.getCurrent().getSeat(getSeatTaken()).getHoles());
		
		
		// Start recursion
		this.navigator.transit(Action.CALL);
		checkState(this.navigator.getCurrent());
		this.navigator = this.builder.navigator();
		this.navigator.transit(Action.RAISE);
		checkState(this.navigator.getCurrent());
	}

	private void initialFold() {
		if(this.navigator.getCurrent().getSeat(getSeatTaken()).getStakes()>0)
			this.navigator.getNext(Action.FOLD).pass();
		else
			this.navigator.getNext(Action.FOLD).reward();
		this.navigator.getNext(Action.FOLD).addValue(
				-this.navigator.getCurrent().getSeat(getSeatTaken()).getStakes());
	}


	/**
	 * Creates a new MonteCarloSimulator for the given
	 * game tree builder.
	 * 
	 * @param builder game tree builder as base for the
	 * simulation.
	 * @param seatTaken deciding seat for the simulation
	 * @param agents agents to model the hand's seats
	 */
	public MonteCarloSimulator(
			final GameTreeBuilder<MonteCarloState> builder,
			final int seatTaken, final List<IAgent> agents) {
		super();

		this.builder = builder;
		this.seatTaken = seatTaken;
		this.agents = agents;
		this.initialRound = builder.getRoot().getRound();
	}


}