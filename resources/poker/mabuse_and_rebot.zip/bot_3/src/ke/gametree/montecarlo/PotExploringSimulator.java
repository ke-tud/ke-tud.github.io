package ke.gametree.montecarlo;

import java.security.SecureRandom;
import java.util.List;
import java.util.Random;

import ke.data.Action;
import ke.data.Round;
import ke.gametree.GameTreeBuilder;
import ke.gametree.IGameState.ISeat;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 * Abstract base class of all monte carlo simulators.
 */
public class PotExploringSimulator implements Runnable {
	/*
	 * Result type of recursion.
	 */
	private static class ResultType {
		private final boolean won;
		private final int amountWon;
		private final int potSize;
		private final int potCosts;

		public boolean hasWon() {
			return this.won;
		}

		public int getAmountWon() {
			return this.amountWon;
		}

		public int getPotSize() {
			return this.potSize;
		}

		public int getCostSize() {
			return this.potCosts;
		}

		
		public ResultType(final boolean won, final int amountWon, final int potSize, final int potCosts) {
			super();
			this.won = won;
			this.amountWon = amountWon;
			this.potCosts = potCosts;
			this.potSize = potSize;
		}

	}
	
	final private SecureRandom random = new SecureRandom();
	
	private final double probBestHand;

	private final double UCTK;

	/* game tree builder for this simulation */
	protected final GameTreeBuilder<PotExplorerState> builder;
	/* deciding seat in this simulation */
	protected final int seatTaken;
	/* models of seats */
	protected final List<IAgent> agents;

	/* navigator pointing at last state */
	private GameTreeBuilder<PotExplorerState>.
	ExpandNavigator navigator;

	/*
	 * Returns the game tree builder.
	 */
	protected final GameTreeBuilder<PotExplorerState> getBuilder() {
		return this.builder;
	}

	/*
	 * Returns the deciding seat in this
	 * simulation.
	 */
	protected final int getSeatTaken() {
		return this.seatTaken;
	}

	/*
	 * Returns the seat models in this
	 * simulation.
	 */
	protected final List<IAgent> getAgents() {
		return this.agents;
	}

	/*
	 * Returns the navigator pointing at
	 * the deepest relevant game state.
	 */
	protected final GameTreeBuilder<PotExplorerState>.ExpandNavigator getNavigator() {
		return this.navigator;
	}

	/*
	 * Selects the next action in the given state.
	 */
	protected Action selectAction(PotExplorerState state){
		if(state.getCurrentSeat().getIndex()!=getSeatTaken())
			return UCTSelection();
		
		return agentSelection();
	}
	
	private Action agentSelection() {
		// Get a successor action for this state
		final IAgent agent = getAgents().
		get(getNavigator().getCurrent().getBase().getCurrentSeat().getIndex());
		final Action action = agent.getAction(getNavigator().getCurrent());
		
		return action;		
	}
	
	private Action UCTSelection() {
		/*
		 * Based on Valkyria-UCT
		 * (http://senseis.xmp.net/?UCT)
		 */
		double bestUCT = 0.0d;
		Action bestAction = null;
		
		for(final Action action : Action.values()) {
			final PotExplorerState next
			= getNavigator().getNext(action);

			if(next==null) return agentSelection(); // Unexplored node -> expand with agent
			if(next.getIterations()>0) {
				final double ratio = next.getRatio();
				final int currentIterations = getNavigator().getCurrent().getIterations();
				final double uct = this.UCTK*Math.sqrt(Math.log(currentIterations)/(5.0d * next.getIterations()));
				final double uctValue = ratio + uct;

				if(uctValue > bestUCT) {
					bestUCT = uctValue;
					bestAction = action;
				}

			} else return agentSelection();

		}
		
		if(bestAction!=null)
			return bestAction;
		return agentSelection();
	}

	/*
	 * Gets the amount won by the seat.
	 */
	protected int getAmountWon(ISeat seat) {
		if(this.random.nextDouble()<this.probBestHand)
			return seat.getStakes();
		
		return -seat.getStakes();
	}

	/*
	 * Recursive method that checks the value in this state
	 * by performing a deep search.
	 */
	private ResultType checkState(final PotExplorerState state) {
		// Get next action
		final Action action = selectAction(state);
		
		Debug.log(Option.MC_MY_ACTION, state.getCurrentSeat().getIndex()+": "+ (state.getCurrentSeat().getIndex()==getSeatTaken() ? action : "-"));
		Debug.log(Option.MC_OPPONENT_ACTION, state.getCurrentSeat().getIndex()+": "+ (state.getCurrentSeat().getIndex()!=getSeatTaken() ? action : "-"));
		
		Debug.log(Option.MC_STREET, state.getRound());
		Debug.log(Option.MC_ACTIVE_SEATS, Integer.valueOf(state.getNumberActiveSeats()));
		
		if((getNavigator().getNext(action)==null)) {
			// Next state is unexplored
			final ISeat seat = state.getSeat(getSeatTaken());
			if((!seat.isActive())
					|| !getNavigator().expand(action)) {
				// Leaf state, calculate values and continue
				Debug.log(Option.MC_SHOWDOWN_CARDS, "Board: "+state.getBoard()+"\n"
						+ "Hole "+state.getSeat(getSeatTaken()).getPlayerIndex()+": "+state.getSeat(getSeatTaken()).getHoles());
				
				final int amountWon = getAmountWon(seat);
				
				Debug.log(Option.MC_WIN, "My amount: "+amountWon);
				
				state.addValue(amountWon);
				state.addPot(state.getCurrentPotSize());
				state.addCosts(seat.getStakes());
				if(amountWon>=0) {
					state.reward();
					return new ResultType(true, amountWon, state.getCurrentPotSize(), seat.getStakes());
				}
				state.pass();
				return new ResultType(false, amountWon, state.getCurrentPotSize(), seat.getStakes());
			}
		}

		// Check next state
		getNavigator().transit(action);
		final ResultType nextResult = checkState(getNavigator().getCurrent());
		state.addValue(nextResult.getAmountWon());
		state.addPot(nextResult.getPotSize());
		state.addCosts(nextResult.getCostSize());

		// Backtracking part:
		if(nextResult.hasWon()) {
			// Got reward from next state
			state.reward();
			return new ResultType(true, nextResult.getAmountWon(), nextResult.getPotSize(), nextResult.getCostSize());
		}
		// Didn't get reward
		state.pass();
		return new ResultType(false, nextResult.getAmountWon(), nextResult.getPotSize(), nextResult.getCostSize());
	}

	/** {@inheritDoc} **/
	@Override
	public void run() {
		// Initialize navigator
		this.navigator = this.builder.navigator();
		
		// Initialize start states
		if(this.navigator.getNext(Action.CALL)==null)
			this.navigator.expand(Action.CALL);
		if(this.navigator.getNext(Action.RAISE)==null)
			this.navigator.expand(Action.RAISE);
		if(this.navigator.getNext(Action.FOLD)==null) {
			this.navigator.expand(Action.FOLD);
			initialFold();
		}
		
		// Start recursion
		this.navigator.transit(Action.CALL);
		checkState(this.navigator.getCurrent());
		this.navigator = this.builder.navigator();
		this.navigator.transit(Action.RAISE);
		checkState(this.navigator.getCurrent());
	}

	private void initialFold() {
		if(this.navigator.getCurrent().getSeat(getSeatTaken()).getStakes()>0)
			this.navigator.getNext(Action.FOLD).pass();
		else
			this.navigator.getNext(Action.FOLD).reward();
		this.navigator.getNext(Action.FOLD).addValue(
				-this.navigator.getCurrent().getSeat(getSeatTaken()).getStakes());
		this.navigator.getNext(Action.FOLD).addCosts(
				this.navigator.getCurrent().getSeat(getSeatTaken()).getStakes());
		this.navigator.getNext(Action.FOLD).addPot(
				this.navigator.getCurrent().getCurrentPotSize());
	}


	/**
	 * Creates a new MonteCarloSimulator for the given
	 * game tree builder.
	 * 
	 * @param builder game tree builder as base for the
	 * simulation.
	 * @param seatTaken deciding seat for the simulation
	 * @param agents agents to model the hand's seats
	 * @param probBestHand 
	 * @param UCTK 
	 */
	public PotExploringSimulator(
			final GameTreeBuilder<PotExplorerState> builder,
			final int seatTaken, final List<IAgent> agents, final double probBestHand,
			final double UCTK) {
		super();

		this.builder = builder;
		this.seatTaken = seatTaken;
		this.agents = agents;
		this.probBestHand = probBestHand;
		this.UCTK = UCTK;
	}


}