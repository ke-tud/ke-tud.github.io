package ke.gametree.montecarlo;

import java.util.List;

import ke.data.Action;
import ke.gametree.GameTreeBuilder;

/**
 * Objects of this class run one simulation with the
 * simple monte carlo simulation. Exploration is provided
 * by the seat models.
 */
public class SimpleMonteCarloSimulator extends MonteCarloSimulator {

	/*
	 * Selects the action from seat models (agents).
	 */
	@Override
	protected Action selectAction(final MonteCarloState state) {
		// Get a successor action for this state
		final IAgent agent = getAgents().
		get(state.getCurrentSeat().getPlayerIndex());
		final Action action = agent.getAction(state);
		return action;
	}

	/**
	 * Creates a new SimpleMonteCarloSimulator for the given
	 * game tree builder.
	 * 
	 * @param builder game tree builder as base for the
	 * simulation.
	 * @param seatTaken deciding seat for the simulation
	 * @param agents agents to model the hand's seats
	 */
	public SimpleMonteCarloSimulator(
			final GameTreeBuilder<MonteCarloState> builder,
			final int seatTaken, final List<IAgent> agents) {
		super(builder,seatTaken,agents);
	}


}
