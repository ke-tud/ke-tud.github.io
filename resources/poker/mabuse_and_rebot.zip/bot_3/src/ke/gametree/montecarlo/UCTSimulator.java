package ke.gametree.montecarlo;

import java.util.List;

import ke.data.Action;
import ke.gametree.GameTreeBuilder;

/**
 * Objects of this class run one simulation with the
 * UCT (Upper confidence tree) monte carlo simulation.
 * Exploration is based on Valkyria-UCT algorithm.
 */
public class UCTSimulator extends MonteCarloSimulator {
	/* UCT constant */
	private final double UCTK;

	/*
	 * Selects the next action from UCT algorithm.
	 */
	@Override
	protected Action selectAction(final MonteCarloState state) {
		if(state.getCurrentSeat().getPlayerIndex()!=getSeatTaken())
			return UCTSelection();
		
		return agentSelection();
	}
	
	private Action agentSelection() {
		// Get a successor action for this state
		final IAgent agent = getAgents().
		get(getNavigator().getCurrent().getBase().getCurrentSeat().getPlayerIndex());
		final Action action = agent.getAction(getNavigator().getCurrent());
		
		return action;		
	}
	
	private Action UCTSelection() {
		/*
		 * Based on Valkyria-UCT
		 * (http://senseis.xmp.net/?UCT)
		 */
		double bestUCT = 0.0d;
		Action bestAction = null;
		
		for(final Action action : Action.values()) {
			final MonteCarloState next
			= getNavigator().getNext(action);

			if(next==null) return agentSelection(); // Unexplored node -> expand with agent
			if(next.getIterations()>0) {
				final double ratio = next.getRatio();
				final int currentIterations = getNavigator().getCurrent().getIterations();
				final double uct = this.UCTK*Math.sqrt(Math.log(currentIterations)/(5.0d * next.getIterations()));
				final double uctValue = ratio + uct;

				if(uctValue > bestUCT) {
					bestUCT = uctValue;
					bestAction = action;
				}

			} else return agentSelection();

		}
		
		if(bestAction!=null)
			return bestAction;
		return agentSelection();
	}

	/**
	 * Creates a new UCTMonteCarloSimulator for the given
	 * game tree builder.
	 * 
	 * @param builder game tree builder as base for the
	 * simulation.
	 * @param seatTaken deciding seat for the simulation
	 * @param agents agents to model the hand's seats
	 * @param UCTK UCT constant: higher value provides
	 * a higher exploration rate
	 */
	public UCTSimulator(
			final GameTreeBuilder<MonteCarloState> builder,
			final int seatTaken, final List<IAgent> agents, final double UCTK) {
		super(builder, seatTaken, agents);
		this.UCTK = UCTK;
	}

}
