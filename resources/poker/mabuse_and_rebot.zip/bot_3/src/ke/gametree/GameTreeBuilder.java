package ke.gametree;

import java.util.EnumMap;
import java.util.List;

import ke.data.Action;

/**
 * The GameTreeBuilder represents a mutable game tree with a extensive
 * navigator to build the tree.
 * 
 * @param <State> type of the states stored in the tree
 */
public final class GameTreeBuilder<State extends IGameState<State>> implements IGameTree<State> {
	/* number of nodes */
	int numberNodes=0;
	

	/*
	 * Helping structure for the storage in the tree
	 */
	private static class Node<State extends IGameState<State>> {
		private State component;
		private final EnumMap<Action, Node<State>> successors
		= new EnumMap<Action, Node<State>>(Action.class);

		public State getComponent() {
			return this.component;
		}

		public void setComponent(final State component) {
			this.component = component;
		}

		public EnumMap<Action, Node<State>> getSuccessors() {
			return this.successors;
		}

		public Node(final State component) {
			super();
			this.component = component;
		}

		/** {@inheritDoc} **/
		@Override
		public String toString() {
			final StringBuilder successorBuilder = new StringBuilder();
			for(final Action action : Action.values())
				successorBuilder.append(", " //$NON-NLS-1$
						+action+" -> "+this.successors.get(action)); //$NON-NLS-1$
			return "("+this.component+": " //$NON-NLS-1$ //$NON-NLS-2$
			+successorBuilder.substring(2)+")"; //$NON-NLS-1$
		}


	}

	/**
	 * Navigator with expand() method to build a tree.
	 */
	public final class ExpandNavigator implements IGameTree.INavigator<State> {
		private Node<State> current;

		/** {@inheritDoc} **/
		@Override
		public State getCurrent() {
			return this.current.getComponent();
		}

		/** {@inheritDoc} **/
		@Override
		public void transit(final Action action) {
			if(this.current.getSuccessors().get(action)!=null)
				this.current = this.current.getSuccessors().get(action);
		}

		/*
		 * Creates a new navigator. This constructor should
		 * only be invoked by the navigator() method of the
		 * game tree.
		 */
		ExpandNavigator(final Node<State> root) {
			this.current = root;
		}

		/**
		 * Expands the game tree in the navigator's current
		 * node for the given action.
		 * 
		 * @param action action branch to expand
		 * @return true, if expansion succeeded; false, if
		 * not (current node is a leaf)
		 */
		public boolean expand(final Action action) {
			final State next = getCurrent().progress(action);
			if(next==null)
				return false;

			final Node<State> nextNode = new Node<State>(next);
			this.current.getSuccessors().put(action, nextNode);
			GameTreeBuilder.this.numberNodes++;
			return true;
		}

		/** {@inheritDoc} **/
		@Override
		public State getNext(final Action action) {
			if(this.current.getSuccessors().get(action)!=null)
				return this.current.getSuccessors().get(action).getComponent();

			return null;
		}

		/** {@inheritDoc} **/
		@Override
		public IGameTree<State> getBranch(final Action action) {
			final Node<State> node = this.current.getSuccessors().get(action);
			if(node==null) return new GameTreeBuilder<State>((State) null);
			return new GameTreeBuilder<State>(node);
		}

	}

	/** {@inheritDoc} **/
	@Override
	public State get(final List<Action> path) {
		Node<State> current = this.root;

		// Traverse the tree
		for(final Action action : path)
			if((current = current.getSuccessors().get(action))==null)
				return null; // No transition, return null

		return current.getComponent();
	}

	/*
	 * The tree's root node
	 */
	private final Node<State> root;

	/** {@inheritDoc} **/
	@Override
	public State getRoot() {
		return this.root.getComponent();
	}

	/** {@inheritDoc} **/
	@Override
	public ExpandNavigator navigator() {
		return new ExpandNavigator(this.root);
	}

	/** {@inheritDoc} */
	@Override
	public final int size() {
		return this.numberNodes;
	}
	
	/**
	 * Creates a new GameTreeBuilder with the given
	 * root state.
	 * 
	 * @param root root state
	 */
	public GameTreeBuilder(final State root) {
		this.root = new Node<State>(root);
	}

	/*
	 * Creates a new tree from a node (only internal
	 * use / branching)
	 */
	GameTreeBuilder(final Node<State> node) {
		this.root = node;
	}

	/** {@inheritDoc} **/
	@Override
	public String toString() {
		return "GameTreeBuilder ["+this.root+"]"; //$NON-NLS-1$ //$NON-NLS-2$
	}

}
