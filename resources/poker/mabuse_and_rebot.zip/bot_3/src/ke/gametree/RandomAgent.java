package ke.gametree;

import java.util.EnumMap;
import java.util.Random;

import ke.data.Action;
import ke.gametree.montecarlo.IAgent;

/**
 * The random agent returns random actions according
 * to there probabilities.
 */
public class RandomAgent implements IAgent {
	private final EnumMap<Action, Double> probabilities;
	private static final Random RANDOM = new Random();

	/** {@inheritDoc} **/
	@Override
	public Action getAction(final IGameState<?> state) {
		final EnumMap<Action, Double> probs = this.probabilities;

		return getAction(probs);
	}

	/**
	 * Gets an action for the given probability distribution.
	 * 
	 * @param probs probabilities for RAISE, CALL, FOLD
	 * @return an action
	 */
	public static Action getAction(final EnumMap<Action, Double> probs) {
		final double dice = RANDOM.nextDouble();
		double threshold = 0.0d;

		for(final Action action : Action.values()) {
			threshold += probs.get(action).doubleValue();
			if(dice<threshold) return action;
		}

		// No action matched? This should not happen
		return null;
	}

	/**
	 * Gets an action for the given probability distribution.
	 * 
	 * @param foldProb probability to fold
	 * @param callProb probability to call
	 * @param raiseProb probability to raise
	 * @return an action
	 */
	public static Action getAction(final double foldProb,
			final double callProb, final double raiseProb) {
		final double dice = RANDOM.nextDouble();
		double threshold = 0.0d;

		threshold += foldProb;
		if(dice<threshold) return Action.FOLD;

		threshold += callProb;
		if(dice<threshold) return Action.CALL;

		return Action.RAISE;
	}

	/**
	 * Creates a new random agent with the given probabilities.
	 * 
	 * @param probabilities probability mapping action -> value
	 */
	public RandomAgent(final EnumMap<Action, Double> probabilities) {
		this.probabilities = probabilities;
	}

	/**
	 * Creates a new random agent with the given probabilities.
	 * @param foldProb probability to fold
	 * @param callProb probability to call
	 * @param raiseProb probability to raise
	 */
	public RandomAgent(final double foldProb,
			final double callProb, final double raiseProb) {
		this.probabilities = new EnumMap<Action, Double>(Action.class);
		this.probabilities.put(Action.FOLD, Double.valueOf(foldProb));
		this.probabilities.put(Action.CALL, Double.valueOf(callProb));
		this.probabilities.put(Action.RAISE, Double.valueOf(raiseProb));
	}
}
