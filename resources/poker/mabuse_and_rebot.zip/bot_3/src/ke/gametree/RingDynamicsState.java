package ke.gametree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import ke.data.Action;
import ke.data.Round;
import ke.utils.Utils;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 * The RingDynamicsState is a game state based on the RingDynamics
 * by Martin Zinkevich. Its successor states are created by delegating
 * the action to a RingDynamics.
 * 
 * @see ca.ualberta.cs.poker.free.dynamics.RingDynamics RingDynamics
 */
public class RingDynamicsState implements IGameState<RingDynamicsState> {
	/**
	 * This seat class uses the ring dynamics of this
	 * game state as source of information.
	 */
	public final class Seat implements ISeat {
		private final int index;
		private final int playerId;

		/** {@inheritDoc} **/
		@Override
		public int getAmountWon() {
			if(!isActive())
				return -getStakes();

			determineAmountWon();
			
			return RingDynamicsState.this.dynamics.grossWon[this.index]
                   - RingDynamicsState.this.dynamics.inPot[this.index];
		}

		/** {@inheritDoc} **/
		@Override
		public int getIndex() {
			return this.index;
		}

		/** {@inheritDoc} **/
		@Override
		public int getPlayerIndex() {
			return this.playerId;
		}

		/** {@inheritDoc} **/
		@Override
		public int getStakes() {
			return RingDynamicsState.this.dynamics.inPot[this.index];
		}

		/** {@inheritDoc} **/
		@Override
		public boolean isActive() {
			return RingDynamicsState.this.dynamics.active[this.index];
		}


		/** {@inheritDoc} **/
		@Override
		public int getAmountToCall() {
			return RingDynamicsState.this.dynamics.getAmountToCall(this.index);
		}

		/** {@inheritDoc} **/
		@Override
		public Collection<Card> getHoles() {
			return Arrays.asList(RingDynamicsState.this.dynamics.hole[getIndex()]);
		}
		
		/** {@inheritDoc} **/
		@Override
		public boolean canRaiseNextTurn() {
			return RingDynamicsState.this.dynamics.canRaiseNextTurn[this.index];
		}
		
		Seat(final int index, final int playerId) {
			this.index = index;
			this.playerId = playerId;
		}
	}

	final RingDynamics dynamics;
	final List<ISeat> seats;

	/**
	 * Creates a new RingDynamicsState from an existing RingDynamics
	 * object copying its properties.
	 * 
	 * @param dynamics base RingDynamics object
	 */
	public RingDynamicsState(final RingDynamics dynamics) {
		super();
		this.dynamics = Utils.copyDynamics(dynamics);
		this.seats = new ArrayList<ISeat>();
		for(int i=0; i<getNumberSeats(); i++)
			this.seats.add(new Seat(i,dynamics.seatToPlayer(i)));
	}

	/** {@inheritDoc} **/
	@Override
	public int getNumberSeatLeftToAct() {
		return this.dynamics.getNumPlayersLeftToAct();
	}

	/** {@inheritDoc} **/
	@Override
	public int getNumberActiveSeats() {
		return this.dynamics.getNumActivePlayers();
	}

	/** {@inheritDoc} **/
	@Override
	public int getNumberSeats() {
		return this.dynamics.numSeats;
	}

	/** {@inheritDoc} **/
	@Override
	public ke.gametree.IGameState.ISeat getSeat(final int index) {
		final ISeat seat = this.seats.get(index);

		return seat;
	}

	/** {@inheritDoc} */
	@Override
	public ISeat getCurrentSeat() {
		final int index = this.dynamics.seatToAct;

		return getSeat(index);
	}
	
	/** {@inheritDoc} */
	@Override
	public Collection<Card> getBoard() {
		return Arrays.asList(this.dynamics.board);
	}

	/** {@inheritDoc} */
	@Override
	public Round getRound() {
		switch(this.dynamics.roundIndex) {
		case 0: return Round.PREFLOP;
		case 1: return Round.FLOP;
		case 2: return Round.TURN;
		case 3: return Round.RIVER;
		case 4: return Round.SHOWDOWN;
		default: return null; // unknown state, should never happen
		}
	}
	
	/** {@inheritDoc} */
	@Override
	public int getCurrentPotSize(){
		int potSize = 0;
		for (int i = 0; i< this.dynamics.numSeats; i++){
			potSize += this.dynamics.inPot[i];
		}
		return potSize;
	}
	
	/** {@inheritDoc} */
	@Override
	public int getRoundBets(){
		return this.dynamics.roundBets;
	}

	/** {@inheritDoc} **/
	@Override
	public RingDynamicsState progress(final Action action) {
		if(this.dynamics.isGameOver())
			return null;

		final RingDynamics nextDynamics = Utils.copyDynamics(this.dynamics);
		nextDynamics.handleAction(action.toChar());

		return new RingDynamicsState(nextDynamics);
	}

	/*
	 * Deals new cards to all opponents (players != player)
	 * and calculates the amount of small blinds won
	 * by the given player.
	 */
	void determineAmountWon() {
		this.dynamics.determineGrossWon(); // FIXME optimize
	}

	/**
	 * Returns the ring dynamics of this state.
	 * 
	 * @return ring dynamics
	 */
	public RingDynamics getDynamics(){
		return this.dynamics;
	}

	/** {@inheritDoc} **/
	@Override
	public void dealRandomCards(Round round,
			int seatTaken) {
		if(round==Round.PREFLOP)
			for(int i=0; i<this.dynamics.board.length; i++)
				this.dynamics.board[i] = null;
		else
			for(int i=4; i>round.getIndex()+1; i--)
				this.dynamics.board[i] = null;
		
		Utils.dealRandomCards(this.dynamics,seatTaken);
	}

	/** {@inheritDoc} **/
	@Override
	public int getCurrentHandNumber() {
		return this.dynamics.handNumber;
	}

}
