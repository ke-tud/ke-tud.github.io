package ke.gametree;

import java.util.Collection;
import ke.data.Action;
import ke.data.Round;
import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * This class represents an abstract game state. It's primary
 * usage is to simulate state transitions.
 * 
 * @param <NextState> GameState type in which this state transforms
 */
public interface IGameState<NextState extends IGameState<?>> {
	/**
	 * Represents a seat in a game.
	 */
	public static interface ISeat {
		/**
		 * Returns the activity of this seat.
		 * 
		 * @return true, if this seat is active;
		 * false, if not
		 */
		public boolean isActive();

		/**
		 * Returns the index number of this seat.
		 * 
		 * @return index number of this seat
		 */
		public int getIndex();

		/**
		 * Returns the index of the player
		 * on this seat.
		 * 
		 * @return the player index
		 */
		public int getPlayerIndex();

		/**
		 * Returns the stakes that this seat has
		 * bet.
		 * 
		 * @return stakes as number of small blinds
		 */
		public int getStakes();

		/**
		 * Gets the amount of small blinds this player
		 * has won.
		 * 
		 * @return the amount in small blinds
		 */
		public int getAmountWon();

		/**
		 * Returns the amount of small blinds required
		 * for the next call.
		 * 
		 * @return number of small blinds required for
		 * the next call
		 */
		public int getAmountToCall();
		
		
		/**
		 * @return if (player in) seat can raise when its his turn
		 */
		public boolean canRaiseNextTurn();
		
		/**
		 * @return current hole cards
		 */
		public Collection<Card> getHoles(); 
	}
	/**
	 * Creates a possible successor game state of this
	 * game state, after the transition is applied.
	 * 
	 * @param action transition action to the next state
	 * @return true, if transition succeed; false, if not
	 * (possible end state)
	 */
	public NextState progress(final Action action);

	/**
	 * Returns the number of seats in this game.
	 * 
	 * @return number of seats
	 */
	public int getNumberSeats();

	/**
	 * Returns the number of seats, that are
	 * able to act in this round.
	 * 
	 * @return number of seats left to act
	 */
	public int getNumberSeatLeftToAct();

	/**
	 * Returns the number of seats, that are
	 * active.
	 * 
	 * @return number of active seats
	 */
	public int getNumberActiveSeats();

	/**
	 * Returns the current round.
	 * 
	 * @return the current round
	 */
	public Round getRound();
	
	/**
	 * Returns the current PotSize
	 *
	 * @return the PotSize
	 */
	public int getCurrentPotSize();

	/**
	 * Returns the seat to act.
	 * 
	 * @return player to act
	 */
	public ISeat getCurrentSeat();

	/**
	 * Returns the seat at the given
	 * index position.
	 * 
	 * @param index position of the seat
	 * @return seat at that position
	 */
	public ISeat getSeat(final int index);
	
	/**
	 * @return current board cards
	 */
	public Collection<Card> getBoard();
	
	/**
	 * @return the bets made so far in this round 
	 */
	public int getRoundBets();
	
	/**
	 * @return amount of hands played so far
	 */
	public int getCurrentHandNumber();
	
	
	/**
	 * Deals a random cards to this state.
	 * 
	 * @param round street of the initial fixed
	 * board cards.
	 * @param seatTaken hole cards of this will
	 * not be re-dealt.
	 */
	public void dealRandomCards(final Round round, final int seatTaken);
}
