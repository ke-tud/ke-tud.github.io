package ke.gametree;

import java.util.EnumMap;
import java.util.Iterator;
import java.util.NoSuchElementException;

import ke.data.Action;
import ke.gametree.IGameTree.INavigator;
import ke.gametree.montecarlo.IAgent;
import ke.gametree.montecarlo.MonteCarloState;
import ke.utils.Utils;

/**
 * This class provides frequently iterators over
 * a game tree.
 */
public class GameTreeIterators {
	/**
	 * A path is an iterator on a game tree. It provides
	 * the getNextAction() method.
	 * 
	 * @param <State> game state
	 */
	public static interface Path<State extends IGameState<State>>
	extends Iterator<State> {
		/**
		 * Returns the next action according
		 * to the concrete iterator implementation.
		 * 
		 * @return next action
		 */
		public Action getNextAction();
	}

	/*
	 * Abstract template for concrete path iterators.
	 */
	protected static abstract class AbstractPath<State extends IGameState<State>>
	implements Path<State> {
		/* The navigator on which the iterator is based */
		private final INavigator<State> navigator;
		/* Next action (will be calculated in every state) */
		private Action nextAction;
		/* First run? Dirty trick */
		private boolean firstRun = true;

		/*
		 * Returns the base navigator of the game tree.
		 */
		protected INavigator<State> getNavigator() {
			return this.navigator;
		}

		/** {@inheritDoc} **/
		@Override
		public boolean hasNext() {
			if(this.firstRun) {
				this.nextAction = getNextAction();
				this.firstRun=false;
			}
			
			if(this.nextAction==null)
				return false;
			if(this.navigator.getNext(this.nextAction)==null)
				return false;

			return true;
		}

		/** {@inheritDoc} **/
		@Override
		public State next() {
			if(hasNext())
				this.navigator.transit(this.nextAction);
			else
				throw new NoSuchElementException();

			this.nextAction = getNextAction();

			return this.navigator.getCurrent();
		}

		/** {@inheritDoc} **/
		@Override
		public void remove() {
			// Not implemented!
			throw new UnsupportedOperationException();
		}

		/**
		 * Creates a new iterator based on the given
		 * navigator.
		 * 
		 * @param navigator game tree navigator
		 */
		public AbstractPath(final INavigator<State> navigator) {
			this.navigator = navigator;
//			this.nextAction = getNextAction();
		}

		/**
		 * Creates a new iterator for the given
		 * tree.
		 * 
		 * @param tree game tree
		 */
		public AbstractPath(final IGameTree<State> tree) {
			this(tree.navigator());
		}
	}

	public final static EnumMap<Action, Double> DEFENSIVE_QUANTIFIER
	= new EnumMap<Action, Double>(Action.class);
	static {
		DEFENSIVE_QUANTIFIER.put(Action.FOLD, Double.valueOf(2d));
		DEFENSIVE_QUANTIFIER.put(Action.CALL, Double.valueOf(1d));
		DEFENSIVE_QUANTIFIER.put(Action.RAISE, Double.valueOf(0.75d));
	}

	public final static EnumMap<Action, Double> NORMAL_QUANTIFIER
	= new EnumMap<Action, Double>(Action.class);
	static {
		NORMAL_QUANTIFIER.put(Action.FOLD, Double.valueOf(1d));
		NORMAL_QUANTIFIER.put(Action.CALL, Double.valueOf(1d));
		NORMAL_QUANTIFIER.put(Action.RAISE, Double.valueOf(1d));
	}

	/**
	 * This iterator creates a path in the game
	 * tree, which contains only the states with
	 * the currently best monte carlo value.
	 * 
	 * On the same tree, it will always return
	 * the same path.
	 */
	public static final class BestValuePath extends AbstractPath<MonteCarloState> {		
		/** {@inheritDoc} */
		@Override
		public Action getNextAction() {
			/* initialise values to compute */
			double bestValue = Double.NEGATIVE_INFINITY;
			Action bestSimulatedAction = Action.CALL;

			for(final Action action : Action.values()) {
				final MonteCarloState next = getNavigator().getNext(action);
				if(next==null) continue;
				final double value = next.getValue();
				if(value>bestValue) {
					bestValue = value;
					bestSimulatedAction = action;
				}
			}
			return bestSimulatedAction;
		}

		/**
		 * Creates a new iterator based on the given
		 * navigator.
		 * 
		 * @param navigator game tree navigator
		 */
		public BestValuePath(final INavigator<MonteCarloState> navigator) {
			super(navigator);
		}

		/**
		 * Creates a new iterator for the given
		 * tree.
		 * 
		 * @param tree game tree
		 */
		public BestValuePath(final IGameTree<MonteCarloState> tree) {
			this(tree.navigator());
		}
	}

	/**
	 * This iterator creates a path in the game
	 * tree, which contains randomly chosen states
	 * with a good monte carlo value.
	 */
	public static final class RandomGoodValuePath extends AbstractPath<MonteCarloState> {
		/* Quantifier to finetune decisions */
		private final EnumMap<Action, Double> quantifier;
		
		/** {@inheritDoc} */
		@Override
		public Action getNextAction() {
			/* initialise values to compute */
			Action bestSimulatedAction = Action.CALL;

			final MonteCarloState nextFOLD = getNavigator().getNext(Action.FOLD);
			final MonteCarloState nextCALL = getNavigator().getNext(Action.CALL);
			final MonteCarloState nextRAISE = getNavigator().getNext(Action.RAISE);

			double foldVal = this.quantifier.get(Action.FOLD).doubleValue() * (nextFOLD!=null ? nextFOLD.getValue() : 0);
			double callVal = this.quantifier.get(Action.CALL).doubleValue() * (nextCALL!=null ? nextCALL.getValue() : 0);
			double raiseVal = this.quantifier.get(Action.RAISE).doubleValue() * (nextRAISE!=null ? nextRAISE.getValue() : 0);

			final double offset = Math.min(foldVal, Math.min(callVal, raiseVal));
			if(offset<0) {
				foldVal -= offset;
				callVal -= offset;
				raiseVal -= offset;
			}

			final double sum = foldVal + callVal + raiseVal;

			if(sum!=0)
				bestSimulatedAction = Utils.getRandomAction(foldVal / sum,
						callVal / sum, raiseVal / sum);
			else
				bestSimulatedAction = Utils.getRandomAction(Utils.LAPLACE_PROBABILITY);

			return bestSimulatedAction;
		}

		/**
		 * Creates a new iterator based on the given
		 * navigator.
		 * 
		 * @param navigator game tree navigator
		 */
		public RandomGoodValuePath(final INavigator<MonteCarloState> navigator) {
			this(navigator,NORMAL_QUANTIFIER);
		}

		/**
		 * Creates a new iterator for the given
		 * tree.
		 * 
		 * @param tree game tree
		 */
		public RandomGoodValuePath(final IGameTree<MonteCarloState> tree) {
			this(tree.navigator());
		}
		
		/**
		 * Creates a new iterator based on the given
		 * navigator.
		 * 
		 * @param navigator game tree navigator
		 */
		public RandomGoodValuePath(final INavigator<MonteCarloState> navigator,
				final EnumMap<Action, Double> quantifier) {
			super(navigator);
			this.quantifier = quantifier;
		}

		/**
		 * Creates a new iterator for the given
		 * tree.
		 * 
		 * @param tree game tree
		 */
		public RandomGoodValuePath(final IGameTree<MonteCarloState> tree,
				final EnumMap<Action, Double> quantifier) {
			this(tree.navigator(), quantifier);
		}
	}

	/**
	 * This iterator creates a path in the game
	 * tree, which contains randomly chosen states
	 * with a good monte carlo ratio.
	 */
	public static final class RandomGoodRatioPath extends AbstractPath<MonteCarloState> {
		/* Quantifier to finetune decisions */
		private final EnumMap<Action, Double> quantifier;
		
		/** {@inheritDoc} */
		@Override
		public Action getNextAction() {
			/* initialise values to compute */
			Action bestSimulatedAction = Action.CALL;
	
			final MonteCarloState nextFOLD = getNavigator().getNext(Action.FOLD);
			final MonteCarloState nextCALL = getNavigator().getNext(Action.CALL);
			final MonteCarloState nextRAISE = getNavigator().getNext(Action.RAISE);
	
			double foldVal = this.quantifier.get(Action.FOLD).doubleValue() * (nextFOLD!=null ? nextFOLD.getRatio() : 0);
			double callVal = this.quantifier.get(Action.CALL).doubleValue() * (nextCALL!=null ? nextCALL.getRatio() : 0);
			double raiseVal = this.quantifier.get(Action.RAISE).doubleValue() * (nextRAISE!=null ? nextRAISE.getRatio() : 0);
	
			final double offset = Math.min(foldVal, Math.min(callVal, raiseVal));
			if(offset<0) {
				foldVal -= offset;
				callVal -= offset;
				raiseVal -= offset;
			}
	
			final double sum = foldVal + callVal + raiseVal;
	
			if(sum!=0)
				bestSimulatedAction = Utils.getRandomAction(foldVal / sum,
						callVal / sum, raiseVal / sum);
			else
				bestSimulatedAction = Utils.getRandomAction(Utils.LAPLACE_PROBABILITY);
	
			return bestSimulatedAction;
		}
	
		/**
		 * Creates a new iterator based on the given
		 * navigator.
		 * 
		 * @param navigator game tree navigator
		 */
		public RandomGoodRatioPath(final INavigator<MonteCarloState> navigator) {
			this(navigator, NORMAL_QUANTIFIER);
		}
	
		/**
		 * Creates a new iterator for the given
		 * tree.
		 * 
		 * @param tree game tree
		 */
		public RandomGoodRatioPath(final IGameTree<MonteCarloState> tree) {
			this(tree.navigator());
		}
		
		/**
		 * Creates a new iterator based on the given
		 * navigator.
		 * 
		 * @param navigator game tree navigator
		 */
		public RandomGoodRatioPath(final INavigator<MonteCarloState> navigator,
				final EnumMap<Action, Double> quantifier) {
			super(navigator);
			this.quantifier = quantifier;
		}
	
		/**
		 * Creates a new iterator for the given
		 * tree.
		 * 
		 * @param tree game tree
		 */
		public RandomGoodRatioPath(final IGameTree<MonteCarloState> tree,
				final EnumMap<Action, Double> quantifier) {
			this(tree.navigator(),quantifier);
		}
	}

	/**
	 * Returns a new iterable object with a BestValuePath iterator.
	 * 
	 * @param tree game tree to iterate
	 * @return a new new iterable object
	 */
	public static Iterable<MonteCarloState> getBestValueIterable(
			final IGameTree<MonteCarloState> tree) {
		return new Iterable<MonteCarloState>() {

			/** {@inheritDoc} **/
			@Override
			public Iterator<MonteCarloState> iterator() {
				return new BestValuePath(tree);
			}

		};
	}

	/**
	 * Returns a new iterable object with a RandomGoodValuePath iterator.
	 * 
	 * @param tree game tree to iterate
	 * @return a new new iterable object
	 */
	public static Iterable<MonteCarloState> getRandomGoodValueIterable(
			final IGameTree<MonteCarloState> tree) {
		return new Iterable<MonteCarloState>() {

			/** {@inheritDoc} **/
			@Override
			public Iterator<MonteCarloState> iterator() {
				return new RandomGoodValuePath(tree);
			}

		};
	}

	/**
	 * Returns a new agent acting according to a given
	 * game tree path.
	 * 
	 * @param path game tree path
	 * @return a new agent for that path
	 */
	public static IAgent getPathAgent(final Path<?> path) {
		return new IAgent() {

			@Override
			public Action getAction(final IGameState<?> state) {
				final Action action = path.getNextAction();
				if(path.hasNext()) path.next();

				return action;
			}

		};

	}

	/*
	 * Do not instantiate this class. Just
	 * a utility class.
	 */
	private GameTreeIterators() {
		// Empty constructor
	}
}
