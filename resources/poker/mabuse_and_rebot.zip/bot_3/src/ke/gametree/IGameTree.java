package ke.gametree;

import java.util.List;

import ke.data.Action;

/**
 * The game tree is a tree structure with game states as nodes
 * and game action as transitions between its nodes.
 * 
 * @param <State> state type stored in this tree
 */
public interface IGameTree<State extends IGameState<State>> {

	/**
	 * The navigator is a mutable object to travel through a
	 * game tree. The transit() method sets the navigator's
	 * cursor one level below.
	 *
	 * @param <State> type of the state of this navigator
	 */
	public interface INavigator<State extends IGameState<State>> {
		/**
		 * Returns the state at the navigator's
		 * cursor.
		 * 
		 * @return current state
		 */
		public State getCurrent();

		/**
		 * Proceeds the navigator's cursor to
		 * the state following the given action.
		 * 
		 * @param action action to proceed
		 */
		public void transit(final Action action);

		/**
		 * Returns the proceeding state after the
		 * given action.
		 * 
		 * @param action next action
		 * @return proceeding state; null, if
		 * next state does not exist.
		 */
		public State getNext(final Action action);

		/**
		 * Returns a new game tree with the given
		 * branch as root.
		 * 
		 * @param action action to the desired branch
		 * @return a new game tree
		 */
		public IGameTree<State> getBranch(final Action action);
	}

	/**
	 * Returns a new tree navigator pointing on the
	 * tree's root game state.
	 * 
	 * @return a new navigator
	 */
	public INavigator<State> navigator();

	/**
	 * Returns the root game state.
	 * 
	 * @return the root game state
	 */
	public State getRoot();

	/**
	 * Returns the number of nodes in this tree.
	 * 
	 * @return the number of nodes
	 */
	public int size();
	
	/**
	 * Returns the game state at the end of
	 * the action path.
	 * 
	 * @param path path of actions
	 * @return game state after the actions
	 */
	public State get(final List<Action> path);
}
