package ke.history;

import java.util.List;
import java.util.Vector;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 *
 */
public class MoneyMonitor implements IStateChangeListener {

	/** Money Storage */
	public class MoneyData{
		/** money of specific player in every round */
		final List<int[]> money;

		int fromHand;
		int toHand;
		
		/**
		 * @param playerId
		 * @return the money a player has absolutely earned so far 
		 * (only includes the winnings not the losses, 
		 * so the return value is effectively between [0, Integer.MAX_VALUE])
		 */
		public int getMoneyEarned(final int playerId){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++)
				result += Math.max(0, this.money.get(i)[playerId]);
			return result;
		}
		
		/**
		 * @param playerId
		 * @return the average money a player has absolutely earned so far 
		 * (only includes the winnings not the losses)
		 */
		public double getAvgMoneyEarned(final int playerId){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			double earnings = getMoneyEarned(playerId);
			return earnings / windowSize;
		}
		
		/**
		 * @param playerId
		 * @return the amount of matches the given player has won so 
		 * far (includes the split pot situations) [0,HANDS_PLAYED]
		 */
		public int getMatchesWon(final int playerId){
			int won = 0;
			for(int i = this.fromHand; i < this.toHand; i++)
				if (this.money.get(i)[playerId] > 0)
					won++;
			return won;
		}
		
		/**
		 * @param playerId
		 * @return the average amount of matches the given player has won so 
		 * far (includes the split pot situations) [0,1]
		 */
		public double getMatchesWonInPercent(final int playerId){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			final double won = getMatchesWon(playerId);
			return won / windowSize;		
		}
		
		/**
		 * @param playerId
		 * @return the money a player has absolutely lost so far 
		 * (only includes the losses not the winnings, 
		 * so the return value is effectively between [Integer.MIN_VALUE, 0])
		 */
		public int getMoneyLost(final int playerId){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++)
				result += Math.min(0, this.money.get(i)[playerId]);
			return result;
		}
		
		/**
		 * @param playerId
		 * @return the average money a player has absolutely lost so far 
		 * (only includes the losses not the winnings)
		 */
		public double getAvgMoneyLost(final int playerId){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			double losses = getMoneyLost(playerId);
			return losses / windowSize;
		}
		
		/**
		 * @param playerId
		 * @return the balance account of a player 
		 * (includes winnings and losses, so the return 
		 * value is effectively between [Integer.MIN_VALUE, Integer.MAX_VALUE])
		 */
		public int getBalance(final int playerId){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++)
				result += this.money.get(i)[playerId];
			return result;
		}
		
		/**
		 * @param playerId
		 * @return the average money a player has absolutely won and lost so far 
		 * (represents (winnings - losses) / windowSize)
		 */
		public double getAvgBalance(final int playerId){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			double balance = getBalance(playerId);
			return balance / windowSize;
		}
		
		/** Constructor */
		MoneyData(){
			this.money = new Vector<int[]>((int)CONSTANT.HANDCOUNT);
		}
	}
	
	/** singleton instance */
	private static MoneyMonitor instance;
	
	/**
	 * @return Singleton access
	 */
	public static MoneyMonitor getInstance(){
		if(instance == null)
			instance = new MoneyMonitor(CONSTANT.PLAYER_COUNT);
		return instance;
	}
	
	/** number of players */
	private final int players;
	/** hands played so far */
	int handCount;
	/** data */
	private final MoneyData moneyData;

	/**
	 * @param players
	 */
	private MoneyMonitor(final int players){
		this.moneyData = new MoneyData();
		this.players = players;
		this.handCount = 0;
	}
	
	/**
	 * @return all the collected data
	 */
	public MoneyData getGlobalData(){
		this.moneyData.fromHand = 0;
		this.moneyData.toHand = this.handCount;
		return this.moneyData;
	}
	
	/**
	 * @param windowSize 
	 * @return the collected data in given window
	 */
	public MoneyData getWindowData(final int windowSize){
		if(this.handCount < windowSize)
			return getGlobalData();
		this.moneyData.fromHand = this.handCount - windowSize;
		this.moneyData.toHand = this.handCount;
		return this.moneyData;
	}
	
	/**
	 * @return the collected data standard window
	 */
	public MoneyData getWindowData(){
		return getWindowData(CONSTANT.WINDOW_SIZE);
	}
	
	/**
	 * @return the number of hands played so far
	 */
	public int getHandCount(){
		return this.handCount;
	}
	
	/** {@inheritDoc} */
	@Override
	public void actionPerformed(final int seat, final int player, final Action action) {
	 /* nothing to do */
	}

	/** {@inheritDoc} */
	@Override
	public void roundFinished(final int ownID, final int playerAtSeatZero, final int[] amountWon,
			final int[] inPot, final Card[][] hole, final Card[] board) {
		
		this.moneyData.money.add(reSortArray(amountWon, playerAtSeatZero));
		this.handCount++;
		
		String debug = "hand number: " + this.handCount + " my player id: " + ownID; 
		debug += "\n\t";
		debug += "Money earned: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tPlayer " + i + ": " + getGlobalData().getMoneyEarned(i) + " average:" + getGlobalData().getAvgMoneyEarned(i);
		debug += "\n\t";
		debug += "Money lost: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tPlayer " + i + ": " + getGlobalData().getMoneyLost(i) + " average:" + getGlobalData().getAvgMoneyLost(i);		
		debug += "\n\t";
		debug += "Balance: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tPlayer " + i + ": " + getGlobalData().getBalance(i) + " average:" + getGlobalData().getAvgBalance(i);		
		debug += "\n\t";
		debug += "windowed Money earned: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tPlayer " + i + ": " + getWindowData().getMoneyEarned(i) + " average:" + getWindowData().getAvgMoneyEarned(i);
		debug += "\n\t";
		debug += "windowed Money lost: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tPlayer " + i + ": " + getWindowData().getMoneyLost(i) + " average:" + getWindowData().getAvgMoneyLost(i);		
		debug += "\n\t";
		debug += "windowed Balance: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tPlayer " + i + ": " + getWindowData().getBalance(i) + " average:" + getWindowData().getAvgBalance(i);
		
		debug += "\n";
		
		Debug.log(Option.MONEY_MONITOR, debug);
		
	}

	private int[] reSortArray(int[] seatArray, int playerAtZero) {
		int[] playerArray = new int[this.players];
		for(int i = 0; i < this.players; i++)
			playerArray[(playerAtZero + i) % this.players] = seatArray[i];
		return playerArray;		
	}

	/** {@inheritDoc} */
	@Override
	public void stateChanged(final GameState state) {
		/* nothing to do */
	}

}
