package ke.history;

/**
 * History
 *
 * @author Alex
 */

import java.util.concurrent.ConcurrentHashMap;

import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.Bucket;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.data.Tools;

import ca.ualberta.cs.poker.free.dynamics.Card;

/***/
public class History implements IStateChangeListener {

	// Save specific data for every Round
	private final ConcurrentHashMap<Integer, OneRoundData> rounds = new ConcurrentHashMap<Integer, OneRoundData>();
	// Save aggregated data in every entry in the amount given by the variable
	// "numOfSumRounds"
	private final ConcurrentHashMap<Integer, GlobalRoundData> sumOfNRounds = new ConcurrentHashMap<Integer, GlobalRoundData>();
	// Save aggregated data over the whole game
	private final GlobalRoundData globalHistory = new GlobalRoundData();
	// This history is used to determine the behavior of the opponent
	// In general the global history could used but we must consider changes in
	// the behavior
	// So if the behavior in the last hundred rounds differ to much from the one
	// in the curHistory the curHistory will be set to this one
	private final GlobalRoundData curHistory = new GlobalRoundData();

	// current round index
	private int roundCount = 0;
	// current index of the partially aggregated data
	private int sumRoundCount = 0;

	// some variables to manage the stepwise construction of the OneRoundData
	private OneRoundData roundData;
	private GameState curGameState;
	private GameState lastStateBeforShowdown;
	
	/***/
	public int ownPlayerID = -1;

	// the last evaluated values for the bucket probabilities (the a player has
	// cards of a special bucket)
	private final double bucketProbabilities[][] = new double[CONSTANT.PLAYER_COUNT][];
	// probabilities are evaluated after every action
	private boolean actionHasOccured = true;

	// define the global history in a singleton pattern
	private static History gameHistory = null;

	/**
	 * @return history
	 */
	public synchronized static History getHistory() {
		if (gameHistory == null)
			gameHistory = new History();
		return gameHistory;
	}

	/***/
	private History() { /**/ }

	
	/**
	 * @param i
	 * @return onerounddata
	 */
	public OneRoundData getOneRound(final int i) {
		return this.rounds.get(new Integer(i));
	}

	
	/**
	 * @return onerounddata
	 */
	public OneRoundData getCurrentRoundData() {
		if(this.roundData == null)
			this.roundData = new OneRoundData();
		return this.roundData;
	}

	
	/**
	 * @param i
	 * @return globalrounddata
	 */
	public GlobalRoundData getSumOfNRounds(final int i) {
		return this.sumOfNRounds.get(new Integer(i));
	}

	
	/**
	 * @return globalrounddata
	 */
	public synchronized GlobalRoundData getGlobal() {
		return this.globalHistory;
	}

	/**
	 * @return globalrounddata
	 */
	public synchronized GlobalRoundData getCurrent() {
		return this.curHistory;
	}

	
	/**
	 * @return currentroundnumber
	 */
	public int getCurRoundNumber() {
		return this.roundCount;
	}

	/**
	 * @return onerounddata 
	 */
	public OneRoundData getLastRound() {
		return this.rounds.get(new Integer(this.rounds.size() - 1));
	}

	
	/**
	 * @return globalrounddata
	 */
	public GlobalRoundData getLastCompletedSumRounds() {
		return this.sumOfNRounds.get(new Integer(this.sumOfNRounds.size() - 2));
	}

	
	/**
	 * @param fromRound
	 * @param toRound
	 * @return globalrounddata
	 */
	public GlobalRoundData getAggregatedData(final int fromRound,
			final int toRound) {
		final GlobalRoundData result = new GlobalRoundData();

		if ((fromRound < 0) || (toRound < 0))
			return result;

		for (int i = fromRound; i < toRound; i++)
			result.addOneRoundData(this.rounds.get(new Integer(i)));

		return result;
	}

	
	/**
	 * @return true or false
	 */
	public boolean isActive() {
		return getCurRoundNumber() > CONSTANT.NUM_ROUNDS_BEFORE_HISTORY;
	}

	
	/**
	 * @return [][]
	 */
	public double[][] getCurrentBucketProbabilities() {
		if ((this.bucketProbabilities == null) || this.actionHasOccured)
			for (int player = 0; player < CONSTANT.PLAYER_COUNT; player++) {
				// at first reset the array to default values
				this.bucketProbabilities[player] = CONSTANT.BUCKET_PREFLOP_PROB
						.clone();

				// if player has folded in the current round no computations are
				// needed
				if ((this.roundData.playerOut[player] == GameState.PREFLOP)
						|| (this.roundData.playerOut[player] == GameState.STARTING))
					continue;

				double globRaise = this.curHistory.getNumRaises(
						GameState.PREFLOP, player);
				final double globCall = this.curHistory.getNumCalls(
						GameState.PREFLOP, player);
				final double globFold = this.curHistory.getNumFolds(
						GameState.PREFLOP, player)
						+ this.curHistory.getNumFolds(GameState.STARTING,
								player);
				final double globAllActions = globRaise + globCall
						+ (globFold * 2);

				globRaise = globAllActions != 0 ? 1.0 - (globRaise / globAllActions)
						: 0;

				final int roundRaise = this.roundData.getNumRaises(
						GameState.PREFLOP, player);
				final int roundCall = this.roundData.getNumCalls(
						GameState.PREFLOP, player);
				double curRaiseRatio = 0;
				if (roundRaise + roundCall != 0)
					curRaiseRatio = ((double) roundRaise)
							/ (double) (roundCall + roundRaise);

				final double value = globRaise * curRaiseRatio
						* CONSTANT.BUCKET_MAX_SHIFT;

				for (int i = 3; i >= 0; i--) {
					this.bucketProbabilities[player][i] -= CONSTANT.BUCKET_PREFLOP_PROB_DIFF[i]
							* CONSTANT.BUCKET_PREFLOP_PROB[0] * value;
				}
			}

		this.actionHasOccured = false;
		return Tools.cloneArray(this.bucketProbabilities);
	}

	/***/
	public void checkForChangedBehaviour() {
		final GlobalRoundData lastNGames = this.sumOfNRounds.get(new Integer(
				this.sumRoundCount - 1));

		if (lastNGames.getAmountWonByPlayers(this.ownPlayerID) > 0)
			return;

		final double lastPlayerRatio[][][] = this.curHistory.getPlayerRatio();
		final double curPlayerRatio[][][] = lastNGames.getPlayerRatio();

		final double stateErrors[] = new double[GameState.values().length];
		double playerError;

		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {

			for (final GameState state : GameState.values()) {
				stateErrors[state.ordinal()] = 0;
				for (final Action action : Action.values())
					stateErrors[state.ordinal()] += Math
							.abs(curPlayerRatio[i][state.ordinal()][action
									.ordinal()]
									- lastPlayerRatio[i][state.ordinal()][action
											.ordinal()]);
				stateErrors[state.ordinal()] /= Action.values().length;
			}
			playerError = 0;
			for (final double value : stateErrors)
				playerError += value;
			playerError /= GameState.values().length;

			if (playerError >= CONSTANT.PERCENT_BEHAVIOUR_CHANGE) {
				if (CONSTANT.DEBUG)
					System.out.println("Behaviour of player " + i
							+ " changed: " + playerError);
				this.curHistory.setPlayerData(lastNGames, i);
			} else if (CONSTANT.DEBUG)
				System.out.println("No change in behavior of playser " + i
						+ " with error " + playerError);
		}
	}

	/**
	 * @param ownID 
	 * @param playerAtSeatZero 
	 * @param amountWon 
	 * @param inPot 
	 * @param hole 
	 */
	public synchronized void roundFinished(final int ownID,
			final int playerAtSeatZero, final int[] amountWon,
			final int[] inPot, final Card hole[][], Card[] board) {
		if (this.ownPlayerID == -1)
			this.ownPlayerID = ownID;
		// complete the data of the OneRoundData
		this.roundData.completeData(playerAtSeatZero, amountWon, inPot, hole);

		// save current round data
		this.rounds.put(new Integer(this.roundCount), this.roundData);

		// construct every "numOfSumRounds" a new aggregated data structure
		if (this.roundCount % CONSTANT.NUM_OF_SUM_ROUNDS == 0) {
			if (this.sumRoundCount > 1)
				checkForChangedBehaviour();
			this.sumOfNRounds.put(new Integer(this.sumRoundCount),
					new GlobalRoundData());
			this.sumRoundCount++;
		}
		this.sumOfNRounds.get(Integer.valueOf(this.sumRoundCount - 1)).addOneRoundData(
				this.roundData, this.lastStateBeforShowdown);

		this.globalHistory.addOneRoundData(this.roundData,
				this.lastStateBeforShowdown);
		this.curHistory.addOneRoundData(this.roundData,
				this.lastStateBeforShowdown);

		this.roundCount++;
		if (CONSTANT.DEBUG) {
			System.out.println();
			System.out.println("*** New History ***");
			System.out.println("Current History");
			System.out.println(this.curHistory.toString());
		}

		if (CONSTANT.DEBUG) {
			System.out.println();
			System.out.println("*** New History ***");
			System.out.println("Global History");
			System.out.println(this.globalHistory.toString());
			System.out.println("Current History");
			System.out.println(this.curHistory.toString());
			final double bettingRatio[][] = this.curHistory.getBettingRatio();
			for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
				System.out.print("Spieler " + i + " betting ratios: ");
				for (final GameState state : GameState.values())
					System.out.print(bettingRatio[i][state.ordinal()] + ",");
				System.out.println();
			}

			final double test1[][][] = this.curHistory.getPlayerRatio();

			for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
				System.out.println("Spieler " + i + " ratios: ");
				for (final GameState state : GameState.values()) {
					System.out.println(state.toString() + ": ");
					for (final Action action : Action.values())
						System.out.print(action.toString() + "="
								+ test1[i][state.ordinal()][action.ordinal()]
								+ " ");
					System.out.println(")");
				}
				System.out.println();
			}

			final double test[][][][] = this.curHistory.getPlayerEstimate();

			for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
				System.out.println("Spieler " + i + " Buckets: ");
				for (final GameState state : GameState.values()) {
					System.out.println(state.toString() + ": ");
					for (int j = 0; j < Bucket.BUCKET_COUNT; j++) {
						System.out.print("Bucket " + j + "(");
						for (final Action action : Action.values())
							System.out.print(action.toString()
									+ "="
									+ test[i][state.ordinal()][j][action
											.ordinal()] + " ");
						System.out.println(")");
					}
				}
				System.out.println();
			}
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
			System.out.println();
		}
	}
	
	/**
	 * @param seat 
	 * @param player 
	 * @param action 
	 */
	public synchronized void actionPerformed(final int seat, final int player,
			final Action action) {
		if ((this.curGameState == GameState.PREFLOP)
				|| (this.curGameState == GameState.STARTING))
			this.actionHasOccured = true;
		this.roundData.addAction(player, action, this.curGameState);
	}

	/** {@inheritDoc} */
	public synchronized void stateChanged(final GameState state) {
		if (state == GameState.STARTING)
			this.roundData = new OneRoundData();
		if (((state == GameState.SHOWDOWN) && (this.curGameState == GameState.RIVER))
				|| (state != GameState.SHOWDOWN))
			this.lastStateBeforShowdown = state;
		this.curGameState = state;
	}
}
