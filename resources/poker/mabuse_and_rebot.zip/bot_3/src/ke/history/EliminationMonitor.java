package ke.history;

import java.util.List;
import java.util.Vector;
import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.utils.Debug;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.Card;
	
	/**
	 *
	 */
	public class EliminationMonitor implements IStateChangeListener {

		/** Elimination Storage */
		public class EliminationData{
			/** round and state each player was eliminated */
			final List<GameState[]> eleminations;
			
			/** Constructor */
			public EliminationData() {
				this.eleminations = new Vector<GameState[]>((int)CONSTANT.HANDCOUNT);
			}
			
			/**
			 * @param roundIndex 
			 * @param playerId
			 * @return elimination state
			 */
			public GameState getEliminationState(final int roundIndex, final int playerId){
				if (roundIndex < 1)
					return GameState.SHOWDOWN;
				return this.eleminations.get(roundIndex)[playerId];
			}
			
			/**
			 * @param playerId
			 * @return elimination state
			 */
			public GameState getEliminationStateFromLastRound(final int playerId){
				return getEliminationState(EliminationMonitor.this.handCount - 1, playerId);
			}
			
			/**
			 * @param playerId
			 * @param state 
			 * @return elimination state
			 */
			public boolean getPlayerActiveInStateLastRound(final int playerId, final GameState state){
				GameState elemState = getEliminationStateFromLastRound(playerId);
				return (elemState.ordinal() >= state.ordinal());
			}
			
			/**
			 * @param state 
			 * @return number of active players in state
			 */
			public int getNumberActivePLayersInStateLastRound(final GameState state){
				int playercount = 0;
				for(int i = 0; i < EliminationMonitor.this.players; i++)
					if (getPlayerActiveInStateLastRound(i, state))
						playercount++;
				return playercount;
			}
		}
		
		/** Elimination Storage */
		public class CurrentEliminationData{
			/** round and state each player was eliminated */
			GameState[] eleminations;
			
		}
		
		/** singleton instance */
		private static EliminationMonitor instance;
		
		/**
		 * @return Singleton access
		 */
		public static EliminationMonitor getInstance(){
			if(instance == null)
				instance = new EliminationMonitor(CONSTANT.PLAYER_COUNT);
			return instance;
		}
		
		/** number of players */
		final int players;
		/** hands played so far */
		int handCount;
		/** current GameState */
		GameState currentGameState;
		/** data */
		private final EliminationData eliminationData;
		/** current data */
		private final CurrentEliminationData currentEliminationData;

		/**
		 * @param players
		 */
		private EliminationMonitor(final int players){
			this.eliminationData = new EliminationData();
			this.currentEliminationData = new CurrentEliminationData();
			this.currentEliminationData.eleminations = new GameState[players];
			this.currentGameState = GameState.STARTING;
			this.players = players;
			this.handCount = 0;
		}
		
		/**
		 * @return all the collected data
		 */
		public EliminationData getGlobalData(){
			return this.eliminationData;
		}
		
		/**
		 * @return the currently collecting data
		 */
		public CurrentEliminationData getCurrentData(){
			return this.currentEliminationData;
		}
			
		/** {@inheritDoc} */
		@Override
		public void actionPerformed(final int seat, final int player, final Action action) {
			if(action.equals(Action.FOLD))
				this.currentEliminationData.eleminations[player] = this.currentGameState;
		}

		/** {@inheritDoc} */
		@Override
		public void roundFinished(final int ownID, final int playerAtSeatZero, final int[] amountWon,
				final int[] inPot, final Card[][] hole, final Card[] board) {
			
			for(int i = 0; i < this.players; i++)
				if(this.currentEliminationData.eleminations[i] == null)
					this.currentEliminationData.eleminations[i] = GameState.SHOWDOWN;
			
			this.eliminationData.eleminations.add(this.currentEliminationData.eleminations);
			this.currentEliminationData.eleminations = new GameState[this.players];
			this.handCount++;
			
			String debug = "hand number: " + this.handCount;
			
			for(int i = 0; i < this.players; i++)
				debug += "\n\t" + "Player " + i + " was eliminated last round in state " + this.eliminationData.getEliminationStateFromLastRound(i);
			
			for(GameState s : GameState.values())
				debug += "\n\t" + "In State " + s + " there were " + this.eliminationData.getNumberActivePLayersInStateLastRound(s) + " Players active.";			

			Debug.log(Option.ELIMINATION_MONITOR, debug);
			
		}

		/** {@inheritDoc} */
		@Override
		public void stateChanged(final GameState state) {
			this.currentGameState = state;		
		}

	}



