package ke.history;

import java.util.List;
import java.util.Vector;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 *
 */
public class BetMonitor implements IStateChangeListener {

	/** Storage Class, to store all bets in each round from each player */
	public class BetData{

		/** bets of a specific player in a specific state */
		final List<int[][]> allBets;

		int fromHand;
		int toHand;
		
		/**
		 * @return bets done overall
		 */
		public int getBetsOverall(){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++){
				for(int j = 0; j < BetMonitor.this.players; j++){
					for(final GameState s : GameState.values()){
						result += this.allBets.get(i)[j][s.ordinal()];
					}
				}
			}
			return result;
		}
		
		/**
		 * @return average bets done overall
		 */
		public double getAvgBetsOverall(){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			final double bets = getBetsOverall();
			return bets / windowSize;
		}
		
		/**
		 * @param state
		 * @return Bets in a certain state
		 */
		public int getBetsInState(final GameState state){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++){
				for(int j = 0; j < BetMonitor.this.players; j++){
					result += this.allBets.get(i)[j][state.ordinal()];
				}
			}
			return result;
		}
		
		/**
		 * @param state
		 * @return average bets in a certain state
		 */
		public double getAvgBetsInState(final GameState state){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			final double betsState = getBetsInState(state);
			return betsState / windowSize;
		}
		
		/**
		 * @param state
		 * @param playerId
		 * @return bets in a certain state by a certain player
		 */
		public int getBetsInStateFromPlayer(final GameState state, final int playerId){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++){
				result += this.allBets.get(i)[playerId][state.ordinal()]; 
			}
			return result;
		}
		
		/**
		 * @param state
		 * @param playerId
		 * @return average bets in a certain state by a certain player
		 */
		public double getAvgBetsInStateFromPlayer(final GameState state, final int playerId){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			final double betsStatePlayer = getBetsInStateFromPlayer(state, playerId);
			return betsStatePlayer / windowSize;
		}
		
		/**
		 * @param playerId
		 * @return bets by a certain player
		 */
		public int getBetsFromPlayer(final int playerId){
			int result = 0;
			for(int i = this.fromHand; i < this.toHand; i++){
				for(final GameState s : GameState.values()){
					result += this.allBets.get(i)[playerId][s.ordinal()];
				}	
			}
			return result;
		}
		
		/**
		 * @param playerId
		 * @return average bets by a certain player
		 */
		public double getAvgBetsFromPlayer(final int playerId){
			final int windowSize = this.toHand - this.fromHand;
			if(windowSize == 0)
				return 0;
			final double betsPlayer = getBetsFromPlayer(playerId);
			return betsPlayer / windowSize;
		}
		
		/** Constructor */
		BetData(){
			this.allBets = new Vector<int[][]>((int)CONSTANT.HANDCOUNT);
		}
	}
	
	/** Storage Class, to store the current bets from each player */
	public class CurrentBetData{

		/** bets of a specific player in a specific state */
		int[][] currentBets;
		
		/**
		 * @return bets done this round
		 */
		public int getBets(){
			int result = 0;
			for(int i = 0; i < BetMonitor.this.players; i++){
				for(final GameState s : GameState.values()){
					result += this.currentBets[i][s.ordinal()];
				}
			}
			return result;
		}
		
		/**
		 * @param state 
		 * @return average bets done until given state (including given state)
		 */
		public double getAvgBetsPerState(final GameState state){
			if(state.ordinal() == 0)
				return 0;
			final double bets = getBets();
			return bets / state.ordinal();
		}
		
		/**
		 * @param state
		 * @return Bets in a certain state
		 */
		public int getBetsInState(final GameState state){
			int result = 0;
			for(int i = 0; i < BetMonitor.this.players; i++){
				result += this.currentBets[i][state.ordinal()];
			}
			return result;
		}
		
		/**
		 * @param state
		 * @param playerId
		 * @return bets in a certain state by a certain player
		 */
		public int getBetsInStateFromPlayer(final GameState state, final int playerId){
			return this.currentBets[playerId][state.ordinal()];
		}
		
		
		/**
		 * @param playerId
		 * @return bets by a certain player
		 */
		public int getBetsFromPlayer(final int playerId){
			int result = 0;
			for(final GameState s : GameState.values()){
				result += this.currentBets[playerId][s.ordinal()];
			}	
			return result;
		}
		
		/**
		 * @param playerId
		 * @param state 
		 * @return average bets by a given player until given state (including given state)
		 */
		public double getAvgBetsFromPlayer(final int playerId, final GameState state){
			if(state.ordinal() == 0)
				return 0;
			final double betsPlayer = getBetsFromPlayer(playerId);
			return betsPlayer / state.ordinal();
		}
	}
	
	/** singleton instance */
	private static BetMonitor instance;
	
	/**
	 * @return SingleTon access
	 */
	public static BetMonitor getInstance(){
		if(instance == null)
			instance = new BetMonitor(CONSTANT.PLAYER_COUNT);
		return instance;
	}
	
	/** numbers of players in game */
	final int players;	
	final BetData betData;
	/** hands played so far */
	int handCount;
	/** current gamestate */
	GameState currentGameState;
	/** counting bets in current state */
	final CurrentBetData currentBetData;
	
	/**
	 * @param players
	 */
	private BetMonitor(final int players){
		this.betData = new BetData();
		this.currentGameState = GameState.STARTING;
		this.currentBetData = new CurrentBetData();
		this.currentBetData.currentBets = new int[players][GameState.values().length];
		this.handCount = 0;
		this.players = players;
	}
	
	/**
	 * @return all the collected data  
	 */
	public BetData getGlobalData(){
		this.betData.fromHand = 0;
		this.betData.toHand = this.handCount;		
		return this.betData;
	}
	
	/**
	 * @param windowSize
	 * @return the collected data in given window
	 */
	public BetData getWindowData(final int windowSize){
	
		if(this.handCount < windowSize)
			return getGlobalData();
		
		this.betData.fromHand = this.handCount - windowSize;
		this.betData.toHand = this.handCount;
		return this.betData;
	}
	
	/**
	 * @return the collected data in standard window
	 */
	public BetData getWindowData(){
		return getWindowData(CONSTANT.WINDOW_SIZE);
	}
	
	/**
	 * @return the currently collecting data of this round
	 */
	public CurrentBetData getCurrentRoundData(){
		return this.currentBetData;
	}
	
	/**
	 * @return the number of hands played so far
	 */
	public int getHandCount(){
		return this.handCount;
	}
	
	/** {@inheritDoc} */
	@Override
	public void actionPerformed(final int seat, final int player, final Action action) {
		if(action.equals(Action.RAISE)){
			this.currentBetData.currentBets[player][this.currentGameState.ordinal()]++;
		}
	}

	/** {@inheritDoc} */
	@Override
	public void roundFinished(final int ownID, final int playerAtSeatZero, final int[] amountWon,
			final int[] inPot, final Card[][] hole, final Card[] board) {
		this.betData.allBets.add(this.currentBetData.currentBets);
		this.currentBetData.currentBets = new int[this.players][GameState.values().length];
		this.handCount++;
		
		String debug = "hand number: " + this.handCount; 
		debug += "\n\t";
		debug += "bets Overall: " + getGlobalData().getBetsOverall() + " average: " + getGlobalData().getAvgBetsOverall();
		debug += "\n\t";
		debug += "bets in State: ";
		for(GameState s : GameState.values())
			debug += "\n\t\t" + s + ": " + getGlobalData().getBetsInState(s) + " average:" + getGlobalData().getAvgBetsInState(s);
		debug += "\n\t";
		debug += "bets from player: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tplayer " + i + ": " + getGlobalData().getBetsFromPlayer(i) + " average:" + getGlobalData().getAvgBetsFromPlayer(i);		
		debug += "\n\t";
		debug += "bets from player in state: ";
		for(int i = 0; i < this.players; i++)
			for(GameState s : GameState.values())
				debug += "\n\t\tplayer " + i + " in State " + s + ": " + getGlobalData().getBetsInStateFromPlayer(s, i) + " average:" + getGlobalData().getAvgBetsInStateFromPlayer(s, i);
		
		debug += "\n\t";
		debug += "windowed bets Overall: " + getWindowData().getBetsOverall() + " average: " + getWindowData().getAvgBetsOverall();
		debug += "\n\t";
		debug += "windowed bets in State: ";
		for(GameState s : GameState.values())
			debug += "\n\t\t" + s + ": " + getWindowData().getBetsInState(s) + " average:" + getWindowData().getAvgBetsInState(s);
		debug += "\n\t";
		debug += "windowed bets from player: ";
		for(int i = 0; i < this.players; i++)
			debug += "\n\t\tplayer " + i + ": " + getWindowData().getBetsFromPlayer(i) + " average:" + getWindowData().getAvgBetsFromPlayer(i);		
		debug += "\n\t";
		debug += "windowed bets from player in state: ";
		for(int i = 0; i < this.players; i++)
			for(GameState s : GameState.values())
				debug += "\n\t\tplayer " + i + " in State " + s + ": " + getWindowData().getBetsInStateFromPlayer(s, i) + " average:" + getWindowData().getAvgBetsInStateFromPlayer(s, i);
		debug += "\n";
		
		Debug.log(Option.BET_MONITOR, debug);
	}

	/** {@inheritDoc} */
	@Override
	public void stateChanged(final GameState state) {
		this.currentGameState = state;
	}
}
