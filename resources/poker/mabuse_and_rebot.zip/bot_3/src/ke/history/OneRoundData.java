package ke.history;

/**
 * OneRoundData
 *
 * @author,Alex
 */

import java.util.Arrays;

import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class OneRoundData extends RoundData {

	public int playerAtSeatZero = -1;
	/** Show the GameState every player has fold in this round */
	public GameState playerOut[] = new GameState[CONSTANT.PLAYER_COUNT];
	public Card hole[][];

	private final boolean playerHasDoneAnything[] = new boolean[CONSTANT.PLAYER_COUNT];
	public int playerOutBettingRounds[] = new int[CONSTANT.PLAYER_COUNT];
	public int numBetsPerState[] = new int[GameState.values().length];

	public OneRoundData() {
		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++) {
			this.playerOut[i] = GameState.SHOWDOWN;
			this.playerHasDoneAnything[i] = false;
			this.playerOutBettingRounds[i] = 0;
		}
		Arrays.fill(this.numBetsPerState, 0);
	}
	
	public int getNumBetsPerState(GameState state){
		return this.numBetsPerState[state.ordinal()];
	}

	public void completeData(final int playerAtSeatZero, final int[] amountWon,
			final int[] inPot, final Card hole[][]) {
		this.playerAtSeatZero = playerAtSeatZero;
		setAmountWonByPlayers(correctArray(playerAtSeatZero, amountWon));
		setInPotFromPlayers(correctArray(playerAtSeatZero, inPot));
		this.hole = new Card[CONSTANT.PLAYER_COUNT][2];
		for (int i = 0; i < hole.length; i++)
			if ((hole[i] != null) && (hole[i].length == 2))
				for (int j = 0; j < hole[i].length; j++) {
					final Card card = hole[i][j];
					if (card != null)
						hole[i][j] = new Card(card.rank, card.suit);
					else {
						hole[i][j] = null;
					}
				}
	}

	public void addAction(final int player, final Action action,
			final GameState state) {
		switch (action) {
		case FOLD:
			if (!this.playerHasDoneAnything[player])
				this.playerOut[player] = GameState.STARTING;
			else {
				this.playerOut[player] = state;
				this.playerOutBettingRounds[player] = this.numBetsPerState[state
						.ordinal()];
			}
			addToNumFolds(state, player, 1);
			break;
		case CALL:
			addToNumCalls(state, player, 1);
			break;
		case RAISE:
			addToNumRaises(state, player, 1);
			this.numBetsPerState[state.ordinal()]++;
			break;
		default:
			System.out.println("Error while handle action: Unknown action '"
					+ action.toChar() + "'");
		}
		this.playerHasDoneAnything[player] = true;
	}

	private int[] correctArray(final int playerAtSeatZero, final int[] array) {
		final int correctedArray[] = array.clone();
		for (int i = 0; i < CONSTANT.PLAYER_COUNT; i++)
			correctedArray[(i + playerAtSeatZero) % CONSTANT.PLAYER_COUNT] = array[i];
		return correctedArray;
	}
}
