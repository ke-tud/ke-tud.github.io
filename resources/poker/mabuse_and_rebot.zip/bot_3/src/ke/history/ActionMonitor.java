package ke.history;

import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.utils.Debug;
import ke.utils.Utils;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.Card;
	
	/**
	 *
	 */
	public class ActionMonitor implements IStateChangeListener {

		/** Action Storage */
		public class ActionData{
			/** round and state each player was eliminated */
			final List<int[][][]> actionCounter;
			
			int fromHand;
			int toHand;
			
			public int getPLayerActionCountsInStateInRound(final int playerId, final GameState state, final Action action, final int round){
				if(round < 0 || round >= ActionMonitor.this.handCount)
					return 0;
				return this.actionCounter.get(round)[playerId][state.ordinal()][action.ordinal()];
			}
			
			public int getPlayerActionCountsInState(final int playerId, final GameState state, final Action action){
				int count = 0;
				for(int i = this.fromHand; i < this.toHand; i++)
					count += getPLayerActionCountsInStateInRound(playerId, state, action, i);
				return count; 
			}
			
			public double getPlayerActionRatioInState(final int playerId, final GameState state, final Action action){
				final int windowSize = (this.toHand - this.fromHand);
				if(windowSize < 1)
					return 0;
				double counts = getPlayerActionCountsInState(playerId, state, action);
				return counts / windowSize;
			}
			
			public double[][] getPlayerActionRatios(final int playerId){
				double[][] ratios = new double[GameState.values().length][Action.values().length];
				for(GameState s : GameState.values())
					for(Action a : Action.values())
						ratios[s.ordinal()][a.ordinal()] = getPlayerActionRatioInState(playerId, s, a);
				return ratios;
			}
			
			/** Constructor */
			public ActionData() {
				this.actionCounter = new Vector<int[][][]>((int)CONSTANT.HANDCOUNT);
			}
		}
		
		/** Current Action Storage */
		public class CurrentActionData{
			/** round and state each player was eliminated */
			int[][][] actionCounter;
			
			/* TODO: implement getter methods */
		}
		
		/** singleton instance */
		private static ActionMonitor instance;
		
		/**
		 * @return Singleton access
		 */
		public static ActionMonitor getInstance(){
			if(instance == null)
				instance = new ActionMonitor(CONSTANT.PLAYER_COUNT);
			return instance;
		}
		
		/** number of players */
		final int players;
		/** hands played so far */
		int handCount;
		/** current GameState */
		GameState currentGameState;
		/** data */
		private final ActionData actionData;
		/** current data */
		private final CurrentActionData currentActionData;

		/**
		 * @param players
		 */
		private ActionMonitor(final int players){
			this.actionData = new ActionData();
			this.currentActionData = new CurrentActionData();
			this.currentActionData.actionCounter = new int[players][GameState.values().length][Action.values().length];
			this.currentGameState = GameState.STARTING;
			this.players = players;
			this.handCount = 0;
		}
		
		/**
		 * @return all the collected data
		 */
		public ActionData getGlobalData(){
			this.actionData.fromHand = 0;
			this.actionData.toHand = this.handCount;
			return this.actionData;
		}
		
		/**
		 * @param windowSize
		 * @return the collected data in given window
		 */
		public ActionData getWindowData(final int windowSize){
		
			if(this.handCount < windowSize)
				return getGlobalData();
			
			this.actionData.fromHand = this.handCount - windowSize;
			this.actionData.toHand = this.handCount;
			return this.actionData;
		}
		
		/**
		 * @return the collected data in standard window
		 */
		public ActionData getWindowData(){
			return getWindowData(CONSTANT.WINDOW_SIZE);
		}
		
		/**
		 * @return the currently collecting data
		 */
		public CurrentActionData getCurrentData(){
			return this.currentActionData;
		}
			
		/** {@inheritDoc} */
		@Override
		public void actionPerformed(final int seat, final int player, final Action action) {
			this.currentActionData.actionCounter[player][this.currentGameState.ordinal()][action.ordinal()]++;
		}

		/** {@inheritDoc} */
		@Override
		public void roundFinished(final int ownID, final int playerAtSeatZero, final int[] amountWon,
				final int[] inPot, final Card[][] hole, final Card[] board) {
						
			this.actionData.actionCounter.add(this.currentActionData.actionCounter);
			this.currentActionData.actionCounter = new int[this.players][GameState.values().length][Action.values().length];
			this.handCount++;
			
			String debug = "hand number: " + this.handCount;

			for(int i = 0; i < this.players; i++)
				debug += "\n\t" + "Player " + i + " has following Action global ratios: " + Utils.ArrayToString(getGlobalData().getPlayerActionRatios(i));
			
			for(int i = 0; i < this.players; i++)
				debug += "\n\t" + "Player " + i + " has following Action ratios in last round: " + Utils.ArrayToString(getWindowData(1).getPlayerActionRatios(i));

			Debug.log(Option.ACTION_MONITOR, debug);
			
		}

		/** {@inheritDoc} */
		@Override
		public void stateChanged(final GameState state) {
			this.currentGameState = state;		
		}
	}



