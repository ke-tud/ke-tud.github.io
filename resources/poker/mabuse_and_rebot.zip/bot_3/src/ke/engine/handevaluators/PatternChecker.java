package ke.engine.handevaluators;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import ke.engine.handevaluators.Hand.Rank;
import ke.utils.CardRankComparator;
import ca.ualberta.cs.poker.free.dynamics.Card;

public interface PatternChecker {
	/**
	 * Returns the best hand for the given cards.
	 * 
	 * @param cards cards to check
	 * @return the best hand
	 */
	public Hand check(Collection<Card> cards);

	/**
	 * A pattern checker using regular expressions.
	 */
	public static class Regex implements PatternChecker {
		private static final String ANY_ALPHANUM = "[\\w]";
		private static final String ANY_CARD = ANY_ALPHANUM + ANY_ALPHANUM;
		private static final String ANY_CARDS = "["+ANY_CARD+"]*";
		
		private final List<Pattern> patterns;
		private final List<Hand> hands;

		public Regex(boolean suitMatters) {
			this.patterns = new ArrayList<Pattern>(suitMatters ? 1019 : 301);
			this.hands = new ArrayList<Hand>(suitMatters ? 1019 : 301);
			
			buildPatterns(suitMatters);
		}

		private void buildPatterns(boolean suitMatters) {
			// Initialize
			final Card.Rank[] ranks = Card.Rank.values();
			final Card.Suit[] suits = Card.Suit.values();
			final int maxSuits = suitMatters ? suits.length-1 : 0;

			// POSSIBLE STRAIGHT FLUSHS
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-5; j>=0; j--) {
					final Pattern pattern = Pattern.compile(ANY_CARDS
							+ ranks[j] + suits[i] + ANY_CARDS
							+ ranks[j+1] + suits[i] + ANY_CARDS
							+ ranks[j+2] + suits[i] + ANY_CARDS
							+ ranks[j+3] + suits[i] + ANY_CARDS
							+ ranks[j+4] + suits[i] + ANY_CARDS);
					patterns.add(pattern);
					hands.add(new Hand(Hand.Rank.STRAIGHT_FLUSH, new Card(ranks[j+4],suits[i])));
				}
			}

			// POSSIBLE FOUR-OF-A-KIND
			for(int j=ranks.length-5; j>=0; j--) {
				final Pattern pattern = Pattern.compile(ANY_CARDS
						+ ranks[j] + suits[0] + ANY_CARDS
						+ ranks[j] + suits[1] + ANY_CARDS
						+ ranks[j] + suits[2] + ANY_CARDS
						+ ranks[j] + suits[3] + ANY_CARDS);
				patterns.add(pattern);
				hands.add(new Hand(Hand.Rank.FOUR, new Card(ranks[j],suits[3])));
			}

			// POSSIBLE FULL-HOUSE
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-1; j>=0; j--) {
					for(int k=j-1; k>=0; k--){
						final Pattern pattern = Pattern.compile(ANY_CARDS
								+ ranks[k] + ANY_ALPHANUM + ANY_CARDS
								+ ranks[k] + ANY_ALPHANUM + ANY_CARDS
								+ "("+ranks[j] + ANY_ALPHANUM+"|"
								+ ranks[k] + ANY_ALPHANUM+")" + ANY_CARDS
								+ ranks[j] + ANY_ALPHANUM + ANY_CARDS
								+ ranks[j] + suits[i] + ANY_CARDS);
						patterns.add(pattern);
						hands.add(new Hand(Hand.Rank.FULL_HOUSE, new Card(ranks[j],suits[i])));
					}
				}
			}


			// POSSIBLE FLUSH
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-1; j>=0; j--) {
					final Pattern pattern = Pattern.compile(ANY_CARDS
							+ ANY_ALPHANUM + suits[i] + ANY_CARDS
							+ ANY_ALPHANUM + suits[i] + ANY_CARDS
							+ ANY_ALPHANUM + suits[i] + ANY_CARDS
							+ ANY_ALPHANUM + suits[i] + ANY_CARDS
							+ ranks[j] + suits[i] + ANY_CARDS);
					patterns.add(pattern);
					hands.add(new Hand(Hand.Rank.FLUSH, new Card(ranks[j],suits[i])));
				}
			}

			// POSSIBLE STRAIGHTS
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-5; j>=0; j--) {
					final Pattern pattern = Pattern.compile(ANY_CARDS
							+ ranks[j] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j+1] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j+2] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j+3] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j+4] + (suitMatters ? suits[i] : ANY_ALPHANUM) + ANY_CARDS);
					patterns.add(pattern);
					hands.add(new Hand(Hand.Rank.STRAIGHT, new Card(ranks[j+4],suits[i])));
				}
			}

			// POSSIBLE THREE-OF-A-KIND
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-5; j>=0; j--) {
					final Pattern pattern = Pattern.compile(ANY_CARDS
							+ ranks[j] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j] + (suitMatters ? suits[i] : ANY_ALPHANUM) + ANY_CARDS);
					patterns.add(pattern);
					hands.add(new Hand(Hand.Rank.THREE, new Card(ranks[j],suits[i])));
				}
			}

			// POSSIBLE TWO-PAIRS
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-1; j>=0; j--) {
					for(int k=j-1; k>=0; k--){
						final Pattern pattern = Pattern.compile(ANY_CARDS
								+ ranks[k] + ANY_ALPHANUM + ANY_CARDS
								+ ranks[k] + ANY_ALPHANUM + ANY_CARDS
								+ ranks[j] + ANY_ALPHANUM + ANY_CARDS
								+ ranks[j] + (suitMatters ? suits[i] : ANY_ALPHANUM) + ANY_CARDS);
						patterns.add(pattern);
						hands.add(new Hand(Hand.Rank.TWO_PAIR, new Card(ranks[j],suits[i])));
					}
				}
			}
			// POSSIBLE PAIR
			for(int i=maxSuits; i>=0; i--) {
				for(int j=ranks.length-1; j>=0; j--) {
					final Pattern pattern = Pattern.compile(ANY_CARDS
							+ ranks[j] + ANY_ALPHANUM + ANY_CARDS
							+ ranks[j] + (suitMatters ? suits[i] : ANY_ALPHANUM) + ANY_CARDS);
					patterns.add(pattern);
					hands.add(new Hand(Hand.Rank.PAIR, new Card(ranks[j],suits[i])));
				}
			}
		}
		
		public Regex() {
			this(true);
		}

		@Override
		public Hand check(final Collection<Card> cards) {
			// Sort collection to detect straights
			final List<Card> sorted = new ArrayList<Card>(cards);
			Collections.sort(sorted, CardRankComparator.COMPARATOR);

			final String cardString = Card.arrayToString(sorted.toArray(new Card[0]));
			for(int i=0; i<patterns.size(); i++)
				if(patterns.get(i).matcher(cardString).matches())
					return hands.get(i);

			return new Hand(Rank.HIGH_CARD, sorted.get(0));
		}

	}
}
