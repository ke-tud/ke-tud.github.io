package ke.engine.handevaluators;

import java.util.Collection;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * A hand is a certain combination of cards. Each hand
 * has its own value, defined by its rank and the highest
 * card in it.
 */
public class Hand {
	/**
	 * The standard ranking for poker:
	 * @see http://en.wikipedia.org/wiki/List_of_poker_hands#Standard_ranking
	 */
	public static enum Rank {
		HIGH_CARD(1),
		PAIR(2),
		TWO_PAIR(3),
		THREE(4),
		STRAIGHT(5),
		FLUSH(6),
		FULL_HOUSE(7),
		FOUR(8),
		STRAIGHT_FLUSH(9);

		private int ordinal;

		/** 
		 * Creates a new rank with the given ordinal rank.
		 * 
		 * @param ordinal ordinal rank for comparisons
		 */
		private Rank(int ordinal) {
			this.ordinal = ordinal;
		}

		/**
		 * Returns the ordinal rank for comparisons.
		 * 
		 * @return rank as integer
		 */
		public int getOrdinalRank() {
			return this.ordinal;
		}

	}
	
	/** Rank for this hand */
	private final Rank rank;
	/** Highest card in this hand */
	private final Card highest;
	

	/** Pattern checker to create a hand from a card collection */ 
	private static PatternChecker checker = new PatternChecker.Regex(false);

	/** 
	 * Creates a hand for a given collection of cards
	 * 
	 * @param cards cards to check
	 * @return hand in the given collection
	 */
	public static Hand forCards(Collection<Card> cards) {
		return checker.check(cards);
	}
	
	/** 
	 * Creates a new hand with a given rank and highest card.
	 * 
	 * @param rank standard poker rank
	 * @param highest highest card in this collection
	 */
	public Hand(Rank rank, Card highest) {
		this.rank = rank;
		this.highest = highest;
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		return "["+this.rank+":"+this.highest+"]";
	}

	/**
	 * Returns the standard poker rank of this
	 * hand.
	 * 
	 * @return the standard poker hand
	 */
	public Rank getRank() {
		return this.rank;
	}

	/**
	 * Returns the highest card in this
	 * hand.
	 * 
	 * @return the highest card in this hand
	 */
	public Card getHighest() {
		return this.highest;
	}
	

	/** {@inheritDoc} */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((highest == null) ? 0 : highest.hashCode());
		result = prime * result + ((rank == null) ? 0 : rank.hashCode());
		return result;
	}

	/** {@inheritDoc} */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hand other = (Hand) obj;
		if (highest == null) {
			if (other.highest != null)
				return false;
		} else if (!highest.equals(other.highest))
			return false;
		if (rank == null) {
			if (other.rank != null)
				return false;
		} else if (!rank.equals(other.rank))
			return false;
		return true;
	}

	/**
	 * A comparator class for poker hands. 
	 */
	public static class Comparator implements java.util.Comparator<Hand> {
		
		/**
		 * Default poker comparator which only uses the rank of the
		 * highest card.
		 */
		public static final Comparator DEFAULT = new Comparator
		(new java.util.Comparator<Card>() {
			public int compare(Card o1, Card o2) {
				return o1.rank.compareTo(o2.rank);
			};
		});
		
		/** Comparator for the highest card */
		private final java.util.Comparator<Card> cardComparator;
		
		/** {@inheritDoc} */
		@Override
		public int compare(Hand o1, Hand o2) {
			if(o1.getRank().getOrdinalRank() != o2.getRank().getOrdinalRank())
				return o1.getRank().getOrdinalRank() > o2.getRank().getOrdinalRank() ? 1 : -1;
				
			return cardComparator.compare(o1.getHighest(), o2.getHighest());
		}
		
		/**
		 * Creates a new comparator with the given comparator for
		 * the hand's highest card.
		 * 
		 * @param cardComparator comparator for the highest card
		 */
		public Comparator(java.util.Comparator<Card> cardComparator) {
			super();
			this.cardComparator = cardComparator;
		}

	}

}