package ke.engine.handevaluators;

import java.util.ArrayList;
import java.util.Collection;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class SimpleHandEvaluator implements IHandEvaluator {

	@Override
	public double evaluateHand(Collection<Card> hole, Collection<Card> board) {
		Collection<Card> cards = new ArrayList<Card>(hole);
		Hand.Rank holeRank = Hand.forCards(cards).getRank();
		cards.addAll(board);
		if(cards.size()==0) return Double.NaN;
		
		if(holeRank == Hand.Rank.PAIR) return 0.8;
		
		switch(Hand.forCards(cards).getRank()) {
			case PAIR : return 0.5;
			case TWO_PAIR : return 1;
			case THREE : return 1;
			case STRAIGHT : return 1;
			case FULL_HOUSE : return 1;
			case FLUSH : return 1;
			case FOUR : return 1;
			case STRAIGHT_FLUSH : return 1;
			default : return 0.1;
		}
	}

	@Override
	public double[] evaluatePotential(Collection<Card> hole,
			Collection<Card> board, boolean full) {
		// Not implemented here
		return new double[]{0,0};
	}

}
