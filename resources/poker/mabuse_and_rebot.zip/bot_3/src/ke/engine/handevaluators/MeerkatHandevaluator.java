package ke.engine.handevaluators;

import static ke.data.CONSTANT.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 *
 */
public class MeerkatHandevaluator implements IHandEvaluator {

	/** the number of unknown opponents (standard is 1) */
	private int numOpponents = 1;
	/** instance of the handEvaluator */
	private final poker.HandEvaluator handEvaluator;
	private final poker.HandPotential handPotential;
	
	private poker.Card hole1;
	private poker.Card hole2;
	private poker.Hand handBoard;

	/**
	 * Getter
	 * @return the number of opponents
	 */
	public int getNumOpponents() {
		return this.numOpponents;
	}
	/**
	 * Setter
	 * @param numOpponents - the number of opponents
	 */
	public void setNumOpponents(final int numOpponents) {
		if (numOpponents < 1){
			// Number of opponents must be greater than 0.
			this.numOpponents = 1;
		}
		else if (numOpponents > 9){
			// Number of opponents must be lower than 10.
			this.numOpponents = 9;
		}
		else
			this.numOpponents = numOpponents;
	}
	/**
	 * Constructor
	 */
	public MeerkatHandevaluator(){
		this.setNumOpponents(1);
		this.handEvaluator = new poker.HandEvaluator();
		this.handPotential = new poker.HandPotential();
	}
	/**
	 * Convert the alberta cards to meerkat cards
	 * @param hole cards
	 * @param board cards
	 */
	public void convertCards(
			final Collection<ca.ualberta.cs.poker.free.dynamics.Card> hole, 
			final Collection<ca.ualberta.cs.poker.free.dynamics.Card> board){
		/* 
		 * Convert the card objects from alberta to card objects from meerkat.
		 * (Fortunately they have the same String representation.)
		 */		
		final List<ca.ualberta.cs.poker.free.dynamics.Card> holeCards = new ArrayList<ca.ualberta.cs.poker.free.dynamics.Card>(hole);
		this.hole1 = new poker.Card(holeCards.get(0).toString());
		this.hole2 = new poker.Card(holeCards.get(1).toString());
		
		this.handBoard = new poker.Hand();
		for(final ca.ualberta.cs.poker.free.dynamics.Card card : board){
			if (card == null)
				continue;
			this.handBoard.addCard(new poker.Card(card.toString()));
		}
	}
	
	/**{@inheritDoc}*/
	@Override
	public final double evaluateHand(
			final Collection<ca.ualberta.cs.poker.free.dynamics.Card> hole, 
			final Collection<ca.ualberta.cs.poker.free.dynamics.Card> board) {

		convertCards(hole, board);
		
		final double probBestHand = this.handEvaluator.handRank(this.hole1,this.hole2,this.handBoard,this.numOpponents);

		if (DEBUG)
			System.out.println("The MeerkatHandevaluator says: With my hole cards ["+this.hole1.toString() + this.hole2.toString()+"] and board cards ["+this.handBoard.toString()+"] and against " + this.numOpponents + " opponents I have a "+ probBestHand*100 +"% chance to have the best Hand.");

		return probBestHand;
	}


	/**
	 * Compute the positive and negative potential of the last evaluated hand and board cards.
	 */
	@Override
	public double[] evaluatePotential(
			final Collection<Card> hole, final Collection<Card> board, final boolean full) {
		
		final double[] potentials = new double[]{0.0d,0.0d};
		
		/* compute the potential only until the river */
		/* after the river our potential can't get better or worse (we then know the full board) */
		if (this.handBoard.size() < 5){
			this.handPotential.ppot_raw(this.hole1, this.hole2, this.handBoard, full);
			potentials[0] = this.handPotential.getLastPPot();
			potentials[1] = this.handPotential.getLastNPot();
		}
		
		if(DEBUG){
			System.out.println("The MeerkatHandevaluator says: Assuming i am behind now there's a " + potentials[0]*100 + "%  raw chance i will be ahead as more board cards are dealt." );
			System.out.println("The MeerkatHandevaluator says: Assuming i am ahead now there's a " + potentials[1]*100 + "%  raw chance i will be behind as more board cards are dealt." );
		}
		
		return potentials;
	}
	
	/** 
	 * Get the number of hands that won against our last evaluated hand.
	 * 
	 * @return number of better hands
	 */
	public int getNumBetter(){
		return this.handEvaluator.getNumBetter();
	}

	/**
	 * Get the number of hands that lost against our last evaluated hand.
	 * 
	 *  @return number of worse hands
	 */
	public int getNumWorse(){
		return this.handEvaluator.getNumWorse();
	}

	/**
	 * Get the number of hands that tied against our last evaluated hand.
	 * 
	 * @return number of ties
	 */
	public int getNumTied(){
		return this.handEvaluator.getNumTied();
	}
}
