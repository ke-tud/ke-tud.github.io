package ke.engine.handevaluators;

import java.util.Collection;

import ca.ualberta.cs.poker.free.dynamics.Card;

public interface IHandEvaluator {
	
	/**
	 * Evaluates the probability to have the best hand at the current time given the
	 * hole- and boardcards.
	 * 
	 * @param hole private cards
	 * @param board common cards
	 * @return probability as double value [0..1]; 
	 * NaN, if its value can not be determined.
	 */
	public double evaluateHand(Collection<Card> hole, Collection<Card> board);
	
	/**
	 * Evaluates the probability that a hand that is currently behind will be ahead as 
	 * more board cards are dealt (PPOT) and also the Negative Potential (NPOT) which is 
	 * the probability that a hand that is currently ahead will be behind as more cards 
	 * aredealt. 
	 * 
	 * @param hole private cards
	 * @param board common cards
	 * @param full - if true, a full 2-card look ahead will be done (slow) 
	 * @return double[] - where double[0] is the PPOT (positive potential) 
	 *  and double[1] is the NPOT (negative potential) 
	 */
	public double[] evaluatePotential(Collection<Card> hole, Collection<Card> board, boolean full);
	
}
