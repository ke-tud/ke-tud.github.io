package ke.engine.strategies;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.Round;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.GameTreeBuilder;
import ke.gametree.IGameState;
import ke.gametree.IGameTree;
import ke.gametree.RandomAgent;
import ke.gametree.montecarlo.IAgent;
import ke.gametree.montecarlo.PotExplorerState;
import ke.gametree.montecarlo.PotExploringSimulator;
import ke.gametree.montecarlo.Factory.ConsistencyError;
import ke.history.ActionMonitor;
import ke.opponent.Opponent;
import ke.opponent.OpponentBuilder;
import ke.opponent.SimpleAgent;
import ke.timermgmt.TimedLoop;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 *
 */
public class OracleSimOpAdvisor implements IStrategy {

	private static final double[][] DEFAULT_ACTION_RATIO =
		new double[][] {
		{ 0.15d, 0.4d, 0.45 },
		{ 0.15d, 0.4d, 0.45 },
		{ 0.2d, 0.5d, 0.35d },
		{ 0.2d, 0.5d, 0.35d },
		{ 0.2d, 0.5d, 0.35d }
	};
	
	private Action currently_best_action;
	private MeerkatHandevaluator handEvaluator;
	private OpponentBuilder opBuilder;

	/**
	 * Constructor
	 * @param opponentBuilder 
	 */
	public OracleSimOpAdvisor(final OpponentBuilder opponentBuilder) {
		this.currently_best_action = Action.CALL; 
		this.handEvaluator = new MeerkatHandevaluator();
		this.opBuilder = opponentBuilder;
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized Action getAction() {
		return this.currently_best_action;
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics) {
		/* Evaluate Hand */	
		this.handEvaluator.setNumOpponents(dynamics.getNumberActiveSeats()-1);

		double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());

		double[] potentials = this.handEvaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard(),
				false);

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);

//		if(dynamics.getCurrentHandNumber() > 1 && dynamics.getRound().equals(Round.PREFLOP)){
//			Debug.log(Option.ACTION_MONITOR, "playerratios from history: ");
//			Debug.log(Option.ACTION_MONITOR, "0: " + Utils.ArrayToString(History.getHistory().getGlobal().getPlayerRatio()[0]));
//			Debug.log(Option.ACTION_MONITOR, "1: " + Utils.ArrayToString(History.getHistory().getGlobal().getPlayerRatio()[1]));
//			Debug.log(Option.ACTION_MONITOR, "2: " + Utils.ArrayToString(History.getHistory().getGlobal().getPlayerRatio()[2]));
//		}

	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {

		/* initialize dynamics */
		dynamics.dealRandomCards(dynamics.getRound(), dynamics.getCurrentSeat().getIndex());

		List<IAgent> agents;
		if(dynamics.getRound().equals(Round.PREFLOP))
			agents = createPreFlopAgents(dynamics, probBestHand);
		else
			agents = createPostFlopAgents(dynamics, probBestHand + pPotential - nPotential, this.opBuilder);

		final IGameTree<PotExplorerState> tree = createGameTree(dynamics, agents,
				500, probBestHand + pPotential - nPotential);

		final PotExplorerState call = tree.get(Collections.singletonList(Action.CALL));
		final PotExplorerState raise = tree.get(Collections.singletonList(Action.RAISE));

		final double ePotSize = (call.getAvgPotSize() + raise.getAvgPotSize()) / 2;

		final double eInPot = (call.getAvgCosts() + raise.getAvgCosts()) / 2;

		final double opStrength = getStrongestOpStrength(dynamics, probBestHand);
		
		final double myModelStrength = getMyModelStrength(dynamics);

		final double probToWin = (call.getRatio() + raise.getRatio()) / 2;

		final double probToLose = (1d - probToWin);

		final double oddsValue = (
				((probToWin)  * (ePotSize - eInPot)) 
				- 
				((probToLose) * eInPot)
		);

		/* compute my advice */
		if (oddsValue  >= eInPot && opStrength < 0.85d){
			this.currently_best_action = Action.CALL;
			if ((probToWin + pPotential) > 0.75d || opStrength < 1/4)
				this.currently_best_action = Action.RAISE;
		}
		else{
			this.currently_best_action = Action.FOLD;
		}


		final boolean iHaveButtonInPF = (dynamics.getCurrentSeat().getIndex() == dynamics.getNumberSeats() - 1) && dynamics.getRound().equals(Round.PREFLOP);
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;		

		if (this.currently_best_action.equals(Action.FOLD))
			if((iHaveButtonInPF && dynamics.getRoundBets() <= 1) || noMoreCostsForNextCards || opStrength < 1/4)
				this.currently_best_action = Action.CALL;

		Debug.log(Option.ORACLE_SIM_OP_ADVISOR, "------\n" + "HandNumber: " + dynamics.getCurrentHandNumber() + " | Iterations: " + call.getIterations());
		Debug.log(Option.ORACLE_SIM_OP_ADVISOR, "MySeatId: " + dynamics.getCurrentSeat().getIndex() + "; NumSeatsleftToAct: " + dynamics.getNumberSeatLeftToAct() + "; NumSeatsActive: " +dynamics.getNumberActiveSeats());
		Debug.log(Option.ORACLE_SIM_OP_ADVISOR,  dynamics.getRound() + "(" + this.currently_best_action + ")" + "- Estimated PotSize: " + ePotSize + " | Estimated Costs: " + eInPot + " | OddsValue: " + oddsValue + " | NumberActivePlayers: " + dynamics.getNumberActiveSeats());
		Debug.log(Option.ORACLE_SIM_OP_ADVISOR, "NoMoreCostsForNextCards: " + noMoreCostsForNextCards + "; iHaveButtonInPF & roundBets <= 1: " + (iHaveButtonInPF && dynamics.getRoundBets() <= 1));
		Debug.log(Option.ORACLE_SIM_OP_ADVISOR, "probWin: " + probToWin + "; probLose:" + probToLose + "; Opponents Strength: " + opStrength + "; MyModelledStrentgh: " + myModelStrength + "; expectedAmountWon: " + call.getValue());

	}


	private IGameTree<PotExplorerState> createGameTree(
			final IGameState<?> state, final List<IAgent> agents,
			final long proposedTime, final double probBestHand) throws ConsistencyError {

		final GameTreeBuilder<PotExplorerState> builder
		= new GameTreeBuilder<PotExplorerState>(
				new PotExplorerState(state));

		final PotExploringSimulator task = new PotExploringSimulator(
				builder, state.getCurrentSeat().getIndex(), agents,probBestHand,Math.sqrt(2));

		TimedLoop.fromRunnable(task).run(proposedTime);

		final IGameTree<PotExplorerState> tree =
			builder;

		return tree;
	}


	private List<IAgent> createPreFlopAgents(final IGameState<?> dynamics, final double probBestHand) {
		final IAgent[] playerAgents = new IAgent[dynamics.getNumberSeats()];

		for(int i=0; i < dynamics.getNumberSeats(); i++) {
			if(!dynamics.getSeat(i).isActive())
				continue;

			final int playerIndex = dynamics.getSeat(i).getPlayerIndex();

			double[][] ratio;
			if(dynamics.getCurrentHandNumber() > CONSTANT.WINDOW_SIZE)
				ratio = ActionMonitor.getInstance().getWindowData().getPlayerActionRatios(playerIndex);/*History.getHistory().getGlobal().getPlayerRatio()[playerIndex];*/
			else 
				ratio = DEFAULT_ACTION_RATIO;

			if(i == dynamics.getCurrentSeat().getIndex()){
				playerAgents[i] = new RandomAgent(0d, 0.8d, 0.2d);
			}else {
				double opponentStrength = 1-probBestHand;
				playerAgents[i] =  new SimpleAgent(
						ratio,opponentStrength);
			}
		}
		List<IAgent> result = Arrays.asList(playerAgents);
		return result;
	}	

	/*
	 * Creates a list of agents for a MC simulation.
	 */
	private List<IAgent> createPostFlopAgents(final IGameState<?> dynamics,
			final double probBestHand, final OpponentBuilder opponentBuilder) {

		final IAgent[] playerAgents = new IAgent[dynamics.getNumberSeats()];

		for(int i=0; i < dynamics.getNumberSeats(); i++) {
			if(!dynamics.getSeat(i).isActive())
				continue;

			final int playerIndex = dynamics.getSeat(i).getPlayerIndex();
			Opponent opponent = opponentBuilder.getOpponent(playerIndex);

			final Round round = dynamics.getRound();

			final double[][] ratio = ActionMonitor.getInstance().getWindowData().getPlayerActionRatios(playerIndex);/*History.getHistory().getGlobal().getPlayerRatio()[playerIndex];*/

			if(i == dynamics.getCurrentSeat().getIndex()){
				playerAgents[i] = new RandomAgent(0d, 0.8d, 0.2d);
			}else {
				double opponentStrength;

				if(opponent.getCurrentRaises(round.getPreviousRound()) > 0)
					opponentStrength = opponent.getRaiseEstimates(
							dynamics.getRound().getPreviousRound(), opponent.getCurrentRaises(round.getPreviousRound()));
				else
					opponentStrength = opponent.getCallEstimates(
							dynamics.getRound().getPreviousRound(), opponent.getCurrentCalls(round.getPreviousRound()));

				if(opponentStrength < 0) opponentStrength = 1-probBestHand;

				playerAgents[i] =  new SimpleAgent(
						ratio,opponentStrength);
			}
		}

		List<IAgent> result = Arrays.asList(playerAgents);
		return result;
	}

	private double getStrongestOpStrength(IGameState<?> dynamics, final double probBestHand){
		double strongest = 0d;

		if(dynamics.getRound().equals(Round.PREFLOP))
			return (1d - probBestHand);

		for(int i=0; i < dynamics.getNumberSeats(); i++) {
			if(!dynamics.getSeat(i).isActive() || dynamics.getSeat(i).equals(dynamics.getCurrentSeat()))
				continue;

			Opponent opponent = this.opBuilder.getOpponent(dynamics.getSeat(i));

			double opponentStrength;
			if(opponent.getCurrentRaises(dynamics.getRound().getPreviousRound())>0)
				opponentStrength = opponent.getRaiseEstimates(
						dynamics.getRound().getPreviousRound(), opponent.getCurrentRaises(dynamics.getRound().getPreviousRound()));
			else{
				opponentStrength = opponent.getCallEstimates(
						dynamics.getRound().getPreviousRound(), opponent.getCurrentCalls(dynamics.getRound().getPreviousRound()));
				opponentStrength -= 0.2d;
			}

			if(opponentStrength > strongest)
				strongest = opponentStrength;
		}
		if(strongest < 0) strongest = 1-probBestHand;
		return strongest;
	}

	private double getMyModelStrength(IGameState<?> dynamics) {

		final Opponent myOpModel = this.opBuilder.getOpponent(dynamics.getCurrentSeat().getPlayerIndex());

		double myStrength;
		if(myOpModel.getCurrentRaises(dynamics.getRound().getPreviousRound())>0)
			myStrength = myOpModel.getRaiseEstimates(
					dynamics.getRound().getPreviousRound(), myOpModel.getCurrentRaises(dynamics.getRound().getPreviousRound()));
		else{
			myStrength = myOpModel.getCallEstimates(
					dynamics.getRound().getPreviousRound(), myOpModel.getCurrentCalls(dynamics.getRound().getPreviousRound()));
			myStrength -= 0.2d;
		}

		return myStrength;
	}
}
