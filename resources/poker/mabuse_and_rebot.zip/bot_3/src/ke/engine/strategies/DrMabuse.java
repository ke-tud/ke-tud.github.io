package ke.engine.strategies;

import java.util.Random;

import ke.data.Action;
import ke.engine.handevaluators.IHandEvaluator;
import ke.engine.handevaluators.SimpleHandEvaluator;
import ke.gametree.*;

/**
 *
 */
public class DrMabuse implements IStrategy {
	private Action nextAction = null; 
	private final IHandEvaluator handEvaluator = new SimpleHandEvaluator(); 
	private static final Random random = new Random();
	
	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		return this.nextAction;
	}
	

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics) {
		final double prob = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());
		
		System.out.println("My chance to win is about "+prob*100+"%");
		
		evaluateSituation(dynamics, prob, 0, 0);
		
		System.out.println("My next action will be "+this.nextAction);
	}

	/*
	 * Calculates an estimated profit with simple pot odds. 
	 */
	private static double calculateSimplePotOdds(final double prob, 
			final IGameState<?> dynamics) {
		// Winning probability

		
		int inPot = 0; // Amount of chips in pot
		for(int i = 0; i < dynamics.getNumberSeats(); i++){
			inPot += dynamics.getSeat(i).getStakes();
		}
		
		final int nextCall = dynamics.getCurrentSeat().getAmountToCall(); // Costs of another call
		
		final double profit = prob * inPot + (1-prob)*(-nextCall);
		return profit;
	}
	
	/*
	 * Calculates an estimated profit with oracle pot. 
	 */
	private static double calculateOraclePot(final double prob, 
			final IGameState<?> dynamics) {
		// Winning probability
		
		final int myContribution = dynamics.getCurrentSeat().getStakes();
		int inPot = 0; // Amount of chips in pot
		for(int i = 0; i < dynamics.getNumberSeats(); i++){
			inPot += dynamics.getSeat(i).getStakes();
		}
		
		final int potValueEstimation = 
//FIXME:			((dynamics.roundBets+1) / (dynamics.roundIndex+1)) * 
			inPot;
		
		final int costEstimation = 
//FIXME:			((dynamics.roundBets+1) / (dynamics.roundIndex+1)) * 
			myContribution;
		
		final double profit = prob * (potValueEstimation - costEstimation)
						+ (1-prob)*(-costEstimation);
		
		return profit - myContribution;
	}
	
	private static Action guess(final Action first, final Action second) {
		final double dice = random.nextDouble();
		if(dice>0.5) return first;
		return second;
	}


	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double PPotential, final double nPotential) {
		
		if(Double.isNaN(probBestHand)) 
			this.nextAction = guess(Action.CALL, Action.FOLD);
		else {
			final double profit = 
				(calculateSimplePotOdds(probBestHand, dynamics) 
						+ calculateOraclePot(probBestHand, dynamics)) / 2;
			System.out.println("The estimated profit is "+profit);
			final double dice = random.nextDouble();

			if(profit > 0)
				if(dice > probBestHand)
					this.nextAction = Action.RAISE;
				else
					this.nextAction = Action.CALL;
			else
				this.nextAction = Action.FOLD;
		}
	}
}
