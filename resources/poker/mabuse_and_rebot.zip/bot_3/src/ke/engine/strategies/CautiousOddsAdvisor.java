package ke.engine.strategies;

import ke.data.Action;
import ke.data.Round;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;
import ke.utils.Debug;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 *
 */
public class CautiousOddsAdvisor implements IStrategy {

	private final MeerkatHandevaluator handEvaluator;
	
	private Action currently_best_action;

	/**
	 * Constructor
	 */
	public CautiousOddsAdvisor() {
		this.currently_best_action = Action.CALL; 
		this.handEvaluator = new MeerkatHandevaluator();
	}
	
	private void evalPreflop(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential){

		final boolean iHaveButton = dynamics.getCurrentSeat().getIndex() == dynamics.getNumberSeats() - 1;
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;
		
		if((probBestHand - 0.1 * dynamics.getRoundBets() ) > 0){
			this.currently_best_action = Action.CALL;
			if ((probBestHand + pPotential - nPotential) > 0.95d)
				this.currently_best_action = Action.RAISE;	
		}else{
			this.currently_best_action = Action.FOLD;
		}
		
		if (this.currently_best_action.equals(Action.FOLD))
			if((iHaveButton && dynamics.getRoundBets() <= 1) || noMoreCostsForNextCards)
				this.currently_best_action = Action.CALL;
	}
	
	private void evalFlop(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential){
		
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;
		
		final OddsAdvisor a = new OddsAdvisor();
		
		a.evaluateSituation(dynamics, probBestHand - 0.1 * dynamics.getRoundBets(), pPotential, nPotential);
		
		this.currently_best_action = a.getImpliedPotOddsAction();
		
		if(this.currently_best_action.equals(Action.FOLD))
			if(dynamics.getRoundBets() < 1 || noMoreCostsForNextCards)
				this.currently_best_action = Action.CALL;
		
	}
	
	private void evalTurn(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential){
		
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;
		
		final OddsAdvisor a = new OddsAdvisor();
		
		a.evaluateSituation(dynamics, probBestHand - 0.1 * dynamics.getRoundBets() , pPotential, nPotential);
		
		this.currently_best_action = a.getImpliedPotOddsAction();
		
		if(this.currently_best_action.equals(Action.FOLD))
			if(dynamics.getRoundBets() < 1 || noMoreCostsForNextCards)
				this.currently_best_action = Action.CALL;
		
	}
	
	private void evalRiver(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential){
		
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;

		final OddsAdvisor a = new OddsAdvisor();
		
		a.evaluateSituation(dynamics, probBestHand - 0.1 * dynamics.getRoundBets(), pPotential, nPotential);
		
		this.currently_best_action = a.getPotOddsAction();
		
		if(this.currently_best_action.equals(Action.FOLD))
			if(dynamics.getRoundBets() < 1 || noMoreCostsForNextCards)
				this.currently_best_action = Action.CALL;

	}
	
	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics) {
		/* Evaluate Hand */	
		this.handEvaluator.setNumOpponents(dynamics.getNumberActiveSeats()-1);

		final double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());

		final double[] potentials = this.handEvaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard(),
				false);

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);

		Debug.log(Option.GAME_DECISION, this.currently_best_action);
		
		Debug.log(Option.GAME_STATE, "Round: "
				+dynamics.getRound()+", id: "+dynamics.getCurrentSeat().getIndex()
				+" ("+dynamics.getCurrentSeat().getPlayerIndex()
				+"), inPot="+dynamics.getCurrentSeat().getStakes());

		Debug.log(Option.GAME_CARDS, "Board: "+dynamics.getBoard()+", my hole: "
				+dynamics.getCurrentSeat().getHoles());
		
		Debug.log(
				"iHaveButton? " +
				(dynamics.getCurrentSeat().getIndex() == dynamics.getNumberSeats() - 1) + 
				" | noMoreCostsForNewCards? " + 
				(dynamics.getCurrentSeat().getAmountToCall() <= 1)
				+ " | iAmFirstToAct? " +  
				(dynamics.getRoundBets() < 1));
		
	}

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics, final double probBestHand,
			final double pPotential, final double nPotential) {
		
		switch(dynamics.getRound()){
		case PREFLOP: 
			evalPreflop(dynamics, probBestHand, pPotential, nPotential);
			break;
		case FLOP: 
			evalFlop(dynamics, probBestHand, pPotential, nPotential);
			break;
		case TURN: 
			evalTurn(dynamics, probBestHand, pPotential, nPotential);
			break;
		case RIVER: 
			evalRiver(dynamics, probBestHand, pPotential, nPotential);
			break;
		default:
			/* nothing to do */
		}
	}

	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		return this.currently_best_action;
	}

}
