package ke.engine.strategies;

import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.data.Round;
import ke.engine.handevaluators.IHandEvaluator;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.IGameState;
import ke.history.BetMonitor;
import ke.history.MoneyMonitor;
import ke.opponent.Opponent;
import ke.opponent.OpponentBuilder;
import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 * An Expert using a more sophisticated OraclePotEstimator.
 */
public class OracleOpAdvisor implements IStrategy {

	private Action currently_best_action;
	private IHandEvaluator handEvaluator;
	private OpponentBuilder opBuilder;
	private IStrategy oracleAdvisor;

	/**
	 * Constructor
	 * @param opponentBuilder 
	 */
	public OracleOpAdvisor(final OpponentBuilder opponentBuilder) {
		this.currently_best_action = Action.CALL; 
		this.handEvaluator = new MeerkatHandevaluator();
		this.opBuilder = opponentBuilder;
		this.oracleAdvisor = new OracleAdvisor();
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized Action getAction() {
		return this.currently_best_action;
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics) {
		/* Evaluate Hand */	
		((MeerkatHandevaluator)this.handEvaluator).setNumOpponents(dynamics.getNumberActiveSeats()-1);

		double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());

		double[] potentials = this.handEvaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard(),
				false);

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);

	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {

		if (dynamics.getCurrentHandNumber() < CONSTANT.WINDOW_SIZE || dynamics.getRound().equals(Round.PREFLOP)){
			this.oracleAdvisor.evaluateSituation(dynamics, probBestHand, pPotential, nPotential);
			this.currently_best_action = this.oracleAdvisor.getAction();
		}
		else 
			evalPostFlop(dynamics, probBestHand, pPotential, nPotential);
	}

	private void evalPostFlop(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential){

		final double strongestOpStrength = getStrongestOpStrength(dynamics, probBestHand);
		final double weakestOpStrength = getWeakestOpStrength(dynamics, probBestHand);

		/* amount to call in this round*/
		final double eAmountToPayInCurrentRound = computeCurrentRoundCosts(dynamics);

		/* amount to pay in all the future rounds */
		double eAmountToPayInFutureRounds = computeFutureRoundCosts(dynamics);


		/* estimation of the minimum potsize at showdown */ 
		final double ePotSize = 
			dynamics.getCurrentPotSize() + 
			(eAmountToPayInCurrentRound * (dynamics.getNumberSeatLeftToAct() + 1)) +
			(eAmountToPayInFutureRounds * dynamics.getNumberActiveSeats());

		/* estimation of the minimum costs until showdown */
		final double eInPot = 
			dynamics.getCurrentSeat().getStakes() + 
			eAmountToPayInCurrentRound + 
			eAmountToPayInFutureRounds;
		
		final double oddsValue = 
			((probBestHand + pPotential - nPotential) * (ePotSize - eInPot)) 
			- 
			((strongestOpStrength/* + nPotential*/) * eInPot);

		/* compute my advice */
		double offset = MoneyMonitor.getInstance().getWindowData().getAvgMoneyEarned(dynamics.getCurrentSeat().getPlayerIndex());
		if (oddsValue  >= 1d){
			this.currently_best_action = Action.CALL;
			if ((probBestHand + pPotential) > 0.9d)
				this.currently_best_action = Action.RAISE;
		}
		else{
			this.currently_best_action = Action.FOLD;
		}

		final boolean iHaveButtonInPF = (dynamics.getCurrentSeat().getIndex() == dynamics.getNumberSeats() - 1) && dynamics.getRound().equals(Round.PREFLOP);
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;		

		if (this.currently_best_action.equals(Action.FOLD))
			if((iHaveButtonInPF && dynamics.getRoundBets() <= 1) || noMoreCostsForNextCards)
				this.currently_best_action = Action.CALL;
		
		Debug.log(Option.ORACLE_OP_ADVISOR, "HandNumber: " + dynamics.getCurrentHandNumber());
		Debug.log(Option.ORACLE_OP_ADVISOR, "MySeatId: " + dynamics.getCurrentSeat().getIndex() + "; NumSeatsleftToAct: " + dynamics.getNumberSeatLeftToAct() + "; NumSeatsActive: " +dynamics.getNumberActiveSeats());
		Debug.log(Option.ORACLE_OP_ADVISOR, dynamics.getRound() + "(" + this.currently_best_action + ")" + "- Estimated PotSize: " + ePotSize + " | Estimated Costs: " + eInPot + " | OddsValue: " + oddsValue + " | NumberActivePlayers: " + dynamics.getNumberActiveSeats());
		Debug.log(Option.ORACLE_OP_ADVISOR, "My Strength: " + probBestHand + " +" +pPotential + " -" + nPotential);
		Debug.log(Option.ORACLE_OP_ADVISOR, "Offset: " + offset);
		Debug.log(Option.ORACLE_OP_ADVISOR, "Strongest Op Strength: " + strongestOpStrength);
		Debug.log(Option.ORACLE_OP_ADVISOR, "Weakest Op Strength: " + weakestOpStrength);
	}

	/**
	 * Compute the estimated amount to pay in the upcoming rounds
	 */
	private double computeFutureRoundCosts(IGameState<?> dynamics){
		double eFutureRoundContribs = 0;
		Round futureRound = dynamics.getRound();
		while((futureRound = futureRound.getNextRound()) != Round.SHOWDOWN){
			for(int i = 0; i < dynamics.getNumberActiveSeats(); i++){
				double prPlayerStaysIn = 1d;
				double playerBetRate = BetMonitor.getInstance().getCurrentRoundData().getAvgBetsFromPlayer(i, GameState.roundIndexToGameState(dynamics.getRound().getPreviousRound().getIndex()));
				eFutureRoundContribs += prPlayerStaysIn * playerBetRate * futureRound.getLimitBet();
			}
		}
		return eFutureRoundContribs / dynamics.getNumberActiveSeats();
	}
	
	/**
	 * Compute the estimated amount to pay in the current round
	 */
	private double computeCurrentRoundCosts(IGameState<?> dynamics){
		double eCurrentRoundContribs = 0;
		for(int i = 0; i < dynamics.getNumberSeats(); i++){
			if(!dynamics.getSeat(i).isActive() || !dynamics.getSeat(i).canRaiseNextTurn())
				continue;
			double prPlayerStaysIn = 1d;
			double playerBetRate = BetMonitor.getInstance().getCurrentRoundData().getAvgBetsFromPlayer(
					dynamics.getSeat(i).getPlayerIndex(), 
					GameState.roundIndexToGameState(dynamics.getRound().getPreviousRound().getIndex()));
			double eBets = playerBetRate - BetMonitor.getInstance().getCurrentRoundData().getBetsInStateFromPlayer(
					GameState.roundIndexToGameState(dynamics.getRound().getIndex()), 
					dynamics.getSeat(i).getPlayerIndex());
			if (eBets < 0)
				eBets = 0;
			eCurrentRoundContribs += prPlayerStaysIn * eBets * dynamics.getRound().getLimitBet();
		}
		return eCurrentRoundContribs / (dynamics.getNumberSeatLeftToAct() + 1);
	}
	
	private double getStrongestOpStrength(IGameState<?> dynamics, final double probBestHand){
		double strongest = 0d;
		for(int i=0; i < dynamics.getNumberSeats(); i++) {
			if(!dynamics.getSeat(i).isActive() || dynamics.getSeat(i).equals(dynamics.getCurrentSeat()))
				continue;

			Opponent opponent = this.opBuilder.getOpponent(dynamics.getSeat(i));
			
			double opponentStrength;
			if(opponent.getCurrentRaises(dynamics.getRound().getPreviousRound())>0)
				opponentStrength = opponent.getRaiseEstimates(
						dynamics.getRound().getPreviousRound(), opponent.getCurrentRaises(dynamics.getRound().getPreviousRound()));
			else
				opponentStrength = opponent.getCallEstimates(
						dynamics.getRound().getPreviousRound(), opponent.getCurrentCalls(dynamics.getRound().getPreviousRound()));

			if(opponentStrength > strongest)
				strongest = opponentStrength;
		}
		if(strongest < 0) strongest = 1-probBestHand;
		return strongest;
	}
	
	private double getWeakestOpStrength(IGameState<?> dynamics, final double probBestHand){
		double weakest = 1d;
		for(int i=0; i < dynamics.getNumberSeats(); i++) {
			if(!dynamics.getSeat(i).isActive() || dynamics.getSeat(i).equals(dynamics.getCurrentSeat()))
				continue;

			Opponent opponent = this.opBuilder.getOpponent(dynamics.getSeat(i));

			double opponentStrength;
			if(opponent.getCurrentRaises(dynamics.getRound().getPreviousRound())>0)
				opponentStrength = opponent.getRaiseEstimates(
						dynamics.getRound().getPreviousRound(), opponent.getCurrentRaises(dynamics.getRound().getPreviousRound()));
			else
				opponentStrength = opponent.getCallEstimates(
						dynamics.getRound().getPreviousRound(), opponent.getCurrentCalls(dynamics.getRound().getPreviousRound()));

			if(opponentStrength < weakest)
				weakest = opponentStrength;
		}
		if(weakest < 0) weakest = 1-probBestHand;
		return weakest;
	}

}
