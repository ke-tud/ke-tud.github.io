package ke.engine.strategies;

import static ke.data.CONSTANT.DEBUG;
import ke.data.Action;
import ke.data.Round;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 *  
 */
public class OddsAdvisor implements IStrategy {
	

	
	private static class Odds{
		
		public static double getPotOdds(IGameState<?> dynamics, final double probBestHand){
			final double odds = (dynamics.getCurrentPotSize() + dynamics.getCurrentSeat().getAmountToCall()) * probBestHand;
			return odds;
		}
		
		public static double getImpliedOdds(final IGameState<?> dynamics, final double probBestHand){
			
			/* amount of upcoming players in this round which not yet have bet including me */
			final int upcomingPlayers = dynamics.getNumberSeatLeftToAct() + 1; 
			
			int amountToCallInFutureRounds = 0;
			Round future = dynamics.getRound();
			while((future = future.getNextRound()) != Round.SHOWDOWN)
				amountToCallInFutureRounds = future.getLimitBet();
			
			/* estimation of the minimum potsize at showdown */ 
			final double ePotSize = 
				dynamics.getCurrentPotSize() + 
				(dynamics.getCurrentSeat().getAmountToCall() * upcomingPlayers) +
				(amountToCallInFutureRounds * dynamics.getNumberActiveSeats());
			
			final double odds = ePotSize * probBestHand;
			
			return odds;
		}
		
		public static double getImpliedOddsValue(final IGameState<?> dynamics, final double probBestHand){
			
			final double odds = getImpliedOdds(dynamics, probBestHand);
			
			int amountToCallInFutureRounds = 0;
			Round future = dynamics.getRound();
			while((future = future.getNextRound()) != Round.SHOWDOWN)
				amountToCallInFutureRounds = future.getLimitBet();
			
			/* estimation of the minimum costs until showdown */
			final double eInPot = 
				dynamics.getCurrentSeat().getStakes() + 
				dynamics.getCurrentSeat().getAmountToCall() + 
				amountToCallInFutureRounds;
			
			return odds - eInPot;
		}
		
		public static double getPotOddsValue(IGameState<?> dynamics, final double probBestHand){
			final double odds = getPotOdds(dynamics, probBestHand);
			return odds - dynamics.getCurrentSeat().getStakes();
		}
		
		
	}

	private Action impliedPotOddsAction;
	private Action potOddsAction;
	private MeerkatHandevaluator handEvaluator;

	/**
	 * Constructor
	 */
	public OddsAdvisor() {
		this.impliedPotOddsAction = Action.CALL; 
		this.handEvaluator = new MeerkatHandevaluator();
	}


	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics) {
		/* Evaluate Hand */	
		this.handEvaluator.setNumOpponents(dynamics.getNumberActiveSeats()-1);

		double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());

		double[] potentials = this.handEvaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard(),
				false);

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);

		if (DEBUG)
			System.out.println("The OddsAdvisor says: I think i would " + this.impliedPotOddsAction + ".");		
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {
				
		final int maxUpcomingBetsInCurrentRound = 4 - dynamics.getRoundBets();
		
		final int maxAmountToCallInCurrentRound = dynamics.getRound().getLimitBet() * maxUpcomingBetsInCurrentRound;
		
		int maxAmountToCallInFutureRounds = 0;
		Round future = dynamics.getRound();
		while(!(future = future.getNextRound()).equals(Round.SHOWDOWN))
			maxAmountToCallInFutureRounds += future.getLimitBet() * 4;
				
		/* compute pot odds action */
		final double potOddsValue = Odds.getPotOdds(dynamics, probBestHand + pPotential - nPotential);
		if(potOddsValue >= 0){
			this.potOddsAction = Action.CALL;
			if(potOddsValue > maxAmountToCallInCurrentRound){
				this.potOddsAction = Action.RAISE;
			}
		}else{
			this.potOddsAction = Action.FOLD;
		}
		
		/* compute implied pot odds action */		
		final double impliedOddsValue = Odds.getImpliedOdds(dynamics, probBestHand + pPotential - nPotential);			
		if(impliedOddsValue >= 0){
			this.impliedPotOddsAction = Action.CALL;
			if(impliedOddsValue > maxAmountToCallInCurrentRound + maxAmountToCallInFutureRounds){
				this.impliedPotOddsAction = Action.RAISE;
			}
		}else{
			this.impliedPotOddsAction = Action.FOLD;
		}
	}
	

	/**{@inheritDoc}*/
	@Override
	public Action getAction() {
		return this.impliedPotOddsAction;
	}
	
	/**
	 * @return potOddsAction
	 */
	public Action getPotOddsAction(){
		return this.potOddsAction;
	}
	
	/**
	 * @return impliedPotOddsAction
	 */
	public Action getImpliedPotOddsAction(){
		return this.potOddsAction;
	}
}
