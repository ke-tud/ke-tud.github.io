package ke.engine.strategies;

import java.util.ArrayList;
import java.util.List;

import ke.data.Action;
import ke.data.Round;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.GameTreeBuilder;
import ke.gametree.GameTreeIterators;
import ke.gametree.IGameState;
import ke.gametree.IGameTree;
import ke.gametree.RandomAgent;
import ke.gametree.GameTreeIterators.Path;
import ke.gametree.IGameTree.INavigator;
import ke.gametree.montecarlo.BayesianSimulator;
import ke.gametree.montecarlo.IAgent;
import ke.gametree.montecarlo.MonteCarloSimulator;
import ke.gametree.montecarlo.MonteCarloState;
import ke.gametree.montecarlo.Factory.ConsistencyError;
import ke.history.History;
import ke.opponent.Opponent;
import ke.opponent.OpponentBuilder;
import ke.opponent.SimpleAgent;
import ke.timermgmt.TimeManager;
import ke.timermgmt.TimedLoop;
import ke.utils.Debug;
import ke.utils.Utils;
import ke.utils.Debug.Option;

/**
 * 
 *
 */
public class SimulatingOracleAdvisor implements IStrategy {
	/**
	 * 
	 */
	static class AdvisorAgent implements IAgent{

		private double probBestHand;
		private double pPotential;
		private double nPotential;
		private final IStrategy advisor;

		/**
		 * Constructor
		 * @param advisor
		 */
		public AdvisorAgent(final IStrategy advisor){
			this.advisor = advisor;
		}

		/**
		 * Set the informationss needed to tell the advisor
		 * @param probBestHand
		 * @param pPotential
		 * @param nPotential
		 */
		public void setVariables(final double probBestHand, final double pPotential, final double nPotential){
			this.probBestHand = probBestHand;
			this.pPotential = pPotential;
			this.nPotential = nPotential;
		}

		/**{@inheritDoc}*/
		@Override
		public Action getAction(final IGameState<?> state) {
			/* askt the advisor */
			this.advisor.evaluateSituation(state, this.probBestHand, this.pPotential, this.nPotential);
			return this.advisor.getAction();
		}
	}

	private Action currently_best_action;
	private final MeerkatHandevaluator handEvaluator;
	private final IStrategy counselor;
	private OpponentBuilder opponentBuilder;

	/**
	 * @return the opponentBuilder
	 */
	protected final OpponentBuilder getOpponentBuilder() {
		return this.opponentBuilder;
	}

	/**
	 * @param opponentBuilder the opponentBuilder to set
	 */
	protected final void setOpponentBuilder(final OpponentBuilder opponentBuilder) {
		this.opponentBuilder = opponentBuilder;
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized Action getAction() {
		return this.currently_best_action;
	}

	private static final double[][] DEFAULT_RATIO =
		new double[][] {
		{ 0.15d, 0.4d, 0.45 },
		{ 0.15d, 0.4d, 0.45 },
		{ 0.2d, 0.5d, 0.35d },
		{ 0.2d, 0.5d, 0.35d },
		{ 0.2d, 0.5d, 0.35d }
	};

	/*
	 * Creates a list of agents for a MC simulation.
	 */
	private static List<IAgent> createAgents(final IGameState<?> dynamics,
			final double probBestHand, final OpponentBuilder opponentBuilder) {
		final List<IAgent> playerAgents = new ArrayList<IAgent>(dynamics.getNumberSeats());
		for(int i=0; i < dynamics.getNumberSeats(); i++) {
			final Opponent opponent = opponentBuilder.getOpponent(dynamics.getSeat(i));
			final int playerIndex = dynamics.getSeat(i).getPlayerIndex();
			final Round round = dynamics.getRound();
			if(round!=Round.PREFLOP)
				Debug.log(Option.GAME_OPPONENT_MODEL,
						"Opponent analysis for player "+playerIndex+" in round "+round+"\n"+
						opponent.getCurrentCalls(round.getPreviousRound())+" calls and "+opponent.getCurrentRaises(round.getPreviousRound())
						+" raises in round "+round.getPreviousRound()+": "+opponent.getCallEstimates(round.getPreviousRound(),
								opponent.getCurrentCalls(round.getPreviousRound()))+
								", "+opponent.getRaiseEstimates(round.getPreviousRound(), opponent.getCurrentRaises(round.getPreviousRound())));
			final double[][] ratio;

			if(History.getHistory().getCurRoundNumber()>10
					&& dynamics.getRound()!=Round.PREFLOP)
				ratio = History.getHistory().getGlobal().getPlayerRatio()[playerIndex];
			else
				ratio = DEFAULT_RATIO;

			if(i==dynamics.getCurrentSeat().getIndex())
				playerAgents.add(new RandomAgent(Utils.LAPLACE_PROBABILITY));
			else {
				double opponentStrength;
				if(opponent.getCurrentRaises(round.getPreviousRound())>0)
					opponentStrength = opponent.getRaiseEstimates(
							round.getPreviousRound(), opponent.getCurrentRaises(round.getPreviousRound()));
				else
					opponentStrength = opponent.getCallEstimates(
							round.getPreviousRound(), opponent.getCurrentCalls(round.getPreviousRound()));

				if(opponentStrength<0)
					opponentStrength = 1-probBestHand; // Simple opponent model

				Debug.log(Option.GAME_OPPONENT_MODEL, "Predicted strength: "+opponentStrength);

				playerAgents.add(new SimpleAgent(
						ratio,opponentStrength));
			}

		}
		return playerAgents;
	}

	private static IGameTree<MonteCarloState> createGameTree(
			final IGameState<?> state, final List<IAgent> agents,
			final long proposedTime, final double probBestHand) throws ConsistencyError {

		final int seatTaken = state.getCurrentSeat().getIndex();

		final GameTreeBuilder<MonteCarloState> builder
		= new GameTreeBuilder<MonteCarloState>(
				new MonteCarloState(state));

		final MonteCarloSimulator task = new BayesianSimulator(
				builder, seatTaken, agents,probBestHand,Math.sqrt(2));

		TimedLoop.fromRunnable(task).run(proposedTime);

		final IGameTree<MonteCarloState> tree =
			builder;

		return tree;
	}

	/*
	 * Runs a MC simulation and returns its preferred result.
	 */
	private static Action getSimulatedAction(final IGameState<?> state,
			final List<IAgent> agents, final double probBestHand,
			final double pPotential, final double nPotential) {
		/* Run MC simulation */
		final long proposedTime
		= Math.min(2000, Math.max(500,TimeManager.getInstance().getRecDuration()));

		/* initialize values to compute */
		Action bestSimulatedAction = Action.CALL;

		final IGameTree<MonteCarloState> tree = createGameTree(state, agents,
				proposedTime, probBestHand+pPotential-nPotential);

		final INavigator<MonteCarloState> navigator = tree.navigator();

		Debug.log(Option.MC_VALUES, "Raise: "+navigator.getNext(Action.RAISE)+"; call: "+navigator.getNext(Action.CALL));

		final Path<?> pathRandom =
			new GameTreeIterators.RandomGoodValuePath(navigator);

		bestSimulatedAction = pathRandom.getNextAction();

		Debug.log(Option.GAME_DECISION, bestSimulatedAction);

		return bestSimulatedAction;
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {

		Debug.log(Option.GAME_STATE, "Round: "
				+dynamics.getRound()+", id: "+dynamics.getCurrentSeat().getIndex()
				+" ("+dynamics.getCurrentSeat().getPlayerIndex()
				+"), stakes="+dynamics.getCurrentSeat().getStakes());

		Debug.log(Option.GAME_CARDS, "Board: "+dynamics.getBoard()+", my hole: "
				+dynamics.getCurrentSeat().getHoles());

		/* my first decision makes my counselor, i'm trusting him */
		this.counselor.evaluateSituation(dynamics, probBestHand, pPotential, nPotential);

		this.currently_best_action = this.counselor.getAction();

		/* initialize dynamics */
		dynamics.dealRandomCards(dynamics.getRound(), dynamics.getCurrentSeat().getIndex());

		/* Create opponent model */
		final List<IAgent> agents = createAgents(dynamics, probBestHand, this.opponentBuilder);


		try {
			this.currently_best_action = getSimulatedAction(dynamics, agents, probBestHand, pPotential, nPotential);
		} catch (final Exception e) { // Catch any exceptions
			Debug.log(e.getMessage());
		}
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics) {
		/* Evaluate Hand */
		this.handEvaluator.setNumOpponents(dynamics.getNumberActiveSeats()-1);

		final double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(),
				dynamics.getBoard());

		final double[] potentials = this.handEvaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(),
				dynamics.getBoard(),
				false); //TODO: if there's enough time make 'full' = 'true'!!!

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);
	}

	/**
	 * Creates a new Simulating Oracle Advisor with
	 * the given opponent builder.
	 * 
	 * @param opponentBuilder opponent builder to use
	 */
	public SimulatingOracleAdvisor(final OpponentBuilder opponentBuilder) {
		this.currently_best_action = Action.CALL;
		this.handEvaluator = new MeerkatHandevaluator();
		this.counselor = new CautiousOddsAdvisor();
		this.opponentBuilder = opponentBuilder;
	}
}
