package ke.engine.strategies;

import static ke.data.CONSTANT.*;
import java.util.ArrayList;
import java.util.List;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ke.data.Action;
import ke.gametree.IGameState;

/**
 *
 */
public class SimplePreflopAdvisor implements IStrategy {
	
	private Action adviseAction;
	
	/**
	 * 
	 */
	public SimplePreflopAdvisor(){
		this.adviseAction = Action.CALL;
	}
	
	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics) {
		evaluateHand(dynamics.getCurrentSeat().getHoles().iterator().next(), dynamics.getCurrentSeat().getHoles().iterator().next());
	}

	/**
	 *  evaluate the hole cards 
	 * @param h1 
	 * @param h2 
	 */
	public void evaluateHand(final Card h1, final Card h2) {
		/* init */
		this.adviseAction = Action.FOLD;
		// play all pocket-pairs    
		if (h1.rank == h2.rank) {
			if (h1.rank.index >= Card.Rank.TEN.index) {
				this.adviseAction = Action.RAISE;
			}
			this.adviseAction = Action.CALL;
		}

		// play all cards where one of both cards are bigger than Tens
		// and raise if they are suited
		if (h1.rank.index >= Card.Rank.TEN.index || h2.rank.index >= Card.Rank.TEN.index) {
			if (h1.suit == h2.suit) {
				this.adviseAction = Action.RAISE;
			}
			this.adviseAction = Action.CALL;
		}

		// play all suited connectors
		if (h1.suit == h2.suit) {
			if (Math.abs(h1.rank.index - h2.rank.index) == 1) {
				this.adviseAction = Action.CALL;
			}
			// raise A2 suited
			if ((h1.rank == Card.Rank.ACE && h2.rank == Card.Rank.TWO) || 
					(h2.rank == Card.Rank.ACE && h1.rank == Card.Rank.TWO)) {
				this.adviseAction = Action.RAISE;
			}
			// raise any suited ace
			if (h1.rank == Card.Rank.ACE || h2.rank == Card.Rank.ACE) {
				this.adviseAction = Action.RAISE;
			}
		}

		// play anything 10% of the time
		if (Math.random() < 0.1) {
			this.adviseAction = Action.CALL;
		}

		if(DEBUG)
			System.out.println("The SimplePreflopAdvisor says i think with my cards [" + h1.toString() + h2.toString() + "] I will " + this.adviseAction.toString() + ".");
	}

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {
		/*
		 * not needed
		 */		
	}

	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		return this.adviseAction;
	}

}
