/**
 * 
 */
package ke.engine.strategies;

import static ke.data.CONSTANT.*;
import ke.data.Action;
import ke.data.Round;
import ke.engine.handevaluators.IHandEvaluator;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.*;

/**
 * An advisor using the SimpleOraclePotEstimator. 
 * 
 *
 */
public class SimpleOracleAdvisor implements IStrategy {
	
	/**
	 *
	 */
	public class SimplePotOddEstimator {

		private double eFold;
		private double eCall;
		private double eRaise;
		
		/**
		 * Constructor
		 */
		public SimplePotOddEstimator() {
			System.out.println("I use a SimplePotOddEstimator.");
		}
		

		/**
		 * @param dynamics
		 * @param probBestHand
		 * @param pPotential
		 * @param nPotential
		 */
		public void calculate(final IGameState<?> dynamics, final double probBestHand,
				final double pPotential, final double nPotential) {
			int potSize = 0;
			for (int i = 0; i< dynamics.getNumberSeats(); i++){
				potSize += dynamics.getCurrentSeat().getStakes();
			}
			this.eFold = 0.0d;
			this.eCall = (probBestHand * potSize) + ((1.0d - probBestHand) * (-dynamics.getCurrentSeat().getAmountToCall()));

			if (DEBUG){
				System.out.println("The SimplePotOddEstimator says: i have calculated:");
				System.out.println("\tE(w|Fold): " + this.eFold);
				System.out.println("\tE(w|Call): " + this.eCall);
				System.out.println("\tE(w|Raise): " + this.eRaise);
			}

		}


		/**
		 * @return ecall
		 */
		public double getProfitCall() {
			return this.eCall;
		}


		/**
		 * @return efold
		 */
		public double getProfitFold() {
			return this.eFold;
		}


		/**
		 * @return eraise
		 */
		public double getProfitRaise() {
			return this.eRaise;
		}

	}

	
	/**
	 *  Computes the expected values for the profit based on the computations of the oracle_pot in the exercise slides. 
	 */
	public class SimpleOraclePotEstimator {

		private double eFold;
		private double eCall;
		private double eRaise;
		
		/**
		 * Constructor
		 */
		public SimpleOraclePotEstimator(){
			System.out.println("I use a SimpleOraclePotEstimator.");
		}
		
		/**
		 * @param dynamics
		 * @param probBestHand
		 * @param pPotential
		 * @param nPotential
		 */
		public void calculate(final IGameState<?> dynamics, final double probBestHand,
				final double pPotential, final double nPotential) {
			
			int potSize = 0;
			for (int i = 0; i< dynamics.getNumberSeats(); i++){
				potSize += dynamics.getSeat(i).getStakes();
			}

			
			/* estimation of the minimum potsize at showdown */ 
			double ePotSize = 
				potSize + 
				dynamics.getCurrentSeat().getAmountToCall();
			
			/* estimation of the minimum costs until showdown */
			double eInPot = 
				dynamics.getCurrentSeat().getStakes() + 
				dynamics.getCurrentSeat().getAmountToCall();

			this.eFold = -eInPot; //-gameState.inPot[gameState.seatTaken];
			
			this.eCall = 
				(probBestHand * (ePotSize - eInPot)) 
				+ 
				((1.0d - probBestHand) * -eInPot);
			
			if(DEBUG){
				System.out.println("The SimpleOraclePotEstimator says: i have calculated:");
				System.out.println("\tE(w|Fold): " + this.eFold);
				System.out.println("\tE(w|Call): " + this.eCall);
				System.out.println("\tE(w|Raise): " + this.eRaise);
			}
		}

		
		/**
		 * @return ecall
		 */
		public double getProfitCall() {
			return this.eCall;
		}

		/**
		 * @return efold
		 */
		public double getProfitFold() {
			return this.eFold;
		}


		/**
		 * @return eraise
		 */
		public double getProfitRaise() {
			return this.eRaise;
		}
	}
	
	private Action currently_best_action;
	private SimpleOraclePotEstimator profitEstimator;
	private IHandEvaluator handEvaluator;
	private IStrategy preflopAdvisor;
	
	/**
	 * Constructor
	 */
	public SimpleOracleAdvisor() {
		this.currently_best_action = Action.CALL; 
		this.profitEstimator = new SimpleOraclePotEstimator(); // new SimplePotOddEstimator();
		this.handEvaluator = new MeerkatHandevaluator();
		this.preflopAdvisor = new SimplePreflopAdvisor();
	}
	
	/**{@inheritDoc}*/
	@Override
	public Action getAction() {
		return this.currently_best_action;
	}

	/**{@inheritDoc}*/
	@Override
	public void evaluateSituation(final IGameState<?> dynamics) {
		/* only invoke the estimator after the flop */
		if(dynamics.getRound().equals(Round.PREFLOP)){
			this.preflopAdvisor.evaluateSituation(dynamics);
			this.currently_best_action = this.preflopAdvisor.getAction();
			return;
		}
		/* Evaluate Hand */	
		((MeerkatHandevaluator)this.handEvaluator).setNumOpponents(dynamics.getNumberActiveSeats()-1);
		
		double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());
				
		evaluateSituation(dynamics, probBestHand, 0, 0);
		
		if(DEBUG)
			System.out.println("The SimpleOracleAdvisor says: I think i would " + this.currently_best_action + ".");
	
	}
	
	/**{@inheritDoc}*/
	@Override
	public void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {
		
		/* check the expectations */
		this.profitEstimator.calculate(dynamics, probBestHand, 0, 0);

		/* compute my advice */
		if (this.profitEstimator.getProfitCall() >= 0.0d){
			this.currently_best_action = Action.CALL;
			if (probBestHand > 0.75d)
				this.currently_best_action = Action.RAISE;
		}
		else{
			this.currently_best_action = Action.FOLD;
		}
	}
}
