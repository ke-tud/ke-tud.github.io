package ke.engine.strategies;

import ke.data.Action;
import ke.data.GameState;
import ke.data.Round;
import ke.engine.handevaluators.IHandEvaluator;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;
import ke.history.BetMonitor;
import ke.utils.Debug;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 * An Expert using a more sophisticated OraclePotEstimator.
 */
public class OracleAdvisor implements IStrategy {

	private Action currently_best_action;
	private IHandEvaluator handEvaluator;

	/**
	 * Constructor
	 */
	public OracleAdvisor() {
		this.currently_best_action = Action.CALL; 
		this.handEvaluator = new MeerkatHandevaluator();
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized Action getAction() {
		return this.currently_best_action;
	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics) {
		/* Evaluate Hand */	
		((MeerkatHandevaluator)this.handEvaluator).setNumOpponents(dynamics.getNumberActiveSeats()-1);

		double probBestHand = this.handEvaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());

		double[] potentials = this.handEvaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard(),
				false);

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);

	}

	/**{@inheritDoc}*/
	@Override
	public synchronized void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double pPotential, final double nPotential) {

		/* amount of upcoming players in this round which not yet have bet including me */
		final int upcomingPlayers = dynamics.getNumberSeatLeftToAct() + 1;
		final double eUpcomingBetsInRound = (getAverageBetsForRound(dynamics.getRound()) - dynamics.getRoundBets());
		/* amount to call in this round*/
		final double eAmountToPayInCurrentRound = Math.max(eUpcomingBetsInRound, 0) * dynamics.getRound().getLimitBet();
		final double amountToPayInCurrentRound = Math.max(dynamics.getCurrentSeat().getAmountToCall(), eAmountToPayInCurrentRound);
		/* amount to pay in all the future rounds */
		double eAmountToPayInFutureRounds = 0;
		Round futureRound = dynamics.getRound();
		while((futureRound = futureRound.getNextRound()) != Round.SHOWDOWN)
			eAmountToPayInFutureRounds += getAverageBetsForRound(futureRound);

		/* estimation of the minimum potsize at showdown */ 
		final double ePotSize = 
			dynamics.getCurrentPotSize() + 
			(amountToPayInCurrentRound * upcomingPlayers) +
			(eAmountToPayInFutureRounds * dynamics.getNumberActiveSeats());

		/* estimation of the minimum costs until showdown */
		final double eInPot = 
			dynamics.getCurrentSeat().getStakes() + 
			amountToPayInCurrentRound + 
			eAmountToPayInFutureRounds;

		final double oddsValue = 
			((probBestHand + pPotential) * (ePotSize - eInPot)) 
			- 
			((1.0d - probBestHand - nPotential) * eInPot);
		
		/* compute my advice */
		if (oddsValue  > 1d){
			this.currently_best_action = Action.CALL;
			if (probBestHand + pPotential > 0.95d)
				this.currently_best_action = Action.RAISE;
		}
		else{
			this.currently_best_action = Action.FOLD;
		}

		final boolean iHaveButtonInPF = (dynamics.getCurrentSeat().getIndex() == dynamics.getNumberSeats() - 1) && dynamics.getRound().equals(Round.PREFLOP);
		final boolean noMoreCostsForNextCards = dynamics.getCurrentSeat().getAmountToCall() <= 1;		

		if (this.currently_best_action.equals(Action.FOLD))
			if((iHaveButtonInPF && dynamics.getRoundBets() <= 1) || noMoreCostsForNextCards)
				this.currently_best_action = Action.CALL;
		
		Debug.log(Option.ORACLE_ADVISOR, dynamics.getRound() + "(" + this.currently_best_action + ")" + "- Estimated PotSize: " + ePotSize + " | Estimated Costs: " + eInPot + " | OddsValue: " + oddsValue + " | NumberActivePlayers: " + dynamics.getNumberActiveSeats());

	}

	private double getAverageBetsForRound(Round round){	
		return BetMonitor.getInstance().getWindowData().getAvgBetsInState(
				GameState.roundIndexToGameState(round.getIndex()));
	}
}
