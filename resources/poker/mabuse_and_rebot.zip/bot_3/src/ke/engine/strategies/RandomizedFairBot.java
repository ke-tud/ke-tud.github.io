package ke.engine.strategies;

import ke.data.Action;
import ke.engine.handevaluators.IHandEvaluator;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.gametree.IGameState;
import ke.utils.Utils;

public class RandomizedFairBot implements IStrategy {
	private IHandEvaluator evaluator =
		new MeerkatHandevaluator();
	private Action nextAction = Action.CALL;
	
	@Override
	public void evaluateSituation(IGameState<?> dynamics) {
		final double probBestHand = this.evaluator.evaluateHand(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard());

		final double[] potentials = this.evaluator.evaluatePotential(
				dynamics.getCurrentSeat().getHoles(), 
				dynamics.getBoard(),
				false);

		evaluateSituation(dynamics, probBestHand, potentials[0], potentials[1]);
	}

	@Override
	public void evaluateSituation(IGameState<?> dynamics, double probBestHand,
			double pPotential, double nPotential) {
		double foldVal = (1-probBestHand) + nPotential;
		double callVal = probBestHand + nPotential;
		double raiseVal = probBestHand + pPotential;

		final double offset = Math.min(foldVal, Math.min(callVal, raiseVal));
		if(offset<0) {
			foldVal -= offset;
			callVal -= offset;
			raiseVal -= offset;
		}

		final double sum = foldVal + callVal + raiseVal;

		if(sum!=0)
			this.nextAction = Utils.getRandomAction(foldVal / sum,
					callVal / sum, raiseVal / sum);
		else
			this.nextAction = Utils.getRandomAction(Utils.LAPLACE_PROBABILITY);

	}

	@Override
	public Action getAction() {
		return this.nextAction;
	}

}
