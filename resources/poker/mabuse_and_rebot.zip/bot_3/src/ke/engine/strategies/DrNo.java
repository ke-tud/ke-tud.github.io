package ke.engine.strategies;

import java.util.ArrayList;
import java.util.List;
import ke.data.Action;
import ke.gametree.IGameState;
import ke.gametree.IGameTree;
import ke.gametree.RandomAgent;
import ke.gametree.RingDynamicsState;
import ke.gametree.IGameTree.INavigator;
import ke.gametree.montecarlo.Factory;
import ke.gametree.montecarlo.IAgent;
import ke.gametree.montecarlo.MonteCarloState;
import ke.gametree.montecarlo.Factory.ConsistencyError;
import ke.utils.Utils;

/**
 * EXPERIMENTAL
 */
public class DrNo implements IStrategy {
	private Action action;
	
	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics) {
		//FIXME: dreckig
		Utils.dealRandomCards(((RingDynamicsState)dynamics).getDynamics(),dynamics.getCurrentSeat().getIndex());
		final RandomAgent opponent = new RandomAgent(0.1d,0.45d,0.45d);
		final RandomAgent me = new RandomAgent(1/3d,1/3d,1/3d);
		final List<IAgent> agents = new ArrayList<IAgent>(3);
		
		
		
		for(int i=0; i<3; i++)
			
			if(i==dynamics.getCurrentSeat().getIndex()) {
				agents.add(me);
			} else
				agents.add(opponent);
		
//TODO: need this?-->		System.out.println("Me: "+dynamics.getCurrentSeat().getSeatNumber()+" (seat), " +
//				dynamics.seatToPlayer(dynamics.getCurrentSeat().getSeatNumber())+"(ix)");
		System.out.println(agents);
		try {
			final IGameTree<MonteCarloState> tree =
				Factory.createMonteCarloTree(dynamics, 1000, 
						agents, dynamics.getCurrentSeat().getIndex());
			
			final INavigator<MonteCarloState> navigator = tree.navigator();
			
			double bestValue = Double.NEGATIVE_INFINITY;
			Action bestAction = Action.CALL;
			System.out.println();
			System.out.println("UCT Tree says: ");
			for(final Action action : Action.values()) {
				final MonteCarloState next = navigator.getNext(action);
				if(next==null) continue;
				final double value = calculateOraclePot(next.getRatio(),dynamics);
				System.out.print(" "+action+": "+next.getValue()+"/"+next.getRatio()+"/"+value);
				if(value>bestValue) {
					bestValue = value;
					bestAction = action;
				}
			}
			System.out.println();
			this.action = bestAction;
			System.out.println();
		} catch (final ConsistencyError e) {
			e.printStackTrace();
		}
		
	}

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics,
			final double probBestHand, final double potential, final double potential2) {
		// TODO Auto-generated method stub
		
	}

	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		System.out.println("Took: "+this.action);
		return this.action;
	}

	/*
	 * Calculates an estimated profit with simple pot odds. 
	 */
	private static double calculateSimplePotOdds(final double prob, 
			final IGameState<?> dynamics) {
		// Winning probability

		
		int inPot = 0; // Amount of chips in pot
		for(int i = 0; i < dynamics.getNumberSeats(); i++){
			inPot += dynamics.getSeat(i).getStakes();
		}
		
		final int nextCall = dynamics.getCurrentSeat().getAmountToCall(); // Costs of another call
		
		final double profit = prob * inPot + (1-prob)*(-nextCall);
		return profit;
	}
	
	/*
	 * Calculates an estimated profit with oracle pot. 
	 */
	private static double calculateOraclePot(final double prob, 
			final IGameState<?> dynamics) {
		// Winning probability
		
		final int myContribution = dynamics.getCurrentSeat().getStakes();
		int inPot = 0; // Amount of chips in pot
		for(int i = 0; i < dynamics.getNumberSeats(); i++){
			inPot += dynamics.getSeat(i).getStakes();
		}
		
		final int potValueEstimation = 
//FIXME:			((dynamics.roundBets+1) / (dynamics.roundIndex+1)) * 
			inPot;
		
		final int costEstimation = 
//FIXME:			((dynamics.roundBets+1) / (dynamics.roundIndex+1)) * 
			myContribution;
		
		final double profit = prob * (potValueEstimation - costEstimation)
						+ (1-prob)*(-costEstimation);
		
		return profit - myContribution;
	}
	
}
