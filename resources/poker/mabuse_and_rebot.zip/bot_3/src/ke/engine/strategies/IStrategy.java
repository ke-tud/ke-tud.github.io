package ke.engine.strategies;

import ke.data.Action;
import ke.gametree.IGameState;

/**
 *
 */
public interface IStrategy {
	/** 
	 * @return the action to advise
	 */
	public Action getAction();
	
	/**
	 * Analyses the situation at a given game-state.
	 * All needed calculations to give a good advice are calculated and evaluated here.
	 * @param dynamics the state of the poker game to analyse and find a good action to advise. 
	 */
	public void evaluateSituation(IGameState<?> dynamics);
	
	/**
	 * Analyses the situation at a given game-state.
	 * If the concrete advisor needs some probabilities, he doesn't need to calculate it on its own.
	 * @param dynamics the state of the poker game to analyse and find a good action to advise.
	 * @param probBestHand to use for calculations 
	 * @param pPotential to use for calculations
	 * @param nPotential to use for calculations
	 */
	public void evaluateSituation(IGameState<?> dynamics, double probBestHand, double pPotential, double nPotential);
}
