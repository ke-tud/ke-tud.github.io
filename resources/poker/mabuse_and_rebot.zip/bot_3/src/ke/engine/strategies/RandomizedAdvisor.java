package ke.engine.strategies;

import java.security.SecureRandom;

import ke.data.Action;
import ke.gametree.*;

/**
 * Generate and return a random action [pr(Action) = 1/3]. 
 */
public class RandomizedAdvisor implements IStrategy {

	private SecureRandom random = new SecureRandom();
	
	/**{@inheritDoc}*/
	@Override
	public void evaluateSituation(IGameState<?> dynamics) {
		// nothing to do
	}
	
	/**{@inheritDoc}*/
	@Override
	public void evaluateSituation(IGameState<?> dynamics,
			double probBestHand, double potential, double potential2) {
		// nothing to do
	}
	
	/**{@inheritDoc}*/
	@Override
	public Action getAction() {
		switch (this.random.nextInt(2/*3*/)){
		case 0: return Action.CALL;
		case 1: return Action.RAISE;
		case 2: return Action.FOLD;
		}
		return null;
	}
}
