package ke.data;


/**
 * These enumeration objects represent a round of a poker
 * hand: preflop, flop, turn, river or showdown.
 */
public enum Round {
	/** Preflop: no community cards are dealt **/
	PREFLOP(0),
	/** Flop: one community card is dealt **/
	FLOP(1),
	/** Turn: two community cards are dealt **/
	TURN(2),
	/** River: three community cards are dealt **/
	RIVER(3),
	/** Showdown: active players must show their cards or fold **/
	SHOWDOWN(4);

	private final int index;

	/**
	 * Returns the index number
	 * of this round.
	 * 
	 * @return index of this round
	 */
	public int getIndex() {
		return this.index;
	}
	
	/**
	 * Returns the amount of rounds to play
	 * if player doesn't fold. ShowDown is not 
	 * a betRound so the River is the here last round.
	 * 
	 * @return amount of rounds to play
	 */
	public int getMaxUpcomingBetRounds() {
		return RIVER.getIndex() - this.index;
	}
	
    /**
     * Gets the standard limit bet.
     * 
     * @return the amount of the limit bet.
     */
    public int getLimitBet(){
    	if(this == SHOWDOWN)
    		return 0;
		return (getIndex() < 2) ? CONSTANT.SMALL_BET_SIZE : CONSTANT.BIG_BET_SIZE;    	
    }
    
    /**
     * Gets the round which follows the current round
     * 
     * @return next round
     */
    public Round getNextRound(){
    	if(this == SHOWDOWN)
    		return PREFLOP;
    	return Round.values()[getIndex() + 1];
    }
    
    /**
     * get the round which precede the current round
     * 
     * @return previous round
     */
    public Round getPreviousRound() {
    	if(this == PREFLOP)
    		return SHOWDOWN;
    	return Round.values()[getIndex() - 1];
    }

	private Round(final int index) {
		this.index = index;
	}
}
