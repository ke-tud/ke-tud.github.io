package ke.utils;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumSet;

/**
 * Utility class for debugging issues.
 */
public class Debug {
	/**
	 * Debug options trigger logging etc.
	 */
	public static enum Option {
		/**
		 * Log current strategy 
		 */
		STRATEGY,
		/**
		 * every time handle state change is called there comes a GamestateString.
		 * Log this one.
		 */
		INCOMING_GAMESTATESTRING,
		
		/**
		 * Log the last rounds winnings
		 */
		WON_LASTROUND,
		
		/**
		 * Log number of iterations in MC tree.
		 */
		MC_ITERATIONS,
		/**
		 * Log card distribution in MC tree.
		 */
		MC_SHOWDOWN_CARDS,
		/**
		 * Log street in MC tree.
		 */
		MC_STREET,
		/**
		 * Log win/loss in MC tree.
		 */
		MC_WIN,
		/**
		 * Log the number of active players
		 */
		MC_ACTIVE_SEATS,
		/**
		 * Log the cards at the beginning of
		 * a MC simulation.
		 */
		MC_INITIAL_CARDS,
		/**
		 * Log my action in MC simulation
		 */
		MC_MY_ACTION,
		/**
		 * Log opponent action in MC simulation
		 */
		MC_OPPONENT_ACTION,
		/**
		 * Log the simulation values for CALL and
		 * RAISE.
		 */
		MC_VALUES,
		/**
		 * Log the current game state
		 */
		GAME_STATE,
		/**
		 * Log cards during actual game
		 */
		GAME_CARDS,
		/**
		 * Log opponent model during
		 * actual game
		 */
		GAME_OPPONENT_MODEL,
		/**
		 * Log decision in game
		 */
		GAME_DECISION,
		/**
		 * Log time management
		 */
		TIME_MGMT,
		/**
		 * Game monitor
		 */
		GAME_MONITOR,
		/**
		 * Observing the bets
		 */
		BET_MONITOR,
		/**
		 * Observing the gambled money
		 */
		MONEY_MONITOR,
		/**
		 * Observing the oracle advisor
		 */
		ORACLE_ADVISOR,
		/**
		 * Observing the oracleOp advisor
		 */
		ORACLE_OP_ADVISOR,
		/**
		 * Observing the oracleSimOp advisor
		 */
		ORACLE_SIM_OP_ADVISOR,
		/**
		 * Log observations in opponent model
		 */
		OPP_OBSERVATION, 
		/**
		 * Log betting ratios
		 */
		GAME_OPPONENT_RATIOS,
		/**
		 * Log betting ratios
		 */
		POT_EXPLORING_SIMULATOR,
		/**
		 * Log the eleminations
		 */
		ELIMINATION_MONITOR,
		/**
		 * Log the performed actions
		 */
		ACTION_MONITOR
	}

	private static final SimpleDateFormat timeFormat = 
		new SimpleDateFormat();
	private static final DateFormat dateFormat =
		new SimpleDateFormat("yyMMddhhmmss");
	private static PrintStream DEFAULT_PRINTSTREAM;
	static  {
		try {
			Date now = new Date();
			DEFAULT_PRINTSTREAM = 
				new PrintStream("captainsLog"+dateFormat.format(now)+".log");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			DEFAULT_PRINTSTREAM = System.out;
		}
	}
	
	/**
	 * Set of debug options that are activated. 
	 */
	public static final EnumSet<Option> DEBUG_LEVEL =
		EnumSet.noneOf(Option.class);
	
	/**
	 * Checks, if the given option is activated.
	 *  
	 * @param option desired debug option
	 * @return true, if activated; false, if not
	 */
	public static boolean isDebugLevel(final Option option) {
		return DEBUG_LEVEL.contains(option);
	}
	
	/**
	 * Logs the given message, if the desired option is activated.
	 * 
	 * @param option desired debug option
	 * @param message message to log
	 */
	public static void log(Option option, Object message) {
		if(isDebugLevel(option)) {
			log(option+" - "+message);
		}
	}
	
	/**
	 * Logs the given message.
	 * 
	 * @param message message to log
	 */
	public static void log(Object message) {
		Date now = new Date();
		DEFAULT_PRINTSTREAM.println(timeFormat.format(now)+": "+ message);
	}
	/*
	 * Do not instantiate!
	 */
	private Debug() {
		/*
		 * Empty constructor
		 */
	}
}
