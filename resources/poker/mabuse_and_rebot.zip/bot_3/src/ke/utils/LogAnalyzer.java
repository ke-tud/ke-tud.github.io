package ke.utils;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;

public class LogAnalyzer {
	public static final class Result {
		private final int amountWon;

		/**
		 * @return the amountWon
		 */
		protected final int getAmountWon() {
			return amountWon;
		}

		public Result(int amountWon) {
			super();
			this.amountWon = amountWon;
		}
		
		public String toString() {
			return "AmountWon: "+amountWon;
		}
	}
	
	public static Map<String, Result> analyze(final File logFile) 
	throws IOException {
		class Parser {
			private final Map<String, Integer> amountWon
			= new HashMap<String, Integer>();
			
			public Map<String, Result> getResult() {
				Map<String, Result> result = new HashMap<String, Result>();
				
				for(String player : this.amountWon.keySet())
					result.put(player, 
							new Result(this.amountWon.get(player).intValue()));
				return result;
			}

			public void parseLine(final String readLine) {
				String[] tokens = readLine.split(":");
				
				String names = tokens[0];
				int number = Integer.parseInt(tokens[1]);
//				String betting = tokens[2];
//				String cards = tokens[3];
				String netto = tokens[4];
				
				String[] nameTokens = names.split("\\|");
				String[] nettoTokens = netto.split("\\|");
				
				for(int i=0; i<nameTokens.length; i++) {
					int amount = amountWon.get(nameTokens[i]) != null ? amountWon.get(nameTokens[i]).intValue() : 0;
					amount += Integer.parseInt(nettoTokens[i]);
					amountWon.put(nameTokens[i], Integer.valueOf(amount));					
				}
										
			}
		}
		BufferedReader reader = new BufferedReader(new FileReader(logFile));
		Parser parser = new Parser();
		while(reader.ready()) {
			final String line = reader.readLine();
			if(!line.startsWith("#"))
				parser.parseLine(line);
		}
		
		return parser.getResult();
	}
	
	public static void main(String[] args) throws IOException {
		File file = null;
		if(args.length>0)
			file = new File(args[0]);
		else {
			Frame f = new Frame();
			JFileChooser fc = new JFileChooser();
			fc.setFileFilter(new FileFilter() {
			
				@Override
				public String getDescription() {
					return "Log Files";
				}
			
				@Override
				public boolean accept(File f) {
					return f.getName().endsWith(".log");
				}
			});
	          int returnVal = fc.showOpenDialog(f);
	            if (returnVal == JFileChooser.APPROVE_OPTION) {
	                file = fc.getSelectedFile();
	            }else System.exit(0);

		}
		
		Map<String, Result> results = analyze(file);
		for(String botName : results.keySet())
			System.out.println(botName+" : "+results.get(botName));
		System.exit(0);
	}
}
