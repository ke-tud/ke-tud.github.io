package ke.utils;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;

import ke.data.Action;
import ke.gametree.IGameState;
import ke.gametree.IGameTree;
import ke.gametree.IGameTree.INavigator;

public class DOTWriter {
	private static class Node {
		public static enum Type {
			ME, OPPONENT;
		}
		
		private static long counter;
		private final long ID;
		private final Type type;
		private final String label;
		
		public static long getNextID() {
			return counter;
		}
		
		public Node(final String label, final Type type) {
			this.label = label;
			this.type = type;
			this.ID = getNextID();
			counter++;
		}
		
		public String getID() {
			return "NODE"+this.ID;
		}
		
		public String toString() {
			return this.getID()+"[label=\""+this.label+"\", shape=" +
					(this.type==Type.ME ? "box" : "triangle") + "];"; 
		}
		
	}
	
	private static class Edge {
		private final Node node1, node2;
		private final String label;
		
		public Edge(Node node1, Node node2, String label) {
			super();
			this.node1 = node1;
			this.node2 = node2;
			this.label = label;
		}
		
		public String toString() {
			return this.node1.getID()+"->"+this.node2.getID()+"[label=\"" 
					+ this.label+"\"];";
		}
	}
	
	private static String shorten(final String label) {
		if(label.length()>30) return label.substring(0, 30)+"...";
		return label;
	}
	
	private static Node createNode(final IGameState<?> state, final int seatTaken) {
		final ke.utils.DOTWriter.Node.Type type = 
					(seatTaken==state.getCurrentSeat().getIndex()) ? 
							ke.utils.DOTWriter.Node.Type.ME : 
							ke.utils.DOTWriter.Node.Type.OPPONENT;
		
		final Node result = new Node(shorten(state.toString()),type); 
		return result;
	}
	
	private static Node collectMembers(final IGameTree branch, final int seatTaken,
			Collection<Node> nodes, Collection<Edge> edges) {
		if(branch.getRoot()==null) return null;
		INavigator<?> navigator = branch.navigator();
		final Node currentNode = createNode(branch.getRoot(), seatTaken);
		nodes.add(currentNode);
		
		for(Action action : Action.values()) {
			final Node nextNode = 
				collectMembers(navigator.getBranch(action),seatTaken,nodes,edges);
			if(nextNode!=null)
				edges.add(new Edge(currentNode,nextNode,action.toString()));
		}
		
		return currentNode;
	}
	
	
	public static void writeTree(final IGameTree tree, final int seatTaken,
			final Writer writer) {
		Collection<Node> nodes = new ArrayList<Node>();
		Collection<Edge> edges = new ArrayList<Edge>();
		
		collectMembers(tree, seatTaken, nodes, edges);
		final String eol = "\n";
		try {
			writer.write("digraph G {"+eol);
			for(Node node : nodes)
				writer.write(node.toString()+eol);
			for(Edge edge : edges)
				writer.write(edge.toString()+eol);
			writer.write("}");
			writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
