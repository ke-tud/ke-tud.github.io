package ke.utils;

import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashSet;

import ke.data.Action;
import ke.data.ClientRingDynamics;
import ke.data.GameState;
import ke.data.Round;
import ke.gametree.RandomAgent;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;


/**
 *
 */
public class Utils {

	private static SecureRandom random = new SecureRandom();

	/**
	 * convert a card to steve brechers long format
	 * @param card
	 * @return card in long format
	 */
	public static long cardToLong(final Card card) {
		return 0x1L << (card.suit.ordinal()*13 + card.rank.ordinal());
	}

	/**
	 * convert a card[] (a hand) to steve brechers long format
	 * @param cards
	 * @return hand in long format
	 */
	public static long cardsToLong(final Card[] cards) {
		long result = 0;
		for (final Card c : cards)
			if (c != null)
				result |= cardToLong(c);
		return result;
	}

	/**
	 * deal random cards for each player and each unknown board card into given dynamics
	 * @param dynamics
	 */
	public static void dealRandomCards(final ClientRingDynamics dynamics) {
		dealRandomCards(dynamics, dynamics.seatTaken);
	}

	/**
	 * deal random cards for each player and each unknown board card into given dynamics
	 * @param dynamics
	 * @param seatTaken
	 */
	public static void dealRandomCards(final RingDynamics dynamics, final int seatTaken) {
		final Collection<Card> deck = new HashSet<Card>(Arrays.asList(Card.getAllCards()));
		/* remove my own hole cards */
		removeCard(dynamics.hole[seatTaken][0], deck);
		removeCard(dynamics.hole[seatTaken][1], deck);

		/* remove all known board cards */
		for(final Card c : dynamics.board)
			if (c != null)
				removeCard(c,deck);

		/* for each player (without me!) (atm not only the active) deal random hole cards */
		for(int i = 0; i < dynamics.numSeats; i++){
			if (i == seatTaken)
				continue;
			if (dynamics.hole[i].length == 0 )
				dynamics.hole[i] = new Card[2];
			for(int j = 0; j < dynamics.hole[i].length; j++)
				dynamics.hole[i][j] = getRandomCard(deck);
		}

		/* deal the board cards */
		for(int i = 0; i < dynamics.board.length; i++)
			if(dynamics.board[i] == null)
				dynamics.board[i] = getRandomCard(deck);
	}

	private static Card getRandomCard(final Collection<Card> deck){
		final int n = random.nextInt(deck.size());
		int i = 0;
		for(final Card c : deck){
			if(n==i){
				deck.remove(c);
				return c;
			}
			i++;
		}
		return null;
	}

	private static boolean removeCard(final Card card, final Collection<Card> deck){
		for(final Card c : deck)
			if (card.equals(c))
				return deck.remove(c);
		return false;
	}
	/**
	 * Creates a copy of the given dynamics without changing them.
	 * 
	 * @param dynamics dynamics to clone
	 * @return a new Ring Dynamics object with the cloned
	 * fields
	 */
	public static RingDynamics copyDynamics(final RingDynamics dynamics) {
		final RingDynamics nextDynamics = new RingDynamics(
				dynamics.numPlayers,dynamics.info,dynamics.botNames);

		nextDynamics.numSeats = dynamics.numSeats;
		nextDynamics.stack = dynamics.stack==null ? null : dynamics.stack.clone();
		nextDynamics.inPot = dynamics.inPot==null ? null : dynamics.inPot.clone();
		nextDynamics.amountWon = dynamics.amountWon==null ? null : dynamics.amountWon.clone();
		nextDynamics.grossWon = dynamics.grossWon==null ? null : dynamics.grossWon.clone();
		nextDynamics.active = dynamics.active==null ? null : dynamics.active.clone();
		nextDynamics.canRaiseNextTurn = dynamics.canRaiseNextTurn==null ? null : dynamics.canRaiseNextTurn.clone();
		nextDynamics.roundBets = dynamics.roundBets;
		nextDynamics.bettingSequence = dynamics.bettingSequence;
		nextDynamics.seatToAct = dynamics.seatToAct;
		nextDynamics.lastActionSeat = dynamics.lastActionSeat;
		nextDynamics.lastBetSize = dynamics.lastBetSize;
		nextDynamics.roundIndex = dynamics.roundIndex;
		nextDynamics.firstActionOnRound = dynamics.firstActionOnRound;
		nextDynamics.handOver = dynamics.handOver;
		nextDynamics.handNumber = dynamics.handNumber;
		nextDynamics.board = dynamics.board==null ? null : dynamics.board.clone();
		nextDynamics.hole = dynamics.hole==null ? null : dynamics.hole.clone();
		return nextDynamics;
	}

	/** LaPlace probability for poker actions (all 1/3) */
	public final static EnumMap<Action, Double> LAPLACE_PROBABILITY
	= new EnumMap<Action, Double>(Action.class);
	static {
		LAPLACE_PROBABILITY.put(Action.FOLD, Double.valueOf(1/3d));
		LAPLACE_PROBABILITY.put(Action.CALL, Double.valueOf(1/3d));
		LAPLACE_PROBABILITY.put(Action.RAISE, Double.valueOf(1/3d));
	}

	/**
	 * Gets an action for the given probability distribution.
	 * 
	 * @param probs probabilities for RAISE, CALL, FOLD
	 * @return an action
	 */
	public static Action getRandomAction(final EnumMap<Action, Double> probs) {
		return RandomAgent.getAction(probs);
	}

	/**
	 * Gets an action for the given probability distribution.
	 * 
	 * @param foldProb probability to fold
	 * @param callProb probability to call
	 * @param raiseProb probability to raise
	 * @return an action
	 */
	public static Action getRandomAction(final double foldProb,
			final double callProb, final double raiseProb) {
		return RandomAgent.getAction(foldProb, callProb, raiseProb);
	}

	/**
	 * Converts a Round instance to a GameState instance.
	 * 
	 * @param round Round instance
	 * @return equal GameState instance
	 */
	public static GameState roundToGameState(final Round round) {
		switch(round) {
		case PREFLOP : return GameState.PREFLOP;
		case FLOP : return GameState.FLOP;
		case TURN : return GameState.TURN;
		case RIVER : return GameState.RIVER;
		case SHOWDOWN : return GameState.SHOWDOWN;
		default : return GameState.STARTING;
		}
	}

	/**
	 * Converts a GameState instance to a Round instance.
	 * 
	 * @param state GameState instance
	 * @return equal Round instance or null if state is STARTING
	 */
	public static Round gameStateToRound(final GameState state) {
		switch(state) {
		case PREFLOP : return Round.PREFLOP;
		case FLOP : return Round.FLOP;
		case TURN : return Round.TURN;
		case RIVER : return Round.RIVER;
		case SHOWDOWN : return Round.SHOWDOWN;
		default : return null;
		}
	}


	/**
	 * Resort a given a card array which is sorted by seatIndices to a card array which is sorted by playerIndices
	 * 
	 * @param seatSortedArray array of holes sorted by seats
	 * @param playerAtZero index of the player at the seat zero
	 * @return array of holes sorted by players
	 */
	public static Card[][] sortHoles(final Card[][] seatSortedArray, final int playerAtZero) {
		final int players = seatSortedArray.length;
		final Card[][] playerSortedArray = new Card[players][];
		for(int i = 0; i < players; i++)
			playerSortedArray[(playerAtZero + i) % players] = seatSortedArray[i];
		return playerSortedArray;
	}
	
	public static String ArrayToString(double[][] array){
		String result = "";
		for(double[] a : array)
			result += "[" + Arrays.toString(a) + "] ; ";
		return result;
	}

	/**
	 * Do not instantiate this class.
	 */
	private Utils(){
		/* no instance */
	}

}
