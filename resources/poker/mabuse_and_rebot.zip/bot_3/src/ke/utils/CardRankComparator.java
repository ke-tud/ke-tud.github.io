package ke.utils;

import java.util.Comparator;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class CardRankComparator implements Comparator<Card> {
	public final static CardRankComparator COMPARATOR = new CardRankComparator();
	
	@Override
	public int compare(Card o1, Card o2) {
		if(o1==null) 
			if(o2==null) return 0;
			else return -1;
		if(o2==null) return 1;
		
		int diff = o1.getIndexRankMajor() - o2.getIndexRankMajor();
		return diff > 0 ? 1 : diff < 0 ? -1 : 0;
	}
	
	private CardRankComparator() {
		
	}

}
