package ke.utils;

/**
 * A collection of mathematical utilities.
 */
public class MathUtils {
	
	/**
	 * A beta distribution instance represents
	 * the function with fixed parameters.
	 */
	public static class BetaDistribution {
		private final int range;
		private final int shape;
		private final double beta;
		
		/**
		 * Evaluates the function at x.
		 * 
		 * @param x
		 * @return beta distribution at x
		 */
		public double evaluate(final double x) {
			return 
			Math.pow(x, this.range)*Math.pow((1-x), this.shape-1) 
			/ this.beta; 
		}
		
		/**
		 * Creates a new beta distribution function
		 * with the given parameters.
		 * 
		 * @param range
		 * @param shape
		 */
		public BetaDistribution(int range, int shape) {
			super();
			this.range = range;
			this.shape = shape;
			this.beta = (fac(range-1)*fac(shape-1)) / (double) fac(range+shape+1);
		}
		
	}
	
	/**
	 * Faculty function.
	 * 
	 * @param n
	 * @return n!
	 */
	public static long fac(final int n) {
		if(n<=1) return 1;
		return n * (fac(n-1));
	}
	
	/*
	 * Do not instantiate.
	 */
	private MathUtils() {
		// Empty constructor
	}
}
