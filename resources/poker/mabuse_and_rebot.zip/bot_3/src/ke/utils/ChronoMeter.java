package ke.utils;

/**
 * Clock the time in milliseconds
 */
public class ChronoMeter {
	
	private class CmException extends  Exception{

		private static final long serialVersionUID = 1L;

		public CmException(final String message){
			super(message);
		}
	}
	
	private boolean running;
	private long startTime;
	private long endTime;

	/**
	 * Constructor
	 */
	public ChronoMeter(){
		this.running = false;
	}

	/**
	 * Start the timer
	 * @throws CmException
	 */
	public void start() throws CmException{
		if (this.running)
			throw new CmException("Chronometer was yet started.");
		this.running = true;
		this.startTime = System.currentTimeMillis();
	}

	/**
	 * Stop the Timer
	 * @throws CmException
	 */
	public void stop() throws CmException{
		if (!this.running)
			throw new CmException("Chronometer was not started.");
		this.running = false;
		this.endTime = System.currentTimeMillis();		
	}

	/** 
	 * @return duration since the timer was started to the timer was stopped
	 * @throws CmException
	 */
	public long getDuration() throws CmException{
		if (this.running)
			throw new CmException("Chronometer is still running.");
		return this.endTime - this.startTime;
	}
}
