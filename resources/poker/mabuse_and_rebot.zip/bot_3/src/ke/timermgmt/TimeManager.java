package ke.timermgmt;

import static ke.data.CONSTANT.*;
import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.GameState;
import ke.utils.Debug;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * the TimeManager observes the game and offers informations about the time to
 * use per round.
 */
public class TimeManager implements IStateChangeListener {
	/** the singleton instance */
	private static TimeManager instance;

	/**
	 * Singleton
	 * @return the TimeManager instance
	 */
	public static TimeManager getInstance(){
		if(instance == null)
			instance = new TimeManager(CONSTANT.HANDTIME, (int)CONSTANT.HANDCOUNT);
		return instance;
	}

	/**
	 * use 50% of the handTime for preflop decisions 30% for flop decisions 15%
	 * for turn decisions 5% for river decisions
	 */
	private final double tFactorPreflop = 0.5d; // 50% | 100% | (0.5/1)
	private final double tFactorFlop = 0.6d; // 30% | 50% | (0.3/0.5)
	private final double tFactorTurn = 0.75d; // 15% | 20% | (0.15/0.2)
	private final double tFactorRiver = 1.0d; // 5% | 5% | (0.05/0.05)

	/** requests handled so far (overall) */
	private int requests;
	/** requests handled in an certain state */
	private int requestsInState;
	/** rounds played so far (don't mix up with handsPlayed) */
	private int roundsPlayed;

	/** the total amount of time we can play  */	
	private final long timeForGame;
	/** the time we spent playing the game */
	private long timePlayedGame;
	/** the time we spent playing the currently one hand */
	private long timePlayedHand;
	/** the time we can invest for computations within this hand */
	private long timePerHand;

	/** the total amount of hands we have to play */
	private final int handsToPlay;
	/** the amount of hands played so far */
	private int handsPlayed;


	/** the TimeStamp where we entered the current state */
	private long tsTurnStarted;
	/** the TimeStamp where we entered a state to play a new hand */
	private long tsHandStarted;
	/** The recommended TimeStamp when we should leave current state at the latest. */
	private long tsRecActionComplete;

	/** current gameState */
	private GameState gameState;

	/**
	 * Creates a new TimeManager.
	 * 
	 * @param handTime the time we have to play one hand
	 * @param numHands the amount of hands we have to play
	 */
	private TimeManager(final long handTime, final int numHands) {
		this.timePerHand = handTime;
		this.handsToPlay = numHands;
		this.timeForGame = handTime * numHands;
		this.handsPlayed = 0;
		this.roundsPlayed = 0;
		this.requests = 0;
		this.requestsInState = 0;
		this.timePlayedGame = 0l;
		this.timePlayedHand = 0l;
		this.gameState = GameState.STARTING;
	}

	/** [1,5] */
	private double getAvgRequestsPerState() {
		if(this.requests == 0)
			return 1.5d;
		return (double)this.requests / this.roundsPlayed;
	}
	private int getRemainingHands(){
		final int remainingHands = this.handsToPlay - this.handsPlayed;
		return (remainingHands != 0) ? remainingHands : 1;
	}
	private long getRemainingGameTime(){
		return this.timeForGame - this.timePlayedGame;
	}
	/** avoid negative values */
	private long getRemainingHandTime(){
		final long remainingTime = this.timePerHand - this.timePlayedHand;
		return (remainingTime > 0) ? remainingTime : 0l;
	}
	/**
	 * calculate the time for all game states
	 */
	private void calculateTimes() {
		long timeInState = 0;
		switch (this.gameState) {
		case PREFLOP:
			timeInState = (long)(getRemainingHandTime() * this.tFactorPreflop);
			break;
		case FLOP:
			timeInState = (long)(getRemainingHandTime() * this.tFactorFlop);
			break;
		case TURN:
			timeInState = (long)(getRemainingHandTime() * this.tFactorTurn);
			break;
		case RIVER:
			timeInState = (long)(getRemainingHandTime() * this.tFactorRiver);
			break;
		default:
			/* nothing to do */
		}
		final long timePerAction = (long)(timeInState / getAvgRequestsPerState());
		this.tsRecActionComplete = timePerAction + this.tsTurnStarted;
		Debug.log(Option.TIME_MGMT,
				"+++\n"
				+ "GameState:" + this.gameState+"\n"
				+ "tph:"+this.timePerHand+"\n"
				+ "tshandstarted:"+this.tsHandStarted+"\n"
				+"tsturnstarted:"+this.tsTurnStarted+"\n"
				+"TsActionComplete: " + this.tsRecActionComplete+"\n"
				+"now: " + System.currentTimeMillis()+"\n"
				+"TimeInState: " + timeInState+"\n"
				+"recommended duration: " + timePerAction+"\n"
				+"AverageRequestsPerState: " + getAvgRequestsPerState()+"\n"
				+"Time played: " + this.timePlayedGame+"\n"
				+"Rounds played: " + this.roundsPlayed+"\n"
				+"Requests: " + this.requests+"\n"
				+"hands played: " + this.handsPlayed+"\n"
				+"remainingHands: " + getRemainingHands()+"\n"
				+"remainingHandTime: " + getRemainingHandTime()+"\n"
				+"remainingGameTime: " + getRemainingGameTime()+"\n"
				+"average Duration: " + getAvgHandDuration()+"\n"
				+"+++");

	}

	/**
	 * Ask the TimeManager how much time he recommends to make 
	 * computations within this special turn.
	 * Returns the amount of the duration in milliseconds.
	 * 
	 * @return recommended duration (zero if the time-stamp would is in past)
	 * 
	 * [avoid negative values]
	 */
	public long getRecDuration(){
		final long recDuration = this.tsRecActionComplete - System.currentTimeMillis();
		if(DEBUG)
			System.out.println("recommended duration: "+ recDuration);
		return (recDuration > 0) ? recDuration : 0l;
	}
	
	/**
	 * @return the average duration we played a hand.
	 */
	public long getAvgHandDuration(){
		if(this.handsPlayed < 2)
			return 7000l;
		return this.timePlayedGame / (this.handsPlayed - 1);
	}

	/**
	 * Getter
	 * @return the suggested time-stamp where the TimeManager recommends to 
	 * complete the computation of a specific action. (Take care! This could be in the past.)
	 */
	public long getTsRecActionComplete(){
		return this.tsRecActionComplete;
	}

	/**
	 * Start a new turn.
	 * (should always be invoked when a new matchString arrives)
	 */
	public void startTurn(){
		this.tsTurnStarted = System.currentTimeMillis();
	}

	/**
	 * Start a set of turns with a new hand.
	 * (should be invoked every time we shall make our first move)
	 */
	public void newHand(){
		this.handsPlayed++;
		this.timePlayedGame += this.timePlayedHand;
		this.tsHandStarted = this.tsTurnStarted;
		this.timePlayedHand = System.currentTimeMillis() - this.tsHandStarted; // cause since coming here are some milliseconds gone
		this.timePerHand = getRemainingGameTime() / getRemainingHands();
	}

	/**
	 *  Recalculate the remaining hand time
	 *  (should always (and only!) be invoked when our(!!!) turn ends)
	 */
	public void reCalculateRemainingTimes(){
		final long duration =  System.currentTimeMillis() - this.tsTurnStarted;
		this.timePlayedHand += duration;
	}
	
	/**
	 * Increment the request counter 
	 * (should always be invoked every time we shall make our move)
	 */
	public void incrementRequests(){
		this.requestsInState++;
		calculateTimes();
	}
	
	/**
	 * overrides the stateChanged method from IStateChangeListener to register a
	 * new state
	 * @param state 
	 */
	public void stateChanged(GameState state) {
		if (state.equals(GameState.STARTING) || state.equals(GameState.SHOWDOWN))
			return;
		this.gameState = state;
		this.requests += this.requestsInState;
		this.requestsInState = 0;
		this.roundsPlayed++;
	}

	/**
	 * overrides the roundFinished method from IStateChangeListener to register
	 * a new round
	 * @param ownID 
	 * @param playerAtSeatZero 
	 * @param amountWon 
	 * @param inPot 
	 * @param hole 
	 */
	public synchronized void roundFinished(int ownID, int playerAtSeatZero,
			int[] amountWon, int[] inPot, Card[][] hole, Card[] board) 
	{ 
		/* nothing to do */ 
	}
	
	/**
	 * overrides the actionPerformed method from IStateChangeListener to
	 * register performed action
	 * @param seat 
	 * @param player 
	 * @param action 
	 */
	public void actionPerformed(int seat, int player, Action action) {/* nothing to do */}
	
}
