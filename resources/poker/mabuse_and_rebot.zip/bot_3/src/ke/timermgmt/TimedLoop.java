package ke.timermgmt;

import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import ke.data.CONSTANT;
import ke.utils.Debug;
import ke.utils.Debug.Option;

public abstract class TimedLoop {
	/* Number of iteration in the last run */
	private int iteration;

	/**
	 * Override this method with atomic task.
	 */
	protected abstract void task();

	/**
	 * Repeats the task until the given time has passed.
	 * 
	 * @param duration maximum duration in milliseconds
	 */
	public void run(final long duration) {
		final long begin = System.currentTimeMillis();
		this.iteration = 1;
		while(((System.currentTimeMillis()-begin) / (double) this.iteration) * (this.iteration + 1)<duration) {
			task();
			this.iteration++;
		}
		
		Debug.log(Debug.Option.MC_ITERATIONS, Integer.valueOf(this.iteration));
	}
	
	/**
	 * Repeats the task until the given time has passed or
	 * the number of iterations is reached.
	 * 
	 * @param duration maximum duration in milliseconds
	 * @param iterations number of maximum iterations
	 */
	public void run(final long duration, final long iterations) {
		final long begin = System.currentTimeMillis();
		this.iteration = 1;
		while((((System.currentTimeMillis()-begin) / (double) this.iteration) * (this.iteration + 1)<duration)
				|| (iterations<this.iteration)) {
			task();
			this.iteration++;
		}
		
		Debug.log(Debug.Option.MC_ITERATIONS, Integer.valueOf(this.iteration));
	}
	

	/**
	 * Returns the number of iterations.
	 * 
	 * @return number of iterations 
	 */
	protected final int getIteration() {
		return this.iteration;
	}

	/**
	 * Creates a new timed loop executing the given task.
	 * 
	 * @param task runnable task to be executed
	 * @return a new timed loop
	 */
	public static TimedLoop fromRunnable(final Runnable task) {
		return new TimedLoop() {
			@Override
			protected void task() {
				task.run();
			}

		};
	}

	/**
	 * Creates a new timed loop executing the given tasks concurrent.
	 * 
	 * @param tasks collection of tasks to be executed
	 * @return a new timed loop
	 */
	public static TimedLoop fromRunnable(final Collection<Runnable> tasks) {
		return new TimedLoop() {
			/* number of threads working */
			private final int numberThreads = tasks.size();
			/* the runnables wrapped with the concurrency wrap */
			private final Runnable[] runnables = new Runnable[this.numberThreads];
			/* executor service for the runnables */
			private final ExecutorService executor = Executors.newFixedThreadPool(this.numberThreads);
			/* current number of finished runnables */
			private int finished;
			/* lock for loop synchronization */
			private final Object lock = new Object();

			/*
			 * Wrapper class that calls the finish() method after
			 * each run.
			 */
			final class ConcurrencyWrap implements Runnable {
				private final Runnable task;

				private ConcurrencyWrap(final Runnable task) {
					this.task = task;
				}

				@Override
				public void run() {
					this.task.run();
					finish();
				}
			}

			/*
			 * Constructor
			 */
			{
				int i=0;
				for(final Runnable task : tasks) {
					this.runnables[i] = new ConcurrencyWrap(task);
					i++;
				}

			}

			/*
			 * Increases a counter of finished tasks and notifies
			 * lock if all tasks have finished.
			 */
			synchronized void finish() {
				this.finished++;
				if(this.finished>=this.numberThreads) {
					this.finished = 0;
					synchronized(this.lock) {
						this.lock.notifyAll();
					}
				}
			}

			/** {@inheritDoc} */
			@Override
			protected void task() {
				this.finished=0;
				synchronized(this.lock) {
					for(final Runnable runnable : this.runnables) {
						this.executor.execute(runnable);
					}
					try {
						this.lock.wait();
					} catch (final InterruptedException e) {
						e.printStackTrace();
					}
				}

			}

		};
	}
}
