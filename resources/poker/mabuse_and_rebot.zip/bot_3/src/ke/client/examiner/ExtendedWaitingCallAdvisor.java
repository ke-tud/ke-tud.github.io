package ke.client.examiner;

import ke.data.Action;
import ke.engine.strategies.IStrategy;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;
import ke.timermgmt.TimeManager;

/**
*
*/
public class ExtendedWaitingCallAdvisor implements IStrategy {

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(IGameState<?> dynamics) {
		System.out.println("Handnumber:\t\t\t\t" + ((RingDynamicsState)dynamics).getDynamics().handNumber);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(IGameState<?> dynamics, double probBestHand,
			double potential, double potential2) {
		/* */
	}

	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		return Action.RAISE;
	}

}
