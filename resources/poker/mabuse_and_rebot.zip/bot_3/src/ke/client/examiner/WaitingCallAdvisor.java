/**
 * 
 */
package ke.client.examiner;

import ke.data.Action;
import ke.engine.strategies.IStrategy;
import ke.gametree.IGameState;
import ke.gametree.RingDynamicsState;
import ke.timermgmt.TimeManager;

/**
 *
 */
public class WaitingCallAdvisor implements IStrategy {

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(IGameState<?> dynamics) {
		System.out.println("Handnumber:\t\t\t\t" + ((RingDynamicsState)dynamics).getDynamics().handNumber);
		System.out.println("Waiting:\t\t\t\t" + TimeManager.getInstance().getRecDuration() +"ms");
		System.out.println("SeatToAct (SeatTaken):\t" + ((RingDynamicsState)dynamics).getDynamics().seatToAct);
		System.out.println("betting Sequence:\t\t"+((RingDynamicsState)dynamics).getDynamics().bettingSequence);
		try {
			Thread.sleep(TimeManager.getInstance().getRecDuration());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(IGameState<?> dynamics, double probBestHand,
			double potential, double potential2) {
		/* */
	}

	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		return Action.CALL;
	}

}
