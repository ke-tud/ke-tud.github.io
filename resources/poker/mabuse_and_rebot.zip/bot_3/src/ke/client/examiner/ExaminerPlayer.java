package ke.client.examiner;

import java.net.InetAddress;
import ke.engine.strategies.CautiousOddsAdvisor;
import ke.engine.strategies.IStrategy;
import ke.engine.strategies.OddsAdvisor;
import ke.engine.strategies.OracleAdvisor;
import ke.engine.strategies.OracleOpAdvisor;
import ke.engine.strategies.OracleSimOpAdvisor;
import ke.engine.strategies.RandomizedAdvisor;
import ke.gametree.RingDynamicsState;


/** 
 *
 */
public class ExaminerPlayer extends ExaminerPokerClient{
	
	private final IStrategy expert;
    
    /**
     * Initialise the player.
     * @param expertToUse 
     */
    public ExaminerPlayer(final String expertToUse) {
    	super();
    	if (expertToUse.equals("waitingcalladvisor"))
    		this.expert = new WaitingCallAdvisor();
    	else if (expertToUse.equals("extendedwaitingcalladvisor"))
    		this.expert = new ExtendedWaitingCallAdvisor();
    	else if (expertToUse.equals("alwaysraiseadvisor"))
    		this.expert = new AlwaysRaiseAdvisor();
    	else if (expertToUse.equals("oracleadvisor"))
    		this.expert = new OracleAdvisor();
    	else if (expertToUse.equals("oracleopadvisor"))
    		this.expert = new OracleOpAdvisor(this.opponentBuilder);
    	else if (expertToUse.equals("oraclesimopadvisor"))
    		this.expert = new OracleSimOpAdvisor(this.opponentBuilder);
    	else if (expertToUse.equals("cautiousoddsadvisor"))
    		this.expert = new CautiousOddsAdvisor();
    	else if (expertToUse.equals("oddsadvisor"))
    		this.expert = new OddsAdvisor();
    	else
    		this.expert = new RandomizedAdvisor();
    	
    	System.out.println("Using Expert: " + this.expert.getClass().getName());
    }
    
    /**
     * invoked every time the state changes and the changed i am on the move
     */
    @Override
	public void reconsider_state_and_make_a_move() {
    	
    	this.expert.evaluateSituation(new RingDynamicsState(this.dynamics));

    	send_action(this.expert.getAction());

    }
    
    /**
     * invoked every time the state changes
     */
    @Override
	public void reconsider_state() {
    	/*
    	 * nothing to do for now
    	 * maybe tell the brain to remember the things happened so far 
    	 */
    }
	
	/**
     * Main Entry Point called by startme.sh (startme.bat)
     * arg[0] must be the server's IP-address or name
     * arg[1] must be the corresponding portnumber
     * arg[2] must be the expert to use    
	 * @param args 
	 * @throws Exception 
     */
    public static void main(final String[] args) throws Exception{
    	ExaminerPlayer pp = new ExaminerPlayer(args[2].toLowerCase());
        System.out.print("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Connection established!");
        pp.run();
    }

}
