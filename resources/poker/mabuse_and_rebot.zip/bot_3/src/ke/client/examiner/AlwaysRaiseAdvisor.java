package ke.client.examiner;

import ke.data.Action;
import ke.engine.strategies.IStrategy;
import ke.gametree.IGameState;

/** */
public class AlwaysRaiseAdvisor implements IStrategy {
	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics) { /**/ }
	/** {@inheritDoc} */
	@Override
	public void evaluateSituation(final IGameState<?> dynamics, final double probBestHand,
			final double potential, final double potential2) { /**/	}
	/** {@inheritDoc} */
	@Override
	public Action getAction() {
		return Action.RAISE;
	}
}
