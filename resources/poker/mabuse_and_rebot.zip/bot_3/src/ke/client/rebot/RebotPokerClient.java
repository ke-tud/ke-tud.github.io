package ke.client.rebot;

import ke.client.ClientRingStateParser;
import ke.client.StateMonitor;
import ke.data.Action;
import ke.data.CONSTANT;
import ke.data.ClientRingDynamics;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.history.ActionMonitor;
import ke.history.BetMonitor;
import ke.history.EliminationMonitor;
import ke.history.MoneyMonitor;
import ke.opponent.OpponentBuilder;
import ke.timermgmt.TimeManager;
import ca.ualberta.cs.poker.free.client.PokerClient;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

/**
 *
 */
public abstract class RebotPokerClient extends PokerClient {

	/** Replication of the server side's state */
	protected ClientRingDynamics dynamics;
	
	private OpponentBuilder opponentBuilder = new OpponentBuilder(new MeerkatHandevaluator());

	/** Constructor. Call connect() and then run() to start the process */
	public RebotPokerClient(){
		this.dynamics = null;
	}


	/** 
	 * Handles the state change. 
	 * Updates state and calls takeAction()
	 */
	@Override
	public synchronized void handleStateChange(){

		if (this.dynamics == null) {
			set_up_new_state_object();
		}
		
		TimeManager.getInstance().startTurn();

		this.dynamics.setFromMatchStateMessage(this.currentGameStateString);

		if (this.dynamics.isOurTurn()){

			if (this.dynamics.roundIndex == 0 && this.dynamics.bettingSequence.length() < 3)
				TimeManager.getInstance().newHand();
			
			TimeManager.getInstance().incrementRequests();

			reconsider_state_and_make_a_move();

			TimeManager.getInstance().reCalculateRemainingTimes();
		}
		else
			reconsider_state();

	}



	/**
	 * 
	 */
	public void set_up_new_state_object() {
		final ClientRingStateParser crsp = new ClientRingStateParser();
		crsp.parseMatchStateMessage(this.currentGameStateString);
		final MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000);
		CONSTANT.PLAYER_COUNT = crsp.numPlayers;
		this.dynamics = new ClientRingDynamics(crsp.numPlayers, mt, crsp);
		this.dynamics.setParser(crsp);
		this.dynamics.addStateChangeListener(TimeManager.getInstance());
		this.dynamics.addStateChangeListener(BetMonitor.getInstance());
		this.dynamics.addStateChangeListener(MoneyMonitor.getInstance());
		this.dynamics.addStateChangeListener(EliminationMonitor.getInstance());
		this.dynamics.addStateChangeListener(ActionMonitor.getInstance());
		this.dynamics.addStateChangeListener(this.opponentBuilder);
//		this.dynamics.addStateChangeListener(new StateMonitor());

	}

	/**
	 * 
	 */
	public void check_state() {
		// make sure everything's fine with tracked state (should never be true)
		if (!this.dynamics.getMatchState(this.dynamics.seatTaken).equals(this.currentGameStateString)) {
			System.err.println("BADMATCHSTATESTRING: ");
			System.err.println("     Localstate : " + this.dynamics.getMatchState(this.dynamics.seatTaken));
			System.err.println("     From Server: " + this.currentGameStateString);
		}
	}

	/**
	 *  analyses state and history the then calls 
	 *  sendFold(), sendCall, or sendRaise() 
	 */
	public abstract void reconsider_state_and_make_a_move();


	/**
	 *  silently analyses state and history 
	 */
	public abstract void reconsider_state();


	/**
	 * triggers an action to the server
	 * @param a
	 */
	public void send_action(final Action a){
		try {
			if (a == Action.RAISE)
				sendRaise();
			else if (a == Action.CALL)
				sendCall();
			else
				sendFold();

		} catch(final Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	
	/**
	 * @return the opponentBuilder
	 */
	final OpponentBuilder getOpponentBuilder() {
		return this.opponentBuilder;
	}

}
