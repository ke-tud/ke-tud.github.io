package ke.client.rebot;

import java.net.InetAddress;

import ke.engine.strategies.IStrategy;
import ke.engine.strategies.OracleAdvisor;
import ke.engine.strategies.OracleOpAdvisor;
import ke.engine.strategies.OracleSimOpAdvisor;
import ke.engine.strategies.SimpleOracleAdvisor;
import ke.gametree.RingDynamicsState;


/** 
 *
 */
public class RebotPlayer extends RebotPokerClient{
	
	/** Rebots expert computes the decisions made by RebotPlayer*/
	private IStrategy expert;
    
    /**
     * Initialise the player.
     * @param expertToUse 
     */
    public RebotPlayer(String expertToUse) {
    	super();
    	System.out.println("Hi, I'm rebot.");
    	
    	if(expertToUse.equals("simpleoracle"))
    		this.expert = new SimpleOracleAdvisor();
    	else
    		this.expert  = 	new OracleSimOpAdvisor(getOpponentBuilder());
    }
    
    /**
     * invoked every time the state changes and the changed i am on the move
     */
    @Override
	public void reconsider_state_and_make_a_move() {
    	
    	this.expert.evaluateSituation(new RingDynamicsState(this.dynamics));

    	send_action(this.expert.getAction());

    }
    
    /**
     * invoked every time the state changes
     */
    @Override
	public void reconsider_state() {
    	/*
    	 * nothing to do for now
    	 * maybe tell the brain to remember the things happened so far 
    	 */
    }
	
	/**
     * Main Entry Point called by startme.sh (startme.bat)
     * arg[0] must be the server's IP-address or name
     * arg[1] must be the corresponding portnumber  
     * arg[2] (if set) is the advisor to use (if not set RebotsExpert will be used)
	 * @param args 
	 * @throws Exception 
     */
    public static void main(final String[] args) throws Exception{
    	RebotPlayer pp;
    	if (args.length >= 3)
    		pp = new RebotPlayer(args[2].toLowerCase());
    	else
    		pp = new RebotPlayer("");
    	
        System.out.print("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Connection established!");
        pp.run();
    }

}
