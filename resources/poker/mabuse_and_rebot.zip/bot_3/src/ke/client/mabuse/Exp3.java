package ke.client.mabuse;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ke.utils.Debug;
import ke.utils.Debug.Option;

/**
 * This is an Exp3 algorithm implementation to
 * chose a probable strategy from a collection
 * of strategies.
 */
public class Exp3 {
	private final boolean random;
	private double ψ;
	private double ρ;
	/**
	 * @return the ψ
	 */
	protected final double getΨ() {
		return this.ψ;
	}

	/**
	 * @param ψ the ψ to set
	 */
	protected final void setΨ(final double ψ) {
		this.ψ = ψ;
	}

	/**
	 * @return the ρ
	 */
	protected final double getΡ() {
		return this.ρ;
	}

	/**
	 * @param ρ the ρ to set
	 */
	protected final void setΡ(final double ρ) {
		this.ρ = ρ;
	}

	private final List<Double> scores =
		new ArrayList<Double>();
	private final List<Double> propabilities =
		new ArrayList<Double>();

	private void calculateProbabilities() {
		double sum = 0.0d;
		for(int i=0; i<this.scores.size(); i++)
			sum += Math.pow(1+this.ρ,this.scores.get(i).doubleValue());

		for(int i=0; i<this.propabilities.size(); i++)
			this.propabilities.set(i, Double.valueOf(
					(1-this.ψ) * Math.pow(1+this.ρ,this.scores.get(i).doubleValue())
					/ sum + this.ψ / this.propabilities.size()));
	}

	/**
	 * Log the results of a given strategy.
	 * 
	 * @param strategy chosen strategy
	 * @param amountWon resulted win
	 */
	public void observe(final int strategy,
			final int amountWon) {
		final double old = this.scores.get(strategy).doubleValue();
		final double newScore = old + this.ψ *
		amountWon / (this.propabilities.size()*
				this.propabilities.get(strategy).doubleValue());

		this.scores.set(strategy, Double.valueOf(newScore));
		calculateProbabilities();
		Debug.log(Option.STRATEGY, "Probs:" + this.propabilities);
		Debug.log(Option.STRATEGY, "Scores:" + this.scores);
	}

	/**
	 * Returns a probable strategy.
	 * 
	 * @return a probable strategy
	 */
	public int getStrategy() {
		if(this.random) {
			final Random randomizer = new Random();
			final double dice = randomizer.nextDouble();
			double threshold = 1.0d;

			for(int i=0; i<this.propabilities.size(); i++){
				threshold -= this.propabilities.get(i).doubleValue();
				if(dice>threshold) return i;
			}

			return 0;
		}

		double max=0.0d;
		int result=0;
		for(int i=0; i<this.propabilities.size(); i++)
			if(this.propabilities.get(i).doubleValue()>max) {
				result=i;
				max=this.propabilities.get(i).doubleValue();
			}

		return result;
	}

	/**
	 * Creates a new exp3 learning model.
	 * 
	 * @param numStrategies number of available
	 * strategies
	 * @param ψ exploration rate
	 * @param ρ learning rate
	 * @param random should the strategy be chosen randomly
	 * with the probability distribution
	 */
	public Exp3(final int numStrategies, final double ψ, final double ρ, final boolean random) {
		this.ψ = ψ;
		this.ρ = ρ;
		this.random = random;

		for(int i=0; i<numStrategies; i++) {
			this.scores.add(Double.valueOf(0));
			this.propabilities.add(Double.valueOf(0.0d));
		}

		calculateProbabilities();
	}
}
