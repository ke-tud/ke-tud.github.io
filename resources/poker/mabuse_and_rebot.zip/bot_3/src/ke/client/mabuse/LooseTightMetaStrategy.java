package ke.client.mabuse;

import ke.data.ClientRingDynamics;
import ke.engine.strategies.IStrategy;
import ke.history.History;
import ke.history.MoneyMonitor;

/**
 * Meta strategy using a tight and a loose strategy.
 * These will be proposed to the client under the
 * premises :
 * <ul><li>client is loosing money -> tight</li>
 * <li>client is winning a little money -> loose/aggressive</li></ul>
 */
public class LooseTightMetaStrategy implements IMetaStrategy {
	private final static int WIN_PER_HAND = 4;
	private final static int WINDOW_SIZE = 50;

	private final IStrategy tightStrategy;
	private final IStrategy aggressiveStrategy;

	/** {@inheritDoc} */
	@Override
	public IStrategy getProposedStrategy(final ClientRingDynamics state) {
		if(History.getHistory().getCurRoundNumber()<50) return this.aggressiveStrategy;

		final int win = MoneyMonitor.getInstance().getWindowData(WINDOW_SIZE).
		getBalance(state.seatToPlayer(state.seatTaken));
		if(win<0) return this.tightStrategy;
		if(win<WINDOW_SIZE*WIN_PER_HAND) return this.aggressiveStrategy;

		return this.tightStrategy;
	}

	/** {@inheritDoc} */
	@Override
	public void playedStrategy(final ClientRingDynamics state, final IStrategy strategy) {
		/* Nothing to do */
	}

	/**
	 * Creates a new meta strategy with the given tight
	 * strategy and aggressive strategy.
	 * 
	 * @param tightStrategy tight strategy (if losing)
	 * @param aggressiveStrategy aggressive (if winning to little)
	 */
	public LooseTightMetaStrategy(final IStrategy tightStrategy,
			final IStrategy aggressiveStrategy) {
		super();
		this.tightStrategy = tightStrategy;
		this.aggressiveStrategy = aggressiveStrategy;
	}

}
