package ke.client.mabuse;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import ke.client.ClientRingStateParser;
import ke.client.StateMonitor;
import ke.data.Action;
import ke.data.ClientRingDynamics;
import ke.engine.handevaluators.MeerkatHandevaluator;
import ke.engine.strategies.IStrategy;
import ke.engine.strategies.OracleOpAdvisor;
import ke.engine.strategies.OracleSimOpAdvisor;
import ke.engine.strategies.SimulatingOracleAdvisor;
import ke.gametree.RingDynamicsState;
import ke.history.ActionMonitor;
import ke.history.BetMonitor;
import ke.history.EliminationMonitor;
import ke.history.History;
import ke.history.MoneyMonitor;
import ke.opponent.OpponentBuilder;
import ke.timermgmt.TimeManager;
import ke.utils.Debug;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.client.PokerClient;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;

/**
 * Mabuse is a poker bot playing two different
 * strategies: a fair Nash equilibrium and an
 * opponent exploiting simulation strategy.
 */
public class MabusePlayer extends PokerClient {
	private static final int NUM_PLAYERS = 3;

	private final Exp3MetaStrategy metaStrategy;

	private final OpponentBuilder opponentBuilder
	= new OpponentBuilder(new MeerkatHandevaluator());
	/** Replication of the server side's state */
	private ClientRingDynamics currentState;

	/*
	 * Parses the current state object from the games state String
	 * and adds some listeners to it.
	 */
	private void setupState() {
		final ClientRingStateParser crsp = new ClientRingStateParser();
		crsp.parseMatchStateMessage(this.currentGameStateString);
		final MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000);

		this.currentState = new ClientRingDynamics(crsp.numPlayers, mt, crsp);
		this.currentState.setParser(crsp);

		this.currentState.addStateChangeListener(History.getHistory());
		this.currentState.addStateChangeListener(TimeManager.getInstance());
		this.currentState.addStateChangeListener(MoneyMonitor.getInstance());
		this.currentState.addStateChangeListener(BetMonitor.getInstance());
		this.currentState.addStateChangeListener(EliminationMonitor.getInstance());
		this.currentState.addStateChangeListener(ActionMonitor.getInstance());
		this.currentState.addStateChangeListener(this.metaStrategy);
		this.currentState.addStateChangeListener(this.opponentBuilder);
		if(Debug.isDebugLevel(Option.GAME_MONITOR))
			this.currentState.addStateChangeListener(new StateMonitor());
	}

	/*
	 * Sends an action to the server.
	 */
	private void sendAction(final Action action){
		try {
			if (action == Action.RAISE)
				sendRaise();
			else if (action == Action.CALL)
				sendCall();
			else
				sendFold();

		} catch(final Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	/*
	 * Invoked every time the state changes and
	 * I am on the move.
	 */
	private void makeMove() {
		final IStrategy currentStrategy = this.metaStrategy.getProposedStrategy(this.currentState);
		final RingDynamicsState state = new RingDynamicsState(this.currentState);
		this.metaStrategy.playedStrategy(this.currentState, currentStrategy);

		currentStrategy.evaluateSituation(state);
		sendAction(currentStrategy.getAction());
	}

	/** {@inheritDoc} */
	@Override
	public synchronized void handleStateChange(){
		if (this.currentState == null)
			setupState();

		TimeManager.getInstance().startTurn();
		this.currentState.setFromMatchStateMessage(this.currentGameStateString);

		if (this.currentState.isOurTurn()){
			if (this.currentState.roundIndex == 0 && this.currentState.bettingSequence.length() < 3)
				TimeManager.getInstance().newHand();

			TimeManager.getInstance().incrementRequests();
			makeMove();
			TimeManager.getInstance().reCalculateRemainingTimes();
		}
	}



	/**
	 * Creates a new MabusePlayer.
	 */
	public MabusePlayer() {
		final List<IStrategy> strategyList = new ArrayList<IStrategy>();
		strategyList.add(new SimulatingOracleAdvisor(this.opponentBuilder));
		strategyList.add(new OracleSimOpAdvisor(this.opponentBuilder));

		this.metaStrategy = new Exp3MetaStrategy(strategyList, NUM_PLAYERS);
	}


	/**
	 * Main Entry Point called by startme.sh (startme.bat)
	 * arg[0] must be the server's IP-address or name
	 * arg[1] must be the corresponding portnumber
	 * @param args
	 * @throws Exception
	 */
	public static void main(final String[] args) throws Exception{
		final MabusePlayer pp = new MabusePlayer();
		System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
		pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.print("Connection established!");

		// Parse debug option
		for(final String arg : args)
			try {
				final Option debugOption = Debug.Option.valueOf(arg);
				Debug.DEBUG_LEVEL.add(debugOption);
			} catch(final Exception e) {
				continue;
			}

			pp.run();

	}
}