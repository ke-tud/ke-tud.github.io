package ke.client.mabuse;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

import ke.client.IStateChangeListener;
import ke.data.Action;
import ke.data.ClientRingDynamics;
import ke.data.GameState;
import ke.data.Round;
import ke.engine.strategies.IStrategy;
import ke.utils.Debug;
import ke.utils.Utils;
import ke.utils.Debug.Option;
import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * The meta strategy uses the Exp3 algorithm to chose
 * between a collection of strategies a strategy with
 * the estimated best result.
 */
public class Exp3MetaStrategy implements IStateChangeListener, IMetaStrategy {
	private static final double INITIAL_EXPLORATION = .5d;
	private static final double INITIAL_LEARNING = 1.0d;

	private final int numPlayers;
	private final EnumMap<Round, Exp3> standardStrategies;
	private final EnumMap<Round, List<Exp3>> headsUpStrategies;
	private final List<IStrategy> strategies;

	private EnumMap<Round, Integer> strategiesUsed;
	private Round currentHeadsUpStart;
	private int currentHeadsUpOpponent;

	private Round currentRound = Round.PREFLOP;
	private IStrategy currentStrategy;
	private boolean planNewStrategy = true;

	private void initializeRounds() {
		this.strategiesUsed = new EnumMap<Round, Integer>(Round.class);
		this.currentHeadsUpStart = Round.PREFLOP;
		this.currentHeadsUpOpponent = -1;
	}

	/** {@inheritDoc} */
	@Override
	public void actionPerformed(final int seat, final int player, final Action action) {
		/* Nothing to do */
	}

	/** {@inheritDoc} */
	@Override
	public void roundFinished(final int ownID, final int playerAtSeatZero, final int[] amountWon,
			final int[] inPot, final Card[][] hole, final Card[] board) {
		for(final Round round:Round.values())  {
			if(this.strategiesUsed.get(round)==null) continue;

			Exp3 exp3;
			if(this.currentHeadsUpOpponent != -1 &&
					this.currentHeadsUpStart.getIndex() < round.getIndex())
				exp3 = this.headsUpStrategies.get(round).get(this.currentHeadsUpOpponent);
			else
				exp3 = this.standardStrategies.get(round);

			exp3.observe(this.strategiesUsed.get(round).intValue(),
					amountWon[ownID]);

			Debug.log(Option.STRATEGY, "Strategy #"+
					this.strategiesUsed.get(round).intValue()+"in round "+round+
					" resulted in a win of "+amountWon[ownID]+"."+
					(this.currentHeadsUpOpponent!=-1 ? "Heads up situation against #"+
							this.currentHeadsUpOpponent : "All player active."));
		}


		initializeRounds();
	}

	/** {@inheritDoc} */
	@Override
	public void stateChanged(final GameState state) {
		this.currentRound = Utils.gameStateToRound(state);
		this.planNewStrategy = true;
	}

	private int getHeadsUpOpponent(final ClientRingDynamics state) {
		if(state.getNumActivePlayers()==2) {
			int headsUpOpponent = 0;
			for(int i=0; i<this.numPlayers; i++)
				if(state.active[i] && i != state.seatTaken) {
					headsUpOpponent = state.seatToPlayer(i);
					break;
				}
			return headsUpOpponent;
		}

		return -1;
	}

	/** {@inheritDoc} */
	public void playedStrategy(final ClientRingDynamics state,
			final IStrategy strategy) {
		final int strategyIdx = this.strategies.indexOf(strategy);

		if(this.currentHeadsUpOpponent == -1 && getHeadsUpOpponent(state)!=-1) {
			this.currentHeadsUpStart = Utils.gameStateToRound(state.gameState);
			this.currentHeadsUpOpponent = getHeadsUpOpponent(state);
		}

		this.strategiesUsed.put(this.currentRound, Integer.valueOf(strategyIdx));
	}

	/** {@inheritDoc} */
	public IStrategy getProposedStrategy(final ClientRingDynamics state) {
		if(this.planNewStrategy) {
			final Exp3 exp3;
			if(getHeadsUpOpponent(state)!=-1)
				exp3 = this.headsUpStrategies.get(
						Utils.gameStateToRound(state.gameState)).get(getHeadsUpOpponent(state));
			else
				exp3 = this.standardStrategies.get(Utils.gameStateToRound(state.gameState));

			this.planNewStrategy = false;
			this.currentStrategy =this.strategies.get(exp3.getStrategy());
		}

		return this.currentStrategy;
	}

	/**
	 * Creates a new MetaStrategy for the given
	 * strategies.
	 * 
	 * @param strategyList list of strategies
	 * @param numPlayers number of players in game
	 */
	public Exp3MetaStrategy(final List<IStrategy> strategyList, final int numPlayers) {
		this.strategies = strategyList;
		this.standardStrategies = new EnumMap<Round, Exp3>(Round.class);
		this.headsUpStrategies = new EnumMap<Round, List<Exp3>>(Round.class);
		this.numPlayers = numPlayers;

		final int numStrategies = strategyList.size();
		for(final Round round: Round.values()) {
			this.standardStrategies.put(round, new Exp3(numStrategies, INITIAL_EXPLORATION, INITIAL_LEARNING, true));
			final ArrayList<Exp3> roundHeadsUpStrategies = new ArrayList<Exp3>(this.numPlayers);
			this.headsUpStrategies.put(round, roundHeadsUpStrategies);
			for(int i=0; i<this.numPlayers; i++)
				roundHeadsUpStrategies.add(new Exp3(numStrategies, INITIAL_EXPLORATION, INITIAL_LEARNING, true));

		}
		initializeRounds();
	}

}
