package ke.client.mabuse;

import ke.data.ClientRingDynamics;
import ke.engine.strategies.IStrategy;

/**
 * A meta strategy can be used to get
 * good strategies for certain states
 * in the game.
 */
public interface IMetaStrategy {

	/**
	 * Logs the strategy played in the given state for
	 * a further evaluation.
	 * 
	 * @param state game state
	 * @param strategy strategy used in this state
	 */
	public abstract void playedStrategy(final ClientRingDynamics state,
			final IStrategy strategy);

	/**
	 * Returns a proposed strategy for the given
	 * game state.
	 * 
	 * @param state game state
	 * @return a proposed strategy
	 */
	public abstract IStrategy getProposedStrategy(final ClientRingDynamics state);

}