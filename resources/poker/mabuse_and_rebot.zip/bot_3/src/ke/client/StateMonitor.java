package ke.client;

import java.util.Arrays;

import ke.data.Action;
import ke.data.GameState;
import ke.utils.Debug;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class StateMonitor implements IStateChangeListener {

	@Override
	public void actionPerformed(int seat, int player, Action action) {
		Debug.log("Action performed: Seat: "+seat+"; player: "+player+"; Action: "+action);
	}

	@Override
	public void roundFinished(int ownID, int playerAtSeatZero, int[] amountWon,
			int[] inPot, Card[][] hole, Card[] board) {
		Debug.log("Own ID: "+ownID+"; Player @ #0: "+playerAtSeatZero+"; Amount won: "
				+Arrays.toString(amountWon)+"; in pot: "+Arrays.toString(inPot)+"; holes: "
				+Arrays.deepToString(hole)+"; board: "+Arrays.toString(board));
	}

	@Override
	public void stateChanged(GameState state) {
		Debug.log(state);
	}

}
