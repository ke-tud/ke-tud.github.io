#!/bin/bash
java -Xms128m -Xmx256m -cp lib/pokerserver.jar:AKI.jar client.simple.SimplePlayer $1 $2
