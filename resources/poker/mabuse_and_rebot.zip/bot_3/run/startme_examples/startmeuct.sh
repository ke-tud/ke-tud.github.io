#!/bin/bash
java -Xms512m -Xmx2048m -cp lib/pokerserver.jar:AKI-UCT.jar player.UCTPlayer $1 $2
