#!/usr/bin/python

import sys,os, datetime,re, shutil
from os import path as op



def system_name():
   
    if  os.name == 'posix':
        os_name = 'LINUX'
    elif os.name in ['nt', 'dos', 'xp', 'vista']:
        os_name = 'WINDOWS'
    else:    
        os_name = 'unknown'
    return os_name

def timestamp():
    date_time_raw = str(datetime.datetime.now())
    date_time     = re.sub(r'[:\.\ -]','_', date_time_raw )
    return date_time

def base_directory():
    me               = op.abspath(sys.argv[0])
    me_dir           = op.dirname(me)
    base_dir         = op.split( me_dir )[0]
    return base_dir

def apath(*compounts):
    """outputs absolute path starting with base_dir,
    ending with path given by compounts"""
    parts = [ base_dir ] + list(compounts)
    return op.join(*parts)

def rpath(*compounts):
    """outputs path given by compounts,
    assumed to be relative to base_dir"""
    return op.join(*compounts)


### accessing config for this script

def get_config_section(section_title):
    config_lines    = get_lines(apath('run', config_file_name))    
    config_sections = sections(config_lines,section_names=[section_title])
    return config_sections[section_title]
    

def get_lines(file_path):
    f = open( file_path )
    lines = [ line.strip() for line in f.readlines() ]
    f.close()
    return [ line for line in lines if not ( line == '' or line[0] in ['%','#'] ) ]

def section_head(line):
    """Subsequent lines that are headed by 
    a line ending with a colon build a section block.
    The prefix of the colon is a section head. 
    Additional spaces are sciped."""
    if line[-1] == ':' :
        compounts = line[:-1].split()          
        return ' '.join(compounts)
    else:
        return ''
    
def sections(lines, section_names=[], section_name_0='root'):
    """Returns dict with one item for each 
    section. A section has section name a can inlcude
    more than one section block that are headed by the 
    same section name (see section_head() )"""
    
    # init output
    sections            = {} # no recursion needed
    for section_name in [ section_name_0 ] + section_names :
        sections[section_name] = []
    
    # go
    section_name = section_name_0 
    while lines:
        line = lines.pop(0)
        if section_head(line):
            section_name = section_head(line)
            if not sections.has_key(section_name):
                sections[section_name] = []
        else:
            sections[section_name] += [ line ]
    return sections 




### building the prf for pokerserver 

field_separator_in_prf  = '\t'

def match_config(competetors):
    lines = []
    n_competetors = len(competetors)
    
    for i in range(n_competetors):
        lines += [ machine_line(str(i+1)) ]
    
    lines += [ 'BEGIN_TOURNAMENT' ] 
    lines += [ '' ]
    lines += [ ring_policy_line() ]
    lines += [ '' ]
    for bot_name in set(competetors):
        n_current_bot = competetors.count(bot_name)
        for i in range(n_current_bot):
            lines += [ bot_line(bot_name, str(i+1)) ]
    lines += [ '' ]
    lines += [ 'END_TOURNAMENT' ]

    return os.linesep.join(lines)


def machine_line(bot_number):
    prefix         = 'LocalMachine 127.0.0.1'
    expansion_dir_ = apath('server', 'expansion',  
                           'expansion'+ str(bot_number) + os.sep )

    return field_separator_in_prf.join([prefix, expansion_dir_, os_name])


def ring_policy_line():
    policy_file_path = apath('run',policy_file_name)
    match_name    = 'Match_' + date_time
    prefix  = 'RingSeries ' + match_name + ' ' + match_name + ' 1 127.0.0.1 '
    return field_separator_in_prf.join([prefix, policy_file_path])


def bot_line(bot_name, bot_subname):

    prefix  = 'BotTarFile ' 
    bot_key = bot_name + '_' + bot_subname
    if os_name == 'WINDOWS':
	   tar_file_path = apath('bots', bot_name + '.jar')  
    else:
	   tar_file_path = apath('bots', bot_name + '.tar')  
        
    path_within_tar = bot_name + os.sep  
    aeh             = 'LOCAL' + os_name
    
    return field_separator_in_prf.join([prefix, 
                           bot_key, 
                           tar_file_path, 
                           path_within_tar,
                           os_name, 
                           aeh
                           ]
                          )


### cleanup expansions

def renew_expansion_dirs():
    for i in [1,2,3,4,5,6]:
        p = apath('server', 'expansion', 'expansion' + str(i)) 
        if os.path.isdir(p):
            shutil.rmtree(p)
        os.mkdir(p) 

### command to call pokerserver

def pokerserver_call_string(sub_command):
    assert os.getcwd() == apath('server') # pokerserver demand
    return command('java -cp %s ca.ualberta.cs.poker.free.tournament.Forge %s %s',
                   rpath(os.pardir,'lib', 'pokerserver.jar'), 
                   rpath(os.pardir,'run', prf_file_name ),
                   sub_command )
    

def command( template, *args):
    return template % tuple([ re.escape(arg) for arg in args]) 


def compile_command(bot_name):

    rel_classpaths_list = get_config_section('classpaths ' + bot_name)
    classpaths_list     = [ apath('lib', p) for p in rel_classpaths_list ] 
    classpaths          = os.pathsep.join( classpaths_list )
    source_file_name    = get_config_section('source ' + bot_name)[0]
    source_file_path    = apath('src', source_file_name)
    

    return command('javac -cp %s -d %s -sourcepath %s %s', 
                   classpaths, 
                   apath('bots', bot_name, 'build'),
                   apath('src'),
                   source_file_path  )
   

def tar_command(bot_name):
    return command('tar -c -f  %s -C bots %s',
                   apath('bots', bot_name + '.tar'),
                   bot_name )
    
def jar_command(bot_name):
    
    return command('jar -cf  %s -C bots %s',
                   apath('bots', bot_name + '.jar'),
                   bot_name )

def pack_archive(bot_name):
    os.chdir( apath('') )
    if os_name == 'WINDOWS':
		os.system( jar_command(bot_name) )
    else:
		os.system( tar_command(bot_name) )     

def copy_classpath_contents(bot_name):
    
    for rel_classpath in get_config_section('classpaths ' + bot_name):
        
        classpath   = apath('lib', rel_classpath)        
        destination = apath('bots', bot_name, 'lib', rel_classpath )

        if os.path.isdir(classpath):
            
            if os.path.exists( destination ):
                shutil.rmtree( destination )
            shutil.copytree(classpath, destination )       
        else:
            shutil.copy( classpath, destination )
        
            
    
### important globals

os_name           = system_name()
base_dir          = base_directory()
date_time         = timestamp()

config_file_name  = 'tournament.conf'
policy_file_name  = 'seating_order.txt'
prf_file_name     = 'match_config_' + date_time + '.prf' # config file read by pokerserver



### check
assert os_name in ['LINUX', 'WINDOWS']



### go


# add lib/ to search path
os.defpath = os.defpath + os.pathsep + apath('lib')
   
# compile bots if demanded in config file
for bot_name in get_config_section('compile'):

    print 'Compile     :', bot_name    
    os.chdir( apath() ) 
    os.system( compile_command(bot_name) )
    copy_classpath_contents(bot_name)   
    pack_archive(bot_name)
    
           
# write prf, the config file for pokerserver
prf_path     = apath('run' , prf_file_name)
print 'Uses prf    :', prf_file_name
    
competetors  = get_config_section('compete')    
prf_content  = match_config(competetors)
out_file     = open(prf_path, 'w')
out_file.write( prf_content )
out_file.close()
    
# remove old expansions    
renew_expansion_dirs()

# start pokerserver (e.g. start tournament)    
print 'Competetors :', competetors
os.chdir(apath('server')  ) 
os.system( pokerserver_call_string('generateCards') )
os.system( pokerserver_call_string('runTournament') )




