#!/bin/bash

ROOT=`cd .. && pwd`


shared_classpath="$ROOT/lib/pokerserver.jar:"

source_file="$ROOT/src/ke/client/timed/TimedPlayer.java"

echo $ROOT
echo $shared_classpath
echo $source_file
echo

cd $ROOT

##compile
javac -cp $shared_classpath -d $ROOT/bots/timed_player/build -sourcepath src $source_file

##copy pokerserver lib into bot directory
cp $ROOT/lib/pokerserver.jar $ROOT/bots/timed_player/pokerserver.jar

## tar bot package
tar cf $ROOT/bots/timed_player.tar -C bots timed_player


###
# find ../src/ -name \*.java > _files.src
# javac -cp ../lib/pokerserver.jar @_files.src
# rm _files.src
