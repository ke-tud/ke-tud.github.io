### Pokerserver lokal starten mit 3 Clients die in linuxlocal.prf definiert sind
#!/bin/sh

## alte expansions loeschen

for i in 1 2 3 4 5 6; do
	if [ -e "../server/expansion/expansion$i" ]; then
		rm -rf ../server/expansion/expansion$i
	fi
	mkdir ../server/expansion/expansion$i
done

## wechsele ins server Verzeichnis - ist nötig da pokerserver im aktuellen Verzeichnis die Results in data/... abspeichert
cd ../server

## alte Spiele loeschen, nicht unbedingt nötig 
#rm -r data/results/*
#rm -r data/cards/*
#rm -r data/serverlog/*

## Erzeuge neues spiel profil. Die Match ID darf nicht bereits existieren (siehe data/results/), da sonst keine neuen 
## Karten generiert werden und auch kein neues Match ausgewertet wird.
suffix=`date +%y%m%d_%H%M%S_PermNo`

## ersetze "MatchName" mit "MatchName_suffix" im Spiel Profil
sed 's/'MatchName'/'Match_${suffix}'/g' ../run/match_config_linux.prf > ../run/match_${suffix}.prf

## generiere Karten und starte Turnier
java -cp ../lib/pokerserver.jar ca.ualberta.cs.poker.free.tournament.Forge ../run/match_${suffix}.prf generateCards
java -cp ../lib/pokerserver.jar ca.ualberta.cs.poker.free.tournament.Forge ../run/match_${suffix}.prf runTournament

#java -cp ../lib/pokerserver.jar ca.ualberta.cs.poker.free.tournament.Forge ../run/match_config_linux.prf generateCards
#java -cp ../lib/pokerserver.jar ca.ualberta.cs.poker.free.tournament.Forge ../run/match_config_linux.prf runTournament

