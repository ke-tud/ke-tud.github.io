java -cp pokerserver.jar:bbhardbot.jar:HoldEmShowdown.jar de.tud.inf.poker.g6bot.free.bots.BBHardBot $1 $2
