java -cp pokerserver.jar:simulator.jar bot.B2BotPS $1 $2
