/*
 * AdvancedPokerClient.java
 *
 * Created on April 19, 2006, 10:19 AM
 */

package ca.ualberta.cs.poker.free.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;


/**
 * An extension of PokerClient that contains a reference to a reproduction of what is happening on 
 * the server side (state).
 * Can overload takeAction() (instead of handleStateChange()) to only receive messages when it is
 * your turn to act.
 *
 * As before, actions can be taken with sendFold, sendCall(), and sendRaise()
 * @author Martin Zinkevich
 */
public class HalloPokerClient extends PokerClient{

	static public int n_player = 6;
    public String expert = "python pypoker/poker.py";
	
    public HalloPokerClient(){
    	super();
        //state = new ClientPokerDynamicsMP();
    }
    
	/**
     * A reproduction of what is happening on the server side.
     */
    //public ClientPokerDynamicsMP state;
    
	
    /** 
     * Handles the state change. 
     * Updates state and calls takeAction()
     */
    @Override
	public void handleStateChange(){
    	//state.setFromMatchStateMessage(currentGameStateString);
    	//if (state.isOurTurn) {
    	
    	// Bsp: MATCHSTATE:5:0:cc:|||||5s8c
        if ( is_my_turn(currentGameStateString) ){
            takeAction();
        }
    }
    
    public static Boolean is_my_turn(String game_state_string){
		
    	// MATCHSTATE:5:0:cc:|||||5s8c
		String[] message_parts = game_state_string.split(":");
		// MATCHSTATE 
		// 5 // Position
		// 0 // hand number
		// cc // action so far...
		// |||||5s8c 
		int my_position = Integer.parseInt(message_parts[1]);
		String bet_part = message_parts[3];
		return ( my_position == target_position(bet_part));   
	}


    /**
     * Whos turns is it?
     */
    public  static int target_position(String bet_string){
    	    	
    	int first_position = 2;
    	int target = first_position;
    	Boolean[] still_in = new Boolean[n_player];
    	for (int i = 0; i < still_in.length; i++) {
			still_in[i] = Boolean.TRUE;
		}
    	
    	char[] bet_sequence = bet_string.toCharArray();
    	
    	// von vorne nach hinten durchlaufen
    	for (char c : bet_sequence) {
    		
    		switch (c){
    			case '/': 
    				target = successor(still_in, n_player - 1 );
    				break;
    			case 'f': 
    				// er hat gefoldet
    				still_in[target] = Boolean.FALSE;
    				target = successor(still_in, target);
    				break;
    			default : 
    				target = successor(still_in, target);
    		}
    		
		}
    	
    	return target;
    }
    
    /*
     * Whos next after target? Helper for target_position(.)
     */
    private static int successor(Boolean[] still_in, int target){
    	target = (target + 1) % n_player;
    	Boolean found  = still_in[target];
    	int tries = 0;
		while (!found && tries < n_player){
			target = (target + 1) % n_player;
			found  =  still_in[target];	
			tries++;
			if (tries == n_player){
				System.out.println("Baaa");
			}
		}
    	return target;
    }
    
    
    /*
     * Do what expert tells you to do
     */
    public void takeAction(){
        try{
        	
        	String answer_string = request(currentGameStateString);
        	//System.out.println("pypoker says: " + answer_string);
        	
        	if (answer_string.equals("fold")) {
        		sendFold();
        	}
        	
        	if (answer_string.equals("call")){
        		sendCall();
        	}
        	
        	if (answer_string.equals("raise")){
        		sendRaise();
        	}
        	
        } catch (Exception e){
            System.out.println(e);
        }
    }

    
    /*
     * Ask expert what to do
     */
    public String request(String query) {
    	//System.out.print("do query");
    	Boolean debug = Boolean.FALSE;
    	String out = "";
    	
    	try {
     		
     		String line;
     		Process p = Runtime.getRuntime().exec(expert + " " + query);
     		
     		BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream() ));
     		BufferedReader error = new BufferedReader(new InputStreamReader(p.getErrorStream() ));
     		
     		while ((line = input.readLine()) != null) {     			
     			out = out + line;
     		}
     		
     		if (debug) {
     		
     			while ( ((line = error.readLine()) != null)) {
     				System.out.print("nene: ");
     				System.out.println(line);
     			}
     			
     		}
     		input.close();
      		error.close();

     		p.getInputStream().close();
     		p.getErrorStream().close();
      		
     		p.destroy();
    	}
    		
     	catch (Exception err) {
     		err.printStackTrace();
     	}     
     	return out;
     }
    
     
    public static void main(String[] args) throws Exception{
        HalloPokerClient rpc = new HalloPokerClient();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
   
}
