package de.tud.inf.poker.g6bot.free.simulator;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.inf.poker.g6bot.free.advisor.EvalSimResult;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

public class gameSimulator {
	Card[] hand;
	Card[] board;
	
	public gameSimulator() {
	}
	
	public void setHand(Card[] hand) {
		this.hand = hand;
	}
	
	public void setBoard(Card[] board) {
		this.board = board;
	}

	public EvalSimResult PreFlopResult() {
		Decision d = Decision.fold;
		double winProb = 0.0;
		
		return new EvalSimResult(winProb, d);
	}

	public EvalSimResult FlopResult() {
		Decision d = Decision.fold;
		double winProb = 0.0;
		
		return new EvalSimResult(winProb, d);
	}

	public EvalSimResult TurnResult() {
		Decision d = Decision.fold;
		double winProb = 0.0;
		
		return new EvalSimResult(winProb, d);
	}

	public EvalSimResult RiverResult() {
		Decision d = Decision.fold;
		double winProb = 0.0;
		
		return new EvalSimResult(winProb, d);
	}

}
