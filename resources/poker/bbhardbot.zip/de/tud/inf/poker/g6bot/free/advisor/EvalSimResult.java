package de.tud.inf.poker.g6bot.free.advisor;

import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;


/**
 * 
 * return the winning probability with
 * the decision
 * 
 * @author bastian
 *
 */
public class EvalSimResult {
	double winningProb = 0.0;
	Decision gameDecision;
	
	public EvalSimResult(double prob, Decision d) {
		this.winningProb = prob;
		this.gameDecision = d;
	}
	
	public Decision getDecision() {
		return this.gameDecision;
	}
	
	public double compareTo(EvalSimResult result2) {
		return (this.winningProb - result2.getWinProb());
	}

	private double getWinProb() {
		return this.winningProb;
	}
}
