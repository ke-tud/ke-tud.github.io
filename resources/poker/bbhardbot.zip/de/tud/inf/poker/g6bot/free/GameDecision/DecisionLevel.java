package de.tud.inf.poker.g6bot.free.GameDecision;


import de.tud.inf.poker.g6bot.free.GameDecision.StateOfGame.GameState;

/**
 * Represents the Decision Level... 
 * @author ben
 *
 */
public class DecisionLevel{
	
	/**
	 * index: 0=preflop,1=flop,2=turn,3=river
	 */
	static private float[] alpha;
	
	static private float gamma_prestate;
	
	/**
	 * index: 0=preflop,1=flop,2=turn,3=river
	 */	
	static private float[] beta;
	
	private static DecisionLevel instance;
	
	
	public DecisionLevel() {
		alpha = new float[4];
		beta = new float[4];
		gamma_prestate = 0.0f;
		init();
	}
	
	/**
	 * Singleton 
	 * @return
	 */
	public static synchronized DecisionLevel getInstance () {
	    if (DecisionLevel.instance == null) {
	    		DecisionLevel.instance = new DecisionLevel ();
	    }
	    
	    return DecisionLevel.instance;
	}
	
	/**
	 * Initialisiert alpha und beta mit Expertenwissen
	 */
	private static void init() {
		alpha[0]= 0.9f;
		alpha[1]= 0.7f;
		alpha[2]= 0.8f;
		alpha[3]= 0.9f;
		
		beta[0]= 1 - alpha[0];
		beta[1]= 1 - alpha[1];
		beta[2]= 1 - alpha[2];
		beta[3]= 1 - alpha[3];		
	}
	
	/**
	 * Returns the Gamma value used for deciding what to play...
	 * 
	 * @param state GameState
	 * @param strength
	 * @param potential
	 * @return Gamma
	 */
	public float getGamma(GameState state, float strength, float potential)
	{
		
		System.out.println(state + " " + strength + " " + potential);
		float gamma = 0.0f;
		
		int i = state.ordinal();
		
		// Reset gamma_prestate to 0.0 because new round started
		if (state.equals(GameState.PreFlop))
		{
			gamma_prestate=0.0f;
		}
		System.out.println(i);
		
		gamma = alpha[i] * strength + beta[i] * potential;
		
		gamma = gamma + (gamma - gamma_prestate);
		gamma_prestate = gamma; 
		
		return gamma;
	}
}
