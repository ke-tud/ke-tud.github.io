package de.tud.inf.poker.g6bot.free.advisor;

import java.util.HashMap;

import de.tud.inf.poker.g6bot.free.ClientRingDynamics;
import de.tud.inf.poker.g6bot.free.GameDecision.Decider;
import de.tud.inf.poker.g6bot.free.GameDecision.DecisionLevel;
import de.tud.inf.poker.g6bot.free.GameDecision.PlayAction;
import de.tud.inf.poker.g6bot.free.GameDecision.StateOfGame.GameState;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;
import de.tud.inf.poker.g6bot.free.advisor.StartingHands.Category;

/**
 * Waehlt die Starthand aus
 * im Pot sind, desto eher mit kleineren spekulativen Haenden einsteigen
 * 
 * @author Benjamin Herbert
 */
public class PreFlopAdvisor extends AbstractAdvisor {
	private ClientRingDynamics dynamics;

	// Tablecontaining
	private HashMap<StartingHands.Category, PlayAction> preflopActiontable;

	final String classSig = "[PreFlopAdvisor]";

	private Category startinghand;
	
	private Decision decision;

	/**
	 * new
	 */
	private PlayAction statePlayAction;
	private Decider stateDecider;

	private Decision lastDecision;
	
	private float strength;
	private float potential;
	
	private GameState actualState = GameState.PreFlop;
	// end new
	
	public PreFlopAdvisor(ClientRingDynamics dynamics) {
		this.dynamics = dynamics;
		initPreflopActiontable();
		
		this.stateDecider = new Decider();
	}

	/**
	 * Creates a new Hashmap anf fills it with standard PlayAction object for
	 * each Startinghand Category
	 */
	public void initPreflopActiontable() {
		preflopActiontable = new HashMap<Category, PlayAction>();
		PlayAction action;
		// Put a new Standard Hashmap into the table
		for (StartingHands.Category category : StartingHands.Category.values()) {
			action = new PlayAction();
			action.category = category.toString();
			preflopActiontable.put(category, action);
		}
	}

	public HashMap<StartingHands.Category, PlayAction> getActionTable() {
		return this.preflopActiontable;
	}

	/**
	 * Mit Grenzen agierende Entscheidungsfunktion
	 * @return
	 */
	@Override
	public Decision getDecision() {
		// float gamma = 0f;

		this.startinghand = StartingHands
				.getCategory(dynamics.getMyHoleCards());

		this.strength = startinghand.strength();
		this.potential = startinghand.potential();

		// Get appropriate PlayAction
		this.statePlayAction = this.preflopActiontable.get(startinghand);
		
		/**
		 * new: using the Decider
		 */

		DecisionLevel level = DecisionLevel.getInstance();
		
		float gamma_state = level.getGamma(this.actualState, this.strength, this.potential);
		
		this.lastDecision = this.stateDecider.getDecision(this.statePlayAction, gamma_state);
		
		
		// Expert rule
		if (this.lastDecision == Decision.fold) {
			
			if (dynamics.getAmountToCall(dynamics.getMySeat()) == 0) {
				System.out.println(classSig + " "
						+ "I am in Bigblind. so I can call as there is no bet");
				this.lastDecision = Decision.call;
				 
			}
		}
		
		return this.lastDecision;
	}

	@Override
	public void update(int result) {	
		
		if(this.statePlayAction != null && this.lastDecision != null)
		{
			this.statePlayAction.update(this.lastDecision, result);
		}
		else
		{
			System.out.println("error: nullvalue");
		}		
	}

}
