package de.tud.inf.poker.g6bot.free.evaluator;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * 
 * contains the HighCard, BestHand
 * and BestDraw in each game state
 * {preflop, flop, turn, river}
 * 
 * 
 * 
 * 
 * @author bastian
 *
 */
public class HandState {
	
	public enum Hand {
		OnePair, TwoPair, ThreeOfKind, 
		Straight, Flush, FullHouse,
		FourOfKind, StraightFlush, RoyalFlush
	}
	
	/*
	 * variables for PreFlop
	 */
	public Card PreFlopHighCard;
	public Hand PreFlopBestHand;
	public Hand PreFlopBestDraw;
	
	/*
	 * variables for Flop
	 */
	public Card FlopHighCard;
	public Hand FlopBestHand;
	public Hand FlopBestDraw;
	
	public boolean increasedHandToFlop;
	public boolean increasedDrawToFlop;
	
	/*
	 * variables for Turn
	 */
	public Card TurnHighCard;
	public Hand TurnBestHand;
	public Hand TurnBestDraw;
	
	public boolean increasedHandToTurn;
	public boolean increasedDrawToTurn;
	
	/*
	 * variables for River
	 */
	public Card RiverHighCard;
	public Hand RiverBestHand;
	public Hand RiverBestDraw;
	
	public boolean increasedHandToRiver;
	public boolean increasedDrawToRiver;
	
}
