package de.tud.inf.poker.g6bot.free;

import java.util.ArrayList;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import ca.ualberta.cs.poker.free.dynamics.RingDynamics;

/**
 * This class extends the RingDynamics class to be used on the client side to
 * keep track of the game dynamics. Central to this class is the method
 * processStateChange that uses a matchstate message to redo the game's actions.
 * 
 * @author Stefan Lück
 * @author Benjamin Herbert
 */
public class ClientRingDynamics extends RingDynamics {

	private ArrayList<Character> preflopHistory;
	private ArrayList<Character> postflopHistory;
	private ArrayList<Character> turnHistory;
	private ArrayList<Character> riverHistory;

	private int numPlayers;

	public int currentSeat;

	static String classSig = "[ClientRingDynamics]";

	/**
	 * TimedAgents to track the time usage of the players. Designed for
	 * chessclock mode. Indexed by player (not seat).
	 */
	public TimedAgent[] Timers;

	/**
	 * Number of players active in the game (that is, positive stack left).
	 * Should equal numSeats, which is private in RingDynamics.
	 */
	public int playersActive;

	public ClientRingDynamics(int numPlayers, MatchType info, String[] botNames) {
		super(numPlayers, info, botNames);
		this.numPlayers = numPlayers;
		preflopHistory = new ArrayList<Character>();
		postflopHistory = new ArrayList<Character>();
		turnHistory = new ArrayList<Character>();
		riverHistory = new ArrayList<Character>();

		if (info.chessClock && info.timePerHand > 0) {
			long timeAllowed = info.timePerHand * info.numHands;
			Timers = new TimedAgent[numPlayers];
			for (int i = 0; i < numPlayers; i++)
				Timers[i] = new TimedAgent(timeAllowed);
		}
	}

	/**
	 * Call this function from handleState in Client to update the current state
	 * of ClientRingDynamics.
	 * 
	 * @param stateMsg
	 *            The state message as passed to handleStateChange
	 * @return Whether a new hand has just started.
	 */
	public boolean processStateChange(AdvMatchStateMessage msm) {
		try {
			if (handOver || isShowdown()) {
				System.out.println(classSig + " " + "hand over/showdown");
				System.out.println(classSig + " " + "betting action was "
						+ this.bettingSequence);
				System.out.print(classSig + " " + "board: ");
				if (board!=null)
				{
					if (board[0] != null)
						System.out.print(board[0]);
					if (board[1] != null)
						System.out.print(board[1]);
					if (board[2] != null)
						System.out.print(board[2]);

					System.out.print(" ");

					if (board.length > 3 && board[3] != null)
						System.out.print(board[3]);

					System.out.print(" ");

					if (board.length > 4 && board[4] != null)
						System.out.print(board[4]);

				}
				
				System.out.println("");

				for (int i = 0; i < this.numPlayers; i++) {
					System.out.print(classSig + " " + "Player " + i
							+ " in seat " + playerToSeat(i) + " shows Cards: ");
					Card[] holes = hole[playerToSeat(i)];
					// if (holes != null && active[i]) {
					if (holes != null) {
						System.out.println(holes[0] + "" + holes[1]
								+ " winning " + amountWon[playerToSeat(i)]);
					} else
						System.out.println("----" + " winning "
								+ amountWon[playerToSeat(i)]);

				}

			}
		} catch (RuntimeException e) {
			e.printStackTrace();
		}

		boolean isNewHand = (hole == null || handOver);

		// first, stop clock for player that acted.
		if (!isNewHand && Timers != null)
			Timers[seatToPlayer(seatToAct)].TurnOver();

		if (isNewHand) // start a new hand
			nextHand();

		this.currentSeat = msm.seatTaken;

		// now set cards as given by matchstate (these are at least our own)
		this.setCardsFromMSM(msm);

		// In the next step we will locally redo last player's action.
		// This is necessary for keeping track of the stack sizes and allowed
		// actions.
		char lastAction = msm.getLastActionChar();
		if (lastAction != '\0')
			this.handleAction(lastAction);

		// finally we start the stop clock for the next player.
		if (!handOver && (Timers != null))
			Timers[seatToPlayer(seatToAct)].TurnStarted();

		return isNewHand;
	}

	/**
	 * Goes to the next hand. If the next hand is the first hand, leaves the
	 * hand number and seats as is. Otherwise, increments them. This is special
	 * for the client. We will perform all actions necessary to start a new hand
	 * except card dealing, as we will get our cards from the server...
	 * 
	 * @param reader
	 */
	public void nextHand() {
		if (hole != null) {
			setHandNumber(handNumber + 1);
			nextSeats();
		}
		initializeBets();
	}

	public void setCardsFromMSM(AdvMatchStateMessage msm) {
		playersActive = msm.hole.length;
		this.hole = new Card[playersActive][];

		for (int i = 0; i < playersActive; i++) {
			if (msm.hole[i] != null && !msm.hole[i].equals(""))
				this.hole[i] = Card.toCardArray(msm.hole[i]);
			else
				this.hole[i] = null;
		}

		if (msm.board != null && !msm.board.equals(""))
			this.board = Card.toCardArray(msm.board);
		else
			this.board = null;
	}

	public boolean isShowdown() {
		return (roundIndex == 4);
	}

	/**
	 * Returns the sum of all contributions to the pot (that is: the pot size).
	 * 
	 * @return the pot size.
	 */
	public int getPotSum() {
		int potSum = 0;
		for (int i = 0; i < this.playersActive; i++)
			potSum += inPot[i];
		return potSum;
	}

	/***************************************************************************
	 * From here on, we define some functions for the client to call to obtain
	 * some personalized game state info.
	 * ****************************************************************************
	 */

	public Card[] getMyHoleCards() {
		return this.hole[currentSeat];
	}

	public boolean isMyTurn() {
		return (currentSeat == seatToAct);
	}

	public boolean sitInDealer() {
		return (currentSeat == 4);
	}

	public boolean sitInSB() {
		return (currentSeat == 0);
	}

	public boolean sitInBB() {
		return (currentSeat == 1);
	}

	public int getMyStackSize() {
		return stack[seatToPlayer(currentSeat)];

	}

	public int getMySeat() {
		return currentSeat;
	}

	public long getMyTimeRemaining() {
		if (Timers != null)
			return Timers[seatToPlayer(currentSeat)].getTimeRemaining();
		else
			return -1;
	}

}
