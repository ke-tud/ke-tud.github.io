package de.tud.inf.poker.g6bot.free.bots;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Date;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import de.tud.inf.poker.g6bot.free.AdvancedRingClient;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor;
import de.tud.inf.poker.g6bot.free.advisor.UpdateAdvisor;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;
import de.tud.inf.poker.g6bot.free.opponent.OpponentInfoManagement;

/**
 * Unser HardBot
 * 
 * @author Benjamin Herbert
 */
public class BBHardBot extends AdvancedRingClient {
	private boolean raiseThisRound;
	
	private boolean otherRaiseSeenThisRound;
	private boolean coldCallPresent;
	private Card[] clientCards;

	private PlayAdvisor p_advisor;
	private UpdateAdvisor u_advisor;
	private OpponentInfoManagement opponentInfo;

	private static String classSig = "[BBHardBot]";
	
	
	
	public BBHardBot(int numPlayers, MatchType matchtype) {
		super(numPlayers, matchtype);
		
		this.p_advisor = new PlayAdvisor(dynamics);
		
		this.u_advisor = new UpdateAdvisor();
		this.u_advisor.initAdvisor(this.p_advisor);
		
		opponentInfo = new OpponentInfoManagement(numPlayers, dynamics);
		
		System.out.println(classSig + " " + "my player id is "
				+ dynamics.seatToPlayer(dynamics.getMySeat()));
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#actionPerformed(char,
	 *      int, boolean, boolean)
	 */
	@Override
	public void actionPerformed(char lastAction, int lastSeat,
			boolean handOver, boolean showdown) {
		// System.out.println("Action '"+ lastAction +"' received by seat " +
		// lastSeat + "!");

		if (handOver || showdown) 
		{
			handleHandEnd();
		}

		// Count raises
		if (lastAction == 'r' && lastSeat != dynamics.getMySeat())
		{
			otherRaiseSeenThisRound = true;
			
			switch (dynamics.roundIndex) {
			case (0):

				PlayAdvisor.setNumRaisesPreflop(PlayAdvisor.getNumRaisesPreflop() + 1);
				break;

			case (1):

				PlayAdvisor.setNumRaisesFlop(PlayAdvisor.getNumRaisesFlop() +1 );
				break;

			case (2):

				PlayAdvisor.setNumRaisesTurn(PlayAdvisor.getNumRaisesTurn() + 1 );
				break;

			case (3):
				PlayAdvisor.setNumRaisesRiver(PlayAdvisor.getNumRaisesRiver() +1 );
				break;

			case (4):
				
				break;
			
			default:
				
				
				break;
			}
			
				
				
			
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#newHandStarted(ca.ualberta.cs.poker.free.dynamics.Card[])
	 */
	@Override
	public void newHandStarted(Card[] clientCards) {
		System.out
				.println("-------------------------------------------------------------------------------------");
		System.out.println(classSig + "Hand was started! I'm in seat "
				+ dynamics.currentSeat + " and got: "
				+ Card.arrayToString(clientCards));

		p_advisor.reset();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean,
	 *      int, int, long)
	 */
	@Override
	public void takeAction(boolean raiseAllowed, int totalPotSize,
			int amountToCall, long timeRemaining) {
		// System.out.println("Supposed to take action...");

		// Unterscheidung der Spielrunde
		/*
		 * Round index incremented when the cards for that round are dealt.
		 * Preflop is 0, Flop is 1, Turn is 2, River is 3, Showdown is 4.
		 */

		try {

			p_advisor.init(dynamics);

			switch (dynamics.roundIndex) {
			case (0):

				handlePreflop();
				break;

			case (1):

				handleFlop();
				break;

			case (2):

				handleTurn();
				break;

			case (3):
				handleRiver();
				break;

			case (4):
				// Showdown...???
				break;
			
			default:
				sendFold();
				break;
			}

			

		} catch (SocketException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}


	}

	/**
	 * Handles end of the hand
	 *
	 */
	private void handleHandEnd() {
		System.out.println(classSig + " " + "calling opponentinfo update");
		
		this.opponentInfo.updateAfterRound();

		int win = dynamics.amountWon[dynamics.getMySeat()];
		
		this.u_advisor.Update(win);
		
		PlayAdvisor.resetRaiseValues();
	}

	/**
	 * Handles Preflop play
	 * 
	 * @throws SocketException
	 * @throws IOException
	 */
	private void handlePreflop() throws SocketException, IOException {
		Decision d = p_advisor.getPreFlopDecision();
		System.out.println(classSig + " " + d.toString());
		doAction(d);
	}

	/**
	 * Handles Flop play
	 * 
	 * @throws SocketException
	 * @throws IOException
	 */
	private void handleFlop() throws SocketException, IOException {
		Decision d = p_advisor.getFlopDecision();
		System.out.println(classSig + " " + d.toString());
		doAction(d);
	}

	/**
	 * Handles Turn play Takes the action the Advisor gives back
	 * 
	 * @throws SocketException
	 * @throws IOException
	 */
	private void handleTurn() throws SocketException, IOException {
		Decision d = p_advisor.getTurnDecision();
		doAction(d);
	}

	/**
	 * Handles the river play Takes the action the Advisor gives back
	 * 
	 * @throws SocketException
	 * @throws IOException
	 */
	private void handleRiver() throws SocketException, IOException {
		Decision d = p_advisor.getRiverDecision();
		doAction(d);
	}

	/**
	 * Method that sends the action d to the server.
	 * 
	 * @param d
	 *            Decision to check/call, bet/raise or fold
	 * @throws SocketException
	 * @throws IOException
	 */
	private void doAction(Decision d) throws SocketException, IOException {

		if (d == Decision.raise) {
			sendRaise();

		} else if (d == Decision.fold) {
			sendFold();

		} else {
			sendCall();
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000);
		BBHardBot myBot = new BBHardBot(6, mt);

		System.out.println(classSig + " " + "Attempting to connect to "
								+ args[0] + " on port " + args[1] + "...");
		
		myBot.connect(InetAddress.getByName(args[0]),
						Integer.parseInt(args[1]));
		
		System.out.println(classSig + " "
							+ "Successful connection of BBHardBot at "
							+ new Date());

		myBot.run();
	}
}
