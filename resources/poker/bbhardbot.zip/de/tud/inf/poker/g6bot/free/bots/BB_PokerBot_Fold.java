/*
 * RandomPokerClient.java
 *
 * Created on April 19, 2006, 2:04 PM
 */

package de.tud.inf.poker.g6bot.free.bots;
import java.io.*;
import java.net.*;
import java.security.*;

import ca.ualberta.cs.poker.free.client.PokerClient;

/**
 * Plays actions uniformly at random. Useful for debugging purposes.
 * 
 * @author Martin Zinkevich
 */
public class BB_PokerBot_Fold extends PokerClient {
    SecureRandom random;
    
    /**
     * Chooses an action uniformly at random using an internal secure random number generator.
     */
    @Override
	public void handleStateChange() throws IOException, SocketException{
    	
    	sendFold();
    }
    
    /** 
     * Creates a new instance of RandomPokerClient 
     */
    public BB_PokerBot_Fold(){
      super();
      random = new SecureRandom();
  	
      this.setVerbose(true);
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        BB_PokerBot_Fold rpc = new BB_PokerBot_Fold();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
    
}
