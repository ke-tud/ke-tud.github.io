package de.tud.inf.poker.g6bot.free.advisor;

import java.util.Random;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.inf.poker.g6bot.free.ClientRingDynamics;
import de.tud.inf.poker.g6bot.free.GameDecision.StateOfGame;
import de.tud.inf.poker.g6bot.free.GameDecision.StateOfGame.GameState;
import de.tud.inf.poker.g6bot.free.evaluator.HandPotentialEvaluator;
import de.tud.inf.poker.g6bot.free.evaluator.HandStrengthEvaluator;
import de.tud.inf.poker.g6bot.free.evaluator.IncorrectBoardException;
import de.tud.inf.poker.g6bot.free.simulation.HandPotential;
import de.tud.inf.poker.g6bot.free.simulator.gameSimulator;

/**
 * PlayAdvisor wird von Bot aufgerufen und übermittelt Spieltentscheidungen
 * Dabei kommen weitere Klassen zum Einsatz.
 * 
 * @author Benjamin Herbert
 * 
 */
public class PlayAdvisor {

	// fuer Spielinformationen
	private ClientRingDynamics dynamics;

	private Card[] board;

	private Card[] myholecards;

	private int minDiffLevel = 0;

	private StateOfGame stateForHand;

	private static String classSig = "[PlayAdvisor]";

	private Decision preflopAdvice = null;
	private Decision flopAdvice = null;
	private Decision turnAdvice = null;
	private Decision riverAdvice = null;

	// Used for preflop
	private PreFlopAdvisor preflopadvisor;
	private FlopAdvisor flopadvisor;
	private TurnAdvisor turnadvisor;
	private RiverAdvisor riveradvisor;

	// Used for flop,turn and river
	private HandStrengthEvaluator hse;

	// Used for flop,turn and river
	private HandPotentialEvaluator hpe;

	static private int numRaisesPreflop;
	static private int numRaisesFlop;
	static private int numRaisesTurn;
	static private int numRaisesRiver;
	
	

	public enum Decision {
		fold, check, call, coldcall, raise,
	}

	/**
	 * Konstruktor
	 * 
	 * @param dynamics
	 */
	public PlayAdvisor(ClientRingDynamics dynamics) {
		this.stateForHand = new StateOfGame();

		this.dynamics = dynamics;
		
		resetRaiseValues();

		this.preflopadvisor = new PreFlopAdvisor(dynamics);
		this.flopadvisor = new FlopAdvisor(dynamics);
		this.turnadvisor = new TurnAdvisor(dynamics);
		this.riveradvisor = new RiverAdvisor(dynamics);
	}

	/*
	 * Getter & Setter
	 * 
	 */

	public void setHand(Card[] hand) {
		this.myholecards = hand;

		// this.simulator.setHand(hand);
	}

	public void setBoard(Card[] board) {
		this.board = board;

		// this.simulator.setBoard(board);
	}

	public Card[] getHand() {
		return this.myholecards;
	}

	/**
	 * Resets the Advice Variables Called each new round
	 * 
	 */
	public void reset() {
		this.preflopAdvice = null;
		this.flopAdvice = null;
		this.turnAdvice = null;
		this.riverAdvice = null;
	}

	/**
	 * Init Advisor, Evaluator, Simulator
	 * 
	 * @param dynamics
	 */
	public void init(ClientRingDynamics dynamics) {
		this.setHand(dynamics.getMyHoleCards());
		this.setBoard(dynamics.board);
	}

	/**
	 * Get Preflop Decision from evaluator and simulator
	 * 
	 * @return Decision
	 */
	public Decision getPreFlopDecision() {
		System.out.println(classSig + " making PreFlop-Decision ...");

		return preflopadvisor.getDecision();
	}

	/**
	 * Get Flop Decision from evaluator and simulator
	 * @return Decision
	 */
	public Decision getFlopDecision() {

		float flopStrength;

		try {
			this.hse = new HandStrengthEvaluator(myholecards, board);
			hse.calculateHandStrength();
			flopStrength = hse.flopHandstrength;

		} catch (IncorrectBoardException e) {
			e.printStackTrace();
			flopStrength = 0.5f;			
		}

		this.hpe = new HandPotentialEvaluator(this.myholecards, this.board);
		
		// float flopPotential = hpe.getPotential();
		
		float flopPotential = 0.0f;
		HandPotential hp;
		
		try {
			hp = this.hse.getHandPotential();
			
			float ppot2 = hp.getPpot2();
			float npot2 = hp.getNpot2();
			
			flopPotential = ppot2;
			
		} catch (IncorrectBoardException e) {
			e.printStackTrace();
		}
		
		flopadvisor.setParameters(flopStrength, flopPotential);

		return flopadvisor.getDecision();

	}


	/**
	 * Get Turn Decision from evaluator and simulator
	 * TurnAdvisor
	 * 
	 * @return Decision
	 */
	public Decision getTurnDecision() {

		// update the actual best hand and draw
		this.stateForHand.update(GameState.Turn, this.board);
		
		
		if (this.turnAdvice != null)
			return this.turnAdvice;

		float turnStrength = .0f;

		try {
			hse.setBoardCards(board);
			hse.calculateHandStrength();
			turnStrength = hse.turnHandstrength;

		} catch (IncorrectBoardException e) {
			e.printStackTrace();
		}


		hpe.setBoardCards(board);
		hpe.calculateHandPotential();

		float turnPotential = hpe.getPotential();

		turnadvisor.setParameters(turnStrength, turnPotential);

		return turnadvisor.getDecision();
		

	}

	/**
	 * Get River Decision from evaluator and simulator 
	 * RiverAdvisor
	 * 
	 * @return Decision
	 */
	public Decision getRiverDecision() {
		// update the actual best hand and draw

		this.stateForHand.update(GameState.River, this.board);
		hse.setBoardCards(board);

		System.out.println(classSig + " making River-Decision ...");

		if (this.flopAdvice != null)
			return this.flopAdvice;

		float x = 0f;
		try {
			hse.calculateHandStrength();
			x = hse.riverHandstrength;
		} catch (IncorrectBoardException e) {
			e.printStackTrace();
		}

		// Randomized decision
		this.flopAdvice = getRandomizedDecision(getRiverCallBound(),
				getRiverRaiseBound());

		System.out.println(classSig + " making River-Decision ..."
				+ this.flopAdvice.toString());

		return this.flopAdvice;
	}

	private float getRiverRaiseBound() {
		return 0.7f;
	}

	private float getRiverCallBound() {
		return 0.01f;
	}

	/**
	 * Returns a randomized decision
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public static Decision getRandomizedDecision(float a, float b) {
		if (a > b) {
			System.err.println(classSig + " " + "wrong parameter order");
		}

		Decision d;
		// If borders are switched
		if (a > b) {
			d = Decision.fold;
		}

		Random r = new Random();
		float dart = r.nextFloat();
		if (dart < a) {
			d = Decision.fold;
		}
		if (dart <= b) {
			d = Decision.call;
		} else {
			d = Decision.raise;
		}
		return d;
	}

	/*
	 * return the advisors for the update-advisor
	 */
	public PreFlopAdvisor getPreFlopAdvisor() {
		return this.preflopadvisor;
	}

	public FlopAdvisor getFlopAdvisor() {
		return this.flopadvisor;
	}

	public TurnAdvisor getTurnAdvisor() {
		return this.turnadvisor;
	}

	public RiverAdvisor getRiverAdvisor() {
		return this.riveradvisor;
	}

	static public int getNumRaisesPreflop() {
		return numRaisesPreflop;
	}

	static public void setNumRaisesPreflop(int num) {
		numRaisesPreflop = num;
	}

	static public int getNumRaisesFlop() {
		return numRaisesFlop;
	}

	static public void setNumRaisesFlop(int num) {
		numRaisesFlop = num;
	}

	static public int getNumRaisesTurn() {
		return numRaisesTurn;
	}

	static public void setNumRaisesTurn(int num) {
		numRaisesTurn = num;
	}

	static public int getNumRaisesRiver() {
		return numRaisesRiver;
	}

	static public void setNumRaisesRiver(int num) {
		numRaisesRiver = num;
	}
	
	static public void resetRaiseValues()
	{
		resetRaiseValuePreflop();
		resetRaiseValueFlop();		
		resetRaiseValueTurn();
		resetRaiseValueRiver();
	}

	private static void resetRaiseValueTurn() {
		numRaisesTurn = 0;
	}

	private static void resetRaiseValueRiver() {
		numRaisesRiver = 0;
	}

	private static void resetRaiseValueFlop() {
		numRaisesFlop = 0;
	}

	private static void resetRaiseValuePreflop() {
		numRaisesPreflop = 0;
	}
	
	

}
