package de.tud.inf.poker.g6bot.free.evaluator;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class HandPotentialEvaluator {
	private Card[] hand;
	private Card[] board;
	
	public HandPotentialEvaluator(Card[] hand, Card[] board) {
		this.hand = hand;
		this.board = board;
	}

	// TODO implement me
	public float getPotential() {
		float potential = 0.0f;
		
		return potential;
	}

	public void calculateHandPotential() {
		
		
	}

	public void setBoardCards(Card[] board) {
		this.board = board;
		
	}

}
