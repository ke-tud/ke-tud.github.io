package de.tud.inf.poker.g6bot.free;

import java.util.Date;

/**
 * The class is used to track the time a player needs for his turns.
 * @author Stefan Lück
 */
public class TimedAgent
{
	
   protected long turnStartedAt;
   
	/**
    * The time remaining to use (in milliseconds)
    */
   protected long timeRemaining;
   
	public TimedAgent (long timeAllowed)
	{
		timeRemaining = timeAllowed;
	}
	
	/**
	 * Signals the start of a player's turn.
	 */
	public void TurnStarted()
	{
		turnStartedAt = new Date().getTime();
	}
	
	/**
	 * Signal that a players turn is over.
	 * Adjusts timeRemaining and returns the time elapsed in ms. 
	 * @return
	 */
	public long TurnOver()
	{
		if (turnStartedAt == 0) return 0;
		long turnOverAt = new Date().getTime();
		long timeTaken = (turnOverAt - turnStartedAt);
		
		timeRemaining -= timeTaken;
		turnStartedAt = 0;
		
		return timeTaken;
	}

	/**
	 * Get the time left for the player to act (total).
	 * Is updated during a player's turn.
    * @return The time remaining for the player to act in ms.
    */
   public long getTimeRemaining ()
   {
   	long timeTaken = 0;
		if (turnStartedAt > 0)
			timeTaken = ((new Date().getTime()) - turnStartedAt);
   	 
   	return (timeRemaining - timeTaken) ;
   }
	
}
