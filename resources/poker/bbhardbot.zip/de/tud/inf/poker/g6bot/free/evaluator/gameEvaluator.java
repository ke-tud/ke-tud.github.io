package de.tud.inf.poker.g6bot.free.evaluator;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.HandAnalysis;
import de.tud.inf.poker.g6bot.free.advisor.EvalSimResult;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

public class gameEvaluator {
	Card[] hand;
	Card[] board;
	
	HandAnalysis analysis;
	
	HandState dState = new HandState();
	
	public gameEvaluator() {
		
	}
	
	public void setHand(Card[] hand) {
		this.hand = hand;
	}
	
	public void setBoard(Card[] board) {
		this.board = board;
	}
	
	public EvalSimResult PreFlopResult() {
		Decision d;
		double winProb = 1.0;
		
		
		
		if (hand[0].rank == hand[1].rank || hand[0].suit == hand[1].suit) {
			d = Decision.raise;
		} else {
			d = Decision.fold;
		}
		
		return new EvalSimResult(winProb, d);
	}

	public EvalSimResult FlopResult() {
		Decision d;
		double winProb = 1.0;
		
		d = Decision.raise;
		
		return new EvalSimResult(winProb, d);
	}

	public EvalSimResult TurnResult() {
		Decision d;
		double winProb = 1.0;
		
		d = Decision.raise;
		
		return new EvalSimResult(winProb, d);
	}

	public EvalSimResult RiverResult() {
		Decision d;
		double winProb = 1.0;
		
		d = Decision.raise;
		
		return new EvalSimResult(winProb, d);
	}
}
