package de.tud.inf.poker.g6bot.free.opponent;

import java.util.ArrayList;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * 
 * Statistic at shown Highcards
 * 
 * @author bastian
 *
 */
public class HighCard {
		
	ArrayList<Betting> HighCardBetting;
	
	/*
	 * Params: Card, totalShown, totalWins, preflop, flop, turn, river
	 * 
	 */
	
	public HighCard() {
		
		HighCardBetting.add( new Betting("A", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("K", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("Q", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("J", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("T", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("9", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("8", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("7", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("6", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("5", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("4", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("3", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HighCardBetting.add( new Betting("2", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
	}
	
	public void shownWon(Card highCard, String betting) {
		
	}
	
	public void shownLose(Card highCard, String betting) {
		
	}
}
