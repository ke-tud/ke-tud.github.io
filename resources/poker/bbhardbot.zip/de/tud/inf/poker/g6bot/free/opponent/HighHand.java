package de.tud.inf.poker.g6bot.free.opponent;

import java.util.ArrayList;

import de.tud.inf.poker.g6bot.free.HandEval.Hand;

/**
 * 
 * statistic at shown hands
 * 
 * @author bastian
 *
 */
public class HighHand {
	ArrayList<Betting> HandBetting;
	
	/*
	 * Params: Hand, totalShown, totalWins, preflop, flop, turn, river
	 * 
	 */
	
	public HighHand() {
		HandBetting.add( new Betting("RoyalFlush", 	0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("StraightFlush", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("FourOfKind", 	0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("FullHouse", 	0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("Flush", 		0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("Straight", 	0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("ThreeOfKind", 0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("TwoPair", 		0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
		HandBetting.add( new Betting("OnePair", 		0, 0, "0c0r", "0c0r", "0c0r", "0c0r") );
	}
	
	/*
	 * Win-function
	 * Update Betting-Obj of the resulting hand with
	 * the resulting betting sequence
	 */
	public void shownWon(Hand handState, String betting) {
		if(handState == Hand.OnePair) {
			this.HandBetting.get(0).win();
			
		} else if(handState == Hand.TwoPair) {
			this.HandBetting.get(1).win();
			
		} else if(handState == Hand.ThreeOfKind) {
			this.HandBetting.get(2).win();
			
		} else if(handState == Hand.Straight) {
			this.HandBetting.get(3).win();
			
		} else if(handState == Hand.Flush) {
			this.HandBetting.get(4).win();
			
		} else if(handState == Hand.FullHouse) {
			this.HandBetting.get(5).win();
			
		} else if(handState == Hand.FourOfKind) {
			this.HandBetting.get(6).win();
			
		} else if(handState == Hand.StraightFlush) {
			this.HandBetting.get(7).win();
			
		} else if(handState == Hand.RoyalFlush) {
			this.HandBetting.get(8).win();
			
		}
	}

	/*
	 * Loose-function
	 * Update Betting-Obj of the resulting hand with
	 * the resulting betting sequence
	 */
	public void shownLose(Hand handState, String betting) {
		if(handState == Hand.OnePair) {
			this.HandBetting.get(0).loose();
			
		} else if(handState == Hand.TwoPair) {
			this.HandBetting.get(1).loose();
			
		} else if(handState == Hand.ThreeOfKind) {
			this.HandBetting.get(2).loose();
			
		} else if(handState == Hand.Straight) {
			this.HandBetting.get(3).loose();
			
		} else if(handState == Hand.Flush) {
			this.HandBetting.get(4).loose();
			
		} else if(handState == Hand.FullHouse) {
			this.HandBetting.get(5).loose();
			
		} else if(handState == Hand.FourOfKind) {
			this.HandBetting.get(6).loose();
			
		} else if(handState == Hand.StraightFlush) {
			this.HandBetting.get(7).loose();
			
		} else if(handState == Hand.RoyalFlush) {
			this.HandBetting.get(8).loose();
			
		}
	}

}
