package de.tud.inf.poker.g6bot.free.GameDecision;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class StateOfGame {
	public enum GameState {
		PreFlop, Flop, Turn, River
	}

	/*
	 * initialize the handstate in PreFlop
	 * with the given hand
	 */
	public void init(GameState state, Card[] hand) {
		if(state == GameState.PreFlop) {
			// set variables for PreFlop
		}
	}
	
	/*
	 * update the handstate in
	 * {Flop, Turn, River} with the actual
	 * board cards
	 */
	public void update(GameState state, Card[] board) {
		if(state == GameState.Flop) {
			// set variables for flop
		} else if(state == GameState.Turn) {
			// set variables for Turn
		} else if(state == GameState.River) {
			// set variables for River
		}
	}

}
