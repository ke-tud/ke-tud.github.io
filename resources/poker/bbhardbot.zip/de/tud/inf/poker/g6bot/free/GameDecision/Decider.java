package de.tud.inf.poker.g6bot.free.GameDecision;

import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

public class Decider {
	private PlayAction roundPlayAction;
	
	private float DecisionGamma;
	private Decision roundDecision;
	
	public Decider() {
		this.roundPlayAction = new PlayAction();
		this.DecisionGamma = 0.0f;
		this.roundDecision = null;
	}
	
	/**
	 * Maps PlayAction and gamma value to a Decision accodring to our expert knowledge
	 * @param playAction
	 * @param gamma
	 * @return
	 */
	public Decision getDecision(PlayAction playAction, float gamma) {
		
		this.roundPlayAction = playAction;
		this.DecisionGamma = gamma;
		
		float foldvalue = roundPlayAction.getFoldLevel();
		float checkvalue = roundPlayAction.getCheckLevel();
		float callvalue = roundPlayAction.getCallLevel();
		float coldcallvalue = roundPlayAction.getColdcallLevel();
		float raisevalue = roundPlayAction.getRaiseLevel();
		
		// We have a very bad hand
		if (this.DecisionGamma < foldvalue) {
			this.roundDecision = Decision.fold;

		} else {

			this.roundDecision = Decision.call;

			if (isReRaisePresent() || isRaisePresent()) {
				if (this.DecisionGamma >= coldcallvalue) {
					this.roundDecision = Decision.raise;
				}
				
			} else if (isBetPresent()) {
				if (this.DecisionGamma >= callvalue) {
					this.roundDecision = Decision.raise;
				}
			}
		}
		
		return this.roundDecision;
	}

	/**
	 * One Bet is present
	 * 
	 * @return
	 */
	private boolean isBetPresent() {
		return raisesPresent() == 1;
	}

	/**
	 * Is a raise present?
	 * 
	 * @return
	 */
	private boolean isRaisePresent() {
		return raisesPresent() == 2;
	}

	/**
	 * Is a reraise present?
	 * 
	 * @return
	 */
	private boolean isReRaisePresent() {
		return raisesPresent() >= 3;
	}

	private int raisesPresent() {
		return PlayAdvisor.getNumRaisesPreflop();
	}


}
