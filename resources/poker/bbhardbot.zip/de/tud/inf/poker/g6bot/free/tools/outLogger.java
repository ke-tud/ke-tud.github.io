package de.tud.inf.poker.g6bot.free.tools;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class outLogger {
	private File out;
	private FileWriter outWriter;
	
	public outLogger() {
		out = new File("gameLogger.log");
		
		boolean append = true;
		
		try {
			outWriter = new FileWriter(out, append);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void addToLog(String message) {
		try {
			outWriter.write( message );
			outWriter.write( "\n" );
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
