package de.tud.inf.poker.g6bot.free.evaluator;

/**
 * MeaningfulException for our Evaluator
 * @author ben
 *
 */
public class IncorrectBoardException extends Exception {

}
