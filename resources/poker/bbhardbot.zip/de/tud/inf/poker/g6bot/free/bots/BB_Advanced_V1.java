/*
 * AdvancedPokerClient.java
 *
 * Created on April 19, 2006, 10:19 AM
 */

package de.tud.inf.poker.g6bot.free.bots;

import java.net.InetAddress;

import ca.ualberta.cs.poker.free.client.ClientPokerDynamics;
import ca.ualberta.cs.poker.free.client.PokerClient;
import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.inf.poker.g6bot.free.tools.outLogger;

/**
 * An extension of PokerClient that contains a reference to a reproduction of what is happening on 
 * the server side (state).
 * Can overload takeAction() (instead of handleStateChange()) to only receive messages when it is
 * your turn to act.
 *
 * As before, actions can be taken with sendFold, sendCall(), and sendRaise()
 * @author Martin Zinkevich
 */
public class BB_Advanced_V1 extends PokerClient{
    /**
     * A reproduction of what is happening on the server side.
     */
    public ClientPokerDynamics state;
    
    /**
     * Logger for game information
     */
    
    public outLogger logger;
    
    /** 
     * Handles the state change. 
     * Updates state and calls takeAction()
     */
    @Override
	public void handleStateChange(){
        state.setFromMatchStateMessage(currentGameStateString);
        if (state.isOurTurn()){
        	showBoard();
        	showHand();
        	
        	logger.addToLog("\n");
        	
            takeAction();
        }
    }
    
    /** 
     * Creates a new instance of AdvancedPokerClient. Must call connect(), then run() to start process 
     */
    public BB_Advanced_V1(){
        state = new ClientPokerDynamics();
        
        logger = new outLogger();
        
        // this.setVerbose(true);
    }
    
    /**
     * Output the current board using the logger
     */
    public void showBoard() {
    	logger.addToLog("showing board ");
    			
    	Card[] theBoard = state.board;
    	
    	logger.addToLog("( " + " /" + theBoard.length + 
    					" ) -- " );
    	logger.addToLog("board is: " + Card.arrayToString( theBoard ) + "\n");
    	
    	/*
    	for(int i=0; i< theBoard.length; i++) {
    		logger.addToLog( theBoard[i].toString() );
    	}
    	
    	*/
    }
    
    /**
     * Output the own hand using the logger
     */
    public void showHand() {
    	logger.addToLog("showing hand -- ");

    	Card[][] allCards = state.hole;
    	
    	logger.addToLog( "player1: " + Card.arrayToString( allCards[0] ) + " -- ");
    	logger.addToLog( "player2: " + Card.arrayToString( allCards[1] ) + "\n");
    	
    	
    	/*
    	
    	if(allCards[0][0] != null) {
    		myHand = allCards[0];
    	} else {
    		myHand = allCards[1];
    	}
    	
    	for(int i=0; i< myHand.length; i++) {
    		logger.addToLog( myHand[i].toString() );
    	}
    	*/    	
    }
    
    /**
     * Overload to take actions.
     */
    public void takeAction(){
        try{
            if (state.roundBets<4){
                if (Math.random()<0.5){
                    sendRaise();
                }  else {
                    sendCall();
                }
            } else {
              sendCall();
            }
        } catch (Exception e){
            System.out.println(e);
        }
    }
    
    /**
     * @param args the command line parameters (IP and port)
     */
    public static void main(String[] args) throws Exception{
        BB_Advanced_V1 rpc = new BB_Advanced_V1();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        rpc.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        rpc.run();
    }
}
