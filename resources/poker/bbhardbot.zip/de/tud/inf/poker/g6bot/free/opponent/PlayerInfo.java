package de.tud.inf.poker.g6bot.free.opponent;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * 
 * After each showdown, the players have shown their cards and the playerinfo
 * can be updated. Here, only hands can be used which are shown.
 * 
 * It is updated after each finished hand.
 * 
 * @author bastian
 * @author ben
 */
public class PlayerInfo {
	private HighCard h_card;

	private HighHand h_hand;

	// id of player as in RingDynamics
	private int playerId;

	// Information about players
	private int nGamesPlayed;

	private int nFlopSeen;

	private int nTurnSeen;

	private int nRiverSeen;

	private int nShowdown;

	private int nGamesWon;

	private int nGamesLost;

	private int nGamesTied;

	private int stack;
	
	private Card[] hand;
	private Card[] board;
	
	static String classSig = "[PlayerInfo]";

	public PlayerInfo(int gamesWon, int gamesLost, int gamesTied) {
		super();
	}
	
	public PlayerInfo(int id) {

		this.playerId = id;
		this.stack = 0;
		this.nFlopSeen = 0;
		this.nTurnSeen = 0;
		this.nRiverSeen = 0;
		this.nShowdown = 0;

		// No games played yet
		this.nGamesPlayed = 0;
		this.nGamesWon = 0;
		this.nGamesLost = 0;
		this.nGamesTied = 0;

	}
	
	/*
	 * get best hand from hand and board
	 * update HighHand- state
	 */
	public void updateWon() {
		this.nGamesWon++;
//		
//		Hand winState = HandEval.getBestHand(this.hand, this.board);
//		
//		this.h_hand.shownWon(winState, "");
	}
	
	/*
	 * get best hand from hand and board
	 * update HighHand- state
	 */
	public void updateLost() {
		this.nGamesLost++;
	}
	
	/*
	 * get best hand from hand and board
	 * update HighHand- state
	 */
	public void updateTie() {
		this.nGamesTied++;
	}
	
	/**
	 * Parses new stack and determines wins, losses, ties, gamesplayed, stack,
	 * etc.
	 * 
	 * @param stack
	 */
	public void updateFromWinAmount(int amount)
	{
		System.out.print(classSig + " " + "updating player " + this.playerId  + ":" );
		this.nGamesPlayed++;
		
		if (amount > 0)
		{
			updateWon();
		}
		else if (amount < -2)
		{
			updateLost();
		}
		else
		{
			updateTie();
		}		
		System.out.println(" new stats are #played " + nGamesPlayed + " #won " + nGamesWon + 
				" #lost " + nGamesLost);
		
	}
}