package de.tud.inf.poker.g6bot.free.opponent;

import java.util.HashMap;
import java.util.Map;

import de.tud.inf.poker.g6bot.free.ClientRingDynamics;

/**
 * Contains a Map of player ids to their corresponding PlayerInfo Objects
 * Creates the objects on init()
 * 
 * @author ben
 * 
 */
public class OpponentInfoManagement {

	private int nPlayers;

	/**
	 * Stacks of Last round Used to determine wins and losses Note: This is not
	 * 100 percent accurate, it falls short for split pots indexed by Id of
	 * player
	 */
	private int[] lastRoundStack;

	private ClientRingDynamics dynamics;

	// Map of playerNUMBER to PlayerInfo Objects
	private Map<Integer, PlayerInfo> infomap;

	static private String classSig = "[OpponentInfoManagement]";

	/**
	 * Creates an object and inits it
	 * 
	 * @param numberofplayers
	 * @param dynamics
	 * @see init()
	 */
	public OpponentInfoManagement(int numberofplayers,
			ClientRingDynamics dynamics)
	{	
		this.dynamics = dynamics;
		this.nPlayers = numberofplayers;

		init();
	}

	/**
	 * Creates Hashmap for PlayerInfos Creates PlayerInfo objects and puts them
	 * in a Hashmap infomap Key is the id of the player
	 * 
	 */
	private void init()
	{
		infomap = new HashMap<Integer, PlayerInfo>();

		// new Stack amounts array
		this.lastRoundStack = new int[this.nPlayers];

		// Initialize stacksize
		for (int i = 0; i < lastRoundStack.length; i++) {
			lastRoundStack[i] = dynamics.stack[i];
		}
		
		// Create PlayerInfo
		for (int i = 0; i < this.nPlayers; i++) {
			int id = dynamics.seatToPlayer(i);
			System.out.println(classSig + " "
					+ "adding PlayerInfo Object for player id: " + id);
			infomap.put(id, new PlayerInfo(id));
		}
	}

	/**
	 * Returns PlayerInfo object
	 * 
	 * @param seat
	 *            The seat the player sits in, changes from round to round
	 * @return
	 */
	public PlayerInfo getPlayerInfoBySeat(int seat) {
		int id = dynamics.seatToPlayer(seat);
		return infomap.get(id);
	}

	/**
	 * Returns PlayerInfo object
	 * 
	 * @param id
	 *            The id of the player, does NOT change
	 * @return
	 */
	public PlayerInfo getPlayerInfoById(int id) {
		// Does NOT contain PlayerInfo for id
		if (infomap.containsKey(id) == false) {
			infomap.put(id, new PlayerInfo(id));
		}

		// return PlayerInfo for Player id
		return infomap.get(id);
	}
	
	/**
	 * This function is called, whenever a round is finished, that means a
	 * showdown occured or everyone folded
	 * 
	 */
	public void updateAfterRound()
	{
		if (dynamics.isShowdown() || dynamics.handOver)
		{
			System.out.println(classSig + " " + "end of hand #" 
									+ dynamics.handNumber 
									+ " occured, updating player stacks");
			
			for (int i = 0; i < nPlayers; i++) 
			{
				int seat = dynamics.playerToSeat(i);
//				System.out.println(classSig + " " +"Updating player " + 
//						dynamics.botNames[i] + " in seat: " + seat);
				PlayerInfo pi = infomap.get(i);
				pi.updateFromWinAmount(dynamics.amountWon[seat]);
			}
		}	
	}
}
