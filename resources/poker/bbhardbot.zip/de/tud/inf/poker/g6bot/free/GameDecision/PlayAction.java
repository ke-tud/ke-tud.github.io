package de.tud.inf.poker.g6bot.free.GameDecision;

import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

/**
 * PlayAction 5-tupel to be used in
 * 
 * @author ben
 * 
 */
public class PlayAction {
	
	public String category;
	private static final String classSig = "[PlayAction]";
	private float call;
	private float check;
	private float coldcall;
	private float fold;

	private float raise;

	public PlayAction() {
		this.fold = 0.2f;
		this.check = 0.2f;
		this.call = 0.2f;
		this.coldcall = 0.2f;
		this.raise = 0.2f;
	}

	/**
	 * Constructor to create a PreflopActionObject
	 * 
	 * @param fold
	 * @param check
	 * @param call
	 * @param coldcall
	 * @param raise
	 */
	public PlayAction(float fold, float check, float call, float coldcall,
			float raise) {
		super();
		this.fold = fold;
		this.check = check;
		this.call = call;
		this.coldcall = coldcall;
		this.raise = raise;
	}

	public float getCallLevel() {
		return call + getCheckLevel();
	}

	public float getCheckLevel() {
		return check + fold;
	}

	public float getColdcallLevel() {
		return coldcall + getCallLevel();
	}

	public float getFoldLevel() {
		return fold;
	}

	public float getRaiseLevel() {
		return raise + getColdcallLevel();
	}

	/**
	 * Normalizes values to sum to one (closely to one)
	 */
	public void normalizeTupel() {
		float sum = this.fold + this.call + this.check + this.coldcall
				+ this.raise;
		this.fold /= sum;
		this.call /= sum;
		this.check /= sum;
		this.coldcall /= sum;
		this.raise /= sum;
	}

	public void setCall(float call) {
		this.call = call;
		if (this.call < 0.0f) {
			this.call = 0.0f;
		}
		normalizeTupel();
	}

	public void setCheck(float check) {
		this.check = check;
		if (this.check < 0.0f) {
			this.check = 0.0f;
		}
		normalizeTupel();
	}

	public void setColdcall(float coldcall) {
		this.coldcall = coldcall;
		if (this.coldcall < 0.0f)
			this.coldcall = 0.0f;
		normalizeTupel();
	}

	public void setFold(float fold) {	
		this.fold = fold;
		if (this.fold < 0.0f)
		{
			this.fold= 0.0f;
		}
		normalizeTupel();
	}

	public void setRaise(float raise) {
		this.raise = raise;
		if (this.raise < 0.0f) {
			this.raise = 0.0f;
		}
		normalizeTupel();
	}

	/**
	 * Prints out the values in a nicer way
	 */
	public String toString() {
		return "|-" + this.fold + "-|-" + this.check + "-|-" + this.call
				+ "-|-" + this.coldcall + "-|-" + this.raise + "-|";
	}

	/**
	 * Carried out after win or loss
	 * 
	 * @param decision
	 * @param result =
	 *            Gewinn oder Verlust
	 * 
	 * 
	 */
	public void update(Decision decision, int result) {
		// System.out.println(PlayAction.classSig + " doing update...");
		// if (decision == null)System.out.println(classSig + " decision == null!!!!! ");
		
		if (result > 0) {
			
			setFold(this.fold - 0.1f);			
			
			if (decision.equals(Decision.coldcall)) 
			{
				setCall(this.call + 0.05f);
				setColdcall(this.coldcall + 0.05f);	
			} 
			else if (decision.equals(Decision.call))
			{
				setCall(this.call + 0.05f);	
				setCheck(this.check + 0.05f);
			} 
			else if (decision.equals(Decision.check))
			{
				setCheck(this.check + 0.1f);
				
			} 
			else if (decision.equals(Decision.raise))
			{
				setRaise(this.raise + 0.1f);
			}

			/*
			 * win: action values after update
			 */
			this.normalizeTupel();
			// System.out.println("Update after WIN for category: " + this.category);
			System.out.println(this.toString());
		}

		// verloren
		else {
			if (decision.equals(Decision.coldcall))
			{
				setCheck(this.check + 0.05f);
				setCall(this.call  + 0.05f);
				setFold(this.fold + 0.05f);
				setColdcall(this.coldcall - 0.10f);
				setRaise(this.raise - 0.05f);
			} 
			else if (decision.equals(Decision.call)) 
			{
				setCheck(this.check + 0.05f);
				setFold(this.fold + 0.05f);
				setCall(this.call - 0.1f);			
			}
			else if (decision.equals(Decision.check)) 
			{
				setFold(this.fold + 0.1f);
				setCheck(this.check - 0.1f);			
			}
			else if (decision.equals(Decision.raise)) 
			{
				setCheck(this.check + 0.05f);
				setCall(this.call  + 0.05f);
				setFold(this.fold + 0.05f);
				setColdcall(this.coldcall - 0.05f);
				setRaise(this.raise - 0.1f);				
			}

			/*
			 * loose: action values after update
			 */
			this.normalizeTupel();
			// System.out.println("Update after LOSS for category: " + this.category);
			System.out.println(this.toString());

		}
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
}
