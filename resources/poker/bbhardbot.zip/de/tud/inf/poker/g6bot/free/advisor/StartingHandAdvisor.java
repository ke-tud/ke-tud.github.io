package de.tud.inf.poker.g6bot.free.advisor;


public class StartingHandAdvisor {
	
	public enum PreflopAction{
		fold,call,raise
	} 

	static void init()
	{
		// Soll starting Hand Tabelle aufbauen oder lernen
	}
	
//	public static PreflopAction getAction( Card[] cards)
//	{
//		
//		//return PreflopAction.fold;
//		
//		
//	}
	
	

}
