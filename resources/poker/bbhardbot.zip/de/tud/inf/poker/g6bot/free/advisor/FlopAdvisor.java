package de.tud.inf.poker.g6bot.free.advisor;

import java.util.HashMap;

import de.tud.inf.poker.g6bot.free.ClientRingDynamics;
import de.tud.inf.poker.g6bot.free.GameDecision.Decider;
import de.tud.inf.poker.g6bot.free.GameDecision.DecisionLevel;
import de.tud.inf.poker.g6bot.free.GameDecision.PlayAction;
import de.tud.inf.poker.g6bot.free.GameDecision.StateOfGame.GameState;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;
import de.tud.inf.poker.g6bot.free.advisor.StartingHands.Category;
import de.tud.inf.poker.g6bot.free.evaluator.HandStrengthEvaluator;
import de.tud.inf.poker.g6bot.free.evaluator.IncorrectBoardException;

public class FlopAdvisor extends AbstractAdvisor {

	
	private PlayAction statePlayAction;
	private Decider stateDecider;

	private Decision lastDecision;
	
	private final GameState actualState = GameState.Flop;
	
	private static String classSig = "[FlopAdvisor]";

	private float strength;
	private float potential;

	// Table with Information about the hands
	private HashMap<StartingHands.Category, PlayAction> flopActiontable;

	public FlopAdvisor(ClientRingDynamics dynamics) {
		this.dynamics = dynamics;
		classSig = "[FlopAdvisor]";
		this.stateDecider = new Decider();
		statePlayAction = new PlayAction(0.2f,0.25f,0.25f, 0.2f,0.1f);
		initActiontable();
	}

	/**
	 * Sets the parameters strength and potential for the later calculation of
	 * gamma
	 * 
	 * @param strength
	 * @param potential
	 */
	public void setParameters(float strength, float potential) {
		this.strength = strength;
		this.potential = potential;
	}

	/**
	 * Inits the actiontable
	 */
	private void initActiontable() {
		this.flopActiontable = new HashMap<Category, PlayAction>();

	}

	@Override
	public Decision getDecision() {

		DecisionLevel level = DecisionLevel.getInstance();

		float gamma_state = level.getGamma(this.actualState, this.strength,
				this.potential);

		this.lastDecision = this.stateDecider.getDecision(this.statePlayAction,
				gamma_state);
		
		System.out.println(classSig + " making Flop-Decision ..." + this.lastDecision);
		System.out.println(classSig + " Strength: " + this.strength + " Potential: "
				+ this.potential);
				
		return this.lastDecision;
	}

	/**
	 * Updates the PlayAction for flop with the last made
	 * decision and the result 
	 */
	@Override
	public void update(int result) {
		if(this.statePlayAction != null && this.lastDecision != null)
		{
			this.statePlayAction.update(this.lastDecision, result);
		}
	}
}
