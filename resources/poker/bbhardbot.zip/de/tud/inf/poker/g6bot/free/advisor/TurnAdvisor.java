package de.tud.inf.poker.g6bot.free.advisor;

import de.tud.inf.poker.g6bot.free.ClientRingDynamics;
import de.tud.inf.poker.g6bot.free.GameDecision.Decider;
import de.tud.inf.poker.g6bot.free.GameDecision.DecisionLevel;
import de.tud.inf.poker.g6bot.free.GameDecision.PlayAction;
import de.tud.inf.poker.g6bot.free.GameDecision.StateOfGame.GameState;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

/**
 * Advisor for Turn
 * @author ben
 *
 */
public class TurnAdvisor extends AbstractAdvisor{

	private static final String classSig = "[TurnAdvisor]";
	private PlayAction statePlayAction;
	
	
	private Decider stateDecider;
	
	private Decision lastDecision;
	
	private float strength;
	private float potential;
	
	private GameState actualState = GameState.Turn;
	
	
	public TurnAdvisor(ClientRingDynamics dynamics) {
		this.dynamics = dynamics;		
		this.stateDecider = new Decider();
		this.statePlayAction = new PlayAction(0.1f, 0.2f, 0.25f, 0.25f, 0.2f);
		this.statePlayAction.category += "Turn";
	}

	/**
	 * Sets the parameters strength and potential for the later
	 * calculation of gamma
	 * 
	 * @param strength
	 * @param potential
	 */
	public void setParameters(float strength, float potential) {
		this.strength = strength;
		this.potential = potential;
	}
	
	/**
	 * Get the gamma-decision-level for the gamestate, state-strength and
	 * state-potential
	 * Get the decision from the decider for the given playaction and
	 * the previously calculated gamma
	 * Save the made decision as last decision
	 */
	@Override
	public Decision getDecision() {
		
		System.out.println(classSig + " getDecision");
		DecisionLevel level = DecisionLevel.getInstance();
		
		float gamma_state = level.getGamma(this.actualState, this.strength, this.potential);
		
		this.lastDecision = this.stateDecider.getDecision(this.statePlayAction, gamma_state);
				
		return this.lastDecision;
		
	}
	
	/**
	 * Updates the PlayAction for turn with the last made
	 * decision and the result after showndown
	 */
	@Override
	public void update(int result) {
		if(this.statePlayAction != null && this.lastDecision != null)
		{
			this.statePlayAction.update(this.lastDecision, result);
		}
	}
	
}