package de.tud.inf.poker.g6bot.free.advisor;

import java.util.Random;

import de.tud.inf.poker.g6bot.free.ClientRingDynamics;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

public abstract class AbstractAdvisor {
	ClientRingDynamics dynamics;
	
	static protected String classSig = "[]";
	
	public abstract Decision getDecision();

	/**
	 * Update the actiontable
	 *
	 */
	public abstract void update(int result) ;

	
	/**
	 * Returns a randomized decision 
	 * @param a
	 * @param b
	 * @return
	 */
	public static Decision getRandomizedDecision(float a, float b)
	{
		if (a > b)
		{
			// TODO Exception? Switch Parameters?
			System.err.println(classSig + " " + "wrong parameter order");
		}
		
		Decision d;
		// If borders are switched
		if (a>b) {d = Decision.fold;} 
		
		Random r = new Random();
		float dart = r.nextFloat();
		if (dart < a) {
			d = Decision.fold;			
		}
		if (dart <= b){
			d = Decision.call;
		}
		else 
		{
			d = Decision.raise;
		}
		return d;			
	}
}
