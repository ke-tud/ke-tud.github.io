package de.tud.inf.poker.g6bot.free.simulation;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.CardSet;

public class Simulator {
	
	
	static String classSig = "[Simulator]";
	
	public Simulator() {
	
	}

	
	
	private void removeCards(CardSet allcards, CardSet cardsToRemove)
	{		
		for (Card card : cardsToRemove) 
		{
			allcards.remove(card);
		}
		
	}
}
