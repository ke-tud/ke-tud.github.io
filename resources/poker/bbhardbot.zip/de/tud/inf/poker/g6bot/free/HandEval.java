package de.tud.inf.poker.g6bot.free;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class HandEval {
	public enum Hand {
		OnePair, TwoPair, ThreeOfKind, 
		Straight, Flush, FullHouse,
		FourOfKind, StraightFlush, RoyalFlush
	}

	public static Hand getBestHand(Card[] hand, Card[] board) {
		return Hand.OnePair;
	}
}
