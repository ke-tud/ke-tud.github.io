package de.tud.inf.poker.g6bot.free.evaluator;

import java.util.ArrayList;
import java.util.List;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.CardSet;
import com.stevebrecher.poker.HandEval;

import de.tud.inf.poker.g6bot.free.simulation.HandPotential;

/**
 * Returns the handstrength Percentage of hands won against enumerated opponent
 * cards (47*46)
 * 
 * @link http://www.cs.ualberta.ca/~jonathan/Grad/papp/node40.html
 * @author ben
 * @see com.stevebrecher.poker.HandEval
 */
public class HandStrengthEvaluator {

	List<Card> holeCards;
	List<Card> boardCards;

	/**
	 * The Handstrength after Flop
	 */
	public float flopHandstrength;
	
	/**
	 * The Handstrength after Turn
	 */
	public float turnHandstrength;
	
	/**
	 * The Handstrength after River
	 */
	public float riverHandstrength;

	private HandPotential potential;
	
	static private String classSig = "[HandStrengthEvaluator]";

	/**
	 * HandStrengthEvaluator - no board cards given 
	 * 
	 * 
	 * @param holecards
	 */
	public HandStrengthEvaluator(
			ca.ualberta.cs.poker.free.dynamics.Card[] holecards) {
		this.holeCards = convertCards(holecards);
		this.flopHandstrength = -1f;
		this.turnHandstrength = -1f;
		this.riverHandstrength = -1f;

	}

	/**
	 * Constructor
	 * 
	 * @param holecards
	 *            the hole cards
	 * @param board
	 *            the 3 flop cards
	 */
	public HandStrengthEvaluator(
			ca.ualberta.cs.poker.free.dynamics.Card[] holecards,
			ca.ualberta.cs.poker.free.dynamics.Card[] board) {
		this(holecards);
		this.boardCards = convertCards(board);
	}

	/**
	 * Adds a turn or river card to the board cards
	 * Conversion to stevebrechers format is performed
	 * @param turnOrRiver
	 *            Turn or River Card from Pokerserver Package
	 */
	public void addCard(ca.ualberta.cs.poker.free.dynamics.Card turnOrRiver) {
		this.boardCards.add(new Card(turnOrRiver.toString()));
	}

	/**
	 * Sets board cards
	 * Conversion to stevebrechers format is performed
	 * @param cards
	 */
	public void setBoardCards(ca.ualberta.cs.poker.free.dynamics.Card[] cards) {
		this.boardCards = convertCards(cards);
	}

	/**
	 * Converts Card from alberta type to com.stevebrecher type For use with
	 * evaluator this is necessary
	 * 
	 * @param cards
	 * @return
	 */
	private static List<Card> convertCards(
			ca.ualberta.cs.poker.free.dynamics.Card[] cards) {
		List<Card> convertedList = new ArrayList<Card>();
		for (int i = 0; i < cards.length; i++) {
			convertedList.add(new Card(cards[i].toString()));
		}
		return convertedList;
	}

	/**
	 * Calculates HandPotential like described here 
	 * http://www.cs.ualberta.ca/%7Ejonathan/Grad/papp/node40.html#FIG_HP
	 * @return
	 * @throws IncorrectBoardException
	 */
	public HandPotential getHandPotential() throws IncorrectBoardException
	{
		CardSet cardset = CardSet.freshDeck();

		// Hole und Board Karten entfernen
		for (Card card : holeCards) {
			cardset.remove(card);
		}

		// Board ist null oder weniger als 3 Karten
		if (boardCards == null || boardCards.size() < 3)
			throw new IncorrectBoardException();

		for (Card card : boardCards) {
			cardset.remove(card);
		}

		// System.out.println(cardset.size());

		// Encoding of Cards of our Hero
		long hero = HandEval.encode(holeCards.get(0))
				| HandEval.encode(holeCards.get(1));
		long flop = encodeFlop();

		float[][] HP = new float[ 3 ][ 3 ];
		float[] HPtotal = new float[ 3 ];
		float ppot2= .0f ;
		float npot2 = 0.f;
		
		int index;
		int ourrank5, ourrank7, oprank;
		
		long board = encodeFlop();
		
		long opponent1;
		long opponent2;
		
		ourrank5 = HandEval.hand5Eval(hero | board);
		
		
		long my7cards;
		long opp7cards;
		int counter = 0;
		// Opponentcards
		for (Card opp1 : cardset)
		{			
			opponent1 = HandEval.encode(opp1);
	
			// Opponentcards
			for (Card opp2 : cardset)
			{
				if (opp1.equals(opp2)) continue;
				
				opponent2 =  opponent1 | HandEval.encode(opp2);
				
				oprank = HandEval.hand5Eval(opponent2 | board);
				
				if (ourrank5>oprank) index = 2;	 // front
				else if (ourrank5==oprank) index = 1; // tied
				else index = 0;	// behind
				
				HPtotal[index] ++;
					
				for (Card turn : cardset)
				{					
					
					for (Card river : cardset)
					{
						counter++;
						long t = board;
						
						t = board | HandEval.encode(turn) | HandEval.encode(river);
						my7cards = t | hero;
						opp7cards = t | opponent2;
						
						
						
						ourrank7 = HandEval.hand7Eval(my7cards);
						oprank = HandEval.hand7Eval(opp7cards);
						if (ourrank7> oprank)
						{
							HP[index][2] ++;
						}
						else if (oprank == ourrank7)
						{
							HP[index][1] ++;							
						}
						else
						{
							HP[index][0] ++;
						}
						
					}	
						
				}// finishes iteration
				ppot2 = ( HP[0][2] + HP[0][1]/2 + HP[1][2]/2 ) / 
						( HPtotal[0] + HPtotal[1]/2 );
				
				npot2 = ( HP[2][0] + HP[2][1]/2 + HP[1][0]/2 ) /
						( HPtotal[2] + HPtotal[1]/2);
						
				
			}
		}
		this.potential = new HandPotential(ppot2/(ppot2+npot2),npot2/(ppot2+npot2));
		return this.potential;
	}
	
	
	

	/**
	 * Calculates handstrength
	 * 
	 * @return
	 * @throws IncorrectBoardException
	 */
	public void calculateHandStrength() throws IncorrectBoardException {
		CardSet cardset = CardSet.freshDeck();

		// Hole und Board Karten entfernen
		for (Card card : holeCards) {
			cardset.remove(card);
		}

		// Board ist null oder weniger als 3 Karten
		if (boardCards == null || boardCards.size() < 3)
			throw new IncorrectBoardException();

		for (Card card : boardCards) {
			cardset.remove(card);
		}

		// System.out.println(cardset.size());

		// Encoding of Cards of our Hero
		long hero = HandEval.encode(holeCards.get(0))
				| HandEval.encode(holeCards.get(1));
		long flop = encodeFlop();
		long flopAndTurn = flop | encodeTurn();
		long flopAndTurnAndRiver = flopAndTurn | encodeRiver();

		long player5Card = hero | flop;
		long player6Card = hero | flopAndTurn;
		long player7Card = hero | flopAndTurnAndRiver;

		int wins;
		int losses;
		int ties;
		int combinations;

		float handstrength;

		// Zero all counters
		wins = losses = ties = combinations = 0;

		// Für alle zwei Kombinationen
		for (Card card1 : cardset) {
			
			for (Card card2 : cardset) {
				// Gleiche Karte überspringen
				if (card1.equals(card2)) {
					// System.out.println(card1.toString());
					continue;
				}

				// Encode players cards
				long p2 = HandEval.encode(card1) | HandEval.encode(card2);

				long opponent5Card = p2 | flop;
				long opponent6Card = p2 | flopAndTurn;
				long opponent7Card = p2 | flopAndTurnAndRiver;

				// Evaluate for 5,6 and 7 cards, depending on:
				int playerValue = 0;
				int opponentValue = 0;
				switch (boardCards.size()) {
				case (3):
					playerValue = HandEval.hand5Eval(player5Card);
					opponentValue = HandEval.hand5Eval(opponent5Card);
					break;
				case (4):
					playerValue = HandEval.hand6Eval(player6Card);
					opponentValue = HandEval.hand6Eval(opponent6Card);
					break;
				case (5):
					playerValue = HandEval.hand7Eval(player7Card);
					opponentValue = HandEval.hand7Eval(opponent7Card);
					break;
				}
				
				// Count Wins
				if (playerValue > opponentValue) {
					wins++;
				} else if (playerValue == opponentValue) {
					ties++;
				} else {
					losses++;
				}
			}

		} // End outer loop

		// Handstaerke
		handstrength = (float) (wins + ties / 2) / (wins + ties + losses);

		// Avoid overwriting values
		switch (boardCards.size()) {
		case 3:
			if (this.flopHandstrength < 0) {
				flopHandstrength = handstrength;
			}
			break;
		case 4:
			if (this.turnHandstrength < 0) {
				this.turnHandstrength = handstrength;
			}
			break;
		case 5:
			if (this.riverHandstrength < 0) {
				this.riverHandstrength = handstrength;
			}
		default:
			break;
		}
		/*
		 * System.out.println(classSig + " " + "handstrength is "
		 *		+ flopHandstrength + " | " + turnHandstrength + " | "
		 *		+ riverHandstrength);
		 */
	}

	/**
	 * Encodes the three flopcards
	 * @return
	 */
	private long encodeFlop() {
		long encodedboard = 0;
		if (boardCards.size() < 3)
		{	
			return encodedboard;
		}
		for (int i = 0; i < 3; i++) {
			encodedboard |= HandEval.encode(boardCards.get(i));
		}
		return encodedboard;
	}

	/**
	 * Encodes the turn card
	 * @return
	 */
	private long encodeTurn() {
		long encodedboard = 0;
		if (boardCards.size() < 4)
			return encodedboard;
		encodedboard |= HandEval.encode(boardCards.get(3));

		return encodedboard;
	}

	/**
	 * Encodes the river card
	 * @return
	 */
	private long encodeRiver() {
		long encodedboard = 0;
		if (boardCards.size() < 5)
			return encodedboard;
		encodedboard |= HandEval.encode(boardCards.get(4));

		return encodedboard;
	}

	public void setBoardCards(List<Card> boardCards) {
		this.boardCards = boardCards;
	}

	private String boardCardsToString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < boardCards.size(); i++) {
			sb.append(boardCards.get(i));
		}
		return sb.toString();
	}

	private String holeCardsToString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < holeCards.size(); i++) {
			sb.append(holeCards.get(i));
		}
		return sb.toString();
	}
	
	
	/**
	 * Convenience Method
	 * @param cards
	 * @return
	 */
	public int getHandStrength(ca.ualberta.cs.poker.free.dynamics.Card[] cards)
	{
		long cardsStrength = 0;
		
		List<Card> list = convertCards(cards);
		
		
		for (Card card : list) {
			cardsStrength |= HandEval.encode(card);
		}
		return HandEval.hand7Eval(cardsStrength);
	}
	
	

}


