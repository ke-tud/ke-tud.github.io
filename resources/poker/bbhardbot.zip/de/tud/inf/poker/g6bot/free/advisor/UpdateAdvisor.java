package de.tud.inf.poker.g6bot.free.advisor;

import de.tud.inf.poker.g6bot.free.tools.outLogger;

public class UpdateAdvisor 
{
	private PreFlopAdvisor 	preflop_advisor;
	private FlopAdvisor		flop_advisor;
	private TurnAdvisor		turn_advisor;
	private RiverAdvisor		river_advisor;
	
	private int FeedBackLength;

	private int loose;
	private int loose_amount;
	private int loose_total;
	
	private int win;
	private int win_amount;
	private int win_total;
	
	private static final String classSig = "[UpdateAdvisor]";
	
	private outLogger logger;
	
	public UpdateAdvisor()
	{
		this.logger = new outLogger();
		
		this.FeedBackLength = 1;
		
		this.win = 0;
		this.win_amount = 0;
		this.win_total = 0;

		this.loose = 0;
		this.loose_amount = 0;
		this.loose_total = 0;
	}
	
	public void Update(int result)
	{
		/*
		 * game won
		 * increasing win-counter
		 */
		if(result > 0)
		{
			this.win++;
			this.win_amount += result;
			
			this.win_total += result;
		}
		
		/*
		 * game lost
		 * increasing loose-counter
		 */
		if(result < 0)
		{
			this.loose++;
			this.loose_amount += (-1) * result;
			
			this.loose_total += (-1) * result;
		}
		
		
		/*
		 * feedback-level reached
		 * doing update for the advisors
		 */
		if( (this.win + this.loose) == this.FeedBackLength)
		{
			System.out.println(UpdateAdvisor.classSig + " Feedback-level reached: " + this.FeedBackLength);
			System.out.println(UpdateAdvisor.classSig + " won-total: " + this.win_total + " lost-total: -" + this.loose_total);
			System.out.println(UpdateAdvisor.classSig + " --- this hand ---" );
			System.out.println(UpdateAdvisor.classSig + " won: " + this.win + " amount: " + this.win_amount);
			System.out.println(UpdateAdvisor.classSig + " lost: " + this.loose + " amount: " + this.loose_amount);
			
			int update_result = this.win_amount - this.loose_amount;
			
			this.preflop_advisor.update( update_result );
			
			this.flop_advisor.update( update_result );
			this.turn_advisor.update( update_result );
			this.river_advisor.update( update_result );
			
			if(this.win_amount >= this.loose_amount) {
				this.FeedBackLength++;
				
			} else {
				if(this.FeedBackLength > 1) {
					this.FeedBackLength--;
				}
			}
			
			this.win = 0;
			this.win_amount = 0;
			
			this.loose = 0;
			this.loose_amount = 0;
		}
		
	}
	
	public void initAdvisor(PlayAdvisor p_advisor) {
		this.preflop_advisor = p_advisor.getPreFlopAdvisor();
		this.flop_advisor = p_advisor.getFlopAdvisor();
		this.turn_advisor = p_advisor.getTurnAdvisor();
		this.river_advisor = p_advisor.getRiverAdvisor();
	}
}
