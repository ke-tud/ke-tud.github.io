package de.tud.inf.poker.g6bot.free.opponent;

/**
 * 
 * stucture to save hand/highcard, count of games where cards
 * were shown, gamecount where player wins his cards, betting
 * statistic at preflop in shown games, betting statistic at
 * flop in shown games, betting statistic at turn in shown games,
 * betting statistic at river in shown games
 * 
 * @author bastian
 *
 */
public class Betting {
	
	String name;
	int shown;
	int wins;
	String preflop;
	String flop;
	String turn;
	String river;
	
	public Betting(String name, int shown, int wins, String preflop, 
			String flop, String turn, String river) {
		
		this.name = name;
		this.shown = shown;
		this.wins = wins;
		this.preflop = preflop;
		this.flop = flop;
		this.turn = turn;
		this.river = river;
		
	}
	
	/*
	 * inc shown and wins
	 */
	public void win() {
		this.shown++;
		this.wins++;
	}
	
	
	public void loose() {
		
	}
}
