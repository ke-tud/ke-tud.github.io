package de.tud.inf.poker.g6bot.free.simulation;

public class HandPotential {
	
	private float ppot2;
	private float npot2;
	
	public HandPotential(float ppot2, float npot2) {
		this.ppot2 = ppot2;
		this.npot2 = npot2;
	}

	public void setPpot2(float ppot2) {
		this.ppot2 = ppot2;
	}

	public float getPpot2() {
		return ppot2;
	}

	public float getNpot2() {
		return npot2;
	}

	public void setNpot2(float npot2) {
		this.npot2 = npot2;
	}
	
	public String toString()
	{
		return "[" + ppot2 + " " + npot2+"]";
	}

}
