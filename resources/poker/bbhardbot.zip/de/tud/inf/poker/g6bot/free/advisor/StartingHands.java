package de.tud.inf.poker.g6bot.free.advisor;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;

public class StartingHands {

	public static enum Category {
		MonsterHand 			(	0.95f	,	0.5f	), 
		BigPair 				(	0.7f	, 	0.5f	), 
		MediumPair 				(	0.4f	,	0.4f	), 
		SmallPair 				(	0.2f	,	0.3f	),
		BigSuitedBroadways 		(	0.5f	,	0.6f	), 
		LittleSuitedBroadways	(	0.5f	,	0.4f	), 
		SuitedAces 				(	0.5f	, 	0.6f	), 
		SuitedKings				(	0.45f	,	0.3f	), 
		SuitedConnectors		(	0.4f	,	0.2f	), 
		JunkSuitedHands			(	0.1f	,	0.05f	), 
		BigOffsuitBroadway		(	0.3f	,	0.3f	), 
		LittleOffsuitBroadway	(	0.2f	,	0.3f	), 
		JunkOffsuitHands		(	0.1f	,	0.01f	);
		
		private final float strength;
		private final float potential;
		
		public float strength()   { return strength; }
	    public float potential() { return potential; }
	    
	    Category(float strength,float potential) {
	    	this.strength=strength;
	    	this.potential=potential;	    	
		}

	    /**
	     * Returns the Category for two given hole cards
	     * 
	     * @param hole
	     * @return
	     */
		public static Category getStartingHandCategory(Card[] hole) {
			Card c1 = hole[0];
			Card c2 = hole[1];

			/*
			 * MonsterHand
			 */
			if (c1.rank == Rank.ACE && c2.rank == Rank.ACE)
				return MonsterHand;

			if (c1.rank == Rank.KING && c2.rank == Rank.KING)
				return MonsterHand;

			/*
			 * Big Pairs
			 */
			if (c1.rank == Rank.QUEEN && c2.rank == Rank.QUEEN)
				return BigPair;

			if (c1.rank == Rank.JACK && c2.rank == Rank.JACK)
				return BigPair;

			if (c1.rank == Rank.TEN && c2.rank == Rank.TEN)
				return BigPair;

			/*
			 * Medium Pairs
			 */
			if (c1.rank == Rank.NINE && c2.rank == Rank.NINE)
				return MediumPair;

			if (c1.rank == Rank.EIGHT && c2.rank == Rank.EIGHT)
				return MediumPair;

			if (c1.rank == Rank.SEVEN && c2.rank == Rank.SEVEN)
				return MediumPair;

			/*
			 * Small Pairs
			 */
			if (c1.rank == Rank.SIX && c2.rank == Rank.SIX)
				return SmallPair;

			if (c1.rank == Rank.FIVE && c2.rank == Rank.FIVE)
				return SmallPair;

			if (c1.rank == Rank.FOUR && c2.rank == Rank.FOUR)
				return SmallPair;

			if (c1.rank == Rank.THREE && c2.rank == Rank.THREE)
				return SmallPair;

			if (c1.rank == Rank.TWO && c2.rank == Rank.TWO)
				return SmallPair;

			/*
			 * Suited Cards
			 */
			if (c1.suit == c2.suit) {

				/*
				 * Big Suited Broadways
				 */
				if ((c1.rank == Rank.ACE && c2.rank == Rank.KING)
						|| (c1.rank == Rank.ACE && c2.rank == Rank.KING))
					return BigSuitedBroadways;

				if ((c1.rank == Rank.ACE && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.QUEEN && c2.rank == Rank.ACE))
					return BigSuitedBroadways;

				if ((c1.rank == Rank.ACE && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.ACE))
					return BigSuitedBroadways;

				if ((c1.rank == Rank.ACE && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.ACE && c2.rank == Rank.TEN))
					return BigSuitedBroadways;

				if ((c1.rank == Rank.KING && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.QUEEN && c2.rank == Rank.KING))
					return BigSuitedBroadways;

				if ((c1.rank == Rank.KING && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.KING))
					return BigSuitedBroadways;

				/*
				 * Little Suited Broadways
				 */

				if ((c1.rank == Rank.QUEEN && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.QUEEN))
					return LittleSuitedBroadways;

				if ((c1.rank == Rank.KING && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.KING))
					return LittleSuitedBroadways;

				if ((c1.rank == Rank.QUEEN && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.QUEEN))
					return LittleSuitedBroadways;

				if ((c1.rank == Rank.JACK && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.JACK))
					return LittleSuitedBroadways;

				/*
				 * Suited Aces
				 */
				if ((c1.rank == Rank.ACE || c2.rank == Rank.ACE))
					return SuitedAces;

				/*
				 * Suited Kings
				 */
				if ((c1.rank == Rank.KING || c2.rank == Rank.KING))
					return SuitedKings;

				// Differenz
				int difference = c1.rank.compareTo(c2.rank);
				difference = Math.abs(difference);

				switch (difference) {

				case 1:
					if ((c1.rank.compareTo(Rank.THREE) < 0)
							|| (c1.rank.compareTo(Rank.THREE) < 0))
						return SuitedConnectors;
					else
						return JunkSuitedHands;

				case 2:
					if ((c1.rank.compareTo(Rank.FOUR) < 0)
							|| (c1.rank.compareTo(Rank.FOUR) < 0))
						return SuitedConnectors;
					else
						return JunkSuitedHands;

				case 3:
					if ((c1.rank.compareTo(Rank.SIX) < 0)
							|| (c1.rank.compareTo(Rank.SIX) < 0))
						return SuitedConnectors;
					else
						return JunkSuitedHands;
				case 4:

					if ((c1.rank == Rank.QUEEN && c2.rank == Rank.EIGHT)
							|| (c1.rank == Rank.EIGHT && c2.rank == Rank.QUEEN)
							|| (c1.rank == Rank.SEVEN && c2.rank == Rank.JACK)
							|| (c1.rank == Rank.JACK && c2.rank == Rank.SEVEN))
						return SuitedConnectors;
					else
						return JunkSuitedHands;

				default:
					return JunkSuitedHands;

				}

			}

			/*
			 * Offsuit
			 */
			else {

				/*
				 * Big Offsuit Broadway
				 */
				if ((c1.rank == Rank.ACE && c2.rank == Rank.KING)
						|| (c1.rank == Rank.KING && c2.rank == Rank.ACE)
						|| (c1.rank == Rank.ACE && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.QUEEN && c2.rank == Rank.ACE)
						|| (c1.rank == Rank.ACE && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.ACE)
						|| (c1.rank == Rank.KING && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.QUEEN && c2.rank == Rank.KING)) {
					return BigOffsuitBroadway;

				}

				/*
				 * Little Offsuit Broadway
				 */
				if ((c1.rank == Rank.QUEEN && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.ACE && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.ACE)
						|| (c1.rank == Rank.KING && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.KING)
						|| (c1.rank == Rank.QUEEN && c2.rank == Rank.JACK)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.KING && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.KING)
						|| (c1.rank == Rank.QUEEN && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.QUEEN)
						|| (c1.rank == Rank.JACK && c2.rank == Rank.TEN)
						|| (c1.rank == Rank.TEN && c2.rank == Rank.JACK)) {
					return LittleOffsuitBroadway;
				}

				// Die restlichen Hände, unsuited
				return JunkOffsuitHands;

			}

		}
	}

	public static Category getCategory(Card[] cards) {
		return Category.getStartingHandCategory(cards);
	}

}
