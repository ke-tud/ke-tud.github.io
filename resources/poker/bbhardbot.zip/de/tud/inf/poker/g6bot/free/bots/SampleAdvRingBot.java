package de.tud.inf.poker.g6bot.free.bots;

import java.net.InetAddress;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.LimitType;
import ca.ualberta.cs.poker.free.dynamics.MatchType;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import de.tud.inf.poker.g6bot.free.AdvancedRingClient;

/**
 * Einfacher Bot zur Demonstration der AdvancedRingClient-Klasse.
 * Der Bot zeigt folgendes Verhalten:
 * Wenn mindestens ein Ass oder zwei gleiche Karten auf der Hand, wird der Bot raisen.
 * Sobald ein Mitspieler raist, wird der Bot feige und callt nur noch.
 * @author Stefan Lück
 */
public class SampleAdvRingBot extends AdvancedRingClient
{
	boolean raiseThisRound;
	boolean otherRaiseSeenThisRound;
	
	public SampleAdvRingBot (int numPlayers, MatchType matchtype)
	{
		super(numPlayers, matchtype);
	}
	
	/**
	 * @param args
	 */
	public static void main (String[] args) throws Exception
	{
		MatchType mt = new MatchType(LimitType.LIMIT, false, 8000, 1000); 
		SampleAdvRingBot myBot = new SampleAdvRingBot(6, mt);

      System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");
      myBot.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
      System.out.println("Successful connection!");

		myBot.run();
	}

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#actionPerformed(char, int, boolean, boolean)
    */
   @Override
   public void actionPerformed (char lastAction, int lastSeat,
                                boolean handOver, boolean showdown)
   {
      System.out.println("Action '"+ lastAction +"' received by seat " + lastSeat + "!");
      if (dynamics.firstActionOnRound) System.out.println("New betting round has started...");
      if (handOver) System.out.println("This hand is over...");
   	if (lastAction == 'r' && lastSeat != dynamics.getMySeat())
   		otherRaiseSeenThisRound = true;
   }

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#newHandStarted(ca.ualberta.cs.poker.free.dynamics.Card[])
    */
   @Override
   public void newHandStarted (Card[] clientCards)
   {
      System.out.println("Hand was started! I'm in seat " + dynamics.currentSeat + " and got: " + Card.arrayToString(clientCards));
  	
   	// decide what to do here
   	raiseThisRound = 
   		clientCards[0].rank == Rank.ACE ||
   		clientCards[1].rank == Rank.ACE ||
   		clientCards[0].rank == clientCards[1].rank;
   	otherRaiseSeenThisRound = false;
   }

	/* (non-Javadoc)
    * @see de.tud.inf.poker.g7bot.free.AdvancedRingClient#takeAction(boolean, int, int, long)
    */
   @Override
   public void takeAction (boolean raiseAllowed, int totalPotSize,
                           int amountToCall, long timeRemaining)
   {
      System.out.println("Supposed to take action...");
   	try{
   	if (raiseAllowed && raiseThisRound && !otherRaiseSeenThisRound)
   		this.sendRaise();
   	else	
   		this.sendCall();
   	}
   	catch (Exception ex) { /* no recovery here... */ }
   	
   }
	
}
