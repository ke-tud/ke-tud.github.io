The Java version of Hold 'Em Showdown can be run on any system which has a Java
Runtime Environment (JRE), version 5 (a.k.a 1.5) or later.  See, e.g.,
http://www.java.com/en/download/index.jsp

HoldEmShowdown.jar contains the .class files required by a Java system (JRE) to
run Hold 'Em Showdown.  It also contains the source (.java) files and, for the
classes that might conceivably be useful in other poker projects -- the ones in
the .poker package -- the HTML programming documentation in javadoc format.

RunHoldEmShowdown.bat is a Windows batch (command) file that can be opened
(double-clicked) to run Hold 'Em Showdown on a Windows system.  Here is
its contents:
@rem   The Sun JRE Windows installation associates the .jar
@rem   file type with javaw, which doesn't display a console
@rem   window.  Hold 'Em Showdown requires a console window
@rem   unless its input is redirected to a file.  Thus this
@rem   .bat file is provided to start java rather than javaw.
@
@java -jar HoldemShowdown.jar

The Hold 'Em Showdown program accepts several OPTIONAL program command
arguments, as follows:

Argument keyword:  output
Followed by value:  yes;  the name or file system path of the text file to
   which output will be written (in addition to console)
Usage:  output path_to_file
Default value:  Showdown.txt

Argument keyword:  threads
Followed by value:  yes; the number of enumeration threads among which
   the calculation work will be divided.
Usage:  threads number_of_threads
Default value:  Runtime.getRuntime().availableProcessors()

Argument keyword:  timed
Followed by value:  no
Usage:  timed
Default value:  false
Provide this argument to include the elapsed time for each enumeration
(showdown calculation) in the output.

Argument keyword:  repeat
Followed by value:  no
Usage:  repeat
Default value:  false
Provide this argument to repeat processing of the first user-specified showdown
scenario until the program is externally terminated.  --Useful to exercise the
JVM/JIT compiler on the enumeration code path for a specific user input before
observing the computation time.  Normally the "timed" argument would also be
provided.
