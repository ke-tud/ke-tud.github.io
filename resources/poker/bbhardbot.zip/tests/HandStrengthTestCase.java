package tests;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;
import de.tud.inf.poker.g6bot.free.evaluator.HandStrengthEvaluator;
import junit.framework.TestCase;

public class HandStrengthTestCase extends TestCase {

	Card c1;
	Card c2;
	Card b1;
	Card b2;
	Card b3;
	
	
	Card[] c;
	Card[] b;
	
	
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		c1 = new Card(Rank.KING,Suit.SPADES);
		c2 = new Card(Rank.QUEEN,Suit.HEARTS);
		
		b1 = new Card(Rank.KING,Suit.CLUBS);
		b2 = new Card(Rank.QUEEN,Suit.SPADES);
		b3 = new Card(Rank.QUEEN,Suit.DIAMONDS);
		
		c = new Card[]{c1,c2};
		b = new Card[]{b1,b2,b3};		
	}

	/**
	 * Constructortest
	 * @throws Exception
	 */
	public void testConstructor() throws Exception {
		
		HandStrengthEvaluator hse = new HandStrengthEvaluator(c,b);		
		assertNotNull(hse);				
	}
	
	public void testGetStrength() throws Exception {
		
		HandStrengthEvaluator hse = new HandStrengthEvaluator(c,b);		
					
	}
	
}
