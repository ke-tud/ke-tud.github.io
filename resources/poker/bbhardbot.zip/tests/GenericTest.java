package tests;

import junit.framework.TestCase;

public class GenericTest extends TestCase {

}
