package tests;

import com.stevebrecher.poker.Card;

import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor;
import de.tud.inf.poker.g6bot.free.advisor.PlayAdvisor.Decision;

import junit.framework.TestCase;

public class EvalTest extends TestCase {
	
	public void testCardConversion() throws Exception {
		Card hole1 = new Card("Ah");
		Card hole2 = new Card("Kh");
		Card board1 = new Card("Ac");
		Card board2 = new Card("6d");
		Card board3 = new Card("3s");
	}
	
	
	public void testDecisionMaker()	
	{
		Decision d = PlayAdvisor.getRandomizedDecision(0.05f,0.5f);
		System.out.println(d);
	}

}
