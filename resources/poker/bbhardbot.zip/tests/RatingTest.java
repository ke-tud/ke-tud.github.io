package tests;

import java.util.Iterator;

import junit.framework.TestCase;

import com.stevebrecher.poker.Card;
import com.stevebrecher.poker.CardSet;
import com.stevebrecher.poker.HandEval;
import com.stevebrecher.poker.Card.Rank;
import com.stevebrecher.poker.Card.Suit;


/**
 * Some tests
 * @author ben
 *
 */
public class RatingTest extends TestCase {
	
	public void testRating() throws Exception {
		
		// Player1
		Card c1 = new Card(Rank.ACE,Suit.HEART);
		Card c2 = new Card(Rank.ACE,Suit.SPADE);
		
		// Player2
		Card c3 = new Card(Rank.JACK,Suit.HEART);
		Card c4 = new Card(Rank.JACK,Suit.DIAMOND);
		
		// BoardCards
		Card board1 = new Card(Rank.TEN,Suit.SPADE);
		Card board2 = new Card(Rank.ACE,Suit.CLUB);
		Card board3 = new Card(Rank.THREE,Suit.CLUB);
		
		
		long p1 = HandEval.encode(c1) | HandEval.encode(c2);
		long p2 = HandEval.encode(c3) | HandEval.encode(c4);
		long board = HandEval.encode(board1) | HandEval.encode(board2) | HandEval.encode(board3);
		
		int p1value = HandEval.hand5Eval(p1 | board);
		int p2value = HandEval.hand5Eval(p2 | board);
		
		
		System.out.println(p1value);
		System.out.println(p2value);
		
		assertEquals(true, true);
		
	}
	
	
	public void testSimulation() throws Exception
	{
		
		long t1 = System.nanoTime();
		
		
//		 Player1
		Card c1 = new Card(Rank.KING,Suit.HEART);
		Card c2 = new Card(Rank.ACE,Suit.SPADE);
		
		CardSet cardset = CardSet.freshDeck();
		
		System.out.println(cardset.size());
		
		removeCards(cardset, c1, c2);
		
//		cardset.remove(c1);
//		cardset.remove(c2);
		
		// System.out.println(cardset.size());
			
		cardset.shuffle();
		
		//System.out.println(cardset.iterator().next().toString());
		
		assertEquals(50, cardset.size());
		
		
		int wins = 0;
		int losses = 0;
		int ties = 0;
		
		final int RUNS = 1000;
		
		// Opponent
		Card o1;
		Card o2;
		
		// Board
		Card b1;
		Card b2;
		Card b3;
		Card b4;
		Card b5;
		
		/*
		 * RUNS Versuche
		 */
		for (int i = 0 ; i < RUNS; i++)
		{
			// Neue Karten
			cardset = CardSet.freshDeck();
			
			// Karten entfernen
			removeCards(cardset, c1, c2);			
			// Mischen!!!
			cardset.shuffle();
			
//			System.out.println("Hero Cards: " + c1.toString() + " " + c2.toString());
			
			// Karten austeilen
			Iterator it = cardset.iterator();
			o1 = (Card) it.next();
			o2 = (Card) it.next();
			
			
//			System.out.println("Opponentcards: " + o1.toString() + " " + o2.toString());
			
			// Boardkarten
			b1 = (Card) it.next();
			b2 = (Card) it.next();
			b3 = (Card) it.next();
			b4 = (Card) it.next();
			b5 = (Card) it.next();
			
//			System.out.println("Boardcards: " + b1.toString() + " " + b2.toString() + " " + b3.toString() + " "+b4.toString() + " "+b5.toString() );
			
			// Werte encodieren für Evaluator
			long p1 = HandEval.encode(c1) | HandEval.encode(c2);
			long p2 = HandEval.encode(o1) | HandEval.encode(o2);
			long board = HandEval.encode(b1) | HandEval.encode(b2) | HandEval.encode(b3);
			
			// PostFlop
			int p1value = HandEval.hand5Eval(p1 | board);
			int p2value = HandEval.hand5Eval(p2 | board);
//			System.out.println("After Flop | p1: " + p1value + " ps: " + p2value);
			
			// Turn and River
			board = board | HandEval.encode(b4) | HandEval.encode(b5);
			
			p1value = HandEval.hand7Eval(p1 | board);
			p2value = HandEval.hand7Eval(p2 | board);
			
//			System.out.println("After River | p1: " + p1value + " ps: " + p2value);
			
			// Wer gewinnt?
			if (p1value > p2value)
			{
				wins++;
			}
			else if (p1value==p2value) 
			{
				ties++;				
			}
			else
			{
				losses++;
			}
			
		
		}
		
		long t2 = System.nanoTime();
		
		long dt = t2-t1;
		
		
		
		System.out.println("von " + RUNS + " spielen:");
		System.out.println("wins " + wins);
		System.out.println("ties " + ties);
		System.out.println("losses " + losses);

		
		System.out.println("evaluated in (s) " + dt / 1e9 );
		
		
	}
	
	
	public void testSimulationWithBets() throws Exception
	{
		
		long t1 = System.nanoTime();
		
//		 Player1
		Card c1 = new Card(Rank.KING,Suit.HEART);
		Card c2 = new Card(Rank.ACE,Suit.SPADE);
		
		CardSet cardset = CardSet.freshDeck();
		
		System.out.println(cardset.size());
		
		removeCards(cardset, c1, c2);
		
//		cardset.remove(c1);
//		cardset.remove(c2);
		
		// System.out.println(cardset.size());
			
		cardset.shuffle();
		
		//System.out.println(cardset.iterator().next().toString());
		
		assertEquals(50, cardset.size());
		
		
		int wins = 0;
		int losses = 0;
		int ties = 0;
		
		final int RUNS = 1000;
		
		// Opponent
		Card o1;
		Card o2;
		
		// Board
		Card b1;
		Card b2;
		Card b3;
		Card b4;
		Card b5;
		
		/*
		 * RUNS Versuche
		 */
		for (int i = 0 ; i < RUNS; i++)
		{
			// Neue Karten
			cardset = CardSet.freshDeck();
			
			// Karten entfernen
			removeCards(cardset, c1, c2);			
			// Mischen!!!
			cardset.shuffle();
			
//			System.out.println("Hero Cards: " + c1.toString() + " " + c2.toString());
			
			// Karten austeilen
			Iterator it = cardset.iterator();
			o1 = (Card) it.next();
			o2 = (Card) it.next();
			
			
//			System.out.println("Opponentcards: " + o1.toString() + " " + o2.toString());
			
			// Boardkarten
			b1 = (Card) it.next();
			b2 = (Card) it.next();
			b3 = (Card) it.next();
			b4 = (Card) it.next();
			b5 = (Card) it.next();
			
//			System.out.println("Boardcards: " + b1.toString() + " " + b2.toString() + " " + b3.toString() + " "+b4.toString() + " "+b5.toString() );
			
			// Werte encodieren für Evaluator
			long p1 = HandEval.encode(c1) | HandEval.encode(c2);
			long p2 = HandEval.encode(o1) | HandEval.encode(o2);
			long board = HandEval.encode(b1) | HandEval.encode(b2) | HandEval.encode(b3);
			
			// PostFlop
			int p1value = HandEval.hand5Eval(p1 | board);
			int p2value = HandEval.hand5Eval(p2 | board);
//			System.out.println("After Flop | p1: " + p1value + " ps: " + p2value);
			
			// Turn and River
			board = board | HandEval.encode(b4) | HandEval.encode(b5);
			
			p1value = HandEval.hand7Eval(p1 | board);
			p2value = HandEval.hand7Eval(p2 | board);
			
//			System.out.println("After River | p1: " + p1value + " ps: " + p2value);
			
			// Wer gewinnt?
			if (p1value > p2value)
			{
				wins++;
			}
			else if (p1value==p2value) 
			{
				ties++;				
			}
			else
			{
				losses++;
			}
			
		
		}
		
		long t2 = System.nanoTime();
		
		long dt = t2-t1;
		
		
		
		System.out.println("von " + RUNS + " spielen:");
		System.out.println("wins " + wins);
		System.out.println("ties " + ties);
		System.out.println("losses " + losses);

		
		System.out.println("evaluated in (s) " + dt / 1e9 );
		
		
	}
	


	
	
	private static void removeCards(CardSet cs, Card c1, Card c2)
	{
		cs.remove(c1);
		cs.remove(c2);
		
	}
}
