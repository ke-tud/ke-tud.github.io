package tests;

import de.tud.inf.poker.g6bot.free.advisor.TurnAdvisor;
import junit.framework.TestCase;

public class testTurnAdvisor extends TestCase {
	public void testUpdate() throws Exception 
	{
	}
}
