package tests;


import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;
import de.tud.inf.poker.g6bot.free.evaluator.HandStrengthEvaluator;
import de.tud.inf.poker.g6bot.free.simulation.HandPotential;
import junit.framework.TestCase;

public class testHSE extends TestCase {
	
	
	/**
	 * Shows how to use HandStrengthCalculator
	 * @throws Exception
	 */
	public void testHandStrengthCalculation() throws Exception 
	{
		// Player1
		Card c1 = new Card(Rank.ACE,Suit.HEARTS);
		Card c2 = new Card(Rank.ACE,Suit.SPADES);
		
		// BoardCards
		Card board1 = new Card(Rank.TEN,Suit.SPADES);
		Card board2 = new Card(Rank.ACE,Suit.HEARTS);
		Card board3 = new Card(Rank.THREE,Suit.CLUBS);
		Card turn = new Card(Rank.JACK,Suit.HEARTS);
		Card river = new Card(Rank.TWO,Suit.DIAMONDS);
		
		
		
		Card[] hole = {c1,c2};
		Card[] board = {board1,board2,board3};
		
		HandStrengthEvaluator hse = new HandStrengthEvaluator(hole,board);
		
		hse.calculateHandStrength();
		
		long start = System.currentTimeMillis();
		HandPotential pot =  hse.getHandPotential();
		long time = System.currentTimeMillis() - start; 
		System.out.println("time " + time);
		// System.out.println(hse.flopHandstrength);
		System.out.println("npot2 " + pot.toString());
		
		hse.addCard(turn);
		
		// hse.calculateHandStrength();
		// hse.calculateHandStrength();
		System.out.println(hse.flopHandstrength);
		
		hse.addCard(river);
		
		hse.calculateHandStrength();
		System.out.println(hse.flopHandstrength);
		
		
		assertEquals(true, true);
		
	}

}
