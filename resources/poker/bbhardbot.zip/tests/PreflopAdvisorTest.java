package tests;

import java.util.HashMap;

import de.tud.inf.poker.g6bot.free.GameDecision.PlayAction;
import de.tud.inf.poker.g6bot.free.advisor.PreFlopAdvisor;
import de.tud.inf.poker.g6bot.free.advisor.StartingHands;
import junit.framework.TestCase;

public class PreflopAdvisorTest extends TestCase {

	PreFlopAdvisor pfa;
	
	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
		 pfa = new PreFlopAdvisor(null);
	}
	
	/**
	 * Test damit ich alle Objekte ausgeben kann...
	 * @throws Exception
	 */
	public void testInit() throws Exception {

		assertNotNull(pfa.getActionTable());	
	
	}
	
	public void testCategoriesPlayActionInit() throws Exception {
		
		for (StartingHands.Category cat : StartingHands.Category.values()) {
			System.out.println(cat.toString());
			assertNotNull(pfa.getActionTable().get(cat) );	
			
			
		}		
	}
	
	public void testCallValueCheck() throws Exception {
		for (PlayAction pa : pfa.getActionTable().values()) {
			System.out.println(pa.getColdcallLevel());
			assertEquals(0.2f, pa.getCallLevel());
		}
	}
	
	
}
