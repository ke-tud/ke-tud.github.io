//package ke.client;
//import java.util.HashMap;
//import java.util.Map;
//
//
//import ke.data.Hand;
//import ke.data.McPlayer;
//import ke.engine.*;
//import ca.ualberta.cs.poker.free.dynamics.Card;
//import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
//import ca.ualberta.cs.poker.free.dynamics.Card.Suit;
//
//
//public class test {
//	private static Map<Rank,Integer> hutchisonRank = new HashMap<Rank,Integer>();
//	
//	public test(){
//		initialHutchisonRank();
//	}
//	
//	private void initialHutchisonRank(){z
//		for(int i=2; i<10; i++){
//			hutchisonRank.put(Rank.toRank(i), i);
//		}
//		hutchisonRank.put(Rank.TEN, 11);
//		hutchisonRank.put(Rank.JACK, 12);
//		hutchisonRank.put(Rank.QUEEN, 13);
//		hutchisonRank.put(Rank.KING, 14);
//		hutchisonRank.put(Rank.ACE, 16);
//	}
//	/**
//	 * 0 : fold 1: call 2 : raise
//	 */
//	public int getAction(Rank[] r, Suit[] s, int seat){
//		int sum = getHutchisonRank(r,s,seat);
//		if(sum>30 && sum<=34)
//			return 1;
//		if(sum>30 && sum>34)
//			return 2;
//		return 0;
//	}
//	
//	private int getHutchisonRank(Rank[] r, Suit[] s, int seat){
//		int sum = 0;
//		
//		if(hutchisonRank.containsKey(r[0]) && hutchisonRank.containsKey(r[1]))
//			sum +=  hutchisonRank.get(r[0]) + hutchisonRank.get(r[1]);
//		if(r[0].equals(r[1]))
//			sum += 10;
//		if(s[0].equals(s[1]))
//			sum += 4;
//		if(r[0].ordinal() == r[1].ordinal() - 1 || r[0].ordinal() == r[1].ordinal() + 1)
//			sum += 3;
//		if(r[0].ordinal() == r[1].ordinal() - 2 || r[0].ordinal() == r[1].ordinal() + 2)
//			sum += 2;
//		if(r[0].ordinal() == r[1].ordinal() - 3 || r[0].ordinal() == r[1].ordinal() + 3)
//			sum += 1;
//		switch (seat) {
//		case 0:
//			sum += 5;
//			break;
//		case 1:
//			sum += 3;
//			break;
//		case 2:
//			sum += 5;
//			break;
//		}
//		
//		return sum;
//	}
//	
//	/**
//	 * Eigene Karten evaulieren, verwendet PokerEngine
//	 * @param hole
//	 * @param seatTaken
//	 */
//	public void evaluateHandCards() {
//		ke.data.Board board = new ke.data.Board();
//        board.addCard(new ke.data.Card(ke.data.Card.Rank.TEN, ke.data.Card.Suit.HEARTS));
//        board.addCard(new ke.data.Card(ke.data.Card.Rank.JACK, ke.data.Card.Suit.HEARTS));
//        board.addCard(new ke.data.Card(ke.data.Card.Rank.NINE, ke.data.Card.Suit.HEARTS));
//        board.addCard(new ke.data.Card(ke.data.Card.Rank.JACK, ke.data.Card.Suit.DIAMONDS));
//        board.addCard(new ke.data.Card(ke.data.Card.Rank.ACE, ke.data.Card.Suit.HEARTS));
//		Hand myHand = new Hand();
//		ke.data.Card myCard1 = new ke.data.Card(Card.Rank.ACE.ordinal(),Card.Suit.CLUBS.ordinal());
//		ke.data.Card myCard2 = new ke.data.Card(Card.Rank.KING.ordinal(),Card.Suit.CLUBS.ordinal());
//		ke.data.Card myCard3 = new ke.data.Card(Card.Rank.TEN.ordinal(),Card.Suit.CLUBS.ordinal());
//		ke.data.Card myCard4 = new ke.data.Card(Card.Rank.KING.ordinal(),Card.Suit.DIAMONDS.ordinal());
//		myHand.addCard(myCard3);
//		myHand.addCard(myCard4);
//		Hand myHand2 = new Hand();
//		myHand2.addCard(myCard1);
//		myHand2.addCard(myCard2);
//		System.out.println(myHand.getHandRank(board));
//		System.out.println(myHand2.getHandRank(board));
//		System.out.println(myHand.getHandRank(board).compareTo(myHand2.getHandRank(board)));
//		
//	}
//
//	
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		MasterMind master = new MasterMind();
//
//		Card[] playerCards = new Card[2];
//		playerCards[0] = new Card(Card.Rank.KING,Card.Suit.HEARTS);
//		playerCards[1] = new Card(Card.Rank.TEN,Card.Suit.DIAMONDS);
//		int[] inPot = new int[3];
//		inPot[0] = 0;
//		inPot[1] = 0;
//		inPot[2] = 0;
//		Card[] board = new Card[5];
////		board[0]= new Card(Card.Rank.ACE,Card.Suit.CLUBS);
////		board[1]= new Card(Card.Rank.QUEEN,Card.Suit.CLUBS);
////		board[2]= new Card(Card.Rank.KING,Card.Suit.DIAMONDS);
//		
//		ke.data.Board testBoard = new ke.data.Board();
//		testBoard.addCard(new ke.data.Card(Card.Rank.ACE.ordinal(),Card.Suit.CLUBS.ordinal()));
//		testBoard.addCard(new ke.data.Card(Card.Rank.QUEEN.ordinal(),Card.Suit.CLUBS.ordinal()));
//		testBoard.addCard(new ke.data.Card(Card.Rank.KING.ordinal(),Card.Suit.DIAMONDS.ordinal()));
//		ke.data.Hand testPlayer = new ke.data.Hand();
//		testPlayer.addCard(new ke.data.Card(Card.Rank.ACE.ordinal(),Card.Suit.DIAMONDS.ordinal()));
//		testPlayer.addCard(new ke.data.Card(Card.Rank.TWO.ordinal(),Card.Suit.DIAMONDS.ordinal()));
//		System.out.println(testPlayer.getHandRank(testBoard));
// 		long time = System.currentTimeMillis();
////		System.out.println(time);
// 		MonteCarloSimulation simulator = new MonteCarloSimulation();
// 		McPlayer[] opponents = new McPlayer[2];
// 		opponents[0] = new McPlayer(master.initialHandRangeMatrix(),1.989);
// 		opponents[1] = new McPlayer(master.initialHandRangeMatrix(),1.989);
// 		McPlayer player = new McPlayer(null,0.0);
// //		System.out.println(simulator.runCompleteSimulation(playerCards, board, 0, 0, inPot, 0, 0, 3, 1, 2, player, opponents, true));
// 		System.out.println((System.currentTimeMillis()-time)/1000);
//		
//	}
//	
//
//}