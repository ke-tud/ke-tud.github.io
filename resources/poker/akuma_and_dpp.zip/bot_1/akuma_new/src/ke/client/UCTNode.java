package ke.client;

public class UCTNode {
	private double value = 0.0;
	private int visits = 0;
	private double averageMCValue  = 0.0;
	private double c = 0.5;
	private UCTNode parent;
	private UCTNode left = null;
	private UCTNode right = null;

	public UCTNode(int value, UCTNode parent){
		this.parent = parent;
		visits++;
		updateMCValue(value);
		updateUCTValue();
	}
	
	public int getVisits(){
		return visits;
	}
	
	public void visit(){
		visits++;
	}
	
	public UCTNode getleft(){
		return left;
	}
	
	public void setleft(UCTNode left){
		this.left = left;
	}
	
	public UCTNode getRight(){
		return right;
	}
	
	public void setRight(UCTNode right){
		this.right = right;
	}
	
	public UCTNode getParent(){
		return parent;
	}
	
	
	public void updateUCTValue(){
		if(parent == null)
			this.value = averageMCValue + c * Math.sqrt(Math.log(0)/visits);
		else
			this.value = averageMCValue + c * Math.sqrt(Math.log(parent.getVisits())/visits);
	}
	
	
	public void updateMCValue(int newMcValue){
		//Normalisierung des MC Wertes Max 72 Min -24
		double value = ((double)newMcValue + (double)24.0)/(double)(72.0+24.0);
		this.averageMCValue = ((averageMCValue + value)/2);
	}
	
	public double getMcValue(){
		return this.averageMCValue;
	}
	
	public double getUCTValue(){
		return this.value;
	}

}
