package ke.engine;

import java.security.SecureRandom;

import ke.client.ClientRingDynamics;
import ke.client.dummy.OpponentStatistics;
import ke.data.Action;
import ke.data.McPlayer;


public class MasterMind {
	 
	private SecureRandom random = new SecureRandom();
	Action currently_best_action = Action.CALL; 
	private Action lastAction; 
	private MonteCarloSimulation mcSimulator = new MonteCarloSimulation();
	private int handNum = -1;
	private int roundIndex = -1;
	private int lastMCEV = 0;
	// handRange[2] = Gewinnwahrscheinlichkeiten der Starth�nde 
	private double[][][] handRanges = new double[2][][];
	private int[][] startingHands;
	private McPlayer[] opponents = new McPlayer[2];
	private OpponentStatistics betHightStatistics;
	private McPlayer player = new McPlayer(null, 0.0);
	private HandStrengths ehs;
	
	public MasterMind(OpponentStatistics betHightStatistics, HandStrengths ehs){
		this.betHightStatistics = betHightStatistics;
		this.ehs = ehs;
		//Initiale OpponentMatrix erstellen.
		handRanges[0] = initialHandRangeMatrix(); 
		handRanges[1] = initialHandRangeMatrix(); 
		startingHands = setPreFlopMatrix();
		// Playererstellung
		opponents[0] = new McPlayer(handRanges[0],110.24);
		opponents[1] = new McPlayer(handRanges[1],110.24);
	}
	
	public McPlayer[] getOpponents(){
		return opponents; 
	}
	
	/**
	 * Analyses the sithuation. And stores a random decission in 
	 * currently_best_action. 
	 * @param state
	 */
	public void think_about(ClientRingDynamics state){
		// Erste Runde, initiale Spielerverteilung bestimmen
		if(handNum == -1 &&  roundIndex == -1){
			player.addPlayerID(state.seatToPlayer(state.seatTaken));
			
			switch (state.seatToPlayer(state.seatTaken)) {
				case 0:
					opponents[0].addPlayerID(1);
					opponents[1].addPlayerID(2);
					break;
				case 1:
					opponents[0].addPlayerID(0);
					opponents[1].addPlayerID(2);
					break;
				case 2:
					opponents[0].addPlayerID(0);
					opponents[1].addPlayerID(1);
					break;
				default:
					System.err.println("Falsche Gegner Player Berechnung");
					System.err.println(state.seatToPlayer(state.seatTaken));	
					System.err.println(state.seatTaken);
					System.err.println(state.numSeats);
					break;
			}//end_switch			
		}
		
		if(state.roundIndex == 0 && state.firstActionOnRound){
			myHandCardsIntoHandRanges(state);
		}//end_if erste Aktion des Spieler
		else{
			if(state.roundIndex > 0 && state.firstActionOnRound){
				// Wenn erste Aktion einer neuen Runde beim Spieler liegt dann muss dieser die neuen Karten 
				// in die HandRanges einflie�en lassen
				newBoardCards(state);
			}
		}
//		if(state.roundIndex == 1){
//			System.out.println("PreFlopEstimation");
////			System.out.println(state.roundIndex);
////			System.out.println(state.firstActionOnRound);
//			preFlopEstimationIntoHandRanges(state);
//		}
		
		
		// Bestimmen ob eine Simulation derselben Hand und Runde nochmal neu berechnet werden muss.
		if(handNum == state.handNumber && roundIndex == state.roundIndex){
			lastMCEV = mcSimulator.getLastMCEV();
		}else{
			handNum = state.handNumber;
			roundIndex = state.roundIndex;
			lastMCEV = 0;
		}
		
		if (lastMCEV < 1000) {
			// PlayerToSeat Mapping Opponentreihenfolgenermittlung
//			System.out.println("MC Simulation");
//			System.out.print("roundIndex");
//			System.out.println(state.roundIndex);
//			System.out.print("lastActionSeat");
//			System.out.println(state.lastActionSeat);
//			System.out.print("lastActionPot");
//			System.out.println(state.lastBetSize);
//			System.out.print("lastMCEV");
//			System.out.println(lastMCEV);
//			System.out.print("seatTaken");
//			System.out.println(state.seatTaken);
//			System.out.print("handumber");
//			System.out.println(state.handNumber);
//			System.out.print("numSeats");
//			System.out.println(state.numSeats);
//			System.out.print("roundBets");
//			System.out.println(state.roundBets);
//			System.out.print("numActiveSeats");
//			System.out.println(state.getNumActivePlayers());
//			System.out.print("inPot");
//			System.out.println(player.getStack());
			int pot = 0;
			for (int i = 0; i < 3; i++) {
				pot += state.inPot[i];
//				System.out.println(state.inPot[i]);
			}
			
//			System.out.print("pot");
//			System.out.println(pot);
			
			McPlayer[] playersInSeat = new McPlayer[state.numSeats];
			playersInSeat[state.seatTaken] = player;
			player.setInitialPot(state.inPot[state.seatTaken], true);
			playersInSeat[state.playerToSeat(opponents[0].getPlayerID())] = opponents[0];
			playersInSeat[state.playerToSeat(opponents[1].getPlayerID())] = opponents[1];
			if(state.active[state.playerToSeat(opponents[0].getPlayerID())]) 
				opponents[0].setInitialPot(state.inPot[state.playerToSeat(opponents[0].getPlayerID())], true);
			else
				opponents[0].setInitialPot(state.inPot[state.playerToSeat(opponents[0].getPlayerID())], false);
			if(state.active[state.playerToSeat(opponents[1].getPlayerID())]) 
				opponents[1].setInitialPot(state.inPot[state.playerToSeat(opponents[1].getPlayerID())], true);
			else
				opponents[1].setInitialPot(state.inPot[state.playerToSeat(opponents[1].getPlayerID())], false);
			
			if(opponents[0].isActive()){
				float[] trippel = betHightStatistics.getProb(opponents[0].getPlayerID(), 
						state.roundIndex,state.getAmountToCall(state.playerToSeat(opponents[0].getPlayerID()))/state.lastBetSize); 
				opponents[0].setCallProp((double)trippel[0] + (double)trippel[1]);
			}
			if(opponents[1].isActive()){
				float[] trippel = betHightStatistics.getProb(opponents[1].getPlayerID(), 
						state.roundIndex,state.getAmountToCall(state.playerToSeat(opponents[1].getPlayerID()))/state.lastBetSize); 
				opponents[1].setCallProp((double)trippel[0] + (double)trippel[1]);
			}	
			
//			System.out.println("Seats:");
//			System.out.println(player);
//			System.out.println(state.playerToSeat(player.getPlayerID()));
//			System.out.println(opponents[0]);
//			System.out.println(state.playerToSeat(opponents[0].getPlayerID()));
//			System.out.println(opponents[1]);
//			System.out.println(state.playerToSeat(opponents[1].getPlayerID()));
						
			currently_best_action = mcSimulator.runCompleteSimulation(state.hole[state.seatTaken], state.board, 
					state.roundBets, state.roundIndex, state.inPot, pot, state.lastActionSeat, state.lastBetSize, state.seatTaken, 
					state.numSeats, state.getNumActivePlayers(), 6000, 2, playersInSeat, state.firstActionOnRound);
//			System.out.println(currently_best_action);
//			System.out.println(mcSimulator.getLastMCEV());
			lastAction = currently_best_action;
		}else{
			System.out.println("KEINE NEUBERECHNUNG");
			System.out.println(lastMCEV);
			System.out.println(state.roundIndex);
			currently_best_action = lastAction;
			System.out.println(currently_best_action);
			System.out.println("Same Action taken!");
		}
		

				
	}
	
	public Action getAction(){
		return currently_best_action;
	}
	
	public void newBoardCards(ClientRingDynamics state){
//		System.out.println("NEW BOARD CARDS!");
		
		double[][] handRange;
		double handRangeSum;
				
		// Update
		int x, y, z = 0;
		for (int i = 0; i < 2; i++) {
			int seat = state.playerToSeat(opponents[i].getPlayerID());
			if(state.active[seat]){
				handRange = opponents[i].getHandRange();
				handRangeSum = opponents[i].getHandRangeSum();
//				System.out.print("HandRange old:");
//				System.out.println(handRangeSum);
				
				// Flop
				if(state.roundIndex == 1){
					for (int j = 0; j < 3; j++) {
						int j2 = j+1;
						if (j==2) {
							 j2= 0;
						}
						x = state.board[j].rank.ordinal();
						y = state.board[j2].rank.ordinal();
						if(x != y){
							if(state.board[j].suit.ordinal() == state.board[j2].suit.ordinal()){
								if(x > y){
									z = x;
									x = y;
									y = z;
								}
							}else{
								if(x < y){
									z = x;
									x = y;
									y = z;
								}
							}
						} 		
						
						//	update
						double temp = handRange[x][y];
						handRange[x][y] = handRange[x][y] - 0.08;
						if(handRange[x][y] < 0.0){
							handRange[x][y] = 0.0;
							handRangeSum = handRangeSum - temp;
						}else
							handRangeSum = handRangeSum - 0.08;
						
					}//end_for
				}//end_if
				else{
					// Turn oder River
					for (int j = 0; j < state.roundIndex+1; j++) {
						x = state.board[j].rank.ordinal();
						y = state.board[state.roundIndex+1].rank.ordinal();
						if(x != y){
							if(state.board[j].suit.ordinal() == state.board[state.roundIndex+1].suit.ordinal()){
								if(x > y){
									z = x;
									x = y;
									y = z;
								}
							}else{
								if(x < y){
									z = x;
									x = y;
									y = z;
								}
							}
						} 		

						//update
						double temp = handRange[x][y];
						handRange[x][y] = handRange[x][y] - 0.08;
						if(handRange[x][y] < 0.01){
							handRange[x][y] = 0.01;
							handRangeSum = handRangeSum - temp;
						}else
							handRangeSum = handRangeSum - 0.08;
						
					}//end_for
				}
//				System.out.print("HandRange new:");
//				System.out.println(handRangeSum);
				
				opponents[i].setHandRange(handRange);
				opponents[i].setHandRangeSum(handRangeSum);
			}
		}
	}
	
	public void preFlopEstimationIntoHandRanges(ClientRingDynamics state){
//		for (int p = 0; p < 2; p++) {
//			if(opponents[p].isActive()){
//			System.out.print(opponents[p]);
//			for (int u = 0; u < 13; u++) {
//				for (int o = 0; o < 13; o++) {
//						System.out.print(opponents[p].getHandRange()[u][o]);
//						System.out.print(" / ");	
//				}
//				System.out.println("");
//			}
//			}
//			System.out.println("");
//		}
		
		
		double[][] handRange;
		double handRangeSum;
		int downs,ups;
		// Update
		int x = 0;
		int y = 0;
		for (int i = 0; i < 2; i++) {
			int seat = state.playerToSeat(opponents[i].getPlayerID());
			if(state.active[seat]){
				handRange = opponents[i].getHandRange();
				handRangeSum = opponents[i].getHandRangeSum();
//				System.out.print("HandRange old:");
//				System.out.println(handRangeSum);
				
				// Update
				double temp2 = (double)(betHightStatistics.getProb(opponents[i].getPlayerID(), state.roundIndex, 
						state.getAmountToCall(state.playerToSeat(opponents[i].getPlayerID()))/state.lastBetSize)[0] - 0.10);
				
				if (temp2 < 0.0) {
					temp2 = 0.0;
				}
//				System.out.println("FOLD STATISTIC");
//				System.out.println(temp2);
				downs  = 169 - (int)(temp2 * 169.0);
				
				temp2 = (double)(betHightStatistics.getProb(opponents[i].getPlayerID(), state.roundIndex, 
						state.getAmountToCall(state.playerToSeat(opponents[i].getPlayerID()))/state.lastBetSize)[0] + 0.10);
						
				if (temp2 > 1.0) {
					temp2 = 1.0;
				}
//				System.out.println("FOLD STATISTIC");
//				System.out.println(temp2);
				ups  = 169 - (int)(temp2 * 169.0);
				// Ups muss mann nicht machen wegen * 1.0 
//				System.out.println(ups);
				// Middle Lineaisiert absteiend
				double value = (1.0 - 0.1) / (double)(downs - ups);
				double n = 1.0;
				for (int j = ups; j < downs; j++) {
					x = startingHands[j][0];
					y = startingHands[j][1];
					//Update
					
					if(handRange[x][y] > 0.01){
						double temp = handRange[x][y] * n;
						handRangeSum = handRangeSum - handRange[x][y];
						handRange[x][y] = temp;
						handRangeSum = handRangeSum + handRange[x][y];
					}else{
						if(handRange[x][y] < 0.01){
							handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
							handRange[x][y] = 0.01;
						}
					}
					
					n = n - value;
				}
				// Downs
//				System.out.println(downs);
				for (int j = downs; j < 169; j++) {
					x = startingHands[j][0];
					y = startingHands[j][1];
					//Update
					double temp = handRange[x][y] - 0.01;
					handRange[x][y] = 0.01;
					handRangeSum = handRangeSum - temp;
				}
//				System.out.print("HandRange new:");
//				System.out.println(handRangeSum);
			
				opponents[i].setHandRange(handRange);
				opponents[i].setHandRangeSum(handRangeSum);
			}
		}
//		for (int p = 0; p < 2; p++) {
//			if(opponents[p].isActive()){
//			System.out.print(opponents[p]);
//			for (int u = 0; u < 13; u++) {
//				for (int o = 0; o < 13; o++) {
//						System.out.print(opponents[p].getHandRange()[u][o]);
//						System.out.print(" / ");	
//				}
//				System.out.println("");
//			}
//			}
//			System.out.println("");
//		}
	}
	
	public void resetHandRange(){
		opponents[0].setHandRange(initialHandRangeMatrix());
		opponents[0].setHandRangeSum(110.24);
		opponents[0].setLastAction(null);
		opponents[1].setHandRange(initialHandRangeMatrix());
		opponents[1].setHandRangeSum(110.24);
		opponents[1].setLastAction(null);
	}
	
	public void opponentMove(ClientRingDynamics state, Action lastAction, int seat){
//		System.out.println("OpponentMove!");
//		System.out.println(seat);
//		System.out.println(lastAction);
		
		
		int[][] test = ehs.getHandStrengths();
//		for(int i = 0; i < test.length; ++i){
//			System.out.printf("%03d: (%2d,%2d)\r\n", i, test[i][0], test[i][1]);
//		}
		
		if (lastAction.equals(Action.FOLD)) {
			System.err.println("FOLD!!!!!!!DAS DARF NICHT SEIN");
		}
		// GetPropabilityTrippel
		int oppo = 0;
		if(opponents[0].getPlayerID() == state.seatToPlayer(seat))
			oppo = 0;
		else
			oppo = 1;
		
		double[][] handRange = opponents[oppo].getHandRange();
		double handRangeSum = opponents[oppo].getHandRangeSum();
		float[] trippel = betHightStatistics.getProb(opponents[oppo].getPlayerID(), 
				state.roundIndex, state.getAmountToCall(seat)/state.lastBetSize);
		
//		System.out.println("Trippel: "+ trippel[0] + " / " + trippel[1] + " / " + trippel [2]);
//			for (int u = 0; u < 13; u++) {
//				for (int o = 0; o < 13; o++) {
//						System.out.print(handRange[u][o]);
//						System.out.print(" / ");	
//				}
//				System.out.println("");
//			}
//			System.out.println("");		
//		
//		System.out.println("HandRangeSum:" + handRangeSum);
		
		int[][] ehs = this.ehs.getHandStrengths();
		int first,second,x,y;
		double value,n;
		
		if (lastAction.equals(Action.CALL)) {
			// Update der 0 bis Fold-10% mit Faktor 0.01
			double temp = (double)(trippel[0] - 0.15) ;
			if (temp < 0.0) {
				temp = 0.0;
			}
//			System.out.println("CALL Opponent 1.Range");
//			System.out.println(temp);
			first  = ( (168 - (int)(temp * 169.0)) + 1);
//			System.out.println(first);
//			System.out.println(169);
			for (int j = first; j < 169; j++) {
				x = ehs[j][0];
				y = ehs[j][1];
				//Update
				if(handRange[x][y] > 0.01){
					double temp2 = handRange[x][y] * 0.1;	
					handRangeSum = handRangeSum - handRange[x][y];
					handRange[x][y] = temp2;
					handRangeSum = handRangeSum + handRange[x][y];
				}else{
					if(handRange[x][y] < 0.01){
						handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
						handRange[x][y] = 0.01;
					}
				}
			}	
			// Update der Fold-10 bis Fold+10% mit Faktor Linearisiert absteigend 
//			temp = (double)(trippel[0] + 0.10) ;
//			if (temp > 1.0) {
//				temp = 1.0;
//			}
////			System.out.println("CALL Opponent 2.Range");
////			System.out.println(temp);
//			second  = ( (168 - (int)(temp * 169.0)) + 1);
////			System.out.println(second);
////			System.out.println(first);
//			value = (1.0 - 0.1) / (double)(first - second);
//			n = 1.0;
//			for (int j = second; j < first; j++) {
//				x = ehs[j][0];
//				y = ehs[j][1];
//				//Update
//				if(handRange[x][y] > 0.01){
//					double temp2 = handRange[x][y] * n;
//					handRangeSum = handRangeSum - handRange[x][y];
//					handRange[x][y] = temp2;
//					handRangeSum = handRangeSum + handRange[x][y];
//				}else{
//					if(handRange[x][y] < 0.01){
//						handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
//						handRange[x][y] = 0.01;
//					}
//				}
//				n = n - value;
//			}
//			// Update der Fold+10% bis Fold+Call-10% mit Faktor 1.0 (also nichts machen) 
//			temp = (double)(trippel[0]+trippel[1] - 0.10) ;
//			if (temp < 0.0) {
//				temp = 0.0;
//			}
////			System.out.println("CALL Opponent 3.Range");
////			System.out.println(temp);
//			first  = ( (168 - (int)(temp * 169.0)) + 1);
////			System.out.println(first);
////			System.out.println(second);
//			// Update der Fold+Call-10% bis Fold+Call+10% mit Faktor Linearisiert aufsteigend
//			temp = (double)(trippel[0]+trippel[1] + 0.10) ;
//			if (temp > 1.0) {
//				temp = 1.0;
//			}
////			System.out.println("CALL Opponent 4.Range");
////			System.out.println(temp);
//			second  = ( (168 - (int)(temp * 169.0)) + 1);
////			System.out.println(second);
////			System.out.println(first);
//			value = (1.0 - 0.1) / (double)(first - second);
//			n = 0.1;
//			for (int j = second; j < first; j++) {
//				x = ehs[j][0];
//				y = ehs[j][1];
//				//Update
//				if(handRange[x][y] > 0.01){
//					double temp2 = handRange[x][y] * n;
//					handRangeSum = handRangeSum - handRange[x][y];
//					handRange[x][y] = temp2;
//					handRangeSum = handRangeSum + handRange[x][y];
//				}else{
//					if(handRange[x][y] < 0.01){
//						handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
//						handRange[x][y] = 0.01;
//					}
//				}
//				n = n + value;
//			}
//			// Update der Fold+Call-10% bis Fold+Call+10% mit Faktor 0.01 
////			System.out.println("CALL Opponent 5.Range");
////			System.out.println(0);
////			System.out.println(second);
//			for (int j = 0; j < second; j++) {
//				x = ehs[j][0];
//				y = ehs[j][1];
//				//Update
//				if(handRange[x][y] > 0.01){
//					double temp2 = handRange[x][y] * 0.1;
//					handRangeSum = handRangeSum - handRange[x][y];
//					handRange[x][y] = temp2;
//					handRangeSum = handRangeSum + handRange[x][y];
//				}else{
//					if(handRange[x][y] < 0.01){
//						handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
//						handRange[x][y] = 0.01;
//					}
//				}
//			}
			
		}else{
			// Update Herabsetzen der 0 bis Fold+Call-10% mit Faktor 0.01  
			double temp = (double)(trippel[0]+trippel[1] - 0.30);
			if (temp < 0.0) {
				temp = 0.0;
			}
//			System.out.println("RAISE Opponent 1.Range");
//			System.out.println(temp);
			first  = ( (168 - (int)(temp * 169.0)) + 1);
//			System.out.println(first);
//			System.out.println(169);
			for (int j = first; j < 169; j++) {
				x = ehs[j][0];
				y = ehs[j][1];
				//Update
				if(handRange[x][y] > 0.01){
					double temp2 = handRange[x][y] * 0.1;
					handRangeSum = handRangeSum - handRange[x][y];
					handRange[x][y] = temp2;
					handRangeSum = handRangeSum + handRange[x][y];
				}else{
					if(handRange[x][y] < 0.01){
						handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
						handRange[x][y] = 0.01;
					}
				}
			}	
			// Update Herabsetzen der Fold+Call-10% bis Fold+Call+10% mit Faktor Linearisiert absteigend 
//			temp = (double)(trippel[0]+trippel[1] + 0.10) ;
//			if (temp > 1.0) {
//				temp = 1.0;
//			}
////			System.out.println("RAISE Opponent 2.Range");
////			System.out.println(temp);
//			second  = ( (168 - (int)(temp * 169.0)) + 1);
////			System.out.println(second);
////			System.out.println(first);
//			value = (1.0 - 0.1) / (double)(first - second);
//			n = 1.0;
//			for (int j = second; j < first; j++) {
//				x = ehs[j][0];
//				y = ehs[j][1];
//				//Update
//				if(handRange[x][y] > 0.01){
//					double temp2 = handRange[x][y] * n;
//					handRangeSum = handRangeSum - handRange[x][y];
//					handRange[x][y] = temp2;
//					handRangeSum = handRangeSum + handRange[x][y];
//				}else{
//					if(handRange[x][y] < 0.01){
//						handRangeSum = handRangeSum + (0.01 - handRange[x][y]);
//						handRange[x][y] = 0.01;
//					}
//				}
//				n = n - value;
//			}
//			// Update Herabsetzen der Fold+Call+10% bis ENDE mit Faktor 1.0 also nichts machen
////			System.out.println("RAISE Opponent 3.Range");
////			System.out.println(0);
////			System.out.println(second);
		}	
		
		opponents[oppo].setHandRange(handRange);
		opponents[oppo].setHandRangeSum(handRangeSum);
		opponents[oppo].setLastAction(lastAction);
		
//			for (int u = 0; u < 13; u++) {
//				for (int o = 0; o < 13; o++) {
//						System.out.print(handRange[u][o]);
//						System.out.print(" / ");	
//				}
//				System.out.println("");
//			}
//		
//		System.out.println("HandRangeSum:" + handRangeSum);
	}
	
	public void myHandCardsIntoHandRanges(ClientRingDynamics state){
		// Eigene Karten in die gegenerischen Handranges einflie�en lassen
//		System.out.println("NEW HandCards Into HangeRange");
		
		double[][] handRange;
		double handRangeSum;
		// Update
		int x, y, z = 0;
		for (int i = 0; i < 2; i++) {
			int seat = state.playerToSeat(opponents[i].getPlayerID());
			handRange = opponents[i].getHandRange();
			handRangeSum = opponents[i].getHandRangeSum();
//			System.out.print("HandRange old:");
//			System.out.println(handRangeSum);
			
			x = state.hole[state.seatTaken][0].rank.ordinal();
			y = state.hole[state.seatTaken][1].rank.ordinal();
//			System.out.println("Meine Handkarten:");
//			System.out.println(state.hole[state.seatTaken][0]);
//			System.out.println(state.hole[state.seatTaken][1]);
			if(x != y){
				if(state.hole[state.seatTaken][0].suit.ordinal() == state.hole[state.seatTaken][1].suit.ordinal()){
					if(x > y){
						z = x;
						x = y;
						y = z;	
					}
				}else{
					if(x < y){
						z = x;
						x = y;
						y = z;
					}
				}
			} 			
			//	update
			double temp = handRange[x][y];
			handRange[x][y] = handRange[x][y] - 0.08;
			if(handRange[x][y] < 0.0 ){
				handRange[x][y] = 0.0;
				handRangeSum = handRangeSum - temp;
			}else
				handRangeSum = handRangeSum - 0.08;
			
//			System.out.print("HandRange new:");
//			System.out.println(handRangeSum);
			opponents[i].setHandRange(handRange);
			opponents[i].setHandRangeSum(handRangeSum);
		}//end_for
	}
	
	/**
	 * HandRange Matrix zur Gegnermodellierung
	 * @return
	 */
	public double[][] initialHandRangeMatrix() {
		double[][] matrix = new double[13][13];
		// 
		for (int x = 0; x < 13; x++) {
			for (int y = 0; y < 13; y++) {
				if(x==y)// Pair 6/663 = 0.009
					matrix[x][y] = 0.5;
				else
					if(x>y)// Unsuited 12/663 = 0.018
						matrix[x][y] = 1.0;
					else// Suited 4/663 = 0.006
						matrix[x][y] = 0.33;
			}
		}
		
		return matrix;
	}
	
	public void stackUpdate(int[] stack){
		// Stack aktualisieren 
//		System.out.print("HANDOVER!");
		player.setStack(stack[player.getPlayerID()]-8000);
		opponents[0].setStack(stack[opponents[0].getPlayerID()]-8000);
		opponents[1].setStack(stack[opponents[1].getPlayerID()]-8000);
//		System.out.print(player.getStack());
//		System.out.print(opponents[0].getStack());
//		System.out.print(opponents[1].getStack());
	}
	
	private int[][] setPreFlopMatrix(){
		// matrix x y Wert
		int[][] matrix = new int[169][2];
		// 
		matrix[0][0] = 12;
		matrix[0][1] = 12;
		
		matrix[1][0] = 11;
		matrix[1][1] = 11;
		
		matrix[2][0] = 10;
		matrix[2][1] = 10;
		
		matrix[3][0] = 9;
		matrix[3][1] = 9;
		
		matrix[4][0] = 8;
		matrix[4][1] = 8;
		
		matrix[5][0] = 7;
		matrix[5][1] = 7;
		
		matrix[6][0] = 11;
		matrix[6][1] = 12;
		
		matrix[7][0] = 6;
		matrix[7][1] = 6;
		
		matrix[8][0] = 10;
		matrix[8][1] = 12;
		
		matrix[9][0] = 12;
		matrix[9][1] = 11;
		
		matrix[10][0] = 9;
		matrix[10][1] = 12;
		
		matrix[11][0] = 8;
		matrix[11][1] = 12;
		
		matrix[12][0] = 10;
		matrix[12][1] = 11;
		
		matrix[13][0] = 12;
		matrix[13][1] = 10;
		
		matrix[14][0] = 5;
		matrix[14][1] = 5;
		
		matrix[15][0] = 9;
		matrix[15][1] = 11;
		
		matrix[16][0] = 12;
		matrix[16][1] = 9;
		
		matrix[17][0] = 8;
		matrix[17][1] = 11;
		
		matrix[18][0] = 7;
		matrix[18][1] = 12;
		
		matrix[19][0] = 11;
		matrix[19][1] = 10;
		
		matrix[20][0] = 12;
		matrix[20][1] = 8;
		
		matrix[21][0] = 9;
		matrix[21][1] = 10;
		
		matrix[22][0] = 6;
		matrix[22][1] = 12;
		
		matrix[23][0] = 4;
		matrix[23][1] = 4;
		
		matrix[24][0] = 11;
		matrix[24][1] = 9;
		
		matrix[25][0] = 8;
		matrix[25][1] = 10;
		
		matrix[26][0] = 5;
		matrix[26][1] = 12;
		
		matrix[27][0] = 7;
		matrix[27][1] = 11;
		
		matrix[28][0] = 11;
		matrix[28][1] = 8;
		
		matrix[29][0] = 8;
		matrix[29][1] = 9;
		
		matrix[30][0] = 12;
		matrix[30][1] = 7;
	
		matrix[31][0] = 3;
		matrix[31][1] = 12;
		
		matrix[32][0] = 10;
		matrix[32][1] = 9;
		
		matrix[33][0] = 4;
		matrix[33][1] = 12;
	
		matrix[34][0] = 7;
		matrix[34][1] = 10;
		
		matrix[35][0] = 2;
		matrix[35][1] = 12;
		
		matrix[36][0] = 12;
		matrix[36][1] = 6;
		
		matrix[37][0] = 10;
		matrix[37][1] = 8;
		
		matrix[38][0] = 6;
		matrix[38][1] = 11;
		
		matrix[39][0] = 3;
		matrix[39][1] = 3;
		
		matrix[40][0] = 1;
		matrix[40][1] = 12;
		
		matrix[41][0] = 7;
		matrix[41][1] = 9;
	
		matrix[42][0] = 11;
		matrix[42][1] = 7;
		
		matrix[43][0] = 12;
		matrix[43][1] = 5;
		
		matrix[44][0] = 5;
		matrix[44][1] = 11;
		
		matrix[45][0] = 9;
		matrix[45][1] = 8;
		
		matrix[46][0] = 0;
		matrix[46][1] = 12;
		
		matrix[47][0] = 7;
		matrix[47][1] = 8;
		
		matrix[48][0] = 6;
		matrix[48][1] = 10;
	
		matrix[49][0] = 12;
		matrix[49][1] = 3;
		
		matrix[50][0] = 4;
		matrix[50][1] = 11;
		
		matrix[51][0] = 12;
		matrix[51][1] = 4;
		
		matrix[52][0] = 10;
		matrix[52][1] = 7;
		
		matrix[53][0] = 6;
		matrix[53][1] = 9;
		
		matrix[54][0] = 3;
		matrix[54][1] = 11;
		
		matrix[55][0] = 12;
		matrix[55][1] = 2;
	
		matrix[56][0] = 11;
		matrix[56][1] = 6;
		
		matrix[57][0] = 2;
		matrix[57][1] = 2;
		
		matrix[58][0] = 6;
		matrix[58][1] = 8;
		
		matrix[59][0] = 2;
		matrix[59][1] = 11;
		
		matrix[60][0] = 5;
		matrix[60][1] = 10;
		
		matrix[61][0] = 12;
		matrix[61][1] = 1;
		
		matrix[62][0] = 9;
		matrix[62][1] = 7;
	
		matrix[63][0] = 11;
		matrix[63][1] = 5;
		
		matrix[64][0] = 6;
		matrix[64][1] = 7;
		
		matrix[65][0] = 1;
		matrix[65][1] = 11;
		
		matrix[66][0] = 4;
		matrix[66][1] = 10;
		
		matrix[67][0] = 8;
		matrix[67][1] = 7;
		
		matrix[68][0] = 12;
		matrix[68][1] = 0;
	
		matrix[69][0] = 5;
		matrix[69][1] = 9;
		
		matrix[70][0] = 10;
		matrix[70][1] = 6;
		
		matrix[71][0] = 0;
		matrix[71][1] = 11;
		
		matrix[72][0] = 11;
		matrix[72][1] = 4;
		
		matrix[73][0] = 3;
		matrix[73][1] = 10;
		
		matrix[74][0] = 5;
		matrix[74][1] = 8;
	
		matrix[75][0] = 9;
		matrix[75][1] = 6;
		
		matrix[76][0] = 5;
		matrix[76][1] = 7;
		
		matrix[77][0] = 2;
		matrix[77][1] = 10;
		
		matrix[78][0] = 11;
		matrix[78][1] = 3;
		
		matrix[79][0] = 5;
		matrix[79][1] = 6;
		
		matrix[80][0] = 1;
		matrix[80][1] = 1;
		
		matrix[81][0] = 8;
		matrix[81][1] = 6;
	
		matrix[82][0] = 4;
		matrix[82][1] = 9;
		
		matrix[83][0] = 1;
		matrix[83][1] = 10;
		
		matrix[84][0] = 11;
		matrix[84][1] = 2;
		
		matrix[85][0] = 10;
		matrix[85][1] = 5;
		
		matrix[86][0] = 3;
		matrix[86][1] = 9;
		
		matrix[87][0] = 7;
		matrix[87][1] = 6;
	
		matrix[88][0] = 4;
		matrix[88][1] = 8;
		
		matrix[89][0] = 0;
		matrix[89][1] = 10;
	
		matrix[90][0] = 10;
		matrix[90][1] = 4;
		
		matrix[91][0] = 11;
		matrix[91][1] = 1;
		
		matrix[92][0] = 4;
		matrix[92][1] = 7;
		
		matrix[93][0] = 2;
		matrix[93][1] = 9;
		
		matrix[94][0] = 9;
		matrix[94][1] = 5;
		
		matrix[95][0] = 4;
		matrix[95][1] = 5;
	
		matrix[96][0] = 4;
		matrix[96][1] = 6;
		
		matrix[97][0] = 10;
		matrix[97][1] = 3;
		
		matrix[98][0] = 11;
		matrix[98][1] = 0;
		
		matrix[99][0] = 8;
		matrix[99][1] = 5;
		
		matrix[100][0] = 1;
		matrix[100][1] = 9;
		
		matrix[101][0] = 3;
		matrix[101][1] = 8;
		
		matrix[102][0] = 0;
		matrix[102][1] = 0;
		
		matrix[103][0] = 7;
		matrix[103][1] = 5;
		
		matrix[104][0] = 10;
		matrix[104][1] = 2;
		
		matrix[105][0] = 0;
		matrix[105][1] = 9;
		
		matrix[106][0] = 6;
		matrix[106][1] = 5;
		
		matrix[107][0] = 3;
		matrix[107][1] = 7;
		
		matrix[108][0] = 2;
		matrix[108][1] = 8;
		
		matrix[109][0] = 3;
		matrix[109][1] = 4;
		
		matrix[110][0] = 3;
		matrix[110][1] = 5;
		
		matrix[111][0] = 3;
		matrix[111][1] = 6;
		
		matrix[112][0] = 9;
		matrix[112][1] = 4;
		
		matrix[113][0] = 10;
		matrix[113][1] = 1;
		
		matrix[114][0] = 1;
		matrix[114][1] = 8;
		
		matrix[115][0] = 9;
		matrix[115][1] = 3;
		
		matrix[116][0] = 8;
		matrix[116][1] = 4;
		
		matrix[117][0] = 2;
		matrix[117][1] = 3;
		
		matrix[118][0] = 0;
		matrix[118][1] = 8;
	
		matrix[119][0] = 10;
		matrix[119][1] = 0;
		
		matrix[120][0] = 7;
		matrix[120][1] = 4;
		
		matrix[121][0] = 5;
		matrix[121][1] = 4;
		
		matrix[122][0] = 2;
		matrix[122][1] = 7;
		
		matrix[123][0] = 2;
		matrix[123][1] = 4;
		
		matrix[124][0] = 6;
		matrix[124][1] = 4;
		
		matrix[125][0] = 9;
		matrix[125][1] = 2;
		
		matrix[126][0] = 2;
		matrix[126][1] = 5;
		
		matrix[127][0] = 2;
		matrix[127][1] = 6;

		matrix[128][0] = 1;
		matrix[128][1] = 7;
		
		matrix[129][0] = 9;
		matrix[129][1] = 1;
	
		matrix[130][0] = 1;
		matrix[130][1] = 3;
		
		matrix[131][0] = 0;
		matrix[131][1] = 7;
	
		matrix[132][0] = 8;
		matrix[132][1] = 3;
		
		matrix[133][0] = 7;
		matrix[133][1] = 3;
	
		matrix[134][0] = 9;
		matrix[134][1] = 0;
		
		matrix[135][0] = 1;
		matrix[135][1] = 4;
				
		matrix[136][0] = 8;
		matrix[136][1] = 2;
		
		matrix[137][0] = 4;
		matrix[137][1] = 3;
	
		matrix[138][0] = 5;
		matrix[138][1] = 3;
		
		matrix[139][0] = 6;
		matrix[139][1] = 3;
	
		matrix[140][0] = 1;
		matrix[140][1] = 5;
		
		matrix[141][0] = 1;
		matrix[141][1] = 2;
	
		matrix[142][0] = 1;
		matrix[142][1] = 6;
		
		matrix[143][0] = 0;
		matrix[143][1] = 6;
	
		matrix[144][0] = 8;
		matrix[144][1] = 1;
		
		matrix[145][0] = 0;
		matrix[145][1] = 3;
	
		matrix[146][0] = 3;
		matrix[146][1] = 2;
		
		matrix[147][0] = 8;
		matrix[147][1] = 0;
	
		matrix[148][0] = 0;
		matrix[148][1] = 4;
	
		matrix[149][0] = 0;
		matrix[149][1] = 2;
		
		matrix[150][0] = 4;
		matrix[150][1] = 2;
	
		matrix[151][0] = 0;
		matrix[151][1] = 5;
		
		matrix[152][0] = 7;
		matrix[152][1] = 2;
		
		matrix[153][0] = 5;
		matrix[153][1] = 2;
	
		matrix[154][0] = 6;
		matrix[154][1] = 2;
		
		matrix[155][0] = 7;
		matrix[155][1] = 1;
	
		matrix[156][0] = 0;
		matrix[156][1] = 1;
		
		matrix[157][0] = 3;
		matrix[157][1] = 1;
		
		matrix[158][0] = 7;
		matrix[158][1] = 0;
		
		matrix[159][0] = 4;
		matrix[159][1] = 1;
		
		matrix[160][0] = 2;
		matrix[160][1] = 1;
	
		matrix[161][0] = 6;
		matrix[161][1] = 1;

		matrix[162][0] = 5;
		matrix[162][1] = 1;

		matrix[163][0] = 6;
		matrix[163][1] = 1;
	
		matrix[164][0] = 3;
		matrix[164][1] = 0;
	
		matrix[165][0] = 2;
		matrix[165][1] = 0;
	
		matrix[166][0] = 4;
		matrix[166][1] = 0;
	
		matrix[167][0] = 5;
		matrix[167][1] = 0;
	
		matrix[168][0] = 1;
		matrix[168][1] = 0;
	
		return matrix;	
	}
	
}


