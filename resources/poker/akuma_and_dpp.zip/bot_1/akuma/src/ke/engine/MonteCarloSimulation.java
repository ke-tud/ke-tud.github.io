package ke.engine;

import java.security.SecureRandom;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;
import ke.client.dummy.OpponentStatistics;
import ke.data.*;


public class MonteCarloSimulation {
	
	private int lastMCEV = -99; 

	/**
	 * Startet aus einer beliebigen Spielphase eine komplette MCSimulation.
	 * @param playerCards
	 * @param board
	 * @param roundBets
	 * @param roundIndex
	 * @param pot
	 * @param inPot
	 * @param lastActionSeat
	 * @param seatTaken
	 * @param rounds
	 * @return
	 */
	public Action runCompleteSimulation(Card[] playerCards, Card[] board, int roundBets,
			int roundIndex, int[] inPot, int pot, int lastActionSeat, int lastActionPot, int seatTaken, int numSeats,
			int numActiveSeats, int rounds, int time, McPlayer[] players, boolean isFirstActionOnRound){
		// HandRanges Testen
		
		
//		for (int i = 0; i < 3; i++) {
//			if(i != seatTaken && players[i].isActive()){
//			System.out.println(players[i]);
//			for (int x = 0; x < 13; x++) {
//				for (int y = 0; y < 13; y++) {
//						System.out.print(players[i].getHandRange()[x][y]);
//						System.out.print(" / ");	
//				}
//				System.out.println("");
//			}
//			}
//			System.out.println("");
//		}
		
		
		// H�chten Potbeitrag bestimmen
		long startTime = System.currentTimeMillis();
		
		McPlayer player = players[seatTaken];
		
		// Player Hand erstellen und verteilen
		Hand playerHand = new Hand();
		playerHand.addCard(new ke.data.Card(playerCards[0].rank.ordinal(),playerCards[0].suit.ordinal()));
		playerHand.addCard(new ke.data.Card(playerCards[1].rank.ordinal(),playerCards[1].suit.ordinal()));
		player.addHand(playerHand);
	
		// �berpr�fung der bereits aufgedeckten Karten
		Board gameBoard = new Board();
		int discoveredBoardCards = 0;
		
		for (; discoveredBoardCards < board.length; discoveredBoardCards++) {
			if(board[discoveredBoardCards]!=null){	
				gameBoard.addCard(new ke.data.Card(board[discoveredBoardCards].rank.ordinal(),board[discoveredBoardCards].suit.ordinal()));
			}else
				break;
		}
		
		// Anzahl Fehlender Board Karten bestimmen.
		discoveredBoardCards = 5 - discoveredBoardCards;
		
		//Zufallskarten
		Card[] randomCards;
		int[] reward = new int[2];
		// spielen 
//		int i = 0;
//		double currentTime = System.currentTimeMillis();
		for (int i = 0; i < rounds; i++) {
//		while ( (currentTime - startTime)/1000 < time ){
			// Eine Runde spielen
			
			for(int j = 0; j < players.length; j++) {
				players[j].reset();
			}
			
			randomCards = generateMissingCards(discoveredBoardCards, playerCards, board, players, seatTaken, numActiveSeats); 
//			System.out.println("RandomCards");
//			for (int j = 0; j < randomCards.length; j++) {	
//				System.out.print(randomCards[j]);
//				System.out.print(" /");
//			}
//			System.out.println(" ");
			Board completeBoard = createNewBoard(gameBoard, randomCards, discoveredBoardCards);
//			System.out.println("BoardCards");
//			for (Iterator iterator = completeBoard.getCards().iterator(); iterator.hasNext();) {
//				ke.data.Card card = (ke.data.Card) iterator.next();
//				System.out.print(card);
//				System.out.print(" /");
//			}
//			System.out.println(" ");
			// Gegnerische Karten verteilen
			int n = 0;
			for(int j = 0; j < players.length; j++) {
				if(j != seatTaken && players[j].isActive() ){
					Hand opponentHand = new Hand();
					opponentHand.addCard(new ke.data.Card(randomCards[discoveredBoardCards+n*2].rank.ordinal(),randomCards[discoveredBoardCards+n*2].suit.ordinal()));
					opponentHand.addCard(new ke.data.Card(randomCards[discoveredBoardCards+n*2+1].rank.ordinal(),randomCards[discoveredBoardCards+n*2+1].suit.ordinal()));
					players[j].addHand(opponentHand);
//					System.out.print("Opponent:");
//					System.out.println(players[j]);
//					System.out.println(players[j].getHand().getHandRank(new ke.data.Board()));
//					System.out.println(players[j].getInpot());
//					System.out.println(players[j].getStack());
//					System.out.println(players[j].getHandRangeSum());
					n++;
				}
			}
//			System.out.println("Player:");
//			System.out.println(player.getHand().getHandRank(new ke.data.Board()));
//			System.out.println(player.getInpot());
//			System.out.println(player.getStack());
			// Erster Kindknoten Call Action
 			reward[0] += runOneSimulation(players, completeBoard, pot, roundBets, roundIndex, 
 					lastActionSeat, seatTaken, numActiveSeats, lastActionPot, Action.CALL, isFirstActionOnRound);
 			
 			for(int j = 0; j < players.length; j++) {
				players[j].reset();
			}
	
 			if(roundBets<4){
 				// Eine Runde spielen
//				randomCards = generateMissingCards(discoveredBoardCards, playerCards, board, actualOpponents); 
//				completeBoard = createNewBoard(gameBoard, randomCards, discoveredBoardCards);
 				// Gegnerische Karten verteilen
// 				for(int j = 0; j < players.length; j++) {
// 					if(j != seatTaken && players[j].isActive() ){
// 					Hand opponentHand = new Hand();
// 					opponentHand.addCard(new ke.data.Card(randomCards[discoveredBoardCards+j*2].rank.ordinal(),randomCards[discoveredBoardCards+j*2].suit.ordinal()));
// 					opponentHand.addCard(new ke.data.Card(randomCards[discoveredBoardCards+j*2+1].rank.ordinal(),randomCards[discoveredBoardCards+j*2+1].suit.ordinal()));
// 					actualOpponents[j].addHand(opponentHand);
// 						System.out.print("Opponent:");
// 						System.out.println(players[j]);
// 						System.out.println(players[j].getHand().getHandRank(new ke.data.Board()));
// 						System.out.println(players[j].getInpot());
// 						System.out.println(players[j].getStack());
// 					}
// 				}
// 				System.out.println("Player:");
// 				System.out.println(player.getHand().getHandRank(new ke.data.Board()));
// 				System.out.println(player.getStack());
 								
 				// 	zweiter Kindknoten Raise Action
 				reward[1] += runOneSimulation(players, completeBoard, pot, roundBets, roundIndex, 
 						lastActionSeat, seatTaken, numActiveSeats, lastActionPot, Action.RAISE, isFirstActionOnRound);
 			
 			}else{
 				reward[1] = -99;
 			}
// 			i++;
// 			currentTime = System.currentTimeMillis();
		}
//		System.out.print("RUNDEN:");
//		System.out.println(i);
		reward[0]= reward[0]/rounds;
		if(reward[1]!=-99)
			reward[1]= reward[1]/rounds;
//		System.out.println("--Rewards--");
//		System.out.print("HandKarten:");
//		System.out.println(player.getHand());
//		System.out.print("BoardKarten:");
//		for (int i = 0; i < board.length; i++) {
//			System.out.println(board[i]);
//		}
//		System.out.print("Call:");
//		System.out.println(reward[0]);
//		System.out.print("Raise:");
//		System.out.println(reward[1]);
//		System.out.print("Aktueller Poteinsatz:");
//		System.out.println(inPot[seatTaken]);
//		System.out.println("--Rewards-Ende--");
		
		// Actionbestimmung
//	    if(reward[0]<(-inPot[seatTaken]/2) && reward[1]<(-inPot[seatTaken]/2)){
//	    if(reward[0]<0 && reward[1]<0)
		int temp = 0 - roundIndex*2;
//		for (int i = 0; i < players.length; i++) {
//			if (!players[i].equals(player)) {
//				if(players[i].isActive() && players[i].getLastAction() != null && players[i].getLastAction().equals(Action.RAISE))
//					temp += 2;
//			}
//		}
//		System.out.println("TEMP MC");
//		System.out.println(temp);

		if(reward[0] < temp && reward[1] < temp){
			lastMCEV = -99;
			return Action.FOLD;
		}else
			if(reward[0]+temp>reward[1]){
				lastMCEV = reward[0];
				return Action.CALL;
			}else{
				lastMCEV = reward[1];
				return Action.RAISE;
			}
	}
	/**
	 * 
	 * @return
	 */
	public int getLastMCEV(){
		return lastMCEV;
	}
	
	/**
	 * Spielt eine Partie zuf�llig zuende bzw macht einen MC Simulationsdurchlauf.
	 * opponents muss geordnet sein
	 */
	public static int runOneSimulation(McPlayer[] players, Board gameBoard, int pot, 
			int roundBets, int roundIndex, int lastActionSeat, int seatTaken, int numActiveSeats, int lastActionPot, Action action, boolean isFirstAction){
			
		McPlayer player = players[seatTaken];
		McPlayer[] playersInSeat = players.clone();
		
//		System.out.println("------ROS------");	
//		System.out.println(playersInSeat[0]);
//		System.out.println(playersInSeat[0].isActive());
//		System.out.println(playersInSeat[1]);
//		System.out.println(playersInSeat[1].isActive());
//		System.out.println(playersInSeat[2]);
//		System.out.println(playersInSeat[2].isActive());
//		System.out.println(numActiveSeats);
//		System.out.println(lastActionPot);
//		System.out.println(lastActionSeat);
//		System.out.println(isFirstAction);
//		System.out.println(roundIndex);
//		System.out.println("------ROS------");

		if(seatTaken == lastActionSeat || isFirstAction){
			lastActionSeat = -1;
			isFirstAction = true;
			if(roundIndex == 0)
				lastActionPot = 2;
			else
				lastActionPot = playersInSeat[seatTaken].getInpot();
		}else{
			if(lastActionPot < playersInSeat[lastActionSeat].getInpot())
				lastActionPot = playersInSeat[lastActionSeat].getInpot();
		}
		
		
		
		Action currentAction;
		int callBets = 0; 
		boolean isBetAllowed = true;
		int i = seatTaken;
		int numFold = 3 - numActiveSeats;
		
		for(int round = roundIndex; round < 4; round++){
			// Eine Random Betrunde.			
			while (i != lastActionSeat) {	
				while (i < playersInSeat.length && i != lastActionSeat){
					if(playersInSeat[i].isActive() != false){

//						System.out.println("---Pre-Rundenstatus---");
//						System.out.print("i:");
//						System.out.println(i);
//						System.out.print("GameRound:");
//						System.out.println(round);
//						System.out.print("Pot:");
//						System.out.println(pot);
//						System.out.print("Players inPot:");
//						System.out.println(playersInSeat[i].getInpot());
//						System.out.print("LastActionSeat:");
//						System.out.println(lastActionSeat);
//						System.out.print("LastActionPot:");
//						System.out.println(lastActionPot);
//						System.out.print("Roundbets:");
//						System.out.println(roundBets);
//						if(playersInSeat[i].equals(player))
//							System.out.println("Player:");
//						
//						System.out.println("---Pre-Rundenstatus-Ende---");

						if(roundBets >= 4)
							isBetAllowed = false;
						// Zur Pottberechnung
						callBets = playersInSeat[i].getInpot();
						// Wurzel der MC Simulation die von au�en bestimmt wird
						if (playersInSeat[i].equals(player) && action != null) {
							currentAction = playersInSeat[i].play(pot, lastActionPot, 
									isBetAllowed, round, action);
							action = null;
						}else{
							// restliches zuf�lliges Spielen 
							currentAction = playersInSeat[i].play(pot,lastActionPot, 
									isBetAllowed,roundIndex+round, null);
						}
						
//						System.out.println(playersInSeat[i].getHand().getHandRank(gameBoard));
//						System.out.print("CurrentAction:");
//						System.out.println(currentAction);
						
						pot = pot + (playersInSeat[i].getInpot() - callBets);
						
						if(currentAction.equals(Action.RAISE)){
							lastActionSeat = i;
							roundBets++;	
						}
						if(currentAction.equals(Action.FOLD)){
							// 	Verloren 
							if(playersInSeat[i].equals(player)){
//								System.out.println("Verloren");
//								System.out.println(-playersInSeat[i].getInpot());
								return -playersInSeat[i].getInpot();
							}else
								playersInSeat[i].setActive(false);
							
							numFold++;
							// 	Gewonnen
							if(numFold > 3){
//								System.out.println("Gewonnen");
//								System.out.println(pot-player.getInpot());
								return pot-player.getInpot();
							}
						}else{
							if(isFirstAction){
								lastActionSeat = i;
								isFirstAction = false;
							}
						}
						if(lastActionPot < playersInSeat[lastActionSeat].getInpot())
							lastActionPot = playersInSeat[lastActionSeat].getInpot();
						
					}//end_if
					i++;
				}//end_while
				if(i >= playersInSeat.length)
					i = 0;
			}//end_while
			
			// Neue Betrunde initialisieren
			isFirstAction = true;
	//		lastActionPot = playersInSeat[0].getInpot();
			lastActionSeat = -1;
			roundBets = 0;
			i = 0;
		}//end_for
		
		//Handevaluierung der restlichen Gegner
		for (int j = 0; j < playersInSeat.length; j++) {
			if( playersInSeat[j].isActive()  && !playersInSeat[j].equals(player) &&
				player.getHand().getHandRank(gameBoard).compareTo(playersInSeat[j].getHand().getHandRank(gameBoard))  < 0){
				// Verloren 
//				System.out.println("Verloren");
//				System.out.println(-player.getInpot());
				return -player.getInpot();
			}
		}
		
		for (int j = 0; j < playersInSeat.length; j++) {
			if( playersInSeat[j].isActive()  && !playersInSeat[j].equals(player) &&
				player.getHand().getHandRank(gameBoard).compareTo(playersInSeat[j].getHand().getHandRank(gameBoard))  == 0){
				// SplitPot Nicht ganz richtig kann ja auch einer schon gefoldet haben aber egal =) 
				// System.out.println("Split");
				return 0;
			}
		}
		// Gewonnen
//		System.out.println("Gewonnen");
//		System.out.println(pot-player.getInpot());
		return pot-player.getInpot();
	}
		
	/**
	 * Generiert Zufallskarten, wobei die �bergebenen Karten nicht doppelt auftreten werden.
	 * @param discoveredBoardCards
	 * @param playerCards
	 * @param board
	 * @return
	 */
	public static Card[] generateMissingCards(int discoveredBoardCards, Card[] playerCards, Card board[], McPlayer[] players, int seatTaken, int numActiveSeats){

//		Card[] randomCards = Card.dealNewArray(new SecureRandom(),discoveredBoardCards + (numActiveSeats-1) * 2);
//		
//		// Rausfiltern der doppelten RandomKarten erstellen
//		int length = randomCards.length;
//		List<Card> cardPool = new LinkedList<Card>();
//		cardPool.add(playerCards[0]);
//		cardPool.add(playerCards[1]);
//		for (int j = 0; j < 5 - discoveredBoardCards ; j++){
//			cardPool.add(board[j]);
//		}
//		for (int j = 0; j < length; j++) {
//			while(cardPool.contains(randomCards[j])){
//				randomCards[j] = Card.dealNewArray(new SecureRandom(),1)[0];	
//			}
//			cardPool.add(randomCards[j]);
//		}	
//			
//		return randomCards;
		
		//fehlende Karten zuf�llig nachf�llen.	
		Card[] randomCards = new Card[discoveredBoardCards + (numActiveSeats-1) * 2];
		for (int i = 0; i < discoveredBoardCards; i++) {
			randomCards[i] = Card.dealNewArray(new SecureRandom(),discoveredBoardCards)[i];
		}
		
		// Rausfiltern der doppelten RandomKarten erstellen
		int length = discoveredBoardCards;
		List<Card> cardPool = new LinkedList<Card>();
		cardPool.add(playerCards[0]);
		cardPool.add(playerCards[1]);
		for (int j = 0; j < 5 - discoveredBoardCards ; j++){
			cardPool.add(board[j]);
		}
		for (int j = 0; j < length; j++) {
			while(cardPool.contains(randomCards[j])){
				randomCards[j] = Card.dealNewArray(new SecureRandom(),1)[0];
			}
			cardPool.add(randomCards[j]);
		}	
		
		
		// 4 Fehlende Gegenerkarten 
		double[][] handRange;
		double handRangeSum;
		double value = 0;
		double random_number;
		SecureRandom random = new SecureRandom();
		int z = 0;
		for (int i = 0; i < players.length; i++) {
//			 System.out.println(players[i]);
//			 System.out.println(players[i].isActive());
			 if(players[i].isActive() && i != seatTaken){
				 value = 0; 
				 handRange = players[i].getHandRange();
				 handRangeSum = players[i].getHandRangeSum();
				 random_number = random.nextDouble() * handRangeSum;
				 // In der HandRange nach dem randomNumber Wert gucken
				 // Wenn kleiner 0.9945 dann von vorne anfangen, sonst von hinten durchgehen
				 int x = 0;
				 int y = 0;
				 boolean isFound = false;
				 if(random_number <= handRangeSum/2){
					 for (x = 0; x < 13 && !isFound; x++) {
						 for (y = 0; y < 13; y++) {
							 value += handRange[x][y];
							 if (value >= random_number) {
								 isFound = true;
								 // um das +1 der �u�eren schleife auszugleichen
								 x -= 1;
								 break;
							 }
						 }
					 }
				 }else{
					 value = handRangeSum;
					 for (x = 12; x >= 0 && !isFound; x--) {
						 for (y = 12; y >= 0; y--) {
							 value -= handRange[x][y];
							 if (value <= random_number) {
								 isFound = true;
								 // um das -1 der �u�eren schleife auszugleichen
								 x += 1;
								 break;
							 }
						 }
					 }
				 }
//				 System.out.println(value);
//				 System.out.println(random_number);
//				 System.out.println(x);
//				 System.out.println(y);
				 int n = 0;
				 boolean falseSuit = false; 
				 // Das gefundene Kartenpaar jetzt genau bestimmen und auf doppelte Karten pr�fen
				 for (int j = 0; j < 2; j++) {
					 int abort = 0;				 
					 n = x;
					 if(j == 1)
						 n = y;
					 do {
//						 System.out.print("ABORT:");
//						 System.out.println(abort);
//						 System.out.print(i);
//						 System.out.print(" ");
//						 System.out.print(j);
//						 System.out.print(" ");
//						 System.out.println(z);
//						 System.out.print(" ");
						 falseSuit = false;
						 random_number = random.nextDouble();					
//             	    	 System.out.println(random_number);
						 
						 if(abort > 4){
							 randomCards[discoveredBoardCards + z*2 + j] = Card.dealNewArray(new SecureRandom(),1)[0];
//					     System.out.println("NEW ABORT RANDOM CARD");
//						 System.out.println(randomCards[discoveredBoardCards + z*2 + j]);
//						 System.out.println("NEW ABORT RANDOM CARD");
						 }else{
							 // suited
							 if(j == 1 && x < y){
								 randomCards[discoveredBoardCards + z*2 + j] = new Card(Rank.toRank(n),Suit.toSuit(randomCards[discoveredBoardCards + z*2].suit.ordinal()));
								 abort = 4;
							 }else{ 
								 if(random_number <= 0.25)
									 randomCards[discoveredBoardCards + z*2 + j] = new Card(Rank.toRank(n),Suit.toSuit(0));
								 else if(random_number <= 0.5)	
									 randomCards[discoveredBoardCards + z*2 + j] = new Card(Rank.toRank(n),Suit.toSuit(1));
								 else if(random_number <= 0.75)
				 							randomCards[discoveredBoardCards + z*2 + j] = new Card(Rank.toRank(n),Suit.toSuit(2));
			 							else
			 								randomCards[discoveredBoardCards + z*2 + j] = new Card(Rank.toRank(n),Suit.toSuit(3)); 			
							 //		offSuited
								 if(j == 1 && x > y && randomCards[discoveredBoardCards + z*2 + j].suit.equals(randomCards[discoveredBoardCards + z*2].suit)) 
									 falseSuit = true;
							 }
						 }
						 abort++;
//						 System.out.print("Try:");
//						 System.out.println(randomCards[discoveredBoardCards + z*2 + j]); 
					 } while ( cardPool.contains(randomCards[discoveredBoardCards + z*2 + j]) || falseSuit );
//    				 System.out.print("ACCEPT:");
//	    			 System.out.println(randomCards[discoveredBoardCards + z*2 + j]);
					 cardPool.add(randomCards[discoveredBoardCards + z*2 + j]);
				 }
				 z++;
			 }
			}

		return randomCards;
	}
		
	/**
	 * erstellt ein neues Board aus bereits aufgedeckten karten und fehlenden random Kartn.
	 * @param board
	 * @param randomCards
	 * @param discoveredBoardCards
	 * @return
	 */
	public static ke.data.Board createNewBoard(Board board, Card[] randomCards, int discoveredBoardCards){
		ke.data.Board gameBoard = new ke.data.Board();
		List<ke.data.Card> cards = board.getCards();
		for (Iterator<ke.data.Card> iterator = cards.iterator(); iterator.hasNext();) {			
			gameBoard.addCard((ke.data.Card) iterator.next());
		}
			
		for (int j = 0; j < discoveredBoardCards; j++) {
			gameBoard.addCard(new ke.data.Card(randomCards[j].rank.ordinal(),randomCards[j].suit.ordinal()));	
		}
			
		return gameBoard;
	}
	
}
