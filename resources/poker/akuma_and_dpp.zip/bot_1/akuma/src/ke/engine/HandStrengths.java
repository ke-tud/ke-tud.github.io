package ke.engine;

import java.util.Arrays;
import java.util.Random;
import ke.client.dummy.winprobability.Deck;
import ca.ualberta.cs.poker.free.dynamics.Card;
import ke.handevaluator.HandEval;

public class HandStrengths{
	Deck deck = new Deck();
	int ehs[][] = new int[169][2];
	Random rand = new Random();

	/**
	 * 
	 * @param player the two cards of the player
	 * @param community the 3, 4 or 5 community cards
	 * @param validCommunity the number of valid community cards (3 for flop, 4 for river, 5 for turn)
	 * @param maxDuration on a Pentium M 1600 MHz a duration of ~<i>1400</i> milliseconds is needed for the desired 10000 simulations
	 * @param maxSimulations a good accuracy is reached if this value is >=<i>10000</i>
	 * @param j 
	 */
	public void updateHandStrength(Card player[], Card community[], int validCommunity, int maxDuration, int maxSimulations){
		long startTime = System.currentTimeMillis();
		EHS handList[] = new EHS[169];
		boolean deck[] = new boolean[52];
		for(int x = 0; x < 13; ++x){
			final int offset = x*13;
			for(int y = 0; y < 13; ++y)
				handList[offset+y] = new EHS(x, y);
		}
		
		long known = 0;
		// remove player and known community cards from deck
		for(int i = 0; i < player.length; ++i)
			deck[player[i].getIndexSuitMajor()] = true;
		for(int i = 0; i < validCommunity; ++i){
			deck[community[i].getIndexSuitMajor()] = true;
			known |= getCard(community[i].rank.index, community[i].suit.index);
		}

		final int remainingCommunity = 5 - validCommunity;
		int simulatedComunity[] = new int[remainingCommunity];
		for(int i = 1; i < maxSimulations; ++i){
			if((i&0xFF) == 0){ // alle 256 Simulationen "auf die Uhr gucken"
				if(System.currentTimeMillis() - startTime >= maxDuration){
					break;
				}
			}
			
			long simulated = 0;
			for(int k = 0; k < simulatedComunity.length; ++k){
				do{
					simulatedComunity[k] = rand.nextInt(52);
				}while(deck[simulatedComunity[k]]);
				deck[simulatedComunity[k]] = true;
				simulated |= getCard(simulatedComunity[k] % 13, simulatedComunity[k] / 13);
			}
			for(int x = 0; x < 52; ++x){
				if(!deck[x]){ // if card is not dealt
					final int xSuit = x / 13;
					final int xRank = x % 13;
					for(int y = x+1; y < 52; ++y){
						if(!deck[y]){ // if card is not dealt
							final int ySuit = y / 13;
							final int yRank = y % 13;
							int ehsX, ehsY;
							if(xSuit == ySuit){
								ehsX = Math.min(xRank, yRank);
								ehsY = Math.max(xRank, yRank);
							}
							else{
								ehsX = Math.max(xRank, yRank);
								ehsY = Math.min(xRank, yRank);								
							}
							final int index = ehsX*13 + ehsY;
							long hand = 0;
							hand |= getCard(xRank, xSuit);
							hand |= getCard(yRank, ySuit);
							if(handList[index].x != ehsX || handList[index].y != ehsY)
								System.err.println(handList[index].x + "!=" + ehsX  + " || " + handList[index].y + "!=" + ehsY);
							try{
								long handValue = HandEval.hand7Eval(hand | known | simulated);
								handList[index].weight += handValue;								
								handList[index].count++;
/*								long fourAcesAndQueen = getCard(2, 0) |  getCard(2, 1) |  getCard(8, 2) |  getCard(4, 3) |  getCard(10, 0);
								if(((hand | known | simulated) & fourAcesAndQueen) == fourAcesAndQueen){
									System.err.println("Four Aces:" + handValue);
								}*/
							} catch(Exception e){
								System.err.println("Exception @" + hand + " + " + known + " + " + simulated + " (" + (hand | known | simulated) + ")");
							}
						}
					}
				}
			}
			for(int k = 0; k < simulatedComunity.length; ++k){
				deck[simulatedComunity[k]] = false;
			}
		}
		Arrays.sort(handList);
		for(int i = 0; i < ehs.length; ++i){
			ehs[i][0] = handList[i].x;
			ehs[i][1] = handList[i].y;
			//System.out.printf("%03d (%2d,%2d): %d\r\n", i, ehs[i][0], ehs[i][1], handList[i].getWeight());
		}
	}
	
	private static long getCard(int rank, int suit){
		//return HandEval.encode(new com.stevebrecher.poker.Card(Rank.values()[rank], Suit.values()[suit]));
		return 0x1L << (suit*13 + rank);
	}
	
	public final int[][] getHandStrengths(){
		return ehs;
	}

	private class EHS implements Comparable{
		public long weight;
		public long count;
		public int x, y;
		
		EHS(int x, int y){
			this.x = x;
			this.y = y;
			this.count = 1;
		}

		@Override
		public int compareTo(Object o){
			return ((EHS)o).getWeight().compareTo(getWeight());
		}
		
		private Long getWeight(){
			return Long.valueOf(weight/Math.max(count, 0x1l));
		}
	}
	
	public static void main(String args[]){
		// up to five community cards
		Card c1 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.THREE, ca.ualberta.cs.poker.free.dynamics.Card.Suit.HEARTS);
		Card c2 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.FOUR, ca.ualberta.cs.poker.free.dynamics.Card.Suit.SPADES);
		Card c3 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.SEVEN, ca.ualberta.cs.poker.free.dynamics.Card.Suit.CLUBS);
		Card c4 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.TWO, ca.ualberta.cs.poker.free.dynamics.Card.Suit.CLUBS);
		Card c5 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.JACK, ca.ualberta.cs.poker.free.dynamics.Card.Suit.CLUBS);

		// our own two cards
		Card p1 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.FIVE, ca.ualberta.cs.poker.free.dynamics.Card.Suit.HEARTS);
		Card p2 = new Card(ca.ualberta.cs.poker.free.dynamics.Card.Rank.FIVE, ca.ualberta.cs.poker.free.dynamics.Card.Suit.SPADES);
		
		HandStrengths hs = new HandStrengths();

		long start = System.currentTimeMillis();
		
		final int visibleCommunityCards = 3;	// only the first three cards should currently be visible, so two sevens would be the best fole cards
		//final int visibleCommunityCards = 4;	// only the first four cards should currently be visible, so a five and a six suited (clubs!) will make a straight
		//final int visibleCommunityCards = 5;	// all cards are visible, a five and a six suited are still the best (straight) followed by ace+two (smaller straight)
		// update
		hs.updateHandStrength(new Card[]{p1, p2}, new Card[]{c1, c2, c3, c4, c5}, visibleCommunityCards, 1500, 10000);
		
		// get the list
		int ehs[][] = hs.getHandStrengths();
		
		System.out.println("Duration:" + (System.currentTimeMillis() - start));
		for(int i = 0; i < ehs.length; ++i){
			System.out.printf("%03d: (%2d,%2d)\r\n", i, ehs[i][0], ehs[i][1]);
		}
	}
}