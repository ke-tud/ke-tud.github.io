package ke.client;

import java.security.SecureRandom;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import ke.data.Action;
import ke.data.Board;
import ke.data.Hand;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class MCSimulation {
	
	/**
	 * Anmerkunf aktuele Potsize gr��e ebenfalls beachten
	 * F�hrt eine bestimmte Anzahl an MC Simulationen mit bestimmten Karten aus. 
	 * @param gameState: Informationen �ber den aktuelle Zustand:
	 * 			0:pottgr��e
	 *          1:Call beitrag
	 *          2:Anzahl der Bets in dieser Runde
	 *          3:Aktueller Zustand
	 *          4:Pottbeitrag
	 * @param board: karten auf dem Board, enth�lt aufgedeckte und nicht aufgedekte Karten.
	 * @param playerCards: Kartenpaar f�r die MC Simulationswurzel
	 * @param rounds: Rundenanzahl f�r die Durchlaufsanzahl der MC Simulation durch einen Knoten.
	 * @return Action: liefert die beste ermittelte Action mittels MC Simulationen.
	 */
	public static Action runMCSimulation(Card[] playerCards, Card[] board, int[] gameState, int rounds, int seatTaken) {
		// Player Hand erstellen
		Hand playerHand = new Hand();
		playerHand.addCard(new ke.data.Card(playerCards[0].rank.ordinal(),playerCards[0].suit.ordinal()));
		playerHand.addCard(new ke.data.Card(playerCards[1].rank.ordinal(),playerCards[1].suit.ordinal()));
		
		// �berpr�fung der aufgedeckten Karten
		ke.data.Board gameBoard = new ke.data.Board();
		int discoveredBoardCards = 0;
		
		for (; discoveredBoardCards < board.length; discoveredBoardCards++) {
			if(board[discoveredBoardCards]!=null)
				gameBoard.addCard(new ke.data.Card(board[discoveredBoardCards].rank.ordinal(),board[discoveredBoardCards].suit.ordinal()));
			else
				break;
		}
		
		// Anzahl Fehlender Board Karten bestimmen.
		discoveredBoardCards = 5 - discoveredBoardCards;
		
		//Reward f�r bet/raise = 0 und call/check = 1.
		int reward[] = new int[2];
		
		//MC Simulationnen f�r bet/raise und call/check starten und reward bestimmen. 
		int newPot;
		int callBets;
		int myInPot;
		int betsPerRound;
		int allCalls = 0;
		int ergebnis;
		Card[] randomCards;
		for (int i = 0; i < rounds; i++) {
			randomCards = generateMissingCards(discoveredBoardCards, playerCards, board);
			ke.data.Board callBoard = createNewBoard(gameBoard, randomCards, discoveredBoardCards);
			
			// Gegnerische Karten verteilen
			Hand opponentHands[] = new Hand[2];
			opponentHands[0] = new Hand();
			opponentHands[0].addCard(new ke.data.Card(randomCards[discoveredBoardCards].rank.ordinal(),randomCards[discoveredBoardCards].suit.ordinal()));
			opponentHands[0].addCard(new ke.data.Card(randomCards[discoveredBoardCards+1].rank.ordinal(),randomCards[discoveredBoardCards+1].suit.ordinal()));
			opponentHands[1] = new Hand();
			opponentHands[1].addCard(new ke.data.Card(randomCards[discoveredBoardCards+2].rank.ordinal(),randomCards[discoveredBoardCards+2].suit.ordinal()));
			opponentHands[1].addCard(new ke.data.Card(randomCards[discoveredBoardCards+3].rank.ordinal(),randomCards[discoveredBoardCards+3].suit.ordinal()));
			
		
			// Wurzel der MC Simulation 
			// Player Call
			callBets = gameState[1];
			newPot = gameState[0] + callBets;
			myInPot = gameState[4] + callBets;
			betsPerRound = gameState[2];
			if(callBets == 0)
				allCalls = seatTaken; // STIMMT NICHT GANZ ! 
			else
				allCalls = 1;
			int lastBet;
			if(seatTaken==0){
				lastBet = 0;
			}else{
				lastBet = 2; // Stimmt nicht ganz k�nnte auch der andere sein.
			}
			
			ergebnis = oneMCSimulation(playerHand, callBoard, opponentHands, newPot, myInPot, betsPerRound, gameState[3], allCalls+1,new LinkedList<Action>(), lastBet); // 2 Stimmt nicht ganz k�nnte auch 1 sein aber vernachl�ssigbar
			reward[0] += ergebnis;
			System.out.print("Erebnis f�r CALL:");
			System.out.println(ergebnis);
			System.out.println("---Eine-MC-Simulation-Ende---");	
			
			// Wurzel der MC Simulation
			// Raise
			randomCards = generateMissingCards(discoveredBoardCards, playerCards, board);
			ke.data.Board raiseBoard = createNewBoard(gameBoard, randomCards, discoveredBoardCards);
			
			// Gegnerische Karten verteilen
			opponentHands[0] = new Hand();
			opponentHands[0].addCard(new ke.data.Card(randomCards[discoveredBoardCards].rank.ordinal(),randomCards[discoveredBoardCards].suit.ordinal()));
			opponentHands[0].addCard(new ke.data.Card(randomCards[discoveredBoardCards+1].rank.ordinal(),randomCards[discoveredBoardCards+1].suit.ordinal()));
			opponentHands[1] = new Hand();
			opponentHands[1].addCard(new ke.data.Card(randomCards[discoveredBoardCards+2].rank.ordinal(),randomCards[discoveredBoardCards+2].suit.ordinal()));
			opponentHands[1].addCard(new ke.data.Card(randomCards[discoveredBoardCards+3].rank.ordinal(),randomCards[discoveredBoardCards+3].suit.ordinal()));
		
			
			if(gameState[2] < 4){
				newPot = gameState[0] + callBets;
				myInPot = gameState[4] + callBets;
				betsPerRound = gameState[2] + 1;				
				allCalls = 0; 
			
				ergebnis = oneMCSimulation(playerHand, raiseBoard, opponentHands, newPot, myInPot, betsPerRound+1, gameState[3], allCalls, new LinkedList<Action>(), 0); // 0 player letzter Beter
				reward[1] += ergebnis;
				System.out.print("Ergebnis f�r RAISE:");
				System.out.println(ergebnis);
				System.out.println("---Eine-MC-Simulation-Ende---");	
			}else{
				reward[1]= -1;
	//			System.out.println("---KEIN RAISE ERLAUBT---");
			}
		}
		
		System.out.println("Rewards:");
		System.out.println(reward[0]);
		System.out.println(reward[1]);
		System.out.println("Urspr�nglicher Pottbeitrag:");
		System.out.println(gameState[4]);
		//Ergebnisevaluirung, wenn beide MC Rewards negativ dann folden
		if(reward[0]<gameState[4] && reward[1]<gameState[4])
			return Action.FOLD;
		else
			if(reward[0]>reward[1])
				return Action.CALL;
			else
				return Action.RAISE;
	}
	
	
	public static int runOneMCSimulation(Card[] playerCards, Card[] board, int[] gameState, int seatTaken, LinkedList<Action> action) {
		// Player Hand erstellen
		Hand playerHand = new Hand();
		playerHand.addCard(new ke.data.Card(playerCards[0].rank.ordinal(),playerCards[0].suit.ordinal()));
		playerHand.addCard(new ke.data.Card(playerCards[1].rank.ordinal(),playerCards[1].suit.ordinal()));
		
		// �berpr�fung der aufgedeckten Karten
		ke.data.Board gameBoard = new ke.data.Board();
		int discoveredBoardCards = 0;
		
		for (; discoveredBoardCards < board.length; discoveredBoardCards++) {
			if(board[discoveredBoardCards]!=null)
				gameBoard.addCard(new ke.data.Card(board[discoveredBoardCards].rank.ordinal(),board[discoveredBoardCards].suit.ordinal()));
			else
				break;
		}
		
		// Anzahl Fehlender Board Karten bestimmen.
		discoveredBoardCards = 5 - discoveredBoardCards;
		
		int reward = 0;
		//MC Simulationnen f�r bet/raise und call/check starten und reward bestimmen. 
		int newPot;
		int callBets;
		int myInPot;
		int betsPerRound;
		int allCalls = 0;
		Card[] randomCards;
		
		randomCards = generateMissingCards(discoveredBoardCards, playerCards, board);
		ke.data.Board callBoard = createNewBoard(gameBoard, randomCards, discoveredBoardCards);
		// Gegnerische Karten verteilen
		Hand opponentHands[] = new Hand[2];
		opponentHands[0] = new Hand();
		opponentHands[0].addCard(new ke.data.Card(randomCards[discoveredBoardCards].rank.ordinal(),randomCards[discoveredBoardCards].suit.ordinal()));
		opponentHands[0].addCard(new ke.data.Card(randomCards[discoveredBoardCards+1].rank.ordinal(),randomCards[discoveredBoardCards+1].suit.ordinal()));
		opponentHands[1] = new Hand();
		opponentHands[1].addCard(new ke.data.Card(randomCards[discoveredBoardCards+2].rank.ordinal(),randomCards[discoveredBoardCards+2].suit.ordinal()));
		opponentHands[1].addCard(new ke.data.Card(randomCards[discoveredBoardCards+3].rank.ordinal(),randomCards[discoveredBoardCards+3].suit.ordinal()));
		
		SecureRandom random = new SecureRandom();
		double randomNumber;
		Action firstAction;
		if(action == null || action.isEmpty()){
			randomNumber = random.nextDouble();
			if(randomNumber < 0.5){
				firstAction = Action.CALL;
			}else{
				firstAction = Action.RAISE;
			}
		}else{
			firstAction = action.getFirst();
			action.removeFirst();
		}
		if (firstAction.compareTo(Action.CALL) == 0) {	
			
			// Wurzel der MC Simulation 
			// Player Call
			callBets = gameState[1];
			newPot = gameState[0] + callBets;
			myInPot = gameState[4] + callBets;
			betsPerRound = gameState[2];
			if(callBets == 0)
				allCalls = seatTaken; // STIMMT NICHT GANZ ! 
			else
				allCalls = 1;
			int lastBet;
			if(seatTaken==0){
				lastBet = 0;
			}else{
				lastBet = 2; // Stimmt nicht ganz k�nnte auch der andere sein.
			}
			
			reward = oneMCSimulation(playerHand, callBoard, opponentHands, newPot, myInPot, betsPerRound, gameState[3], allCalls+1, action, lastBet); // 2 Stimmt nicht ganz k�nnte auch 1 sein aber vernachl�ssigbar
		
			System.out.print("Erebnis f�r CALL:");
			System.out.println(reward);
			System.out.println("---Eine-MC-Simulation-Ende---");	
		}else{	
			if(gameState[2] < 4){
				newPot = gameState[0] + gameState[1];
				myInPot = gameState[4] + gameState[1];
				betsPerRound = gameState[2] + 1;				
				allCalls = 0; 
			
				reward = oneMCSimulation(playerHand, callBoard, opponentHands, newPot, myInPot, betsPerRound+1, gameState[3], allCalls, action,  0); // 0 player letzter Beter
				System.out.print("Ergebnis f�r RAISE:");
				System.out.println(reward);
				System.out.println("---Eine-MC-Simulation-Ende---");	
			}else{
				reward= -100;
	//			System.out.println("---KEIN RAISE ERLAUBT---");
			}
		}
		
		System.out.println("Rewards:");
		System.out.println(reward);
		System.out.println("Urspr�nglicher Pottbeitrag:");
		System.out.println(gameState[4]);
		//Ergebnisevaluirung, wenn beide MC Rewards negativ dann folden
		return reward;
	}
	
		
	/**
	 * Spielt eine Partie zuf�llig zuende bzw macht einen MC Simulationsdurchlauf.
	 * @param gameState: Informationen �ber den aktuelle Zustand:
	 * 			0:pottgr��e
	 *          1:Call beitrag
	 *          2:Anzahl der Bets in dieser Runde
	 *          3:Aktueller Zustand
	 *          4:Pottbeitrag
	 * @param playerCards: Eigene Karten.
	 * @param gameBoard: Boardkarten.
	 * @param opponentHands: Gegnersiche Karten.
	 * @param gamePhase: aktuelle Game Phase.
	 * @return int: Reward der einen MC Simulation.
	 */
	public static int oneMCSimulation(Hand playerHand, Board gameBoard,
			Hand[] opponentHands, int newPot, int myInPot, int betsForSimulation, int gamePhase, int allCall, LinkedList<Action> action, int lastBet){
		
/*		System.out.println("---Eine-MC-Simulation-Start---");
		
		System.out.println("-----------H�nde-Start--------");
		System.out.print("Spieler: ");
		System.out.println(playerHand);
		System.out.print("Gegener1: ");
		System.out.println(opponentHands[0]);
		System.out.print("Gegner2: ");
		System.out.println(opponentHands[1]);
		System.out.println("-----------H�nde-Ende--------");
		
		System.out.println("-----------Board-Start--------");
		System.out.println(gameBoard);
		System.out.println("-----------Board-Ende--------");
*/		// 	LastBet 0 = Player, 1 und 2 Gegner
		double random_number;
		SecureRandom random = new SecureRandom();
		int bets = betsForSimulation;
		Action firstAction;
		
		for(int rounds = 0; rounds <= 4-gamePhase; rounds++){
			// Eine Random Betrunde.			
			while (bets <= 4 && allCall < 3) {	
				for(int i = 0; i < 2 && allCall < 3; i++){ 
					if( (allCall == 2 && i == 0 && lastBet == 1) || (allCall == 2 &&  i == 1 && lastBet == 2) ){
						allCall = 3;
					}else{
						random_number = random.nextDouble();
						if(random_number < 0.5 || bets >= 4){
							// 	call
							allCall++;
						}else{
							bets++;
							allCall = 0;
							lastBet = i+1;
						}
					}
				}
				
				//Player 
				if(allCall >= 3 || lastBet == 0)
					break;
				
				if(action == null || action.isEmpty()){
					random_number = random.nextDouble();
					if(random_number < 0.5){
						firstAction = Action.CALL;
					}else{
						firstAction = Action.RAISE;
					}
				}else{
					firstAction = action.getFirst();
					action.removeFirst();
				}
				
				if(firstAction.compareTo(Action.CALL) == 0){
					// call
					allCall++;
				}else{
					bets++;
					allCall = 0;
					lastBet = 0;
				}
			}// end_while
			if(gamePhase+rounds < 2){
				newPot += bets*3;
				myInPot += bets-betsForSimulation;
			}else{
				newPot += bets*3*2;
				myInPot += (bets-betsForSimulation)*2;
			}
			bets = 0;
			allCall = 0;
		}// end_for
		
		// Handevaluierung
	
		
		if(playerHand.getHandRank(gameBoard).compareTo(opponentHands[0].getHandRank(gameBoard)) == 0){
			if(playerHand.getHandRank(gameBoard).compareTo(opponentHands[1].getHandRank(gameBoard)) == 0){
//				System.out.print("Erebnis:");
//				System.out.println(0);
//				System.out.println("---Eine-MC-Simulation-Ende---");		
				return 0;
			}
		}
		
		if(playerHand.getHandRank(gameBoard).compareTo(opponentHands[0].getHandRank(gameBoard)) > 0){
			if(playerHand.getHandRank(gameBoard).compareTo(opponentHands[1].getHandRank(gameBoard)) > 0){
				return newPot;
			}else{
				return -myInPot;
			}
		}else{	
			return -myInPot;
		}
	}
	
	public static Card[] generateMissingCards(int discoveredBoardCards, Card[] playerCards, Card board[]){
		// fehlende Karten zuf�llig nachf�llen.
		Card[] randomCards = Card.dealNewArray(new SecureRandom(),discoveredBoardCards + 4);
		
		// Rausfiltern der doppelten RandomKarten erstellen
		int length = randomCards.length;
		List<Card> cardPool = new LinkedList<Card>();
		cardPool.add(playerCards[0]);
		cardPool.add(playerCards[1]);
		for (int j = 0; j < 5 - discoveredBoardCards ; j++){
			cardPool.add(board[j]);
		}
		for (int j = 0; j < length; j++) {
			while(cardPool.contains(randomCards[j])){
				randomCards[j] = Card.dealNewArray(new SecureRandom(),1)[0];
			}
			cardPool.add(randomCards[j]);
		}
		
		return randomCards;
	}
	
	public static ke.data.Board createNewBoard(Board board, Card[] randomCards, int discoveredBoardCards){
		ke.data.Board gameBoard = new ke.data.Board();
		List<ke.data.Card> cards = board.getCards();
		for (Iterator<ke.data.Card> iterator = cards.iterator(); iterator.hasNext();) {
			gameBoard.addCard((ke.data.Card) iterator.next());
		}
		
		for (int j = 0; j < discoveredBoardCards; j++) {
			gameBoard.addCard(new ke.data.Card(randomCards[j].rank.ordinal(),randomCards[j].suit.ordinal()));
		}
		
		return gameBoard;
	}


}
