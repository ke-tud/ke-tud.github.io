package ke.client.dummy.winprobability;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;

public class Hand{
	public enum Type{
		HIGH_CARD, TWO_OF_A_KIND, DOUBLE_TWO_OF_A_KIND, THREE_OF_A_KIND, STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND, STRAIGHT_FLUSH;
	}

	static class Value{
		public Type type;
		public long weight;
		public Value(Type type, long weight){
			this.type = type;
			this.weight = weight;
		}
		
		public Value(){
			this.type = Type.HIGH_CARD;
			this.weight = 0;
		}

		public void set(Type type, long weight){
			this.type = type;
			this.weight = weight;
		}

		public boolean lessThen(final Value value){
			return type.compareTo(value.type) < 0 || (type.compareTo(value.type) == 0 && weight < value.weight);
		}

		public boolean equal(final Value value){
			return type.compareTo(value.type) == 0 && weight == value.weight;
		}

		public boolean greaterThen(final Value value){
			return type.compareTo(value.type) > 0 || (type.compareTo(value.type) == 0 && weight > value.weight);
		}
	};

	public static void main(String[] args){
		Value v[] = new Value[9];
		v[0] = new Value(Type.HIGH_CARD, 2);
		v[1] = new Value(Type.TWO_OF_A_KIND, 3);
		v[2] = new Value(Type.DOUBLE_TWO_OF_A_KIND, 4);
		v[3] = new Value(Type.THREE_OF_A_KIND, 5);
		v[4] = new Value(Type.STRAIGHT, 6);
		v[5] = new Value(Type.FLUSH, 7);
		v[6] = new Value(Type.FULL_HOUSE, 8);
		v[7] = new Value(Type.FOUR_OF_A_KIND, 9);
		v[8] = new Value(Type.STRAIGHT_FLUSH, 10);
		for(int i = 0; i < v.length - 1; ++i){
			if(v[i].greaterThen(v[i+1]))
				System.out.println("Fehler: " + i + " < " + (i+1));
			if(!v[i].equal(v[i]))
				System.out.println("Fehler: " + i + " != " + i);
			if(!v[i].lessThen(v[i+1]))
				System.out.println("Fehler: " + i + " > " + (i+1));
		}
		System.out.println("Ende");
	}

	public Card cards[] = new Card[5];
	public Value value = new Value();

	int weight(){
		return	(1 << cards[0].rank.index) + 
				(1 << cards[1].rank.index) +
				(1 << cards[2].rank.index) +
				(1 << cards[3].rank.index) +
				(1 << cards[4].rank.index);
	}

	int getHighest(){
		int maxValue = cards[0].rank.index;
		for(int i = 1; i < 5; ++i){
			if(cards[i].rank.index > maxValue){
				maxValue = cards[i].rank.index;
			}
		}
		return maxValue;
	}

	public void setCards(Card cards[]){
		this.cards = cards.clone();
		calcValue();
	}

	public void setHand(Hand hand){
		cards = hand.cards.clone();
		value.type = hand.value.type;
		value.weight = hand.value.weight;
	}

	void setCard(int i, final Card card){
		cards[i] = card;
	}

	void calcValue(){
		int i = 0;
		int j = i+1;
		int index[] = new int[]{i, j};
		if(PokerBeating.isTwoOfAKind(this, index)){
			i = index[0];
			j = index[1];
			int iTwo = i;
			int k = j + 1;
			index = new int[]{i, j, k};
			if(PokerBeating.isThreeOfAKind(this, index)){
				i = index[0];
				j = index[1];
				k = index[2];
				int iThree = i;
				++k;
				index = new int[]{i, j, k};
				if(PokerBeating.isFourOfAKind(this, index)){
					i = index[0];
					j = index[1];
					k = index[2];
					value.set(Type.FOUR_OF_A_KIND, ((long)cards[i].rank.index << 19) + weight());
				}
				else{
					int iHouse = iThree;
					int iFull = iTwo;
					index = new int[]{iFull};
					if(iHouse != iFull || PokerBeating.isFullHouse(this, cards[iHouse].rank.index, index)){ // Full House
						iFull = index[0];
						value.set(Type.FULL_HOUSE, ((long)cards[iHouse].rank.index << 4) + cards[iFull].rank.index);
					}
					else{ // three of a kind
						value.set(Type.THREE_OF_A_KIND, ((long)cards[iThree].rank.index << 19) + weight());
					}
				}
			}
			else{
				i = iTwo + 1;
				j = i + 1;
				index = new int[]{i, j};
				if(PokerBeating.isTwoOfAKind(this, index)){ // double two of a kind
					i = index[0];
					j = index[1];
					value.set(Type.DOUBLE_TWO_OF_A_KIND, ((((long)1 << cards[iTwo].rank.index) + ((long)1 << cards[i].rank.index)) << 19) + weight());
				}
				else{ // two of a kind
					value.set(Type.TWO_OF_A_KIND, ((long)cards[iTwo].rank.index << 19) + weight());
				}
			}
		}
		else{
			int iMin = 0, iMax = 0;
			index = new int[]{iMin, iMax};
			PokerBeating.getMinMax(this, index);
			iMin = index[0];
			iMax = index[1];
			if(PokerBeating.isFlush(this)){
				if(PokerBeating.isStraight(this, iMin, iMax)){ // Straight Flush
					value.set(Type.STRAIGHT_FLUSH, cards[iMax].rank.index);
				}
				else if(PokerBeating.isStraightStartingWithAce(this, iMin, iMax)){ // Straight Flush A-2-3-4-5
					value.set(Type.STRAIGHT_FLUSH, Rank.FIVE.index);
				}
				else{ // Flush
					value.set(Type.FLUSH, weight());
				}
			}
			else if(PokerBeating.isStraight(this, iMin, iMax)){ // Straight
				value.set(Type.STRAIGHT, cards[iMax].rank.index);
			}
			else if(PokerBeating.isStraightStartingWithAce(this, iMin, iMax)){ // Straight A-2-3-4-5
				value.set(Type.STRAIGHT, Rank.FIVE.index);
			}
			else{ // High Card
				value.set(Type.HIGH_CARD, weight());
			}
		}
	}


	public boolean lessThan(final Hand hand){
		return value.lessThen(hand.value);
	}
	
	public boolean equal(final Hand hand){
		return value.equal(hand.value);
	}

	public boolean greaterThan(final Hand hand){
		return value.greaterThen(hand.value);
	}

	final Card get(final int index){
		return cards[index];
	}
}
