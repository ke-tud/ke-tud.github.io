package ke.client.dummy;

public class OpponentStatistics{

	public static final int FOLD = 0, CALL = 1, RAISE = 2;
	static final int PRE_FLOP = 0, FLOP = 1, RIVER = 2, TURN = 3;
	private int counter[][][][];
	private int initialSum, criticalSum;
	
	public OpponentStatistics(int players, int maxBetsPerRound, int[] prob, int criticalSum){
		counter = new int[players][4][maxBetsPerRound+1][3];
		for(int player = 0; player < counter.length; ++player){
			for(int street = 0; street < counter[player].length; ++street){
				for(int bets = 0; bets < counter[player][street].length; ++bets){
					counter[player][street][bets][FOLD] = prob[FOLD] + ((street+bets)*prob[RAISE])/10; // initiale Verteilung realistischer machen
					counter[player][street][bets][CALL] = prob[CALL] + ((street+bets)*prob[RAISE])/10;
					counter[player][street][bets][RAISE] = prob[RAISE] - ((street+bets)*prob[RAISE])/20;
				}
			}
		}
		initialSum = sum(prob);
		this.criticalSum = criticalSum;
	}
	
	public void add(int player, int street, int bets, int action){
		++counter[player][street][bets][action];
	}

	public float[] getProb(int player, int street, int bets){
		int[] counts = getTriple(player, street, bets);
		int sum = Math.max(1, counts[FOLD] + counts[CALL] + counts[RAISE]);
		float prob[] = new float[3];
		prob[FOLD] = (float)counts[FOLD]/sum;
		prob[CALL] = (float)counts[CALL]/sum;
		prob[RAISE] = (float)counts[RAISE]/sum;
		return prob;
	}
	
	public int[] getProb1000(int player, int street, int bets){
		int[] counts = getTriple(player, street, bets);
		int sum = Math.max(1, counts[FOLD] + counts[CALL] + counts[RAISE]);
		int prob[] = new int[3];
		prob[FOLD] = counts[FOLD]*1000/sum;
		prob[CALL] = counts[CALL]*1000/sum;
		prob[RAISE] = counts[RAISE]*1000/sum;
		return prob;
	}

	/**
	 * 
	 * @param player
	 * @param street
	 * @param bets
	 * @return the currently stored triple, is may be unaccurate
	 */
	public int[] getRealTriple(int player, int street, int bets){
		return counter[player][street][bets];
	}
	
	/**
	 * 
	 * @param player
	 * @param street
	 * @param bets
	 * @return an accurate triple as possible, by summing the bets and streets if necessary
	 */
	public int[] getTriple(int player, int street, int bets){
		if(sum(counter[player][street][bets]) < initialSum + criticalSum){
			int[] averageTriple = getAverageTriple(player, street);
			if(sum(averageTriple) < initialSum + criticalSum)
				return getAverageTriple(player);
			return averageTriple;
		}
		return counter[player][street][bets];
	}
	
	private int[] getAverageTriple(int player){
		int[] triple = new int[3];
		for(int street = 0; street < counter[player].length; ++street)
			for(int bets = 0; bets < counter[player][street].length; ++bets){
				triple[FOLD] += counter[player][street][bets][FOLD];
				triple[CALL] += counter[player][street][bets][CALL];
				triple[RAISE] += counter[player][street][bets][RAISE];
			}
		return triple;
	}

	private int[] getAverageTriple(int player, int street){
		int[] triple = new int[3];
		for(int bets = 0; bets < counter[player][street].length; ++bets){
			triple[FOLD] += counter[player][street][bets][FOLD];
			triple[CALL] += counter[player][street][bets][CALL];
			triple[RAISE] += counter[player][street][bets][RAISE];
		}
		return triple;
	}

	public int[] getProbAbs(int player, int street, int bets){
		return counter[player][street][bets];
	}
	
	public void reweight(float weight, int threshold){
		for(int player = 0; player < counter.length; ++player)
			for(int street = 0; street < counter[player].length; ++street)
				for(int bets = 0; bets < counter[player][street].length; ++bets){
					if(sum(counter[player][street][bets]) > threshold){
						counter[player][street][bets][FOLD] *= weight;
						counter[player][street][bets][CALL] *= weight;
						counter[player][street][bets][RAISE] *= weight;
					}
				}
	}

	public void reweight(int divisor, int threshold){
		for(int player = 0; player < counter.length; ++player)
			for(int street = 0; street < counter[player].length; ++street)
				for(int bets = 0; bets < counter[player][street].length; ++bets)
					if(sum(counter[player][street][bets]) > threshold){
						counter[player][street][bets][FOLD] /= divisor;
						counter[player][street][bets][CALL] /= divisor;
						counter[player][street][bets][RAISE] /= divisor;
					}
	}
	
	static private int sum(int[] triple){
		return triple[FOLD] * triple[CALL] + triple[RAISE];
	}
}
