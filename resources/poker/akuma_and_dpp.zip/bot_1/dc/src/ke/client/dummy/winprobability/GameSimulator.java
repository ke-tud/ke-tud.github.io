package ke.client.dummy.winprobability;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

/**
 * Class for the simulation of texas hold 'em poker games
 * 
 * @author Daniel Schumann
 * @version 1.0
 */
public class GameSimulator{
	public static void main(String[] args){
/**
		Card cards[] = new Card[2];
		cards[0] = new Card(Rank.FIVE, Suit.DIAMONDS);
		cards[1] = new Card(Rank.FIVE, Suit.CLUBS);/**/
/**
		Card cards[] = new Card[5];
		cards[0] = new Card(Rank.FIVE, Suit.DIAMONDS);
		cards[1] = new Card(Rank.FIVE, Suit.CLUBS);
		cards[2] = new Card(Rank.FIVE, Suit.SPADES);
		cards[3] = new Card(Rank.TEN, Suit.DIAMONDS);
		cards[4] = new Card(Rank.TEN, Suit.HEARTS);/**/
/**/
		Card cards[] = new Card[6];
		cards[0] = new Card(Rank.THREE, Suit.HEARTS);
		cards[1] = new Card(Rank.FOUR, Suit.HEARTS);
		cards[2] = new Card(Rank.THREE, Suit.CLUBS);
		cards[3] = new Card(Rank.FOUR, Suit.CLUBS);
		cards[4] = new Card(Rank.FIVE, Suit.SPADES);
		cards[5] = new Card(Rank.ACE, Suit.DIAMONDS);
		/**/

		System.out.println((int)(getWinProbability(20000, 2, cards)*100.0f) + "%");
		
/**
		Card player[] = new Card[2];
		Card community[] = new Card[5];
		player[0] = new Card(Rank.FIVE, Suit.DIAMONDS);
		player[1] = new Card(Rank.FIVE, Suit.CLUBS);
		community[0] = new Card(Rank.FIVE, Suit.SPADES);
		community[1] = new Card(Rank.TEN, Suit.DIAMONDS);
		community[2] = new Card(Rank.TEN, Suit.HEARTS);
		community[3] = new Card(Rank.KING, Suit.CLUBS);
		community[4] = new Card(Rank.ACE, Suit.SPADES);
		Hand best = getBest(player, community);
		System.out.println(best.value.type);/**/
}
	
	/**
	 * <b>getWinProbability</b> simulates {@link rounds} showdowns for the given cards of one player
	 * and returns the probability of winning
	 * 
	 * @param players the number of players
	 * @param playerCards array of length 2 with both cards of the player
	 * @param communityCards array of length 0-5 with the currently visible community cards
	 * @param wins array of length {@link players}, the element for the player who wins is incremented
	 * @param draws array with an element for each player, the elements for the players with an draw is incremented
	 */
	public static float getWinProbability(final int rounds, final int players, Card cards[]){
		int wins[] = new int[players];
		int draws[] = new int[players];
		Card player[] = new Card[]{cards[0], cards[1]};
		Card community[] = new Card[cards.length - 2];
		for(int i = 0; i < community.length; ++i){
			community[i] = cards[2 + i];
		}
		for(int i = 0; i < rounds; ++i){
				playRound(players, player, community, wins, draws);
		}
		return (float)Math.max(wins[0], draws[0]) / (float)rounds;
	}

	public static float getGoodWinProbability(final int rounds, final int players, Card cards[]){
		int wins[] = new int[players];
		int draws[] = new int[players];
		Card player[] = new Card[]{cards[0], cards[1]};
		Card community[] = new Card[cards.length - 2];
		for(int i = 0; i < community.length; ++i){
			community[i] = cards[2 + i];
		}
		int lastResult = -1;
		int curResult = 0;
		int count = 0;
		while(lastResult != curResult){
			++count;
			for(int i = 0; i < rounds; ++i){
					playRound(players, player, community, wins, draws);
			}
			lastResult = curResult;
			curResult = (int)(100000.0f * (float)Math.max(wins[0], draws[0]) / (float)(count * rounds));
			//System.out.println(curResult);
		}
		System.out.println("I have a good result after " + (count*rounds) + " rounds");
		return (float)Math.max(wins[0], draws[0]) / (float)(count * rounds);
	}

	/**
	 * <b>playRound</b> simulates a showdown for the given cards of one player
	 * and return the number of wins and draw in the given arrays ({@link wins}, {@link draws})
	 * 
	 * @param players the number of players
	 * @param playerCards array of length 2 with both cards of the player
	 * @param communityCards array of length 0-5 with the currently visible community cards
	 * @param wins array of length {@link players}, the element for the player who wins is incremented
	 * @param draws array with an element for each player, the elements for the players with an draw is incremented
	 */
	public static void playRound(int players, Card playerCards[], Card communityCards[], int wins[], int draws[]){
		Deck deck = new Deck();
		for(Card card : playerCards)
			deck.remove(card);
		for(Card card : communityCards)
			deck.remove(card);

		Card community[] = new Card[5];
		for(int i = 0; i < communityCards.length; ++i)
			community[i] = communityCards[i];

		Card cards[][] = new Card[players][2];
		cards[0][0] = playerCards[0];
		cards[0][1] = playerCards[1];
		for(int i = 1; i < players; ++i){
			cards[i][0] = deck.get();
			cards[i][1] = deck.get();
		}

		for(int i = communityCards.length; i < community.length; ++i){
			community[i] = deck.get();
		}

		Hand hands[] = new Hand[players];
		for(int i = 0; i < players; ++i){
			hands[i] = getBest(cards[i], community);
		}

		evaluateResult(players, wins, draws, hands);

/*		for(int i = 1; i < players; ++i){
			 deck.put(cards[i][0]);
			 deck.put(cards[i][1]);
		}

		for(int i = 0; i < community.length; ++i){
			deck.put(community[i]);
		}*/
	}
	
	/**
	 * <b>getBest</b> determines the best hand, e.g. five cards, from the two hole cards and the five community cards
	 * 
	 * @param players the number of players
	 * @param draws array with an element for each player, the elements for the players with an draw is incremented
	 * 
	 * @return An instance of type {@link GameSimulator.Hand} containing the best five cards
	 */
	public static Hand getBest(final Card player[], final Card community[]){
		Hand best = new Hand();
		best.setCards(community);
		Hand cur = new Hand();
		cur.setCard(0, player[0]);
		for(int c1 = 0; c1 < 2; ++c1){
			cur.setCard(1, community[c1]);
			for(int c2 = c1 + 1; c2 < 3; ++c2){
				cur.setCard(2, community[c2]);
				for(int c3 = c2 + 1; c3 < 4; ++c3){
					cur.setCard(3, community[c3]);
					for(int c4 = c3 + 1; c4 < 5; ++c4){
						cur.setCard(4, community[c4]);
						cur.calcValue();
						if(cur.greaterThan(best))
							best.setHand(cur);
					}
				}
			}
		}

		cur.setCard(0, player[1]);
		for(int c1 = 0; c1 < 2; ++c1){
			cur.setCard(1, community[c1]);
			for(int c2 = c1 + 1; c2 < 3; ++c2){
				cur.setCard(2, community[c2]);
				for(int c3 = c2 + 1; c3 < 4; ++c3){
					cur.setCard(3, community[c3]);
					for(int c4 = c3 + 1; c4 < 5; ++c4){
						cur.setCard(4, community[c4]);
						cur.calcValue();
						if(cur.greaterThan(best))
							best.setHand(cur);
					}
				}
			}
		}

		cur.setCard(0, player[0]);
		cur.setCard(1, player[1]);
		for(int c1 = 0; c1 < 3; ++c1){
			cur.setCard(2, community[c1]);
			for(int c2 = c1 + 1; c2 < 4; ++c2){
				cur.setCard(3, community[c2]);
				for(int c3 = c2 + 1; c3 < 5; ++c3){
					cur.setCard(4, community[c3]);
					cur.calcValue();
					if(cur.greaterThan(best))
						best.setHand(cur);
				}
			}
		}

		return best;
	}

	public static void evaluateResult(int players, int counterWins[], int counterDraws[], Hand hands[]){
		int winner = 0;
		boolean draw = false;
		for(int i = winner + 1; i < players; ++i){
			if(hands[i].greaterThan(hands[winner])){
				winner = i;
				draw = false;
			}
			else if(hands[i].equal(hands[winner])){
				draw = true;
			}
		}

		if(draw){
			for(int i = 0; i < players; ++i){
				if(hands[i].equal(hands[winner])){
					++counterDraws[i];
				}
			}
		}
		else{
			++counterWins[winner];
		}
	}
}