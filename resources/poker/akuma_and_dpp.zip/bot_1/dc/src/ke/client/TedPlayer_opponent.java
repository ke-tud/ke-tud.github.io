package ke.client;
import java.net.InetAddress;

import ke.client.dummy.OpponentStatistics;
import ke.data.Action;
import ke.engine.MasterMind;
import ke.engine.HandStrengths;
import ke.engine.PreFlop;


public class TedPlayer_opponent extends TedPokerClient{
	/** 
	 * the backend Interface
	 */
    protected MasterMind backend;
    private HandStrengths ehs = new HandStrengths();
    private int roundIndex = -1;
	private OpponentStatistics betHightStatistics = new OpponentStatistics(3, 2, new int[]{20,50,30}, 200);
    /**
     * Initialize this player.
     */
    public TedPlayer_opponent() {
    	backend  = new MasterMind(betHightStatistics, ehs);
    }

    
    /**
     * sends the decided action to the server
     */
    public void reconsider_state_and_make_a_move() {
    	double time = System.currentTimeMillis();
    	updateStatistics(state);
    	updateHandStrengths();
    	if(state.roundIndex == 0){
    		// Spezialbehandlung in der PreFlop-Phase
			PreFlop pf = new PreFlop();
			send_action(pf.getAction(state));
    	}
    	else{
	    	backend.think_about(state);
	    	if(backend.getAction().equals(Action.FOLD) && state.getAmountToCall(state.seatTaken) == 0){
	    		System.out.println("LIEBER EIN CALL STATT ZU FOLDEN");
	    		send_action(Action.CALL);
	    	}
	    	else{
	    		send_action(backend.getAction());
	    	}
    	}
    	System.out.print("Meine Zugzeit:");
    	System.out.println((System.currentTimeMillis()-time)/1000);
    }


	/**
     * Andere Spieler am Zug
     */
    public void reconsider_state() {
    double time = System.currentTimeMillis();
    updateStatistics(state);	
    updateHandStrengths();
    	if(state.handOver){
    		System.out.println("HAND IS OVER!");
    		backend.stackUpdate(state.stack);
    		roundIndex = -1;
    		backend.resetHandRange();
    	}else{
          if(state.active[state.seatTaken]){
    		if(roundIndex != state.roundIndex){
    			if(state.roundIndex > 0 && state.firstActionOnRound){
    				System.out.println("NewBoardCards");
    				System.out.println(state.roundIndex);
    				System.out.println(state.firstActionOnRound);
    				backend.newBoardCards(state);
    			}
    			if(state.roundIndex == 0 && state.firstActionOnRound){
    				System.out.println("NewMYHandCards");
    				System.out.println(state.roundIndex);
    				System.out.println(state.firstActionOnRound);
    				backend.myHandCardsIntoHandRanges(state);
    			}
    		}
    	  }
    	}
    	roundIndex = state.roundIndex;	
    	System.out.print("Zeit von Opponent " + state.seatToAct + ":");
    	System.out.println((System.currentTimeMillis()-time)/1000);
    }
    
    // attributes for statistic updates
	private int player = -1;
	private int street;
//	private int bets;
	private int betsToCall;

//	private int rounds = 0;

	private void updateStatistics(ClientRingDynamics state){
		// add current action to the statistics
		if(player >= 0){
			int action = getLastAction(state.bettingSequence);
			if(action >= 0){
				System.out.println("adding (" + player + ", " + state.playerToSeat(player) + ", " + street + ", " + betsToCall + ", " + action + ")");
				betHightStatistics.add(player, street, betsToCall, action);
				
				if (state.roundIndex == 1 && state.firstActionOnRound) {
					System.out.println("PreFlopEstimation");
//				System.out.println(state.roundIndex);
//				System.out.println(state.firstActionOnRound);
					backend.preFlopEstimationIntoHandRanges(state);
				}
				
				if(state.roundIndex > 0 && player != state.seatToPlayer(state.seatTaken) && !state.handOver && state.active[state.seatTaken]){
					if(action == 2)
						backend.opponentMove(state, Action.RAISE, state.playerToSeat(player));
					else if(action == 1)
						backend.opponentMove(state, Action.CALL, state.playerToSeat(player));
				}
			}
		}
		
		if(state.handOver){
			// wait for next player
			player = -1;
	//		if(++rounds % 50 == 0){
				showStatistics(betHightStatistics);
	//		}
			if(state.handNumber % 200 == 0){
				betHightStatistics.reweight(0.7f, 400);
			}
		}
		else{
			// save for next update
			player = state.seatToPlayer(state.seatToAct);
			street = state.roundIndex;
//			bets = state.roundBets;
			betsToCall = state.getAmountToCall(state.seatToAct) / state.lastBetSize;
		}
	}

	public static int getLastAction(String bettingSequence){
		int result = -1;
		int iLastAction = bettingSequence.length() - (bettingSequence.endsWith("/") ? 2 : 1);
		if(iLastAction >= 0){
			switch(bettingSequence.charAt(iLastAction)){
			case 'f':
				result = OpponentStatistics.FOLD;
				break;
			case 'c':
				result = OpponentStatistics.CALL;
				break;
			case 'r':
				result = OpponentStatistics.RAISE;
				break;
			}
		}
		return result;
	}

	private static void showStatistics(OpponentStatistics statistics){
		System.out.println("** PlayerStatistics **");
		for(int p = 0; p < 3; ++p){
			System.out.println();
			System.out.println(" * Player: " + p + " *");
			for(int s = 0; s < 4; ++s){
				System.out.println("   Street " + s);
				for(int b = 0; b < 3; ++b){
					float prob[] = statistics.getProb(p, s, b);
					int probAbs[] = statistics.getProbAbs(p, s, b);
					System.out.printf("    %d Bets: Rel(%.03f/%.03f/%.03f) Abs(%3d/%3d/%3d) Sum(%d)", b, prob[0], prob[1], prob[2], probAbs[0], probAbs[1], probAbs[2], probAbs[0] + probAbs[1] + probAbs[2]);
					System.out.println();
				}					
			}
		}
	}
    void updateHandStrengths(){
    	if(state.active[state.seatTaken] && state.roundIndex > 0 ){ // nur updaten, wenn wir noch	mitspielen
    	final int validCards[] = new int[]{0,3,4,5,5}; // Anzahl der sichtbaren Community-Karten je Strasse
    	final int milliseconds = state.isOurTurn() ? 800 : 1400; // maximal time for computation is lower if it is our turn
    	ehs.updateHandStrength(state.hole[state.seatTaken],
    			state.board, validCards[state.roundIndex], milliseconds, 10000);
    	}
    }
	
    /**
     * A function for startme.bat to call
     */
    public static void main(String[] args) throws Exception{
        TedPlayer_opponent pp = new TedPlayer_opponent();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        pp.run();

    }
}
