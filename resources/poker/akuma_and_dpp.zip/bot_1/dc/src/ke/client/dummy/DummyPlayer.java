package ke.client.dummy;

/*
 * DummyPlayer.java
 *
 * Created on April 21, 2006, 11:54 AM
 */

import java.net.InetAddress;

import ke.client.ClientRingDynamics;
import ke.engine.DummyMasterMind;

/**
 * The actuall poker mathc participant which is called 
 * from the shell-skript startme.sh/startme.bat . 
 * 
 * @author Alex, Immi, Kami
 * @author FG KE
 */
public class DummyPlayer extends DummyPokerClient{
	/** 
	 * the backend Interface
	 */
	protected DummyMasterMind backend;
	private OpponentStatistics statistics = new OpponentStatistics(3, 4, new int[]/*{5,50,45}*/{0,0,0}, 500);

	/**
	 * Initialize this player.
	 */
	public DummyPlayer(){
		super();
		backend = new DummyMasterMind();
	}

	/**
	 * sends the decided action to the server
	 */
	public void reconsider_state_and_make_a_move(){
		updateStatistics(state);

		//System.out.println("Let me think.");

		backend.think_about(state);

		send_action(backend.getAction());

	}

	/**
	 * sends the decided action to the server
	 */
	public void reconsider_state(){
		updateStatistics(state);
		//System.out.println("So so.");
	}

	
	// attributes for statistic updates
	private int player = -1;
	private int street, bets;

	private int rounds = 0;

	private void updateStatistics(ClientRingDynamics state){
		// add current action to the statistics
		if(player >= 0){
			int action = getLastAction(state.bettingSequence);
			if(action >= 0){
				//System.out.println("adding (" + player + ", " + street + ", " + bets + ", " + action + ")");
				statistics.add(player, street, bets, action);
			}
		}
		
		if(state.handOver){
			// wait for next player
			player = -1;
			if(++rounds % 50 == 0){
				showStatistics(statistics);
			}
		}
		else{
			// save for next update
			player = state.seatToPlayer(state.seatToAct);
			street = state.roundIndex;
			bets = state.roundBets;
		}
	}

	private static int getLastAction(String bettingSequence){
		int result = -1;
		int iLastAction = bettingSequence.length() - (bettingSequence.endsWith("/") ? 2 : 1);
		if(iLastAction >= 0){
			switch(bettingSequence.charAt(iLastAction)){
			case 'f':
				result = OpponentStatistics.FOLD;
				break;
			case 'c':
				result = OpponentStatistics.CALL;
				break;
			case 'r':
				result = OpponentStatistics.RAISE;
				break;
			}
		}
		return result;
	}

	private static void showStatistics(OpponentStatistics statistics){
		System.out.println("** PlayerStatistics **");
		for(int p = 0; p < 3; ++p){
			System.out.println();
			System.out.println(" * Player: " + p + " *");
			for(int s = 0; s < 4; ++s){
				System.out.println("   Street " + s);
				for(int b = 0; b < 5; ++b){
					float prob[] = statistics.getProb(p, s, b);
					int probAbs[] = statistics.getProbAbs(p, s, b);
					System.out.printf("    %d Bets: Rel(%.03f/%.03f/%.03f) Abs(%3d/%3d/%3d) Sum(%d)", b, prob[0], prob[1], prob[2], probAbs[0], probAbs[1], probAbs[2], probAbs[0] + probAbs[1] + probAbs[2]);
					System.out.println();
				}					
			}
		}
	}

	/**
	 * A function for startme.bat to call
	 */
	public static void main(String[] args) throws Exception{
		DummyPlayer pp = new DummyPlayer();
		System.out.println("Attempting to connect to " + args[0] + " on port " + args[1] + "...");

		pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
		System.out.println("Successful connection!");
		pp.run();

	}
}
