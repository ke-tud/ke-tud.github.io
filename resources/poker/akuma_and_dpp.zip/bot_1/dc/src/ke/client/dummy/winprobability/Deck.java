package ke.client.dummy.winprobability;

import java.security.SecureRandom;
import java.util.Random;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

public class Deck{
	boolean deck[][] =  new boolean[4][13];
	Random rand;
	public Deck(){
		rand = new SecureRandom();
	}

	public Deck(long seed){
		rand = new Random(seed);
	}

	public void reset(){
		for(int i = 0; i < deck.length; ++i){
			for(int j = 0; j < deck[i].length; ++j)
				deck[i][j] = false;
		}
	}

	public Card get(){
		int rank, suit;
		do{
			rank = rand.nextInt(13);
			suit = rand.nextInt(4);
		}while(deck[suit][rank]);
		deck[suit][rank] = true;
		return new Card(Rank.toRank(rank), Suit.toSuit(suit));
	}

	public Card get(char suit, char rank){
		deck[suit][rank] = true;
		return new Card(Rank.toRank(rank), Suit.toSuit(suit));
	}

	public Card get(Card card){
		deck[card.suit.index][card.rank.index] = true;
		return card;
	}

	public void remove(Card card){
		deck[card.suit.index][card.rank.index] = true;
	}

	public void put(char suit, char rank){
		deck[suit][rank] = false;
	}

	public void put(Card card){
		deck[card.suit.index][card.rank.index] = false;
	}
}