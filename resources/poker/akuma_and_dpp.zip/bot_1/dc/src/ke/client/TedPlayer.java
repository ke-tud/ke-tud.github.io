package ke.client;
import java.net.InetAddress;

import ke.data.Action;
import ke.data.CONSTANT;
import ke.engine.MasterMind;


public class TedPlayer extends TedPokerClient{
	/** 
	 * the backend Interface
	 */
    protected MasterMind backend;
    protected test hutch;
    /**
     * Initialize this player.
     */
    public TedPlayer() {
    	backend  = new MasterMind();
    	hutch = new test();
    }

    
    /**
     * sends the decided action to the server
     */
    public void reconsider_state_and_make_a_move() {
    	
    	System.out.println("Let me think.");
 
    	backend.think_about(state,hutch);
 
    	send_action(backend.getAction());

    }
    
    /**
     * sends the decided action to the server
     */
    public void reconsider_state() {
    	
    	System.out.println("So so.");
    	
    }
    
    
    /**
     * A function for startme.bat to call
     */
    public static void main(String[] args) throws Exception{
        TedPlayer pp = new TedPlayer();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        pp.run();

    }
}