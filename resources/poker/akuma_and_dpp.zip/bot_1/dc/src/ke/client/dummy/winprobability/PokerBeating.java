package ke.client.dummy.winprobability;

import ca.ualberta.cs.poker.free.dynamics.Card;

public final class PokerBeating{
	static boolean isFlush(final Hand hand){
		return hand.cards[0].suit.index == hand.cards[1].suit.index &&
				hand.cards[0].suit.index == hand.cards[2].suit.index &&
				hand.cards[0].suit.index == hand.cards[3].suit.index &&
				hand.cards[0].suit.index == hand.cards[4].suit.index;
	}

	static boolean containsCard(final Hand hand, final int rank){
		for(int i = 0; i < 5; ++i){
			if(hand.cards[i].rank.index == rank)
				return true;
		}
		return false;
	}

	static void getMinMax(final Hand hand, int index[]){
		int iMin = 0, iMax = 0;
		for(int i = 1; i < 5; ++i){
			if(hand.cards[i].rank.index < hand.cards[iMin].rank.index)
				iMin = i;
			else if(hand.cards[i].rank.index > hand.cards[iMax].rank.index){
				iMax = i;
			}
		}
		index[0] = iMin;
		index[1] = iMax;
	}

	static boolean isStraight(final Hand hand, final int iMin, final int iMax){ // vorher pr�fen ob kein Paar vorhanden ist?
		if(hand.cards[iMax].rank.index - hand.cards[iMin].rank.index == 4){
			return containsCard(hand, hand.cards[iMin].rank.index + 1) && containsCard(hand, hand.cards[iMin].rank.index + 2) && containsCard(hand, hand.cards[iMin].rank.index + 3);
		}
		return false;
	}

	static boolean isStraightStartingWithAce(final Hand hand, final int iMin, final int iMax){ // A-2-3-4-5
		if(hand.cards[iMin].rank.index == Card.Rank.TWO.index && hand.cards[iMax].rank.index == Card.Rank.ACE.index){
			return containsCard(hand, Card.Rank.THREE.index) && containsCard(hand, Card.Rank.FOUR.index) && containsCard(hand, Card.Rank.FIVE.index);
		}
		return false;
	}

	static boolean isTwoOfAKind(final Hand hand, int index[]){
		int i = index[0];
		int j = index[1];
		while(i < 4){
			for(; j < 5; ++j){ //for(j = i + 1; j < 5; ++j){
				if(hand.cards[i].rank.index == hand.cards[j].rank.index){
					index[0] = i;
					index[1] = j;
					return true;
				}
			}
			++i;
			j = i + 1;
		}
		index[0] = i;
		index[1] = j;
		return false;
	}

	static boolean isThreeOfAKind(final Hand hand, int index[]){ // vorher isTwoOfAKind aufrufen
		int i = index[0];
		int j = index[1];
		int k = index[2];
		for(; k < 5; ++k){ //for(k = j + 1; k < 5; ++k){ // dritte suchen
			if(hand.cards[i].rank.index == hand.cards[k].rank.index){
				index[0] = i;
				index[1] = j;
				index[2] = k;
				return true;
			}
		}

		// drei andere suchen
		++i;
		for(; i < 3; ++i){
			for(j = i + 1; j < 4; ++j){
				int subIndex[] = new int[]{i, j};
				if(isTwoOfAKind(hand, subIndex)){
					i = subIndex[0];
					j = subIndex[1];
					for(k = j + 1; k < 5; ++k){
						if(hand.cards[i].rank.index == hand.cards[k].rank.index){
							index[0] = i;
							index[1] = j;
							index[2] = k;
							return true;
						}
					}
				}
				else{
					i = subIndex[0];
					j = subIndex[1];
				}
			}
		}
		index[0] = i;
		index[1] = j;
		index[2] = k;
		return false;
	}

	static boolean isFourOfAKind(final Hand hand, int index[]){ // vorher isThreeOfAKind aufrufen
		int i = index[0];
		int j = index[1];
		int k = index[2];
		for(; k < 5; ++k){ //for(k = k + 1; k < 5; ++k){
			if(hand.cards[i].rank.index == hand.cards[k].rank.index){
				index[0] = i;
				index[1] = j;
				index[2] = k;
				return true;
			}
		}
		index[0] = i;
		index[1] = j;
		index[2] = k;
		return false;
	}

	static boolean isFullHouse(final Hand hand, final int houseRank, int index[]){ // vorher isThreeOfAKind aufrufen
		int iFull = index[0];
		for(iFull = 0; iFull < 4; ++iFull){
			if(hand.cards[iFull].rank.index != houseRank){
				int j = iFull + 1;
				int subIndex[] = new int[]{iFull, j};
				if(isTwoOfAKind(hand, subIndex) && hand.cards[subIndex[0]].rank.index != houseRank){
					iFull = subIndex[0];
					j = subIndex[1];
					index[0] = iFull;
					return true;
				}
				else{
					iFull = subIndex[0];
					j = subIndex[1];
				}
			}
		}
		index[0] = iFull;
		return false;
	}
}
