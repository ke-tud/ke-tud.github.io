package ke.engine;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ke.client.ClientRingDynamics;
import ke.data.Action;

public class PreFlop{
	public static final int probs[][] = new int[][]{
			{304, 234, 242, 250, 243, 242, 255, 268, 284, 301, 322, 347, 386},
			{193, 333, 259, 268, 261, 260, 259, 275, 291, 308, 329, 354, 395},
			{202, 221, 365, 286, 280, 279, 278, 280, 299, 316, 337, 363, 404},
			{210, 230, 249, 398, 297, 297, 297, 299, 304, 324, 346, 371, 413},
			{202, 222, 242, 261, 429, 316, 315, 317, 323, 330, 354, 380, 409},
			{201, 220, 241, 261, 280, 463, 334, 338, 344, 351, 362, 390, 422},
			{214, 220, 240, 260, 279, 300, 498, 357, 364, 371, 383, 399, 434},
			{228, 236, 241, 262, 282, 303, 323, 535, 384, 392, 404, 421, 444},
			{244, 252, 261, 268, 287, 309, 331, 353, 575, 416, 429, 446, 469},
			{262, 270, 279, 288, 294, 316, 338, 361, 387, 611, 439, 457, 480},
			{283, 292, 301, 310, 319, 328, 350, 373, 400, 411, 649, 469, 493},
			{310, 318, 328, 337, 346, 358, 367, 391, 417, 429, 442, 688, 506},
			{351, 361, 371, 380, 377, 391, 403, 415, 442, 454, 467, 481, 734}};

	final int NoCall = 1000, NoRaise = 1000;
	enum Situation{					FirstInBu,	FirstInSb,	ThreeBet,	RaiseAndCaller,	BigBlindBu,	BigBlindSb,	SmallBlind,	OneCaller, TwoCaller, Complex};
	int minForRaise[] = new int[]{	334,		315,		386,		467,			422,		365,		422,		403,		442};
	int minForCall[] = new int[]{	NoCall, 	NoCall, 	NoCall,		384,			310,		279,		286,		286,		/*357*/0}; // wenn beide callen, k�nnen wir checken
	
	public Situation getSituation(ClientRingDynamics state){
		if(state.bettingSequence.length() == 0)
			return Situation.FirstInBu;
		if(state.bettingSequence.equalsIgnoreCase("f"))
			return Situation.FirstInSb;
		if(state.bettingSequence.equalsIgnoreCase("rr"))
			return Situation.ThreeBet;
		if(state.bettingSequence.equalsIgnoreCase("r") || state.bettingSequence.equalsIgnoreCase("rc") || state.bettingSequence.equalsIgnoreCase("cr"))
			return Situation.RaiseAndCaller;
		if(state.bettingSequence.equalsIgnoreCase("rf"))
			return Situation.BigBlindBu;
		if(state.bettingSequence.equalsIgnoreCase("fr"))
			return Situation.BigBlindSb;
		if(state.bettingSequence.equalsIgnoreCase("c"))
			return Situation.SmallBlind;
		if(state.bettingSequence.equalsIgnoreCase("fc") || state.bettingSequence.equalsIgnoreCase("cf"))
			return Situation.OneCaller;
		if(state.bettingSequence.equalsIgnoreCase("cc"))
			return Situation.TwoCaller;
		return Situation.Complex;
	}
	
	public Action getAction(ClientRingDynamics state){
		int sit = getSituation(state).ordinal();
		int prob = getProb(state.hole[state.seatTaken]);
		if(sit < Situation.Complex.ordinal()){
			if(prob >= minForRaise[sit])
				return Action.RAISE;
			
			if(prob >= minForCall[sit])
				return Action.CALL;
			
			return Action.FOLD;
		}
		// else use the decision of the DummyPlayer
		int inPot = 0;
		
		for(int bet : state.inPot)
			inPot += bet;

		boolean canRaise = state.canRaise(state.seatTaken);
		boolean preFlop = state.roundIndex == 0;
		int numActivePlayers = state.getNumActivePlayers();
		int amountToCall = state.getAmountToCall(state.seatTaken);
		int amountToRaise = amountToCall + state.lastBetSize;//state.getMinRaise(state.seatTaken);
		float benefitOfRaise = prob * inPot - amountToRaise;
		float benefitOfCall = prob * inPot - amountToCall;
		
		if(canRaise && benefitOfRaise >= 0 && prob > 1.0f - 1.0f/numActivePlayers + state.roundBets*0.05f)
			return Action.RAISE;
		
		if(benefitOfCall >= 0 || amountToCall == 0 || (preFlop && prob >= 1.0f/numActivePlayers))
			return Action.CALL;
		
		return Action.FOLD;
	}

	private int getProb(Card[] cards){
		boolean suited = cards[0].suit == cards[1].suit;
		int x, y;
		if(suited){
			x = Math.max(cards[0].rank.index, cards[1].rank.index);
			y = Math.min(cards[0].rank.index, cards[1].rank.index);
		}
		else{
			x = Math.min(cards[0].rank.index, cards[1].rank.index);
			y = Math.max(cards[0].rank.index, cards[1].rank.index);
		}
		return probs[y][x];
	}
}
