/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package ke.data;

/**
 * User: sam
 * Date: Apr 2, 2005
 * Time: 4:03:51 PM
 */
public final class Card implements Comparable<Card> {
    private final Rank rank;
    private final Suit suit;

    public int compareTo(Card card) {
        return rank.compareTo(card.rank);
    }

    public enum Suit {
        CLUBS, DIAMONDS, HEARTS, SPADES;

        private final String[] suitStrings = {"c", "d", "h", "s"};

        public String toString() {
            return suitStrings[this.ordinal()];
        }
    }

    public enum Rank {
        TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE;

        private final String[] rankStrings = {"2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"};

        public String toString() {
            return rankStrings[this.ordinal()];
        }
    }

    public Rank getRank() {
        return rank;
    }

    public Suit getSuit() {
        return suit;
    }

    public Card(Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
    }
    
    public Card(int rank, int suit) {
       switch (rank) {
       	case 0: this.rank = Rank.TWO; break;
       	case 1: this.rank = Rank.THREE; break;
       	case 2: this.rank = Rank.FOUR; break;
       	case 3: this.rank = Rank.FIVE; break;
       	case 4: this.rank = Rank.SIX; break;
       	case 5: this.rank = Rank.SEVEN; break;
       	case 6: this.rank = Rank.EIGHT; break;
       	case 7: this.rank = Rank.NINE; break;
       	case 8: this.rank = Rank.TEN; break;
       	case 9: this.rank = Rank.JACK; break;
       	case 10: this.rank = Rank.QUEEN; break;
       	case 11: this.rank = Rank.KING; break;
       	case 12: this.rank = Rank.ACE; break;
       	default: this.rank = null; break;
       }
       switch (suit) {
      	case 0: this.suit = Suit.CLUBS; break;
      	case 1: this.suit = Suit.DIAMONDS; break;
      	case 2: this.suit = Suit.HEARTS; break;
      	case 3: this.suit = Suit.SPADES; break;
      	default: this.suit = null; break;
      }   
    }

    public String toString() {
        return "" + rank + suit;
    }
}
