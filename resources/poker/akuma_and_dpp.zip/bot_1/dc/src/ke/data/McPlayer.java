package ke.data;

import java.security.SecureRandom;
import java.lang.Cloneable;

import ke.client.dummy.OpponentStatistics;

public class McPlayer implements Cloneable{
	
	private Hand handCards; 
	private int roundSeat;
	private int inPot;
	private int initialInPot;
	private int stack = 0;
	private double[][] handRange;
	private int playerID;
	private double handRangeSum;
	private boolean isActive = true;
	private boolean isInitialActive = true;
	private int playerTyp = 0;
	private Action lastAction;
	private double callProp;
	
	public McPlayer(double[][] handRange, double handRangeSum){
		this.handRange = handRange;
		this.handRangeSum = handRangeSum;
	}
	
	public void setCallProp(double call){
		callProp = call;
	}
	
	public Action getLastAction(){
		return lastAction;
	}
	
	public void setLastAction(Action action){
		lastAction = action;
	}
	
	public void setHandRangeSum(double sum){
		handRangeSum = sum;
	}
		
	public int getPlayerTyp(){
		return playerTyp;
	}
	
	
	
	private void setPlayerTyp(int typ){
		this.playerTyp = typ;
	}
	
	public int getStack(){
		return stack;
	}
	
	public double getHandRangeSum(){
		return handRangeSum;
	}
	
	public double[][] getHandRange(){
		return handRange;
	}
	
	public void setStack(int stack){
		this.stack = stack;
	}
	
	public void addPlayerID(int playerID){
		this.playerID = playerID;
	}
	
	public int getPlayerID(){
		return playerID;
	}
	
	public void addHand(Hand hand){
		this.handCards = hand;
	}
	
	public Hand getHand(){
		return handCards;
	}
	
	public int getInpot(){
		return inPot;
	}
	
	public void setHandRange(double[][] handRange){
		this.handRange = handRange;
	}
	
	
	public void setInitialPot(int inPot, boolean isActive){
		initialInPot = inPot;
		this.inPot = inPot;
		this.isActive = isActive;
		this.isInitialActive = isActive;
	}
	
	public boolean isActive(){
		return isActive;
	}
	
	public void setActive(boolean isActive){
		this.isActive = isActive;;
	}
		
	public int getRoundSeat(){
		return roundSeat;
	}
	
	public void setRoundSet(int seat){
		roundSeat = seat;
	}
	
	public Action play(int pot, int lastActionPot ,boolean isBetAllowed, int roundIndex, Action action){
		Action returnAction;
		double random_number;
		SecureRandom random = new SecureRandom();
		if((lastActionPot-inPot)<0){
			System.out.println("LastActionPot Fehler!");
			System.err.println("LastActionPot Fehler bla!");
		}
		// Actionbestimmung
		double relativeCallProb = callProp;
		if(lastAction != null && lastAction.equals(Action.RAISE))
			relativeCallProb = callProp-0.05;
		else if(lastAction != null)
			relativeCallProb = callProp+0.05;
		
		if (action != null) 
			returnAction = action;
		else{
			// Aktionsauswahl
			random_number = random.nextDouble();
			if (random_number<0.00 && (lastActionPot-inPot)!=0){
				returnAction = Action.FOLD;
		    } else if (random_number<=relativeCallProb || !isBetAllowed){
		    	returnAction = Action.CALL;
		    } else {
		    	returnAction = Action.RAISE;
		    }	
		}
		if(!returnAction.equals(Action.FOLD)){
			// myInPot Aktualisierung
			if(returnAction.equals(Action.CALL))
				inPot += (lastActionPot - inPot);
			else//Raise
				if(roundIndex < 2)
					inPot += (lastActionPot - inPot) + 2;
				else
					inPot += (lastActionPot - inPot) + 4;
		}
		if(returnAction.equals(Action.RAISE) && !isBetAllowed)
			System.err.println("Raise obwohl !isBetAllowed");
		
		return returnAction;
	}

	
	public void reset(){
		inPot = initialInPot;
		isActive = isInitialActive;
	}
	
	public McPlayer clone() 
	  { 
	    try { 	 
	      return (McPlayer) super.clone(); 
	    } catch ( CloneNotSupportedException e ) { 
	      // this shouldn't happen, since we are Cloneable 
	      throw new InternalError(); 
	    } 
	  } 
	
}
