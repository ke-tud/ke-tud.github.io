java -cp build:lib/pokerserver.jar ke.client.TedPlayer_opponent  $1 $2


