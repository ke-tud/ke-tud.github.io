java -cp build:pokerserver.jar ke.client.dummy.DummyPlayer  $1 $2


