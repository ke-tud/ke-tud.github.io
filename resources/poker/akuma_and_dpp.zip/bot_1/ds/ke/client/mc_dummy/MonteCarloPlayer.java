package ke.client.mc_dummy;


import java.net.InetAddress;

import ke.client.timed.ActionFunction;
import ke.client.timed.TimedPokerClient;
import ke.data.Action;
import ke.engine.MonteCarloMasterMind;
import ke.timermgmt.ITimerFunction;
import ke.timermgmt.Timer;


/**
 * The actuall poker mathc participant which is called 
 * from the shell-skript startme.sh/startme.bat . 
 * 
 * @author Daniel Schumann
 */
public class MonteCarloPlayer extends TimedPokerClient {
	/** 
	 * the backend Interface
	 */
    protected MonteCarloMasterMind backend;
    
    /**
     * the function that should be called from within the timer
     */
    private ITimerFunction function;

    /**
     * Initialize this player.
     */
    public MonteCarloPlayer() {
    	backend  = new MonteCarloMasterMind();
        function = new ActionFunction(this);        
    }
    
    /**
     * start the thinkprocess and the timer, 
     */
    public void startTakeAction() {
        backend.think_about(state);
        //timerManager.waitForDecision(function);
        waitForDecision(function);
    }
    
	public synchronized void waitForDecision(ITimerFunction function) {
		long timeStarted = System.currentTimeMillis();
        Timer timer = new Timer(timeStarted, timeStarted + ((4-state.roundIndex)*512), function); // ~2s PreFlop, ~1.5s Flop, ~1s Turn, ~0.5s River
        timer.start();
	}


    /**
     * sends the decided action to the server
     */
    public void sendAction(){
        try {
            // the decision engine has to be capable of returning a decision at any time
        	Action a = backend.getAction();
        	/*
        	if (CONSTANT.DEBUG) {
        		System.out.println("Our decision: " + a + " Our Amount in: " + this.state.inPot[this.state.seatTaken]);
        		System.out.print("Hole|Board:");
        		for (Card c: this.state.hole[this.state.seatTaken]) {
        			if (c!=null)
        				System.out.print(c);
        		}
        		System.out.print("|");
        		for (Card c: this.state.board) {
        			if (c!=null)
        				System.out.print(c + "|");
        		}
        		System.out.println();
        	}
            */
        	
        	if (a == Action.RAISE && state.canRaise(state.seatTaken))
        		sendRaise();
            else if (a == Action.RAISE || a == Action.CALL)
            	sendCall();
            else
            	sendFold();
        	
        } catch(Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
    /** 
     * what to do after our Action
     */
 	public void afterTakeAction() {
      //maybe cleanup Mastermind waste
      //kill simulations etc..
	}
    
    /**
     * A function for startme.bat to call
     */
    public static void main(String[] args) throws Exception{
        MonteCarloPlayer pp = new MonteCarloPlayer();
        System.out.println("Attempting to connect to "+args[0]+" on port "+args[1]+"...");

        pp.connect(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
        System.out.println("Successful connection!");
        pp.run();

    }
}
