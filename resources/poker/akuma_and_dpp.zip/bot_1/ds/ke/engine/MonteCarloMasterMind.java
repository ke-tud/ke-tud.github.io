package ke.engine;

import java.security.SecureRandom;
import java.util.Random;

import ke.client.ClientRingDynamics;
import ke.client.dummy.winprobability.Deck;
import ke.client.dummy.winprobability.GameSimulator;
import ke.client.dummy.winprobability.Hand;
import ke.data.Action;
import ca.ualberta.cs.poker.free.dynamics.Card;

public class MonteCarloMasterMind extends MasterMind{
	MonteCarloThread mc;

	public void think_about(ClientRingDynamics state){
		currently_best_action = Action.CALL;
		mc = new MonteCarloThread(this, state, new ProbabilityTripleProvider(state.seatTaken));

		// start monte carlo simulation
		mc.start();
	}

	public Action getAction(){
		mc.stopSimulation();
		return currently_best_action;
	}
}

/**
 * Standard Action is CALL.
 * A Monte Carlo simulation is used to determine any better action in the current situation. 
 */

class MonteCarloThread extends Thread{

	MasterMind mind;
	ClientRingDynamics state;
	ProbabilityTripleProvider probTriples;
	SimulationState simState = new SimulationState();
	int amount[] = new int[3];
	int counter[] = new int[3];

	boolean stopThread = false;
	public final int desiredNumberOfSimulations = 8192;
	private int simCounter = 0;

	static Random random = new SecureRandom();
	
	public static final int FOLD = 0, CALL = 1, RAISE = 2;
	private static final int RIVER = 3;
	private static final int NUM_MAX_BETS = 4;
	/**
	 * 
	 * @param client 
	 * @param mind
	 * @param state
	 * @param probabilityTriples[playerCount][3] Wahrscheinlichkeitsverteilungen f�r die Aktionen (fold/call/raise) der Spieler w�hrend der Simulation, in zehntel Prozent, z.B. (0, 500, 500) oder (333,334,333)
	 */
	public MonteCarloThread(MasterMind mind, ClientRingDynamics state, ProbabilityTripleProvider probTriples){
		this.mind = mind;
		this.state = state;
		this.probTriples = probTriples;
	}

	public void run(){
		amount[FOLD] = amount[CALL] = amount[RAISE] = 0;
		counter[FOLD] = counter[CALL] = counter[RAISE] = 0;
//		try{
			while(!stopThread && !accuracyReached()){
				//startSimulationWith(FOLD); // we need not to simulate this, because we already know the result (-> 0)
				//if(stopThread) break;
				startSimulationWith(CALL);
				if(!stopThread && state.canRaise(state.seatTaken)){
					startSimulationWith(RAISE);
				}
			}
//		}
//		catch (InterruptedException e){
//		}
	}
	
	private void startSimulationWith(int firstAction){
		// initialize simulation state
		simState.roundIndex = state.roundIndex;
		simState.roundBets = state.roundBets;
		simState.lastActionPlayer = state.lastActionSeat;
		simState.active = state.active.clone();
		simState.playerToAct = state.seatTaken;
		simState.numActivePlayers = state.getNumActivePlayers();
		simState.inPot = new int[state.inPot.length];
		simState.inPotThisRound = state.inPot.clone();
		simState.maxBetInRound = maxArray(simState.inPotThisRound);
		simState.betAmount = state.getLimitBet(); // I think this is always 2

		probTriples.setNextAction(firstAction); // we want to make the desired action at first
		playerDoAction(); // do the action
		nextActivePlayer(simState); // switch to next player
		amount[firstAction] += simulate();
		++counter[firstAction];
	}

	/**
	 * 
	 * @param roundIndex 0=PreFlop, 1=Flop, 2=Turn, 3=River, 4=Showdown
	 * @param roundBets number of bets in this round, maximum number of bets is defined by NUM_MAX_BETS
	 * @param curPlayerIndex index of the player 
	 * @param numActivePlayers
	 */
	private int simulate(){
		if(simState.numActivePlayers <= 1){ // all other players folded
			nextRound();
			//++counter[simState.playerToAct];
			//amount[simState.playerToAct] += sumArray(simState.inPot);
			if(simState.playerToAct == state.seatTaken)
				return sumArray(simState.inPot);
			return -simState.inPot[state.seatTaken];
		}
		else if(simState.lastActionPlayer == simState.playerToAct){ // it's the turn of the last acted player -> next round
			nextRound();
			if(simState.roundIndex > RIVER){ // showdown
				return evaluateResult();
			}
		}
		// proceed in current round
		playerDoAction();
		nextActivePlayer(simState);
		return simulate();
	}

	private void playerDoAction(){
		int action = randomAction(probTriples.getProbabilityTriple(simState));
		if(action == RAISE && simState.roundBets >= NUM_MAX_BETS)// no further raises possible
			action = CALL;
		switch(action){
		case FOLD:
			simState.active[simState.playerToAct] = false;
			--simState.numActivePlayers;
			break;
		case CALL:
			if(simState.inPotThisRound[simState.playerToAct] < simState.maxBetInRound)
				simState.inPotThisRound[simState.playerToAct] += simState.maxBetInRound - simState.inPotThisRound[simState.playerToAct];
			break;
		case RAISE:
			simState.maxBetInRound += simState.betAmount; // increase bet amount
			simState.inPotThisRound[simState.playerToAct] += simState.maxBetInRound - simState.inPotThisRound[simState.playerToAct]; // pay the remaining amount
			++simState.roundBets; // increase the number of bets
			simState.lastActionPlayer = simState.playerToAct; // mark as last acted player
			break;
		}
	}

	/**
	 * updates the SimulationState (attribute <b>simState</b>) to represent the next round 
	 */
	private void nextRound(){
		++simState.roundIndex; // next round
		for(int i = 0; i < simState.inPot.length; ++i){
			simState.inPot[i] += simState.inPotThisRound[i]; // add all bets to the pot
			simState.inPotThisRound[i] = 0; // reset bets
		}
		simState.roundBets = 0; // reset the number of bets
		simState.playerToAct = 0; // from RingDynamics.initializeBets() -> Player 0 sits behind the button and so is the first player to act...
		nextActivePlayer(simState); // ...or the next still active player
		simState.lastActionPlayer = simState.playerToAct; // the first player makes the first "action", this may also be a "call" (i.e. check)
	}

	/**
	 * updates the field playerToAct to the next active player
	 * @param simState
	 */
	private void nextActivePlayer(SimulationState simState){
		int nextPlayer = (simState.playerToAct + 1) % simState.active.length;
		while(!simState.active[nextPlayer])
			nextPlayer = (nextPlayer + 1) % simState.active.length;
		simState.playerToAct = nextPlayer;
	}

	/**
	 * @param probTriple has to be a <b>int[3]</b> in the format (30%,30%,40%) -> (300,600,1000)
	 * @return FOLD=0 | CALL=1 | RAISE=2
	 */
	static int randomAction(int probTriple[]){
		int ran = random.nextInt(1000);
		if(ran < probTriple[FOLD])
			return FOLD;
		if(ran < probTriple[CALL])
			return CALL;
		return RAISE;
	}
	

	private int evaluateResult(){
		Deck deck = new Deck();
		Card community[] = new Card[5];
		int boardCards = 0;
		switch(state.roundIndex){
		case 3: //River
			boardCards += 1;
		case 2: //Turn
			boardCards += 1;
		case 1: //Flop
			boardCards += 3;
		case 0: //Pre-Flop
			for(int i = 0; i < boardCards; ++i) // fill in the known cards
				community[i] = state.board[i];
			break;
		}
		for(int i = boardCards; i < community.length; ++i) // fill up with random cards
			community[i] = deck.get();

		Hand hands[] = new Hand[simState.numActivePlayers];
		for(int i = 0; i < hands.length; ++i){
			Card player[] = new Card[2];
			if(i == state.seatTaken){
				player[0] = deck.get(state.hole[state.seatTaken][0]);
				player[1] = deck.get(state.hole[state.seatTaken][1]);
			}
			else{
				player[0] = deck.get();
				player[1] = deck.get();				
			}
			hands[i] = GameSimulator.getBest(player, community);
		}
		int counterWins[] = new int[simState.numActivePlayers];
		int counterDraws[] = new int[simState.numActivePlayers];
		GameSimulator.evaluateResult(simState.numActivePlayers, counterWins, counterDraws, hands);
		
		int indexOfActivePlayers[] = new int[simState.numActivePlayers];
		int index = 0;
		for(int i = 0; i < indexOfActivePlayers.length; ++i){
			while(!simState.active[index])
				++index;
			indexOfActivePlayers[i] = index;
		}
		int winner = -1;
		for(int i = 0; i < counterWins.length; ++i){
			if(counterWins[i] > 0){
				winner = indexOfActivePlayers[i];
				break;
			}
		}
		if(winner >= 0){ // we have a winner
			//amount[winner] += sumArray(simState.inPot);
			if(winner == state.seatTaken)
				return sumArray(simState.inPot);
		}
		else{ // draw
			int split = sumArray(simState.inPot) / sumArray(counterDraws);
			for(int i = 0; i < counterDraws.length; ++i){
				if(counterDraws[i] > 0 && indexOfActivePlayers[i] == state.seatTaken){
					//amount[indexOfActivePlayers[i]] += split;
					return split;
				}
			}
		}
		return -simState.inPot[state.seatTaken];
	}

	/**
	 * @param array
	 * @return the maximum of all elements in the given array
	 */
	private int maxArray(int[] array){
		int max = array[0];
		for(int i = 1; i < array.length; ++i)
			if(array[i] > max)
				max = array[i];
		return max;
	}

	/**
	 * @param array
	 * @return the sum of all elements in the given array
	 */
	private int sumArray(int[] array){
		int sum = array[0];
		for(int i = 1; i < array.length; ++i)
			sum += array[i];
		return sum;
	}


	/**
	 * May be used to stop the simulation earlier.
	 * But additional modifications are needed, to actually send the action to the server!
	 * (a thread-safe call of sendAction from the PokerClient is needed
	 * in the run method of this class, when the simulation has ended)
	 * @return <b>true</b> to stop the simulation, <b>false</b> to continue
	 */
	private boolean accuracyReached(){
		if(simCounter >= desiredNumberOfSimulations)
			return true;
		++simCounter;
		return false;
	}

	/**
	 * Called from outside, to stop the simulation, e.g. when
	 */
	void stopSimulation(){
		stopThread = true;
		int averageAmount[] = new int[3];
		for(int i = 0; i < averageAmount.length; ++i)
			averageAmount[i] = amount[i] / Math.max(counter[i], 1);
		
		System.out.println("I've done " + simCounter + "/" + desiredNumberOfSimulations + " simulations.");
		System.out.print("The results are: ");
		for(int i = 0; i < averageAmount.length; ++i){
			System.out.print(averageAmount[i] + " ");
		}
		System.out.println();
		System.out.print("So I decide to ");
		if(averageAmount[CALL] >= 0 && averageAmount[CALL] > averageAmount[RAISE])
			mind.currently_best_action = Action.CALL;
		else if(averageAmount[RAISE] >= 0 && averageAmount[RAISE] >= averageAmount[CALL])
			mind.currently_best_action = Action.RAISE;
		else
			mind.currently_best_action = Action.FOLD;
		System.out.println(mind.currently_best_action);
	}
}

class SimulationState{
	public int betAmount;
	public int roundIndex, roundBets, lastActionPlayer, playerToAct, numActivePlayers, maxBetInRound;
	public int inPot[], inPotThisRound[];
	public boolean active[];

	public SimulationState(){}
	
	public SimulationState(int roundIndex, int roundBets, int lastActionPlayer, int playerToAct, int numActivePlayers, boolean[] active){
		this.roundIndex = roundIndex;
		this.roundBets = roundBets;
		this.lastActionPlayer = lastActionPlayer;
		this.playerToAct = playerToAct;
		this.numActivePlayers = numActivePlayers;
		this.active = active.clone();
	}
}

class ProbabilityTripleProvider{
	int thisPlayer;
	int nextAction = -1;
	
	ProbabilityTripleProvider(int thisPlayer){
		this.thisPlayer = thisPlayer;
	}
	
	public void setNextAction(int action){
		nextAction = action;
	}

	public int[] getProbabilityTriple(SimulationState simState){
		int triple[];
		if(nextAction < MonteCarloThread.FOLD){ // default action
			triple = new int[]{0,500,1000}; //(0%,50%,50%)
			//triple = new int[]{100,700,1000}; //(10%,60%,30%) // more realistic!?
		}
		else{
			if(nextAction == MonteCarloThread.FOLD){
				triple = new int[]{1000,1000,1000}; // (100%,0%,0%)
			}
			else if(nextAction == MonteCarloThread.FOLD){
				triple = new int[]{0,1000,1000}; // (0%,100%,0%)
			}
			else{
				triple = new int[]{0,0,1000}; // (0%,0%,100%)
			}
			nextAction = -1;
		}
		return triple;
	}
}