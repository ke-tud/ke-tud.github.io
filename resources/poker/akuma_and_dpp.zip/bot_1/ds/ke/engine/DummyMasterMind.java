package ke.engine;

import java.security.SecureRandom;

import ke.client.ClientRingDynamics;
import ke.client.dummy.winprobability.GameSimulator;
import ke.data.Action;
import ca.ualberta.cs.poker.free.dynamics.Card;


public class DummyMasterMind {
	SecureRandom random = new SecureRandom();
	Action currently_best_action = Action.CALL;
	
	int lastHandNumber = -1;
	int lastRoundIndex = -1;
	float prob = 0.0f;

	/**
	 * Analysis the situation. And stores the statistically
	 * correct decision in currently_best_action.
	 * 
	 * @param state_of_the_world
	 */
	public void think_about(ClientRingDynamics state_of_the_world){
		if(state_of_the_world.handNumber != lastHandNumber || state_of_the_world.roundIndex != lastRoundIndex){
			prob = evalHand(state_of_the_world);
			lastHandNumber = state_of_the_world.handNumber;
			lastRoundIndex = state_of_the_world.roundIndex;
			System.out.println("I estimate my probability of winning to " + prob);
		}
		int inPot = 0;
		
		for(int bet : state_of_the_world.inPot)
			inPot += bet;

		boolean canRaise = state_of_the_world.canRaise(state_of_the_world.seatTaken);
		boolean preFlop = state_of_the_world.roundIndex == 0;
		int numActivePlayers = state_of_the_world.getNumActivePlayers();
		int amountToRaise = state_of_the_world.getMinRaise(state_of_the_world.seatTaken);
		int amountToCall = state_of_the_world.getAmountToCall(state_of_the_world.seatTaken);
		float benefitOfRaise = prob * inPot - amountToRaise;
		float benefitOfCall = prob * inPot - amountToCall;
//		if(prob >= 0.7){
		if(canRaise && benefitOfRaise >= 0 && prob > 1.0f - 1.0f/numActivePlayers){
			currently_best_action = Action.RAISE;
			System.out.println("So I will RAISE, to win approx. " + benefitOfRaise + "[inPot=" + inPot + ", amountToRaise=" + amountToRaise + ", amountToCall=" + amountToCall + "]");
		}
//		else if(prob >= 0.3){
		else if(benefitOfCall >= 0 || amountToCall == 0 || (preFlop && prob >= 1.0f/numActivePlayers)){
			currently_best_action = Action.CALL;
			System.out.println("So I will CALL, to win approx. " + benefitOfCall + "[inPot=" + inPot + ", amountToRaise=" + amountToRaise + ", amountToCall=" + amountToCall + "]");
		}
		else{
			currently_best_action = Action.FOLD;
			System.out.println("So I will FOLD, to not loose at least " + (-Math.max(benefitOfCall, benefitOfRaise)) + "[inPot=" + inPot + ", amountToRaise=" + amountToRaise + ", amountToCall=" + amountToCall + "]");
		}
	}
	
	private float evalHand(ClientRingDynamics ws){
		final int simulationRounds = 4096;
		float prob = 0.0f;
		int boardCards = 0;
		switch(ws.roundIndex){
		case 3: //River
			boardCards += 1;
		case 2: //Turn
			boardCards += 1;
		case 1: //Flop
			boardCards += 3;
		case 0: //Pre-Flop
			//System.out.println("I believe my hole cards are a " + ws.hole[ws.seatTaken][0].rank + " of " + ws.hole[ws.seatTaken][0].suit + " and a " + ws.hole[ws.seatTaken][1].rank + " of " + ws.hole[ws.seatTaken][1].suit);
			//prob = ((float)ws.hole[ws.seatTaken][0].rank.index + (float)ws.hole[ws.seatTaken][1].rank.index) / (float)(Rank.ACE.index + Rank.ACE.index);
			//break;
/*			prob = 0.1f;
			for(int i = 0; i < boardCards; ++i)
				if(ws.hole[ws.seatTaken][0].rank.index == ws.board[i].rank.index || 
				   ws.hole[ws.seatTaken][1].rank.index == ws.board[i].rank.index)
					prob = 0.9f;*/
			Card cards[] = new Card[boardCards + 2];
			cards[0] = ws.hole[ws.seatTaken][0];
			cards[1] = ws.hole[ws.seatTaken][1];
			for(int i = 0; i < boardCards; ++i)
				cards[i + 2] = ws.board[i];
			prob = GameSimulator.getWinProbability(simulationRounds, ws.getNumActivePlayers(), cards);

			break;
		}
		return prob;
	}

	public Action getAction(){
		return currently_best_action;
	}	
}


