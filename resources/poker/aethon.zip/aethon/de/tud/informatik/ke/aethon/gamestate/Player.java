package de.tud.informatik.ke.aethon.gamestate;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.common.AbstractPot;
import de.tud.informatik.ke.aethon.common.Table;

public class Player {
	
	private final String name;
	protected final int seat;
	protected double stack;
	protected double lastGain;
	protected Card[] holeCards;
	
	protected Hand hand;
	protected Table table;
	protected AbstractPot pot;
	
	public Player(int seat, String name) {
		this.name = name;
		this.seat = seat;
		stack = 0;
		holeCards = new Card[2];
		
		hand = null;
		table = null;
		pot = null;
	}
	
	public Player(Player player, Hand hand, Table table, AbstractPot pot) {
		name = player.name;
		seat = player.seat;
		stack = player.stack;
		lastGain = player.lastGain;
		
		holeCards = new Card[2];
		if(player.holeCards[0] != null) {
			holeCards[0] = new Card(player.holeCards[0].toString());
			holeCards[1] = new Card(player.holeCards[1].toString());
		}
		
		this.hand = hand;
		this.table = table;
		this.pot = pot;
	}
	
	/**
	 * Adds the gained CHIPS to the player's stack.
	 * 
	 * @param gain
	 */
	public void addToStack(double gain) {
		lastGain += gain;
		stack += gain;
	}
	
	/**
	 * The player calls the bet
	 */
	public void call() {
		contribute(pot.getAmountToCall(seat));
		table.check();
	}
	
	private void contribute(int amount) {
		lastGain -= amount;
		stack -= amount;
		pot.contribute(this,amount);
	}
	
	public void contributeBigBlind() {
		hand.bet();
		contribute(Hand.bigBlind);
	}
	
	public void contributeSmallBlind() {
		contribute(Hand.smallBlind);
	}
	
	/**
	 * @return true, if the players names are equal and false else.
	 */
	@Override
	public boolean equals(Object object) {
		if(!(object instanceof Player)) {
			throw new IllegalArgumentException(
					"The argument has to be instance of Player. Argument is instance of"
							+ object.getClass().getSimpleName());
		}
		return name.equals(((Player)object).name);
	}
	
	/**
	 * The player folds
	 */
	public void fold() {
		table.fold(this);
	}
	
	/**
	 * @return the hole cards of this player.
	 */
	public Card[] getHoleCards() {
		return holeCards;
	}
	
	/**
	 * @return the last amount the player won
	 */
	public double getLastGain() {
		return lastGain;
	}
	
	public String getName() {
		return name;
	}
	
	/**
	 * @return the index (seat) the player tooks place.
	 */
	public int getSeat() {
		return seat;
	}
	
	/**
	 * @return the amount the player has gained.
	 */
	public double getStack() {
		return stack;
	}
	
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	
	/**
	 * The player prepares for the next hand.
	 */
	public void newHand() {
		holeCards[0] = null;
		holeCards[1] = null;
		lastGain = 0;
	}
	
	/**
	 * Deals exacly two hole cards to player.
	 * 
	 * @param cards
	 */
	public void pickUp(Card[] cards) {
		if(cards.length != 2) {
			throw new IllegalArgumentException("Player " + name + " has got "
					+ cards.length + " holecards. Two were expected.");
		}
		holeCards[0] = cards[0];
		holeCards[1] = cards[1];
	}
	
	/**
	 * If possible the player raises. Otherwise she calls the bet.
	 */
	public void raise() {
		if(hand.canBet()) {
			table.bet();
			hand.bet();
			contribute(pot.getAmountToCall(seat) + hand.getBetSize());
		} else {
			call();
		}
	}
	
	/**
	 * Sets the played hand.
	 * 
	 * @param hand
	 */
	public void setHand(Hand hand) {
		this.hand = hand;
	}
	
	/**
	 * Sets the pot the player pays in.
	 * 
	 * @param pot
	 */
	public void setPot(AbstractPot pot) {
		this.pot = pot;
	}
	
	/**
	 * Sets the board the game is played on.
	 * 
	 * @param table
	 */
	public void setTable(Table table) {
		this.table = table;
	}
	
	@Override
	public String toString() {
		String result = "";
		
		result += "Name: " + name + "\n";
		result += "Seat: " + seat + "\n";
		result += "Stack: " + stack + "\n";
		result += "Last gain: " + lastGain + "\n";
		
		result += "Hole cards>> |";
		if(holeCards[0] == null)
			result += "null";
		else if(holeCards[1] == null) {
			result += "ERROR: CARDS ARE NOT COMPLETELY SET!\n";
			result += "hole[0]: " + holeCards[0] + "\n";
		} else
			for(Card card : holeCards)
				result += card.toString();
		result += "|";
		
		return result;
	}
	
}
