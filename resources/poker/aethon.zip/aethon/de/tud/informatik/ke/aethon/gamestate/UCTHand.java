package de.tud.informatik.ke.aethon.gamestate;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.common.EvaluatingPot;
import de.tud.informatik.ke.aethon.movegenerator.Action;
import de.tud.informatik.ke.aethon.movegenerator.CardDealing;
import de.tud.informatik.ke.aethon.movegenerator.Move;

// TODO UCTHand should be super class and most specific classes should be
// implemented.
public class UCTHand extends Hand {
	
	private int seatTaken;
	private Card[] deck;
	private int deckSize;
	
	private boolean handOver;
	
	public UCTHand(ClientHand hand) {
		super(hand);
		seatTaken = hand.getSeatTaken();
		
		deck = Card.getAllCards();
		deckSize = deck.length;
		handOver = false;
		
		pot = new EvaluatingPot(hand.pot);
		
		// Remove cards that have been dealt from the board
		int numDealtBoardsCards = table.getNumDealtCards();
		Card[] holeCards = players[seatTaken].getHoleCards();
		Card[] boardCards = table.getBoardCards();
		Card[] cards = new Card[boardCards.length + 2];
		
		for(int card = 0; card < numDealtBoardsCards; card++)
			cards[card] = boardCards[card];
		cards[numDealtBoardsCards] = holeCards[0];
		cards[numDealtBoardsCards + 1] = holeCards[1];
		
		removeCardsFromDeck(cards);
	}
	
	public UCTHand(UCTHand hand) {
		super(hand);
		seatTaken = hand.seatTaken;
		handOver = hand.handOver;
		
		pot = new EvaluatingPot(hand.pot);
		
		deckSize = hand.deckSize;
		deck = new Card[deckSize];
		for(int card = 0; card < deckSize; card++)
			deck[card] = hand.deck[card];
	}
	
	/**
	 * @return if the amount that have to be called is zero. This happens if all
	 *         players before checked and therefore no bet is outstanding.
	 */
	public boolean callIsFree() {
		return pot.getAmountToCall(table.getSeatToAct()) == 0;
	}
	
	private void executeAction(Action action) {
		Player player = players[table.getSeatToAct()];
		
		switch(action) {
		case RAISE:
			player.raise();
			break;
		case CALL:
			player.call();
			break;
		case FOLD:
			player.fold();
			break;
		default:
			throw new IllegalArgumentException("Unexpected action: "
					+ action.toString());
		}
	}
	
	private void executeDealing(CardDealing dealing) {
		Card[] cards = dealing.getCards();
		
		removeCardsFromDeck(cards);
		
		// Deal cards
		// Card[] holeCards = new Card[2];
		// for(int seat = 0; seat < getNumPlayers(); seat++) {
		// if(seat != seatTaken) {
		// holeCards[0] = cards[seat << 1];
		// holeCards[1] = cards[(seat << 1) + 1];
		// dealer.dealHoleCards(seat,holeCards);
		// }
		// }
		
		// Deal cards to board
		// for(int card = getNumPlayers() << 1; card < cards.length; card++)
		// table.addCard(cards[card]);
		
		for(int card = 0; card < cards.length; card++)
			table.addCard(cards[card]);
		
		// Pay off winners
		pot.payOffWinners(players,table);
		pot.clearPot();
		handOver = true;
	}
	
	/**
	 * A generated move is executed by this function. Since the hand is not over
	 * an action is expected - otherwise move must be a card dealing.
	 * 
	 * @param move
	 */
	public void executeMove(Move move) {
		if(isShowdown)
			executeDealing((CardDealing)move);
		else
			executeAction((Action)move);
	}
	
	/**
	 * @param index
	 * @return the card at position <code>index</code>
	 */
	public Card getCardFromDeck(int index) {
		if(index >= deckSize) {
			// index < 0 throws an exception
			throw new IndexOutOfBoundsException(
					"The requested card have been dealt. The deck contains "
							+ deckSize + " cards. Index = " + index);
		}
		return deck[index];
	}
	
	public int getNumCardsToDeal() {
		return 5 - table.getNumDealtCards();// + (getNumPlayers() << 1);
	}
	
	public int getNumDeckCards() {
		return deckSize;
	}
	
	/**
	 * @return the gain from the last showdown of each player.
	 */
	public double[] getValue(boolean immediate) {
		// Normalisation is total(ly) intelligent arbitrariness.
		final double normalisation = 1.0f / 12.0f;
		double[] value = new double[getNumPlayers()];
		
		if(immediate) {
			pot.splitPot(players,table);
			pot.clearPot();
		}
		
		for(int player = 0; player < getNumPlayers(); player++)
			value[player] = players[player].getLastGain() * normalisation;
		
		return value;
	}
	
	@Override
	protected void handleBoardCardDealing() {
	// Ignored
	}
	
	@Override
	protected void handleHoleCardDealing() {
	// Ignored
	}
	
	@Override
	protected void handleShowdown() {
	// Ignored
	}
	
	/**
	 * Indicates that the hand is over.
	 */
	public boolean isHandOver() {
		return handOver;
	}
	
	/**
	 * Call handleMessage before this. Otherwise the result will be incorrect.
	 * 
	 * @return true if it is our turn to act and false otherwise.
	 * @see ClientHand#handleMessage(GameStateMessage)
	 */
	public boolean isOurTurn() {
		return !isShowdown && seatTaken == table.getSeatToAct();
	}
	
	/**
	 * @return if a random move have to be generated
	 */
	public boolean isRandomMove() {
		return isShowdown;
	}
	
	/**
	 * Removes cards from the deck in average 4 hits per card. The estimation is
	 * an upper bound and depends on the number of cards. Less hits are expected
	 * 
	 * @param cards
	 */
	private void removeCardsFromDeck(Card[] cards) {
		for(Card card : cards) {
			int index = card.getIndexRankMajor();
			
			if(index < deckSize) {
				swapCard(index);
				continue;
			} else
				for(int k = 0; k < deckSize; k++)
					if(deck[k].equals(card))
						swapCard(k);
		}
	}
	
	/**
	 * @param seat
	 *            of the player.
	 * @return The total amount of chips earned by this player during the
	 *         current game.
	 */
	public double getStackOfPlayer(int seat) {
		return players[seat].getStack();
	}
	
	private void swapCard(int card) {
		deckSize--;
		
		Card temp = deck[deckSize];
		deck[deckSize] = deck[card];
		deck[card] = temp;
	}
	
	@Override
	public String toString() {
		String result = "";
		
		result += "Number of cards in deck: " + deckSize + "\n";
		
		return result + super.toString();
	}
	
	public boolean weHaveFolded() {
		return table.hasFolded(seatTaken);
	}
	
}
