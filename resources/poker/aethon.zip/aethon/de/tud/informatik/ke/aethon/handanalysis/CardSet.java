package de.tud.informatik.ke.aethon.handanalysis;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

public class CardSet implements Set<Card> {
	
	/**
	 * The look up table decodes the number of cards in a five rank encoding.
	 * For any code (which is element of <code>[0,31]</code>) used as index,
	 * the corresponding entry provides the number of ones in the code.
	 */
	private static LookupTable lookupTable = null;
	private static final int TABLEINDEXBITS = 5;
	private static final String FILENAME = "lookup" + TABLEINDEXBITS;
	
	/**
	 * <p>
	 * Converts the {@link Rank} of a card to an integer. The encoding is
	 * defined in the following way:<br>
	 * <code>0000|0000|0000|0000|00AK|QJT9|8765|432A</code>
	 * </p>
	 * <p>
	 * Note that the ace is duplicated because it can be used as lowest or
	 * highest rank.
	 * </p>
	 * 
	 * @see Rank
	 * @param rank
	 * @return The encoding of the <code>rank</code>.
	 */
	public static int encodeRank(Rank rank) {
		int code = 1 << (rank.index + 1);
		if(rank.equals(Rank.ACE))
			code |= 1;
		return code;
	}
	
	/**
	 * The suit is encoded to obtain invariance between suited and unsuited
	 * sets. If the set is unsuited the encoding is always 0 and therefore
	 * <code>suit</code> may be null.
	 * 
	 * @param suit
	 * @param suited
	 * @return
	 */
	public static int encodeSuit(Suit suit, boolean suited) {
		return (suited) ? suit.index : 0;
	}
	
	// public static CardSet intersect(CardSet a, CardSet b) {
	// if(a.suited != b.suited) {
	// String message = "Cannot intersect suited with unsuited cardset.";
	// message = "\n a is " + ((a.suited) ? "suited." : "unsuited.");
	// message = "\n b is " + ((b.suited) ? "suited." : "unsuited.");
	// throw new IllegalArgumentException(message);
	// }
	//		
	// CardSet intersection = new CardSet(a.suited);
	// for(int suit = 0; suit < a.numSuits; suit++) {
	// intersection.ranks[suit] = a.ranks[suit] & b.ranks[suit];
	// intersection.numCards[suit] = intersection.countCards(Rank.TWO,
	// Rank.ACE,Suit.toSuit(suit));
	// }
	//		
	// // 2.4 accesses are needed in average.
	// int highcard = 0;
	// for(int i = 1; i <= intersection.numCards[encoding]; i++) {
	// Rank highest = cardset.getHighestRank(i);
	//			
	// // No more cards available.
	// if(highest == null)
	// break;
	//			
	// // Add highest card if the suit matches the projection.
	// if((projection.ranks[encoding] & (1 << highest.index)) > 0) {
	// projection.highest[highcard] = highest.index;
	// if(highcard == 1)
	// break;
	// highcard++;
	// }
	// }
	//		
	// return intersection;
	// }
	
	public static CardSet project(CardSet cardset, Suit suit) {
		CardSet projection = new CardSet(cardset.suited);
		int encoding = encodeSuit(suit,cardset.suited);
		
		projection.ranks[encoding] = cardset.ranks[encoding];
		projection.numCards[encoding] = cardset.numCards[encoding];
		
		// 2.4 accesses are needed in average.
		int highcard = 0;
		for(int i = 1; i <= cardset.size(); i++) {
			Rank highest = cardset.getHighestRank(i);
			
			// No more cards available.
			if(highest == null)
				break;
			
			// Add highest card if the suit matches the projection.
			if((projection.ranks[encoding] & (1 << (highest.index + 1))) > 0) {
				projection.highest[highcard] = highest.index;
				if(highcard == 1)
					break;
				highcard++;
			}
		}
		
		return projection;
	}
	
	public static CardSet toUnsuited(CardSet cardset) {
		if(!cardset.suited)
			return new CardSet(cardset);
		
		// Merge ranks.
		CardSet unsuited = new CardSet(false);
		for(Suit suit : Suit.values())
			unsuited.ranks[0] |= cardset.ranks[encodeSuit(suit,cardset.suited)];
		
		// Count cards.
		unsuited.numCards[0] = unsuited
				.countCards(Rank.TWO,Rank.ACE,Suit.CLUBS);
		
		// Highest cards.
		unsuited.highest = cardset.highest.clone();
		
		return unsuited;
	}
	
	public static CardSet unite(CardSet a, CardSet b) {
		if(a.suited != b.suited) {
			String message = "Cannot unite suited with unsuited cardset.";
			message = "\n a is " + ((a.suited) ? "suited." : "unsuited.");
			message = "\n b is " + ((b.suited) ? "suited." : "unsuited.");
			throw new IllegalArgumentException(message);
		}
		
		CardSet union = new CardSet(a.suited);
		for(int suit = 0; suit < a.numSuits; suit++) {
			union.ranks[suit] = a.ranks[suit] | b.ranks[suit];
			union.numCards[suit] = union.countCards(Rank.TWO,Rank.ACE,Suit
					.toSuit(suit));
		}
		
		// Ugly but useful.
		union.highest[0] = Math.max(a.highest[0],b.highest[0]);
		union.highest[1] = Math.max(Math.min(a.highest[0],b.highest[0]),Math
				.max(a.highest[1],b.highest[1]));
		
		return union;
	}
	
	private boolean suited;
	private int numSuits;
	
	/**
	 * highest contains the two highest cards ranks to speed up search. The
	 * second entry is the second highest rank which is NOT necessarily the
	 * second highest card.
	 */
	private int[] highest;
	private int[] ranks;
	private int[] numCards;
	
	public CardSet(boolean suited) {
		this.suited = suited;
		numSuits = (suited) ? Suit.values().length : 1;
		
		highest = new int[]{-1,-1};
		ranks = new int[numSuits];
		numCards = new int[numSuits];
		
		if(lookupTable == null)
			lookupTable = new LookupTable(new File(FILENAME));
	}
	
	public CardSet(CardSet cardset) {
		suited = cardset.suited;
		numSuits = cardset.numSuits;
		
		highest = cardset.highest.clone();
		ranks = cardset.ranks.clone();
		numCards = cardset.numCards.clone();
		
		// Look up table must have been loaded, because of the existing cardset.
		if(lookupTable == null)
			throw new RuntimeException(
					"Lookup table is expected to be initialised. But it is null.");
	}
	
	@Override
	public boolean add(Card e) {
		if(e == null)
			throw new NullPointerException("Null cannot be added to a cardset.");
		
		if(contains(e))
			return false;
		
		// Remember highest two cards.
		Rank rank = e.rank;
		if(highest[0] < rank.index) {
			highest[1] = highest[0];
			highest[0] = rank.index;
		} else if(highest[1] < rank.index)
			highest[1] = rank.index;
		
		// Encode card and add to set.
		int suit = encodeSuit(e.suit,suited);
		ranks[suit] |= encodeRank(rank);
		numCards[suit]++;
		return true;
	}
	
	@Override
	public boolean addAll(Collection<? extends Card> c) {
		if(c == null)
			throw new NullPointerException("The collection must not be null.");
		
		boolean changed = false;
		for(Card card : c)
			changed |= add(card);
		return changed;
	}
	
	@Override
	public void clear() {
		highest[0] = -1;
		highest[1] = -1;
		
		for(int index = 0; index < numSuits; index++) {
			ranks[index] = 0;
			numCards[index] = 0;
		}
	}
	
	@Override
	public boolean contains(Object o) {
		if(o instanceof Card) {
			Card card = (Card)o;
			return (ranks[encodeSuit(card.suit,suited)] & encodeRank(card.rank)) > 0;
		}
		return false;
	}
	
	@Override
	public boolean containsAll(Collection<?> c) {
		if(c == null)
			throw new NullPointerException("The collection must not be null.");
		
		boolean subset = true;
		for(Object object : c)
			subset &= contains(object);
		return subset;
	}
	
	/**
	 * @param begin
	 *            If <code>begin</code> is an ace it is interpreted as lowest
	 *            rank.
	 * @param end
	 *            If <code>end</code> is an ace it is interpreted as highest
	 *            rank.
	 * @param suit
	 *            of the counted cards.
	 * @return The number of cards between rank <code>a</code> and
	 *         <code>b</code> of the same <code>suit</code>. If
	 *         <code>a</code> and <code>b</code> are aces, one is returned.
	 */
	public int countCards(Rank begin, Rank end, Suit suit) {
		// Trivial case and ace equivalence.
		if(begin.equals(end))
			return 1;
		
		// Wrap ace
		int beginIndex = (begin.equals(Rank.ACE)) ? 0 : begin.index + 1;
		int endIndex = end.index + 1;
		
		// Calculate offset and length
		int offset = Math.min(beginIndex,endIndex);
		int length = Math.max(beginIndex,endIndex) - offset + 1;
		
		// Prepare counting
		int mask = (1 << TABLEINDEXBITS) - 1;
		int code = ranks[encodeSuit(suit,suited)] >> offset;
		int total = 0;
		
		// Use maximum stepsize bounded by the lookup table size.
		while(length >= TABLEINDEXBITS) {
			total += lookupTable.getEntrie(code & mask);
			code >>= TABLEINDEXBITS;
			length -= TABLEINDEXBITS;
		}
		
		// Use the rest of length as final stepsize.
		mask = (1 << length) - 1;
		return total + lookupTable.getEntrie(code & mask);
	}
	
	/**
	 * @param i
	 * @return The <code>i-th</code> highest rank in the set. If the rank does
	 *         not exist <code>null</code> is returned.
	 */
	public Rank getHighestRank(int i) {
		i--;
		
		// If one of the first highest cards is requested.
		if(i <= 1) {
			if(highest[i] < 0)
				return null;
			return Rank.toRank(highest[i]);
		}
		
		// If later ranks are requested.
		int rankcode = 1;
		for(int rank = highest[1] - 1; rank >= Rank.TWO.index; rank--)
			for(int suit = 0; suit < numSuits; suit++)
				// rank + 1 to skip duplicated ace.
				if((ranks[suit] & (rankcode << (rank + 1))) > 0) {
					if(i == 0)
						return Rank.toRank(rank);
					i--;
				}
		
		// There are insufficient different ranks.
		return null;
	}
	
	public int getNumSuits() {
		return numSuits;
	}
	
	@Override
	public boolean isEmpty() {
		return size() == 0;
	}
	
	public boolean isSuited() {
		return suited;
	}
	
	@Override
	public Iterator<Card> iterator() {
		// TODO Auto-generated method stub
		return null;
	}
	
	/***/
	@Override
	@Deprecated
	public boolean remove(Object o) {
		throw new UnsupportedOperationException(
				"Nothing can be removed from a cardset.");
	}
	
	/***/
	@Override
	@Deprecated
	public boolean removeAll(Collection<?> c) {
		throw new UnsupportedOperationException(
				"Nothing can be removed from a cardset.");
	}
	
	@Override
	@Deprecated
	public boolean retainAll(Collection<?> c) {
		throw new UnsupportedOperationException(
				"Use intersect instead of retainAll.");
	}
	
	@Override
	public int size() {
		int total = 0;
		for(int number : numCards)
			total += number;
		return total;
	}
	
	/**
	 * @param rank
	 *            of the counted cards.
	 * @return The number of cards in the set which have the same
	 *         <code>rank</code>.
	 */
	public int size(Rank rank) {
		int shift = rank.index + 1;
		int index = 0;
		for(int subset : ranks)
			index = (index << 1) | ((subset >> shift) & 1);
		return lookupTable.getEntrie(index);
	}
	
	/**
	 * @param suit
	 *            of the counted cards.
	 * @return The number of cards in the set which are of the same
	 *         <code>suit</code>.
	 */
	public int size(Suit suit) {
		return numCards[encodeSuit(suit,suited)];
	}
	
	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}
}
