package de.tud.informatik.ke.aethon.handanalysis;

import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

public class HighCard extends Combinatorics {
	
	private int numFreeCards;
	
	public HighCard(Outcome outcome, int const1, int const2, int numFreeCards) {
		super(outcome,const1,const2);
		this.numFreeCards = numFreeCards;
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		CardSet unsuited = CardSet.toUnsuited(hole);
		Rank highcard = unsuited.getHighestRank(1);
		
		if(numFreeCards == 2)
			count2FreeCards(unsuited,highcard,hole.getNumSuits());
		else
			count1FreeCard(highcard,hole.getNumSuits());
	}
	
	private void count2FreeCards(CardSet unsuited, Rank first, int numSuits) {
		final int numRanks = Rank.values().length;
		Rank second = unsuited.getHighestRank(2);
		
		int secondRank = 0;
		if(second != null)
			secondRank = second.index + 1;
		
		// Upper triangle without lower.
		int firstRank = first.index + 1;
		int numFirstHigher = (numRanks * (numRanks + 1) - firstRank
				* (firstRank + 1)) >> 1;
		int numSecondHigher = firstRank - secondRank - 1;
		int numDefCombs = numSuits * (numFirstHigher + numSecondHigher);
		addToDefeats(numDefCombs - getNumDofConstraints(1));
		
		/*
		 * Lower triangle. These are all combinations for cards with ranks less
		 * then the highest rank in the combined set and without the cards which
		 * are contained in a previous found hand type. Because those have
		 * already been counted.
		 */
		int numTieCombs = Suit.values().length
				* (secondRank + ((firstRank - 1) * firstRank >> 1));
		addToTies(numTieCombs - getNumDofConstraints(2));
		selectTie();
		addToDofConstraint(1,numDefCombs);
		addToDofConstraint(2,numTieCombs);
	}
	
	private void count1FreeCard(Rank highcard, int numSuits) {
		final int numRanks = Rank.values().length;
		
		int highRank = 0;
		if(highcard != null)
			highRank = highcard.index + 1;
		
		int numDefCombs = numSuits * (numRanks - highRank);
		addToDefeats(numDefCombs);
		
		int numTieCombs = Suit.values().length * highRank;
		addToTies(numTieCombs - getNumDofConstraints(1));
		selectTie();
		addToDofConstraint(1,numDefCombs + numTieCombs);
	}
}
