package de.tud.informatik.ke.aethon.handanalysis;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class HandAnalyser {
	
	private CardSet hole;
	private CardSet board;
	private CardSet combined;
	
	private int numWins;
	private int numTies;
	private int numDefeats;
	
	public HandAnalyser(Card[] hole, Card[] board) {
		this.hole = new CardSet(true);
		this.board = new CardSet(true);
		this.combined = new CardSet(true);
		
		for(Card card : hole)
			this.hole.add(card);
		for(Card card : board)
			this.board.add(card);
		this.combined = CardSet.unite(this.hole,this.board);
	}
	
	/**
	 * Evaluate the probability for the given hole cards.
	 */
	public void evaluate() {
		// Count straight flushes
		Straight straightFlush = new Straight();
		straightFlush.evaluate(hole,board,combined);
		
		// Count four of a kind
		FourOfAKind foak = new FourOfAKind(straightFlush.getOutcome(),
				straightFlush.getNumDofConstraints(1),straightFlush
						.getNumDofConstraints(2));
		foak.evaluate(hole,board,combined);
		
		// Count full houses
		FullHouse fullhouse = new FullHouse(foak.getOutcome(),foak
				.getNumDofConstraints(1),foak.getNumDofConstraints(2));
		fullhouse.evaluate(hole,board,combined);
		
		// Count flushes
		Flush flush = new Flush(fullhouse.getOutcome(),fullhouse
				.getNumDofConstraints(1),fullhouse.getNumDofConstraints(2),
				straightFlush.getTotal());
		flush.evaluate(hole,board,combined);
		
		// Count straights
		Straight straight = new Straight(flush.getOutcome(),flush
				.getNumDofConstraints(1),flush.getNumDofConstraints(2),false);
		straight.evaluate(hole,board,combined);
		
		// Count three of a kind
		NOfAKind toak = new NOfAKind(straight.getOutcome(),straight
				.getNumDofConstraints(1),straight.getNumDofConstraints(2),
				fullhouse,3);
		toak.evaluate(hole,board,combined);
		
		// Count two pair
		TwoPair twoPair = new TwoPair(toak.getOutcome(),toak
				.getNumDofConstraints(1),toak.getNumDofConstraints(2),toak);
		twoPair.evaluate(hole,board,combined);
		
		// Count pairs
		NOfAKind pair = new NOfAKind(twoPair.getOutcome(),twoPair
				.getNumDofConstraints(1),twoPair.getNumDofConstraints(2),
				twoPair,2);
		pair.evaluate(hole,board,combined);
		
		// Count high cards
		HighCard highcard = new HighCard(pair.getOutcome(),pair
				.getNumDofConstraints(1),pair.getNumDofConstraints(2),2);
		highcard.evaluate(hole,board,combined);
		
		// Get total win, tie, lost.
		numDefeats = straightFlush.getNumDefeats() + foak.getNumDefeats()
				+ fullhouse.getNumDefeats() + flush.getNumDefeats()
				+ straight.getNumDefeats() + toak.getNumDefeats()
				+ twoPair.getNumDefeats() + pair.getNumDefeats()
				+ highcard.getNumDefeats();
		
		numTies = straightFlush.getNumTies() + foak.getNumTies()
				+ fullhouse.getNumTies() + flush.getNumTies()
				+ straight.getNumTies() + toak.getNumTies()
				+ twoPair.getNumTies() + pair.getNumTies()
				+ highcard.getNumTies();
		
		numWins = straightFlush.getNumWins() + foak.getNumWins()
				+ fullhouse.getNumWins() + flush.getNumWins()
				+ straight.getNumWins() + toak.getNumWins()
				+ twoPair.getNumWins() + pair.getNumWins()
				+ highcard.getNumWins();
	}
	
	/**
	 * @return The probability for the given hole cards to win the hand.
	 */
	public double getWinProb() {
		return (double)(numWins + numTies) / (numWins + numTies + numDefeats);
	}
	
	/**
	 * @return The probability for the given hole cards to loose the hand.
	 */
	public double getDefeatProb() {
		return (double)(numDefeats) / (numWins + numTies + numDefeats);
	}
}
