package de.tud.informatik.ke.aethon.common;

public class ThisWasBadAndShouldNotHappenException extends RuntimeException {

	private static final long serialVersionUID = 2716982125200104921L;

	public ThisWasBadAndShouldNotHappenException(String message){
		super(message);
	}
}
