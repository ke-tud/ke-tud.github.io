package de.tud.informatik.ke.aethon.common;

import de.tud.informatik.ke.aethon.client.AethonClient;
import de.tud.informatik.ke.aethon.gamestate.Player;
import de.tud.informatik.ke.aethon.handanalysis.HandAnalyser;

public class EvaluatingPot extends AbstractPot {
	
	private HandAnalyser analyser;
	private double ourProb;
	private int ourSeat;
	
	public EvaluatingPot(AbstractPot pot) {
		super(pot);
		ourSeat = -1;
	}
	
	public EvaluatingPot(int numPlayers) {
		super(numPlayers);
		ourSeat = -1;
	}
	
	@Override
	public void payOffWinners(Player[] players, Table table) {
		
		if(ourSeat < 0)
			for(int p = 0; p < players.length; p++)
				if(players[p].getName().equals(AethonClient.OURNAME)) {
					ourSeat = p;
					break;
				}
		
		// Get win prob
		analyser = new HandAnalyser(players[ourSeat].getHoleCards(),table
				.getBoardCards());
		analyser.evaluate();
		
		Probability.getInstance().add(analyser.getWinProb());
		double prob = Probability.getInstance().get();
		
		int numWinners = table.getNumPlayersInGame();
		
		// Prob that n players will not win with prob Pr[Defeat]
		ourProb = 1.0f;
		for(int p = 0; p < numWinners; p++)
			// Win equals 1-Defeat
			ourProb *= prob;
		
		splitPot(players,table);
	}
	
	@Override
	public void splitPot(Player[] players, Table table) {
		double ourGain = getPotSize() * ourProb;
		double oppGain = getPotSize() * (1 - ourProb);
		
		int seat = table.getPlayerInGame();
		for(int winner = 0; winner < table.getNumPlayersInGame(); winner++) {
			if(seat == ourSeat)
				players[seat].addToStack(ourGain);
			else
				players[seat].addToStack(oppGain);
			seat = table.getNextPlayerInGame(seat);
		}
	}
	
}
