package de.tud.informatik.ke.aethon.common;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.HandAnalysis;
import de.tud.informatik.ke.aethon.gamestate.Player;

public class SimplePot extends AbstractPot {
	
	@Override
	public String toString() {
		String result = "";
		
		result += "Contributions>> ";
		for(int contribution : contributions)
			result += "|" + contribution;
		result += "|\n";
		
		result += "Maximum contribution: " + maxContribution;
		
		return result;
	}
	
	public SimplePot(int numPlayers) {
		super(numPlayers);
	}
	
	public SimplePot(AbstractPot pot) {
		super(pot);
	}
	
	@Override
	public void payOffWinners(Player[] players, Table table) {
		Card[] boardCards = table.getBoardCards();
		
		// Determine the first preliminary winner
		int numActive = table.getNumPlayersInGame();
		int active = table.getPlayerInGame();
		Player[] winners = new Player[numActive];
		winners[0] = players[active];
		int numWinners = 1; // Assume the first active player to be the winner.
		
		Card[][] holeCards = new Card[2][2];
		holeCards[0] = winners[0].getHoleCards();
		for(int index = 1; index < numActive; index++) {
			int player = table.getNextPlayerInGame(active);
			holeCards[1] = players[player].getHoleCards();
			int relation = HandAnalysis.determineWinner(holeCards,boardCards);
			
			if(relation == -1) { // Tie
				winners[numWinners] = players[player];
				numWinners++;
			} else if(relation == 1) { // Current player beats all former.
				holeCards[0][0] = holeCards[1][0];
				holeCards[0][1] = holeCards[1][1];
				winners[0] = players[player];
				numWinners = 1;
			}
		}
		
		double gain = getPotSize() / numWinners;
		for(int winner = 0; winner < numWinners; winner++)
			winners[winner].addToStack(gain);
	}
	
	@Override
	public void splitPot(Player[] players, Table table) {
		double gain = getPotSize() / table.getNumPlayersInGame();
		for(int seat = 0; seat < players.length; seat++)
			if(!table.hasFolded(seat))
				players[seat].addToStack(gain);
	}
}
