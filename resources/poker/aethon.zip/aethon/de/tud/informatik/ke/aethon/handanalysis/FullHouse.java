package de.tud.informatik.ke.aethon.handanalysis;

import de.tud.informatik.ke.aethon.common.Math;

public class FullHouse extends SeveralOfAKind {
	
	public FullHouse(Outcome outcome, int const1, int const2) {
		super(outcome,const1,const2);
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		
		// Initialise full house table if it has not been set externally.
		if(table == null)
			initTable(hole,board);
		
		/*
		 * Count number of defeating combinations. Use the defeating three of a
		 * kinds and all pairs. These loops look pretty much like hell. But most
		 * of them are passed only once.
		 */
		for(int toakDof = DOF1; toakDof <= DOF2; toakDof++)
			for(int pairDof = DOF0; toakDof + pairDof <= MAXDOF; pairDof++)
				/*
				 * Because all three of a kind are expected to defeat the given
				 * hole card three of a kinds at the moment, the number of
				 * reserved hole cards have to be less then the degree of
				 * freedom.
				 */
				for(int toakReserved = DOF0; toakReserved < toakDof; toakReserved++)
					/*
					 * While looking for defeating full houses the pairs for the
					 * given hole cards are never subset of any three of a kind.
					 * Otherwise a winning or tying three of a kind would have
					 * been found. Therefore the number of reserved hole cards
					 * is always less then the degree of freedom.
					 */
					for(int pairReserved = DOF0; pairReserved <= pairDof; pairReserved++)
						addToDefeats(getNumCombs(DEFEATING,toakDof,
								toakReserved,WINTIE,pairDof,pairReserved));
		
		// Defeating Toak Toak Combs
		for(int pairDof = DOF0; pairDof <= DOF1; pairDof++)
			for(int pairReserved = DOF0; pairReserved < pairDof + 1; pairReserved++)
				addToDefeats(getNumCombsTT(DEFEATING,pairDof + 1,pairReserved));
		
		// Do the given hole cards contains a full house.
		if(foundHolePair && foundHoleToak) {
			
			// Handle tie.
			if(tieToakDof >= DOF0 && tieToakDof < DOF2) {
				// Defeating due to higher pairs.
				for(int pairDof = DOF1; tieToakDof + pairDof <= DOF2; pairDof++)
					for(int pairReserved = DOF0; pairReserved < pairDof; pairReserved++)
						addToDefeats(getNumCombs(TIE,tieToakDof,tieToakDof,
								DEFEATING,pairDof,pairReserved));
				
				// Ties
				int arbitrary = 1;
				// Check if tiePairDof is negative becaus it is actually a three
				// of a kind.
				int tiePairDofCopy = ((0 > tiePairDof) ? 0 : tiePairDof);
				int more = (tiePairDof < 0) ? 1 : 0;
				int freeCards = MAXDOF - tiePairDofCopy - tieToakDof;
				
				if(freeCards > 0) {
					arbitrary = (2 - more)
							* (NUMFREECARDS - getNumDofConstraints(freeCards));
					increaseDofConstraint(freeCards);
				}
				addToTies(arbitrary);
				selectTie();
			}
			
			/*
			 * Count wins or ties. Use all winning three of a kinds and all
			 * pairs.
			 */
			for(int pairDof = DOF0; tieToakDof + pairDof <= MAXDOF; pairDof++)
				for(int pairReserved = DOF0; pairReserved <= MAXDOF; pairReserved++) {			
					int numCombs = getNumCombs(TIE,tieToakDof,tieToakDof,
							WINTIE,pairDof,pairReserved);
					if(numCombs > 0) {
						addToWins(numCombs);
						selectWin();
					}
				}
		}
	}
	
	private int getNumCombsTT(int toakOutcome, int toakDof, int toakReserved) {
		// Number of suit combinations.
		int nToak = NUMSUITS - (TOAKMAXDOF - toakDof + toakReserved);
		
		if(nToak < 0)
			return 0;
		
		int oldToakDof = toakDof;
		if(nToak < toakDof)
			toakDof = nToak;
		
		int numToakSuits = (int)Math.nCr(nToak,toakDof);
		
		// Number of toak toak combinations.
		int fullhouseCombs = table[DEFEATING][THREEOFAKIND][0][0]
				* table[DEFEATING][PAIR][oldToakDof - 1][toakReserved]
				* numToakSuits;
		
		int arbitrary = 1;
		int dof = MAXDOF - toakDof;
		if(dof > DOF0) {
			arbitrary = NUMFREECARDS - getNumDofConstraints(dof);
			addToDofConstraint(dof,fullhouseCombs);
		}
		
		return fullhouseCombs * arbitrary;
	}
	
	private int getNumCombs(int toakOutcome, int toakDof, int toakReserved,
			int pairOutcome, int pairDof, int pairReserved) {
		
		// Number of suit combinations.
		int nToak = NUMSUITS - (TOAKMAXDOF - toakDof + toakReserved);
		int nPair = NUMSUITS - (PAIRMAXDOF - pairDof + pairReserved);
		
		if(nToak < 0 || nPair < 0)
			return 0;
		
		int oldToakDof = toakDof;
		if(nToak < toakDof)
			toakDof = nToak;
		
		int oldPairDof = pairDof;
		if(nPair < pairDof)
			pairDof = nPair;
		
		int numToakSuits = (int)Math.nCr(nToak,toakDof);
		int numPairSuits = (int)Math.nCr(nPair,pairDof);
		int suitCombs = numToakSuits * numPairSuits;
		
		// Number of toak pair combinations.
		int numPairs = 0;
		for(int outcome = 0; outcome <= pairOutcome; outcome++)
			numPairs += table[outcome][PAIR][oldPairDof][pairReserved];
		int fullhouseCombs = table[toakOutcome][THREEOFAKIND][oldToakDof][toakReserved]
				* numPairs * suitCombs;
		
		// Number of included pair pair combinations.
		int duplicated = 0;
		if(toakDof == DOF1 && pairDof == DOF0)
			duplicated = table[toakOutcome][THREEOFAKIND][DOF1][toakReserved]
					* suitCombs;
		
		int arbitrary = 1;
		int dof = MAXDOF - toakDof - pairDof;
		if(dof > DOF0) {
			arbitrary = NUMFREECARDS - getNumDofConstraints(dof);
			addToDofConstraint(dof,fullhouseCombs - duplicated);
		}
		
		return fullhouseCombs * arbitrary - duplicated;
	}
}
