package de.tud.informatik.ke.aethon.common;

import java.util.Random;

import de.tud.informatik.ke.aethon.playermodelling.PlayerModel;

/**
 * Provides us with instances of all the classes that should have only one
 * instance (e.g. for performance or memory reasons).
 * 
 * @author marian
 * 
 */
public class SingletonProvider {
	private static SingletonProvider singleton = null;

	private Random random = new Random(System.currentTimeMillis());

	private PlayerModel[] players;
	
	private SingletonProvider() {
		// constructor should be called by getInstance only.
	}

	public static SingletonProvider getInstance() {
		if (singleton == null) {
			singleton = new SingletonProvider();
		}
		return singleton;
	}
	
	public void setPlayerModel(PlayerModel[] players){
		this.players=players;
	}
	
	public PlayerModel getPlayer(int seat){
		return players[seat];
	}

	/**
	 * 
	 * @return a random number generator (the only one that should be used in
	 *         this whole project)
	 */
	public Random getRandom() {
		return random;
	}
}
