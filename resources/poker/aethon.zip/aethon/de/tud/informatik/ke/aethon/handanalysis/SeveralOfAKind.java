package de.tud.informatik.ke.aethon.handanalysis;

import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

public abstract class SeveralOfAKind extends Combinatorics {
	
	// Outcome/Table
	protected final static int DEFEATING = 0;
	protected final static int TIE = 0;
	protected final static int WINTIE = 1;
	
	// Column
	protected final static int PAIR = 0;
	protected final static int THREEOFAKIND = 1;
	
	// Row
	protected final static int DOF0 = 0;
	protected final static int DOF1 = 1;
	protected final static int DOF2 = 2;
	
	// Misc
	protected final static int PAIRMAXDOF = 2;
	protected final static int TOAKMAXDOF = 3;
	protected final static int NUMSUITS = Suit.values().length;
	
	/**
	 * <p>
	 * The table counts the number of two and three of a kind with different
	 * degree of freedom. To find a valid full house combination the degree of
	 * freedom of a three of a kind and a pair must be at most two in sum. The
	 * full house for the given hole and the correct number of combinations for
	 * opponent cards can be derived from each other and are counted as reserved
	 * cards (owned by the given hole cards). But the number of combinations
	 * which defeat the given hole cards have to be counted seperatly.
	 * </p>
	 * <p>
	 * The dimensions are defined as:
	 * <code>(outcome x kind x dof x reserved) := (2 x 2 x 3 x 3)</code>.
	 * </p>
	 */
	protected int[][][][] table;
	protected boolean foundHolePair;
	protected boolean foundHoleToak;
	protected int tieToakDof;
	protected int tiePairDof;
	
	public SeveralOfAKind(Outcome outcome, int const1, int const2) {
		super(outcome,const1,const2);
		table = null;
	}
	
	/**
	 * Sets a existing look up table and some additional information for the new
	 * "several" of a kind object. This constructor should be used if any
	 * previously calculated look up table can be reused.
	 * 
	 * @param table
	 */
	public SeveralOfAKind(Outcome outcome, int const1, int const2,
			SeveralOfAKind soak) {
		super(outcome,const1,const2);
		
		// Copy table. This is ugly but faster then recomputation.
		table = new int[2][2][3][3];
		for(int o = DEFEATING; o <= WINTIE; o++)
			for(int kind = PAIR; kind <= THREEOFAKIND; kind++)
				for(int dof = DOF0; dof <= DOF2; dof++)
					for(int reserved = DOF0; reserved <= DOF2; reserved++)
						table[o][kind][dof][reserved] = soak.table[o][kind][dof][reserved];
		
		// Copy additional information.
		foundHolePair = soak.foundHolePair;
		foundHoleToak = soak.foundHoleToak;
		tiePairDof = soak.tiePairDof;
		tieToakDof = soak.tieToakDof;
	}
	
	/**
	 * Initialising the look up table takes time which might be saved in later
	 * calculations. If it is possible reuse existing tables.
	 * 
	 * @param hole
	 * @param board
	 */
	protected void initTable(CardSet hole, CardSet board) {
		table = new int[2][2][3][3];
		
		// All possible ranks.
		Rank[] ranks = Rank.values();
		
		int toakTable = DEFEATING;
		foundHoleToak = false;
		foundHolePair = false;
		tieToakDof = -1;
		tiePairDof = -1;
		
		for(int index = Rank.ACE.index; index >= Rank.TWO.index; index--) {
			
			// Count number of cards based on the board cards.
			int numBoard = board.size(ranks[index]);
			
			// Count number of cards based on the given hole cards.
			int numHole = hole.size(ranks[index]);
			
			// Ignore four of a kind.
			if(numBoard == NUMSUITS || numBoard + numHole == NUMSUITS)
				continue;
			
			// Test full house for hole cards.
			int numCombined = numBoard + numHole;
			if(numCombined == TOAKMAXDOF && !foundHoleToak) {
				foundHoleToak = true;
				tieToakDof = TOAKMAXDOF - numBoard;
				if(tieToakDof <= numHole)
					table[TIE][THREEOFAKIND][tieToakDof][numHole] = 1;
				toakTable = WINTIE;
			} else if(numCombined >= PAIRMAXDOF && !foundHolePair) {
				foundHolePair = true;
				tiePairDof = PAIRMAXDOF - numBoard;
			}
			
			/*
			 * CREATE TABLE: Sometimes both pair and three of a kind are
			 * increased. A full house with the same rank as triple and pair is
			 * possible. Therefore the number of invalid combinations has to be
			 * subducted later. The subducted value can be obtained from the
			 * minimum of the currently written cells.
			 */
			int dofPair = PAIRMAXDOF - numBoard;
			if(dofPair >= DOF0) {
				/*
				 * If there is a three of a kind which ties the given hole
				 * cards, these pairs provide additional defeating full houses.
				 */
				if(!foundHolePair)
					table[DEFEATING][PAIR][dofPair][numHole]++;
				else
					table[WINTIE][PAIR][dofPair][numHole]++;
			}
			
			int dofToak = dofPair + 1;
			if(dofToak < TOAKMAXDOF)
				table[toakTable][THREEOFAKIND][dofToak][numHole]++;
		}
	}
	
	/**
	 * @return The look up table for "several" of a kind.
	 */
	public int[][][][] getTable() {
		return table;
	}
	
	@Override
	public String toString() {
		String info = "";
		
		for(int r = DOF0; r <= DOF2; r++) {
			info += "\nDEFEATING - " + r + ":\n";
			info += "\tP\tT\n";
			for(int d = DOF0; d <= DOF2; d++) {
				info += d + "\t" + table[DEFEATING][PAIR][d][r];
				info += "\t" + table[DEFEATING][THREEOFAKIND][d][r] + "\n";
			}
		}
		
		info += "\n";
		for(int r = DOF0; r <= DOF2; r++) {
			info += "\nWINTIE - " + r + ":\n";
			info += "\tP\tT\n";
			for(int d = DOF0; d <= DOF2; d++) {
				info += d + "\t" + table[WINTIE][PAIR][d][r];
				info += "\t" + table[WINTIE][THREEOFAKIND][d][r] + "\n";
			}
		}
		
		info += "\n\nFULL HOUSE FOR GIVEN HOLE CARDS: "
				+ (foundHolePair && foundHoleToak) + "\n";
		
		info += "\n" + "NUMBER OF WINS: " + getNumWins();
		info += "\n" + "NUMBER OF TIES: " + getNumTies();
		info += "\n" + "NUMBER OF DEFEATS: " + getNumDefeats();
		
		return info;
	}
	
}
