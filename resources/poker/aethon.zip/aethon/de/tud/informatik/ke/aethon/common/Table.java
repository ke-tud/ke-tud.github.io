package de.tud.informatik.ke.aethon.common;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.gamestate.Hand;
import de.tud.informatik.ke.aethon.gamestate.Player;

public class Table {
	
	private Hand hand;
	private Card[] boardCards;
	private int numDealtCards;
	
	/**
	 * The index (seat) of the player who owns the button.
	 */
	private int button;
	private boolean firstAction;
	protected int seatToAct;
	private final int numPlayers;
	
	/**
	 * The indices (seats) of the players who folded.
	 */
	private boolean[] folded;
	
	/**
	 * The number of players who did not bet.
	 */
	private int numChecked;
	private int numFolded;
	
	/**
	 * Creates a new board to play poker. The last player owns the button and
	 * the small blind and big blind are always next to that player.
	 * 
	 */
	public Table(int numPlayers, Hand hand) {
		this.hand = hand;
		this.numPlayers = numPlayers;
		boardCards = new Card[5];
		button = numPlayers - 2; // The new hand increments the button
		folded = new boolean[numPlayers];
	}
	
	public Table(Table table, Hand hand) {
		this.hand = hand;
		numDealtCards = table.numDealtCards;
		boardCards = new Card[5];
		for(int index = 0; index < numDealtCards; index++)
			boardCards[index] = new Card(table.boardCards[index].toString());
		
		button = table.button;
		firstAction = table.firstAction;
		seatToAct = table.seatToAct;
		numPlayers = table.numPlayers;
		
		folded = new boolean[numPlayers];
		for(int player = 0; player < numPlayers; player++)
			folded[player] = table.folded[player];
		numChecked = table.numChecked;
		numFolded = table.numFolded;
	}
	
	/**
	 * Deals new cards to the board.
	 * 
	 * @param cards
	 */
	public void addCards(Card[] cards) {
		for(Card card : cards)
			addCard(card);
	}
	
	/**
	 * Deals a new card to the board.
	 * 
	 * @param card
	 */
	public void addCard(Card card) {
		boardCards[numDealtCards] = card;
		numDealtCards++;
	}
	
	/**
	 * A player calls this method if he bets.
	 */
	public void bet() {
		numChecked = 1;
		voluntaryActionTaken();
	}
	
	/**
	 * A player calls this method if he checks.
	 */
	public void check() {
		numChecked++;
		voluntaryActionTaken();
	}
	
	/**
	 * A player calls this method if he folds.
	 * 
	 * @param player
	 */
	public void fold(Player player) {
		folded[player.getSeat()] = true;
		numFolded++;
		voluntaryActionTaken();
	}
	
	/**
	 * @return the seat of the player who contributes the big blind.
	 */
	public int getBigBlind() {
		return indexToSeat(button + 2);
	}
	
	/**
	 * Request board cards if they have been dealt completely.
	 * 
	 * @return the cards on the board.
	 */
	public Card[] getBoardCards() {
		Card[] cards = new Card[numDealtCards];
		
		for(int card = 0; card < numDealtCards; card++)
			cards[card] = boardCards[card];
		
		return cards;
	}
	
	/**
	 * @return the active (not folded) player next to the specified
	 *         <code>seat</code> is returned. It is assumed that at least one
	 *         player has not folded. If the player at <code>seat</code> is
	 *         the only player who did not fold yet <code>seat</code> is
	 *         returned.
	 */
	public int getNextPlayerInGame(int seat) {
		do {
			seat = indexToSeat(seat + 1);
		} while(folded[seat]);
		return seat;
	}
	
	/**
	 * @return the number of cards which have been dealt to the board.
	 */
	public int getNumDealtCards() {
		return numDealtCards;
	}
	
	/**
	 * @return the number of players who did not fold yet.
	 */
	public int getNumPlayersInGame() {
		return numPlayers - numFolded;
	}
	
	/**
	 * @return the seat of the first (seat with lowest index) player who has not
	 *         folded is returned. It is assumed that at least one player has
	 *         not folded.
	 */
	public int getPlayerInGame() {
		int seat = 0;
		
		// If there is no active player an
		// ArrayIndexOutOfBoundsException is
		// expected.
		while(folded[seat])
			seat++;
		return seat;
	}
	
	/**
	 * @return the seat of the player who is on the turn.
	 */
	public int getSeatToAct() {
		return seatToAct;
	}
	
	/**
	 * @return the seat of the player who contributes the small blind.
	 */
	public int getSmallBlind() {
		return indexToSeat(button + 1);
	}
	
	/**
	 * @param index
	 *            has to be element of [0, 2*numPlayers-1].
	 * @return the seat for <code>index</code> where <code>index</code> is
	 *         wrapped around.
	 */
	public int indexToSeat(int index) {
		return (index >= numPlayers) ? index - numPlayers : index;
	}
	
	/**
	 * @return true if the next action is the first at a stage.
	 */
	public boolean isFirstAction() {
		return firstAction;
	}
	
	/**
	 * Prepares the board for a new hand.
	 */
	public void newHand() {
		int nextButton = button + 1;
		button = (nextButton < numPlayers) ? nextButton : 0;
		seatToAct = indexToSeat(button + 3);
		firstAction = true;
		
		numFolded = 0;
		numChecked = 0;
		for(int seat = 0; seat < numPlayers; seat++) {
			folded[seat] = false;
		}
		
		numDealtCards = 0;
	}
	
	@Override
	public String toString() {
		String result = "";
		
		result += "Number of dealt cards: " + numDealtCards
				+ "\nBoard cards>> |";
		for(int card = 0; card < numDealtCards; card++)
			result += boardCards[card].toString();
		result += "|\n";
		
		result += "Button: " + button + "\n";
		result += "First action: " + firstAction + "\n";
		result += "Seat to act: " + seatToAct + "\n";
		result += "Number of players: " + numPlayers + "\n";
		result += "Number of players who have checked: " + numChecked + "\n";
		result += "Number of players who have folded: " + numFolded + "\n";
		
		for(boolean fold : folded)
			result += "|" + fold;
		result += "|";
		
		return result;
	}
	
	private void voluntaryActionTaken() {
		// All but one player folded
		if(getNumPlayersInGame() == 1) {
			firstAction = true;
			hand.showdown();
			return;
		}
		
		// All player have checked or folded
		if(numChecked + numFolded == numPlayers) {
			seatToAct = getNextPlayerInGame(button);
			firstAction = true;
			numChecked = 0;
			hand.nextStage();
			return;
		}
		
		seatToAct = getNextPlayerInGame(seatToAct);
		firstAction = false;
	}
	
	public boolean hasFolded(int seat) {
		return folded[seat];
	}
	
}
