package de.tud.informatik.ke.aethon.gamestate;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.movegenerator.Action;

public class ClientHand extends Hand {
	
	private GameStateMessage message;
	private Action lastAction;
	
	/**
	 * The seat Aethon takes place at the beginning of the game. The table
	 * shifts the button and not the players, which should be much more
	 * perfomant. So the seat will differ from the {@link GameStateMessage}.
	 */
	private int seatTaken;
	
	public ClientHand(Player[] players) {
		super(players);
		seatTaken = -1;
	}
	
	public int getHandNumber() {
		return message.getHandNumber();
	}
	
	/**
	 * Call handleMessage before this. Otherwise the result will be incorrect.
	 * 
	 * @return the last action taken by a player.
	 * @see ClientHand#handleMessage(GameStateMessage)
	 */
	public Action getLastAction() {
		return lastAction;
	}
	
	/**
	 * @return the seat Aethon has taken in the first hand (NOT THE SEAT NUMBER
	 *         FROM {@link GameStateMessage}).
	 */
	public int getSeatTaken() {
		return seatTaken;
	}
	
	@Override
	protected void handleBoardCardDealing() {
		dealer.dealBoardCards(message.getLastBoardCards());
	}
	
	@Override
	protected void handleHoleCardDealing() {
		if(seatTaken < 0)
			seatTaken = message.getSeatTaken();
		dealer.dealHoleCards(seatTaken,message.getHoleCards(message
				.getSeatTaken()));
	}
	
	/**
	 * Maps a {@link GameStateMessage} to an equivalent hand state.
	 * 
	 * @param message
	 * @see GameStateMessage
	 * @see Hand
	 */
	public void handleMessage(GameStateMessage message) {
		Player player = players[table.getSeatToAct()];
		
		this.message = message;
		switch(message.getLastAction()) {
		case 'r':
			player.raise();
			lastAction = Action.RAISE;
			break;
		case 'c':
			player.call();
			lastAction = Action.CALL;
			break;
		case 'f':
			player.fold();
			lastAction = Action.FOLD;
			break;
		case GameStateMessage.NOACTION:
			newHand();
			break;
		default:
			throw new IllegalArgumentException("Unexpected action: "
					+ message.getLastAction());
		}
	}
	
	@Override
	protected void handleShowdown() {
		Card[][] holeCards = message.getHoleCards();
		
		// Deal all known hole cards. Aethon will receive his
		// hole cards again. But they should be the same.
		int sb = table.getSmallBlind();
		if(table.getNumPlayersInGame() > 1) {
			for(int messageSeat = 0; messageSeat < players.length; messageSeat++) {
				int tableSeat = table.indexToSeat(sb + messageSeat);
				if(!table.hasFolded(tableSeat))
					dealer.dealHoleCards(tableSeat,holeCards[messageSeat]);
			}
		}
		
		// Pay off winners
		pot.payOffWinners(players,table);
		pot.clearPot();
	}
	
	/**
	 * Call handleMessage before this. Otherwise the result will be incorrect.
	 * 
	 * @return true if it is our turn to act and false otherwise.
	 * @see ClientHand#handleMessage(GameStateMessage)
	 */
	public boolean isOurTurn() {
		return !isShowdown && seatTaken == table.getSeatToAct();
	}
	
	@Override
	public String toString() {
		String result = "";
		
		result += "seat taken: " + seatTaken + "\n";
		result += "last action: " + lastAction + "\n";
		result += super.toString();
		
		return result;
	}
	
}
