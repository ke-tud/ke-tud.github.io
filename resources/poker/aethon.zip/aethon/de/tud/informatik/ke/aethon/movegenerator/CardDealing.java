package de.tud.informatik.ke.aethon.movegenerator;

import ca.ualberta.cs.poker.free.dynamics.Card;

/**
 * A simulated dealing of cards to one player (or the board)
 * 
 * @author michael
 * 
 */
public class CardDealing implements Move {

	/**
	 * the cards that are dealt to the player
	 */
	private Card[] cards;

	/**
	 * 
	 * @param cards
	 *            the cards to deal
	 */
	public CardDealing(Card[] cards) {
		this.cards = cards;
	}

	/**
	 * 
	 * @return the cards that are dealt to the player
	 */
	public Card[] getCards() {
		return cards;
	}

	public boolean equals(CardDealing other) {
		for (Card i : other.getCards())
			if (!cardContained(i))
				return false;
		return true;
	}

	private boolean cardContained(Card other) {
		for (Card i : this.getCards())
			if (other.equals(i))
				return true;
		return false;
	}
}
