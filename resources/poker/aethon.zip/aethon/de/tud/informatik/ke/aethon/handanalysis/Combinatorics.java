package de.tud.informatik.ke.aethon.handanalysis;

public abstract class Combinatorics {
	
	public static final int NUMFREECARDS = 52 - 2 - 5;
	public static int MAXDOF = 2;
	
	private Outcome domOutcome;
	
	private int numDefeats;
	private int numWins;
	private int numTies;
	
	private int[] dofConstraints;
	
	public static int nC2(int n) {
		return (n - 1) * n >> 1;
	}
	
	public Combinatorics(Outcome outcome, int const1, int const2) {
		dofConstraints = new int[MAXDOF];
		clear();
		domOutcome = outcome;
		dofConstraints[0] = const1;
		dofConstraints[1] = const2;
	}
	
	protected void addToDefeats(int amount) {
		switch(domOutcome) {
		case DEFEAT:
			numDefeats += amount;
			break;
		case TIE:
			addToTies(amount);
			break;
		case WIN:
			addToWins(amount);
			break;
		}
	}
	
	protected void addToTies(int amount) {
		if(domOutcome.equals(Outcome.WIN)) {
			addToWins(amount);
			return;
		}
		numTies += amount;
	}
	
	protected void addToWins(int amount) {
		if(domOutcome.equals(Outcome.TIE)) {
			addToTies(amount);
			return;
		}
		numWins += amount;
	}
	
	public void selectTie() {
		if(domOutcome.equals(Outcome.DEFEAT))
			domOutcome = Outcome.TIE;
	}
	
	public void selectWin() {
		if(domOutcome.equals(Outcome.DEFEAT))
			domOutcome = Outcome.WIN;
	}
	
	/**
	 * Resets the combination counter.
	 */
	public void clear() {
		numDefeats = 0;
		numTies = 0;
		numWins = 0;
		for(int index = 0; index < MAXDOF; index++)
			dofConstraints[index] = 0;
	}
	
	protected abstract void countCombs(CardSet hole, CardSet board,
			CardSet combined);
	
	/**
	 * Counts how many times the given hole cards win, loose or tie.
	 */
	public void evaluate(CardSet hole, CardSet board, CardSet combined) {
		clear();
		countCombs(hole,board,combined);
	}
	
	protected void addToDofConstraint(int dof, int amount) {
		dofConstraints[dof - 1] += amount;
	}
	
	public int getNumDofConstraints(int dof) {
		int sum = 0;
		for(int index = 0; index < dof; index++)
			sum += dofConstraints[index];
		return sum;
	}
	
	public Outcome getOutcome() {
		return domOutcome;
	}
	
	public int getNumDefeats() {
		return numDefeats;
	}
	
	public int getNumTies() {
		return numTies;
	}
	
	public int getNumWins() {
		return numWins;
	}
	
	public int getTotal() {
		return numDefeats + numWins + numTies;
	}
	
	public void increaseDofConstraint(int dof) {
		dofConstraints[dof - 1]++;
	}
}
