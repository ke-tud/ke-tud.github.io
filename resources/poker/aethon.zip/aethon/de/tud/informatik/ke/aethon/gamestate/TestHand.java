package de.tud.informatik.ke.aethon.gamestate;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.playermodelling.PlayerModel;
import de.tud.informatik.ke.aethon.playermodelling.SimplePlayer;
import de.tud.informatik.ke.aethon.uct.UCT;

public class TestHand extends ClientHand {
	
	private int currentHandNumber;
	private static final int numHands = 1;
	private static final int numPlayer = 6;
	private Card[][] hands;
	
	public TestHand(Player[] players) {
		super(players);
		
		currentHandNumber = -1;
		hands = new Card[numHands][(players.length << 1) + 5];
		loadCardFile();
	}
	
	private void loadCardFile() {
		try {
			// TODO insert file name
			BufferedReader reader = new BufferedReader(new FileReader(new File(
					"misc/testcards")));
			String line = reader.readLine();
			int numCards = line.length() >> 1;
			
			for(int handNumber = 0; handNumber < numHands; handNumber++) {
				for(int index = 0; index < numCards; index++) {
					int cardIndex = index << 1;
					hands[handNumber][index] = new Card(line.substring(
							cardIndex,cardIndex + 2));
				}
				line = reader.readLine();
			}
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void handleHoleCardDealing() {
		super.handleHoleCardDealing();
		
		currentHandNumber++;
		for(int seat = 0; seat < players.length; seat++) {
			int cardIndex = seat << 1;
			players[seat].pickUp(new Card[]{
					hands[currentHandNumber][cardIndex],
					hands[currentHandNumber][cardIndex + 1]});
		}
	}
	
	@Override
	protected void handleShowdown() {
		pot.payOffWinners(players,table);
		pot.clearPot();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PlayerModel[] playerModels = new SimplePlayer[numPlayer];
		Player[] players = new Player[numPlayer];
		for(int index = 0; index < numPlayer; index++) {
			playerModels[index] = new SimplePlayer(index,"Test" + index);
			players[index] = new Player(index,"Test" + index);
		}
		
		TestHand testHand = new TestHand(players);
		String message = "MATCHSTATE:0:0::KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		UCT uct = new UCT(new UCTHand(testHand),playerModels);
		
		message = "MATCHSTATE:0:0:c:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:ccc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:ccccc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccr:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrcc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrccc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrcccc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrccccr:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrccccrr:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrccccrrc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrccccrrcc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		message = "MATCHSTATE:0:0:cccccrccccrrccc:KhQh|||||";
		testHand.handleMessage(new GameStateMessage(message));
		uct.run(2000);
		uct.descendIntoSubtree(testHand.getLastAction());
		
		uct.run(10000000000l);
	}
	
}
