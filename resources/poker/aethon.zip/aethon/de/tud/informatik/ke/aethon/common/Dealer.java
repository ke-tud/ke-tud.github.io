package de.tud.informatik.ke.aethon.common;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.gamestate.Player;

public class Dealer {
	
	protected Player[] players;
	protected Table table;
	
	public Dealer(Dealer dealer, Player[] players, Table table) {
		this.players = players;
		this.table = table;
	}
	
	@Override
	public String toString() {
		String result = "";
		
		result += "Number of players: "+players.length+"\n";
		result += table.getNumDealtCards()+" board cards are dealt.";
		
		return result;
	}
	
	public Dealer(Player[] players, Table table) {
		this.players = players;
		this.table = table;
	}
	
	/**
	 * Deals all board cards to the table. The cards are taken from the board
	 * card queue.
	 */
	public void dealBoardCards(Card[] cards) {
		table.addCards(cards);
	}
	
	/**
	 * Deals all hole cards to the players at the specified seats. The cards are
	 * taken from the hole card queue.
	 */
	public void dealHoleCards(int seat, Card[] cards) {
		players[seat].pickUp(cards);
	}
}
