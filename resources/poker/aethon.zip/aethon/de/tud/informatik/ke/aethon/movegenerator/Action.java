package de.tud.informatik.ke.aethon.movegenerator;

public enum Action implements Move {
	FOLD, CALL, RAISE;

	public static Action indexToAction(int index) {
		switch (index) {
		case 0:
			return FOLD;
		case 1:
			return CALL;
		case 2:
			return RAISE;
		default:
			throw new IllegalArgumentException("Only 0, 1 and 2 allowed.");
		}
	}
}
