package de.tud.informatik.ke.aethon.playermodelling;

import de.tud.informatik.ke.aethon.gamestate.Stage;
import de.tud.informatik.ke.aethon.movegenerator.Action;

public class DefaultPlayer implements PlayerModel {
	
	private static final int numActions = Action.values().length;
	private static final double[][] deviationPropability = new double[numActions][numActions];
	private static final double[] actionPropability = new double[numActions];
	
	public DefaultPlayer() {
		for(int index = 0; index < numActions; index++) {
			deviationPropability[index][index] = 1;
			actionPropability[index] = 1.0f / numActions;
		}
	}
	
	@Override
	public double[] getActionPropability(Stage stage) {
		return actionPropability;
	}
	
	@Override
	public double getDeviationPropability(Stage stage, Action predicted, Action expected) {
		return deviationPropability[predicted.ordinal()][expected.ordinal()];
	}
	
	@Override
	public void update(Stage stage, Action predicted, Action performed) {
	// The default player is not learning anything.
	}
	
}
