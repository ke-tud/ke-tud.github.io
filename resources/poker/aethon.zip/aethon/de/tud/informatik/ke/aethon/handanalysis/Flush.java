package de.tud.informatik.ke.aethon.handanalysis;

import ca.ualberta.cs.poker.free.dynamics.Card.Suit;

public class Flush extends Combinatorics {
	
	private int numStraightFlushes;
	
	public Flush(Outcome outcome, int const1, int const2, int numStraightFlushes) {
		super(outcome,const1,const2);
		this.numStraightFlushes = numStraightFlushes;
	}
	
	/**
	 * Searches for possible flushes. Since only two opponent hole cards can be
	 * used to complete a flush at least three of five board cards must have the
	 * same suit. Therefore at most one suit can lead to a flush.
	 * 
	 * @return The the suit which leads to a possible flush or null if no flush
	 *         is possible.
	 */
	public static Suit getFlushSuit(CardSet board) {
		for(Suit suit : Suit.values())
			if(board.size(suit) >= 3)
				return suit;
		return null;
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		
		// Find the only suit which possibly contains flushes.
		Suit flushSuit = getFlushSuit(board);
		if(flushSuit == null)
			return;
		
		/*
		 * Project set onto the flush suit. Only the combined set is used by
		 * HighCard.
		 */
		CardSet flushCombined = CardSet.toUnsuited(CardSet.project(combined,
				flushSuit));
		
		/*
		 * Count flushes like high cards restricted to suit equality and number
		 * of cards.
		 */
		HighCard highcard = new HighCard(getOutcome(),getNumDofConstraints(1),
				getNumDofConstraints(2),2);
		highcard.evaluate(flushCombined,null,null);
		
		int numCombs = highcard.getNumDefeats();
		addToDefeats(numCombs + getArbitraryCombs(5 - board.size(flushSuit)));
		
		if(highcard.getNumTies() > 0) {
			numCombs = highcard.getNumTies() - numStraightFlushes;
			if(board.size(flushSuit) + hole.size(flushSuit) >= 5) {
				addToTies(numCombs);
				selectTie();
			} else
				addToDefeats(numCombs);
		}
	}
	
	private int getArbitraryCombs(int dof) {
		return (dof > 0) ? getNumDofConstraints(dof) : 1;
	}
}
