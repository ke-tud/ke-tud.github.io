package de.tud.informatik.ke.aethon.client;

import java.awt.Toolkit;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

import ca.ualberta.cs.poker.free.client.PokerClient;
import de.tud.informatik.ke.aethon.common.Probability;
import de.tud.informatik.ke.aethon.gamestate.ClientHand;
import de.tud.informatik.ke.aethon.gamestate.GameStateMessage;
import de.tud.informatik.ke.aethon.gamestate.Stage;
import de.tud.informatik.ke.aethon.gamestate.UCTHand;
import de.tud.informatik.ke.aethon.movegenerator.Action;
import de.tud.informatik.ke.aethon.playermodelling.SimplePlayer;
import de.tud.informatik.ke.aethon.timemanagement.TimeManager;
import de.tud.informatik.ke.aethon.uct.UCT;

// TODO in UCT die MC Simulation wegschmeissen und durch Evaluation ersetzen
// TODO wenn simulate durch evaluate ersetzt wird, muss im grunde im gesamten
// baum nur einmal evaluiert werden (oder zumindest ermittelt werden welche
// haende uns schlagen und diese koennen dann im oponent modelling gewichtet
// werden)

public class AethonClient extends PokerClient {
	
	public static final String OURNAME = "The Mighty Aethon";
	
	public static void main(String[] args) throws Exception {
		AethonClient aeth = new AethonClient();
		System.out.println("Attempting to connect to " + args[0] + " on port "
				+ args[1] + "...");
		aeth.connect(InetAddress.getByName(args[0]),Integer.parseInt(args[1]));
		System.out.println("Successful connection!");
		aeth.run();
	}
	
	private UCT uct;
	private SimplePlayer[] players;
	private TimeManager timeManager;
	private PonderingTask task;
	
	/**
	 * A reproduction of what is happening on the server side.
	 */
	protected ClientHand hand;
	
	public AethonClient() {
		super();
	}
	
	private void handleMessage() {
		GameStateMessage message = new GameStateMessage(currentGameStateString);
		
		if(hand == null) {
			int seatTaken = message.getSeatTaken();
			players = new SimplePlayer[message.getNumberOfPlayers()];
			for(int seat = 0; seat < players.length; seat++) {
				if(seat == seatTaken)
					players[seat] = new SimplePlayer(seat,OURNAME,numHands);
				else
					players[seat] = new SimplePlayer(seat,"Alice&Bob" + seat,10);
			}
			hand = new ClientHand(players);
		}
		hand.handleMessage(message);
	}
	
	// XXX Change number of hands to tournament conditions.
	// Note that the tournament conditions could have changed.
	public static final int numTournaments = 1, numHands = 6000,
			millisecondsPerHand = 6990;
	
	/**
	 * Handles the state change. Updates state and calls takeAction()
	 */
	public void handleStateChange() {
		try {
			// Interrupt running task
			if(task != null) {
				task.terminate();
				while(!task.hasTerminated()) {
					Thread.sleep(10);
				}
//				System.out.println("PONDERING STOP: "
//						+ System.currentTimeMillis());
			}
			
			handleMessage();
			if(hand.getHandNumber() == numHands - 1
					&& hand.getCurrentStage().equals(Stage.SHOWDOWN)) {
				Toolkit.getDefaultToolkit().beep();
				return;
			}
			
			// Create an uct instance
			if(uct == null)
				uct = new UCT(new UCTHand(hand),players);
			
			// Create a new time manager instance
			if(timeManager == null)
				timeManager = new TimeManager(numTournaments * numHands
						* millisecondsPerHand,numTournaments * numHands,hand);
			
			// Decide to descend into a subtree or refresh board cards
			if(hand.isFirstAction()) {
				uct.clearTree(new UCTHand(hand));
				Probability.getInstance().reset();
			} else
				uct.descendIntoSubtree(hand.getLastAction());
			
			// Take an action if it is out turn or ponder
			if(hand.isOurTurn())
				takeAction();
			else {
//				System.out.println("PONDERING START: "
//						+ System.currentTimeMillis());
				ponder();
			}
		} catch(Throwable t) {
			System.err
					.println("!!!ERROR!!! IRGENDETWAS IST WIEDER SCHIEF GEGANGEN!!!");
			t.printStackTrace(System.err);
			Toolkit.getDefaultToolkit().beep();
			try {
				sendCall();
			} catch(SocketException e) {
				e.printStackTrace();
			} catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private void ponder() {
		task = new PonderingTask(uct);
		task.start();
	}
	
	private void takeAction() {
//		System.out.println("AETHON TAKES ACTION.");
		uct.run(timeManager.getTimeSlice());
		Action action = uct.getResult();
		
		try {
			switch(action) {
			case RAISE:
				sendRaise();
				break;
			case CALL:
				sendCall();
				break;
			case FOLD:
//				System.out.println("AETHON FOLDED.");
				sendFold();
				break;
			default:
				throw new Exception("Illegal action: " + action.toString());
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
