package de.tud.informatik.ke.aethon.handanalysis;

import de.tud.informatik.ke.aethon.common.Math;
import de.tud.informatik.ke.aethon.common.ThisWasBadAndShouldNotHappenException;

public class NOfAKind extends SeveralOfAKind {
	
	private final int KIND;
	private final int NMAXDOF;
	private final boolean FOUNDHOLEKIND;
	
	public NOfAKind(Outcome outcome, int const1, int const2,
			SeveralOfAKind soak, int n) {
		super(outcome,const1,const2,soak);
		switch(n) {
		case 2:
			KIND = PAIR;
			NMAXDOF = PAIRMAXDOF;
			FOUNDHOLEKIND = foundHolePair;
			break;
		case 3:
			KIND = THREEOFAKIND;
			NMAXDOF = TOAKMAXDOF;
			FOUNDHOLEKIND = foundHoleToak;
			break;
		default:
			throw new ThisWasBadAndShouldNotHappenException(
					"n should equals 2 or 3 but was: " + n);
		}
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		
		// Initialise full house table if it has not been set externally.
		if(table == null)
			initTable(hole,board);
		
		/*
		 * Count number of defeating combinations using the defeating "same" of
		 * a kinds. "Same" is meant to be two or three.
		 */
		for(int kindDof = DOF1; kindDof <= DOF2; kindDof++)
			/*
			 * Because all "same" of a kind are expected to defeat the given
			 * hole card "same" of a kinds at the moment, the number of reserved
			 * hole cards have to be less then the degree of freedom.
			 */
			for(int kindReserved = DOF0; kindReserved < kindDof; kindReserved++)
				addToDefeats(getNumCombs(DEFEATING,kindDof,kindReserved));
		
		// Handle tie.
		if(FOUNDHOLEKIND) {
			
			// Ties
			if(tiePairDof > DOF0 || (tieToakDof > DOF0 && tieToakDof < MAXDOF))
				// Just switching to tie counter. The next loop does the rest.
				selectTie();
			
			/*
			 * Count wins or ties using all winning "same" of a kinds.
			 */
			for(int kindDof = DOF0; kindDof <= DOF2; kindDof++) {
				for(int kindReserved = DOF0; kindReserved <= DOF2; kindReserved++) {
					int numCombs = getNumCombs(WINTIE,kindDof,kindReserved);
					if(numCombs > 0) {
						addToWins(numCombs);
						selectWin();
					}
				}
			}
		}
	}
	
	private int getNumCombs(int kindOutcome, int kindDof, int kindReserved) {
		
		int n = NUMSUITS - (NMAXDOF - kindDof + kindReserved);
		
		if(n < 0)
			return 0;
		
		int oldDof = kindDof;
		if(n < kindDof)
			kindDof = n;
		
		// Number of suit combinations.
		int suitCombs = (int)Math.nCr(n,kindDof);
		
		// Number of kinds.
		int kindCombs = table[kindOutcome][KIND][oldDof][kindReserved]
				* suitCombs;
		
		if(kindCombs == 0)
			return 0;
		
		int arbitrary = 1;
		int freeCards = MAXDOF - kindDof;
		if(freeCards > DOF0) {
			arbitrary = NUMFREECARDS - getNumDofConstraints(freeCards);
			addToDofConstraint(freeCards,kindCombs);
		}
		
		return kindCombs * arbitrary;
	}
	
}
