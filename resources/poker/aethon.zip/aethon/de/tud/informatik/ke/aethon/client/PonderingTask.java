package de.tud.informatik.ke.aethon.client;

import de.tud.informatik.ke.aethon.timemanagement.TimeManager;
import de.tud.informatik.ke.aethon.uct.UCT;

public class PonderingTask extends Thread {
	
	private UCT uct;
	private boolean terminate;
	private boolean terminated;
	
	public PonderingTask(UCT uct) {
		this.uct = uct;
	}
	
	@Override
	public synchronized void start() {
		terminate = false;
		terminated = false;
		super.start();
	}
	
	@Override
	public void run() {
		super.run();
		
		while(!terminate)
			uct.run(TimeManager.timeSliceForPodering);
		terminated = true;
	}
	
	public synchronized void terminate() {
		terminate = true;
	}

	public boolean hasTerminated() {
		return terminated;
	}
}
