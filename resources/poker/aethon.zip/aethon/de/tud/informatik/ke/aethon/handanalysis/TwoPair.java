package de.tud.informatik.ke.aethon.handanalysis;

import de.tud.informatik.ke.aethon.common.Math;

public class TwoPair extends SeveralOfAKind {
	
	public TwoPair(Outcome outcome, int const1, int const2, SeveralOfAKind soak) {
		super(outcome,const1,const2,soak);
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		
		// Initialise full house table if it has not been set externally.
		if(table == null)
			initTable(hole,board);
		
		/*
		 * Count number of defeating combinations using the defeating pairs.
		 * First combinations in the same cell are counted.
		 */
		for(int reserved = DOF0; reserved <= DOF1; reserved++)
			addToDefeats(getNumCombs(DEFEATING,DOF1,reserved));
		
		for(int dof1st = DOF1; dof1st <= DOF2; dof1st++)
			for(int dof2nd = DOF0; dof1st + dof2nd <= MAXDOF; dof2nd++)
				/*
				 * While looking for two pair, the given hole cards are never
				 * subset of any three of a kind or completing a high card pair.
				 * Otherwise a winning or tying combination would have been
				 * found. Therefore the number of reserved hole cards is always
				 * less then the degree of freedom.
				 */
				for(int reserved1st = DOF0; reserved1st < dof1st; reserved1st++)
					for(int reserved2nd = DOF0; reserved2nd <= dof2nd; reserved2nd++)
						addToDefeats(getNumCombs(DEFEATING,dof1st,reserved1st,
								WINTIE,dof2nd,reserved2nd));
		
		/*
		 * It is impossible to win two pair exclusively. There will be always a
		 * combination which ties the given hole cards.
		 */
		for(int dof1st = DOF0; dof1st <= DOF2; dof1st++)
			for(int dof2nd = dof1st; dof1st + dof2nd <= MAXDOF; dof2nd++)
				for(int reserved1st = DOF0; reserved1st <= DOF2; reserved1st++)
					for(int reserved2nd = DOF0; reserved2nd <= DOF2; reserved2nd++) {
						int numCombs;
						if(dof1st == dof2nd && reserved1st == reserved2nd)
							numCombs = getNumCombs(WINTIE,dof1st,reserved1st);
						else
							numCombs = getNumCombs(WINTIE,dof1st,reserved1st,
									WINTIE,dof2nd,reserved2nd);
						
						if(numCombs > 0) {
							addToTies(numCombs);
							selectTie();
						}
					}
	}
	
	private int getNumCombs(int outcome1st, int dof1st, int reserved1st,
			int outcome2nd, int dof2nd, int reserved2nd) {
		
		int n1st = NUMSUITS - (PAIRMAXDOF - dof1st + reserved1st);
		int n2nd = NUMSUITS - (PAIRMAXDOF - dof2nd + reserved2nd);
		
		if(n1st < 0 || n2nd < 0)
			return 0;
		
		int oldDof1st = dof1st;
		if(n1st < dof1st)
			dof1st = n1st;
		
		int oldDof2nd = dof2nd;
		if(n1st < dof2nd)
			dof2nd = n2nd;
		
		// Number of suit combinations.
		int numSuits1st = (int)Math.nCr(n1st,dof1st);
		int numSuits2nd = (int)Math.nCr(n2nd,dof2nd);
		int suitCombs = numSuits1st * numSuits2nd;
		
		// Number of pair pair combinations.
		int twoPairCombs = table[outcome1st][PAIR][oldDof1st][reserved1st]
				* table[outcome2nd][PAIR][oldDof2nd][reserved2nd] * suitCombs;
		
		if(twoPairCombs == 0)
			return 0;
		
		int arbitrary = 1;
		int dof = MAXDOF - dof1st - dof2nd;
		if(dof > DOF0) {
			arbitrary = NUMFREECARDS - getNumDofConstraints(dof);
			addToDofConstraint(dof,twoPairCombs);
		}
		
		return twoPairCombs * arbitrary;
	}
	
	private int getNumCombs(int outcome, int dof, int reserved) {
		
		// Number of suit combinations.
		int numSuits = (int)Math.nCr(NUMSUITS - (PAIRMAXDOF - dof + reserved),
				dof);
		int suitCombs = numSuits * numSuits;
		
		/*
		 * Counting two pairs in the same cell must take into account that there
		 * are duplicated combinations. The formula to avoid duplications is sum
		 * i = 1 to n-1 {i} = (n - 1) * n / 2.
		 */
		int twoPairCombs = (table[outcome][PAIR][dof][reserved]
				* (table[outcome][PAIR][dof][reserved] - 1) * suitCombs) >> 1;
		
		if(twoPairCombs == 0)
			return 0;
		
		int arbitrary = 1;
		int totalDof = MAXDOF - 2 * dof;
		if(totalDof > DOF0) {
			arbitrary = NUMFREECARDS - getNumDofConstraints(totalDof);
			addToDofConstraint(totalDof,twoPairCombs);
		}
		
		return twoPairCombs * arbitrary;
	}
}
