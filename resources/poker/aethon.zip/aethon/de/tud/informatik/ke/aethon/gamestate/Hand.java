package de.tud.informatik.ke.aethon.gamestate;

import de.tud.informatik.ke.aethon.common.AbstractPot;
import de.tud.informatik.ke.aethon.common.Probability;
import de.tud.informatik.ke.aethon.common.Table;
import de.tud.informatik.ke.aethon.common.Dealer;
import de.tud.informatik.ke.aethon.common.SimplePot;

public abstract class Hand {
	
	public static final int smallBlind = 1;
	public static final int bigBlind = 2;
	static final int smallBet = 2;
	static final int bigBet = 4;
	private static final int betLimit = 4;
	
	protected Table table;
	protected AbstractPot pot;
	protected Dealer dealer;
	protected Player[] players;
	private static int numPlayers = 0;
	
	protected boolean isShowdown;
	protected Stage currentStage;
	private int numBets;
	
	public Hand(Hand hand) {
		table = new Table(hand.table,this);
		pot = new SimplePot(hand.pot);
		players = new Player[numPlayers];
		for(int seat = 0; seat < numPlayers; seat++)
			players[seat] = new Player(hand.players[seat],this,table,pot);
		dealer = new Dealer(hand.dealer,players,table);
		
		isShowdown = hand.isShowdown;
		currentStage = hand.currentStage;
		numBets = hand.numBets;
	}
	
	public Hand(Player[] players) {
		numPlayers = players.length;
		table = new Table(numPlayers,this);
		pot = new SimplePot(numPlayers);
		dealer = new Dealer(players,table);
		this.players = players;
		
		for(int seat = 0; seat < numPlayers; seat++) {
			players[seat].setTable(table);
			players[seat].setPot(pot);
			players[seat].setHand(this);
		}
	}
	
	/**
	 * This method have to be called if a bet is taken.
	 */
	public void bet() {
		numBets++;
	}
	
	/**
	 * @return true if the number of bets does not exceed the bet limit and
	 *         false otherwise.
	 */
	public boolean canBet() {
		return numBets < betLimit;
	}
	
	/**
	 * @return the bet amount for the curent round.
	 */
	public int getBetSize() {
		return currentStage.betSize;
	}
	
	/**
	 * @return the currentStage
	 */
	public Stage getCurrentStage() {
		return currentStage;
	}
	
	/**
	 * @return the seat of the player who is on the turn.
	 */
	public int getSeatToAct() {
		return table.getSeatToAct();
	}
	
	/**
	 * Implement this method to handle a board card dealing. The number of cards
	 * which have to be dealt can be read from the <code>currentStage</code>.
	 * It is up to you to deal the cards proper.
	 */
	protected abstract void handleBoardCardDealing();
	
	/**
	 * Implement this method to handle a hole card dealing. It is up to you to
	 * deal the cards proper.
	 */
	protected abstract void handleHoleCardDealing();
	
	/**
	 * This method is called if all bettings and card regular card dealings are
	 * over. The players should be paid off and the pot may be cleared.
	 */
	protected abstract void handleShowdown();
	
	/**
	 * @return true if the next action is the first at a stage.
	 * @see Table#isFirstAction()
	 */
	public boolean isFirstAction() {
		return table.isFirstAction();
	}
	
	/**
	 * Starts a new hand
	 */
	public void newHand() {
		// A new hand starts with the preflop
		numBets = 0;
		isShowdown = false;
		currentStage = Stage.PREFLOP;
		
		table.newHand();
		for(int seat = 0; seat < numPlayers; seat++)
			players[seat].newHand();
		
		// Deal hole cards
		handleHoleCardDealing();
		
		// The blinds
		players[table.getSmallBlind()].contributeSmallBlind();
		players[table.getBigBlind()].contributeBigBlind();
	}
	
	/**
	 * Switches to the next stage.
	 */
	public void nextStage() {
		currentStage = currentStage.next;
		numBets = 0;
		
		// Omit all folded players
		if(currentStage.equals(Stage.SHOWDOWN))
			showdown();
		else
			handleBoardCardDealing();
	}
	
	/**
	 * Call this method if it is showtime.
	 */
	public void showdown() {
		isShowdown = true;
		handleShowdown();
	}
	
	@Override
	public String toString() {
		String result = "";
		
		result += "Stage: " + currentStage.toString() + "\n";
		result += "number of bets: " + numBets + "\n";
		result += "is hand over? " + isShowdown + "\n\n";
		result += "   Table>> \n" + table.toString() + "\n\n";
		result += "   Pot>> \n" + pot.toString() + "\n\n";
		result += "   Dealer>> \n" + dealer.toString() + "\n\n";
		for(Player player : players) {
			result += "   Player>> \n" + player.toString() + "\n";
		}
		
		return result;
	}
	
	/**
	 * @return the number of players
	 */
	public static int getNumPlayers() {
		return numPlayers;
	}
	
}
