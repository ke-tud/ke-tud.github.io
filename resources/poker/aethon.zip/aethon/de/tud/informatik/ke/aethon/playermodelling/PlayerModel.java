package de.tud.informatik.ke.aethon.playermodelling;

import de.tud.informatik.ke.aethon.gamestate.Stage;
import de.tud.informatik.ke.aethon.movegenerator.Action;

public interface PlayerModel {
	
	public void update(Stage stage, Action predicted, Action performed);
	
	public double getDeviationPropability(Stage stage, Action predicted,
			Action expected);
	
	public double[] getActionPropability(Stage stage);
}
