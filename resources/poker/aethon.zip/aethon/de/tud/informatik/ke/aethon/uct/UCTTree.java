package de.tud.informatik.ke.aethon.uct;

import java.util.Vector;

import de.tud.informatik.ke.aethon.common.SingletonProvider;
import de.tud.informatik.ke.aethon.common.ThisWasBadAndShouldNotHappenException;
import de.tud.informatik.ke.aethon.gamestate.Stage;
import de.tud.informatik.ke.aethon.gamestate.UCTHand;
import de.tud.informatik.ke.aethon.movegenerator.Action;
import de.tud.informatik.ke.aethon.movegenerator.Move;
import de.tud.informatik.ke.aethon.movegenerator.MoveGenerator;

public class UCTTree {
	
	/**
	 * This nodes parent node. If null, this node is the root (no parent node
	 * exists).
	 */
	private UCTTree parent;
	
	/**
	 * Children of this node (Subtrees of this tree).
	 */
	private Vector<UCTTree> children;
	
	/**
	 * The Moves that lead to the children.
	 */
	private Vector<Move> moves;
	
	/**
	 * The movegenerator that's associated to this node.
	 */
	private MoveGenerator generator;
	
	/**
	 * The number of simulations that ran through this node.
	 */
	private int numberOfSimulations;
	
	/**
	 * Sum of the values of all the simulations that ran through this node
	 * (individually for each player). Needed for the computation of the mean
	 * value.
	 */
	private double[] summedValues;
	
	/**
	 * Sum of the squares of the values of all the simulations that ran through
	 * this node (individually for each player). Needed for the computation of
	 * the exploration/exploitation-tradeoff constant.
	 */
	private double[] summedSquareValues;
	
	private UCTHand hand;
	
	public UCTTree(UCTHand hand, UCTTree parent) {
		numberOfSimulations = 0;
		summedValues = new double[UCTHand.getNumPlayers()];
		summedSquareValues = new double[UCTHand.getNumPlayers()];
		for(int i = 0; i < UCTHand.getNumPlayers(); i++) {
			summedValues[i] = 0;
			summedSquareValues[i] = 0;
		}
		children = new Vector<UCTTree>();
		moves = new Vector<Move>();
		this.hand = hand;
		this.parent = parent;
		generator = new MoveGenerator(this);
	}
	
	/**
	 * @return this node's children
	 */
	public Vector<UCTTree> getChildren() {
		return children;
	}
	
	/**
	 * @return the moves that lead to the children
	 */
	public Vector<Move> getMoves() {
		return moves;
	}
	
	/**
	 * @return the parent node. If null, this node is the root (no parent node
	 *         exists).
	 */
	public UCTTree getParent() {
		return parent;
	}
	
	/**
	 * @return the current state of the game
	 */
	public UCTHand getHand() {
		return hand;
	}
	
	/**
	 * @return the MoveGenerator that's associated to this node
	 */
	public MoveGenerator getMoveGenerator() {
		return generator;
	}
	
	public int getNumberOfSimulations() {
		return numberOfSimulations;
	}
	
	/**
	 * adds the values of the last simulation to the summed values and updates
	 * the UCTValue
	 * 
	 * @param valuesOfLastSimulation
	 */
	public void updateValues(double[] valuesOfLastSimulation) {
		for(int i = 0; i < summedValues.length; i++) {
			summedValues[i] += valuesOfLastSimulation[i];
			summedSquareValues[i] += valuesOfLastSimulation[i]
					* valuesOfLastSimulation[i];
		}
	}
	
	/**
	 * @return the UCTValue using all simulated values
	 */
	public double getUCTValue() {
		return valueForPlayer(hand.getSeatToAct()) + nosinessSummand()
				+ varianceSummand() + derivationSummand();
	}
	
	/**
	 * the mean value of the simulations performed so far
	 * 
	 * @param seat
	 * @return
	 */
	private double valueForPlayer(int seat) {
		return (summedValues[seat] / numberOfSimulations);
	}
	
	/**
	 * This is the standard UCT uncertainty summand, which lets us explore other
	 * lines than the best one, because the other ones could be inferior to the
	 * current best and we might not have noticed this yet.
	 */
	private double nosinessSummand() {
		if(parent == null)
			return 0;
		double logParentsSimulations = Math
				.log(parent.getNumberOfSimulations());
		double oneDividedByNumberOfSimulations = 1.0f / getNumberOfSimulations();
		double coefficient;
		double valueForPlayerToAct = valueForPlayer(hand.getSeatToAct());
		double vJ = summedSquareValues[hand.getSeatToAct()]
				* oneDividedByNumberOfSimulations;
		vJ -= valueForPlayerToAct * valueForPlayerToAct;
		vJ += Math.sqrt(2 * logParentsSimulations
				* oneDividedByNumberOfSimulations);
		if(vJ < 0) {
			System.err.println();
			System.err.println(logParentsSimulations);
			System.err.println(oneDividedByNumberOfSimulations);
			System.err.println(valueForPlayerToAct);
			System.err.println(summedSquareValues[hand.getSeatToAct()]);
			System.err.println((Math.sqrt(2 * logParentsSimulations
					* oneDividedByNumberOfSimulations)));
			throw new ThisWasBadAndShouldNotHappenException(
					"vJ is less than zero and would be given to Math.sqrt(). As you may have already guessed, this is not good.");
		}
		coefficient = Math.min(0.5,Math.sqrt(vJ));
		
		return coefficient * Math.sqrt(logParentsSimulations
				* oneDividedByNumberOfSimulations);
	}
	
	/**
	 * This summands purpose is to let us minimize the variance of various
	 * player's stack sizes. If all the player's stack sizes are nearly equal,
	 * this is the best case for us. It's defined as sum over all i (except for
	 * the player to act) of var(H_i/H) where H_i is the stack of player i and H
	 * is the sum of all stacks (except for the player to act)
	 */
	private double varianceSummand() {
		if(parent == null || !parent.getHand().isOurTurn())
			return 0;
		
		// calculate H
		double summedStackOfEnemies = 0.0f;
		for(int i = 0; i < UCTHand.getNumPlayers(); i++) {
			if(i == hand.getSeatToAct())
				continue;
			summedStackOfEnemies += Math.abs(hand.getStackOfPlayer(i)
					+ valueForPlayer(i));
		}
		
		// calculate H_i/H and my
		double normalization = 1.0 / summedStackOfEnemies;
		double[] normalizedStacks = new double[UCTHand.getNumPlayers()];
		double meanNormalizedStack = 0.0;
		for(int i = 0; i < UCTHand.getNumPlayers(); i++) {
			if(i == hand.getSeatToAct())
				continue;
			normalizedStacks[i] = hand.getStackOfPlayer(i) * normalization;
			meanNormalizedStack += normalizedStacks[i];
		}
		meanNormalizedStack /= UCTHand.getNumPlayers() - 1;
		
		// calculate variance=sum((H_i/H - my)^2)
		double variance = 0.0;
		for(int i = 0; i < UCTHand.getNumPlayers(); i++) {
			if(i == hand.getSeatToAct())
				continue;
			double xMinusMy = normalizedStacks[i] - meanNormalizedStack;
			variance += (xMinusMy * xMinusMy);
		}
		
		return -UCT.constantForVariance * variance;
	}
	
	public double derivationSummand() {
		if(parent == null || parent.getHand().isOurTurn())
			return 0;
		
		double value = 0.0f;
		Vector<UCTTree> siblings = parent.getChildren();
		Vector<Move> moves = parent.getMoves();
		int numSiblings = siblings.size();
		Action performed = null;
		for(int i = 0; i < numSiblings; i++)
			if(siblings.elementAt(i) == this)
				performed = (Action)moves.elementAt(i);
		
		Stage stage = hand.getCurrentStage();
		for(int i = 0; i < numSiblings; i++) {
			Action sibling = (Action)moves.elementAt(i);
			value += SingletonProvider.getInstance().getPlayer(
					parent.getHand().getSeatToAct()).getDeviationPropability(
					stage,sibling,performed)
					* siblings.elementAt(i).nosinessSummand();
		}
		return UCT.constantForDerivationSummand * value;
	}
	
	/**
	 * increases the number of simulations by 1
	 */
	public void incNumberOfSimulations() {
		numberOfSimulations++;
	}
	
	/**
	 * adds a child to this node
	 * 
	 * @param child
	 *            the child that shall be added
	 * @param move
	 *            the move that leads to the child
	 */
	private void addChild(UCTTree child, Move move) {
		children.add(child);
		moves.add(move);
	}
	
	/**
	 * expands one of the childs that have not yet been expanded
	 * 
	 * @return the new child
	 */
	public UCTTree expandNewChild() {
		Move move = generator.generateNextMove();
		return expandNewChild(move);
	}
	
	public UCTTree expandNewChild(Move move) {
		UCTHand newHand = new UCTHand(hand);
		newHand.executeMove(move);
		UCTTree child = new UCTTree(newHand,this);
		addChild(child,move);
		return child;
	}
	
	/**
	 * sets this node's parent node to a new one
	 * 
	 * @param newParent
	 */
	public void setParent(UCTTree newParent) {
		parent = newParent;
	}
	
	/**
	 * @return depth from the root to this node; returns 0 if this node is the
	 *         root
	 */
	public int depth() {
		if(this.getParent() == null)
			return 0;
		else
			return 1 + this.getParent().depth();
	}
	
	@Override
	public String toString() {
		String message = "";
		
		message += "Is root? " + (parent == null) + "\n";
		message += "Depth of node: " + depth() + "\n";
		message += "Number of children: " + children.size() + "\n";
		message += "All children expanded? "
				+ (this.getMoveGenerator().allChildrenExpanded()) + "\n";
		message += "Possible moves: ";
		for(Move move : moves)
			message += move.toString() + " ";
		message += "\nNode has been simulated " + numberOfSimulations
				+ " times\n";
		message += "Its UCT value is: " + getUCTValue() + "\n";
		message += "Variance summand: " + varianceSummand() + "\n";
		message += "Nosiness summand: " + nosinessSummand();
		
		return message;
	}
	
	public String getShortInfo() {
		String message = "";
		double uctValue = getUCTValue();
		double meanValue = valueForPlayer(hand.getSeatToAct());
		double varianceSummand = varianceSummand();
		double nosinessSummand = nosinessSummand();
		double derivationSummand = derivationSummand();
		
		message += "Node has been simulated " + numberOfSimulations
				+ " times (" + parent.getNumberOfSimulations() + ")\n";
		message += "Its UCT value (mean, nosi, var, deriv) is: " + uctValue
				+ " (" + meanValue + " + " + nosinessSummand + " + "
				+ varianceSummand + " + " + derivationSummand + ")\n";
		message += "Variance summand: " + varianceSummand + " ("
				+ UCT.constantForVariance + " * "
				+ (varianceSummand / UCT.constantForVariance) + ")\n";
		
		return message;
	}
}
