/**
 * 
 */
package de.tud.informatik.ke.aethon.handanalysis;

public enum Outcome {
	DEFEAT, TIE, WIN;
}