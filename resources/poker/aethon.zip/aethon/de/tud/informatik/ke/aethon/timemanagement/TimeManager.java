package de.tud.informatik.ke.aethon.timemanagement;

import de.tud.informatik.ke.aethon.gamestate.ClientHand;
import de.tud.informatik.ke.aethon.gamestate.Stage;

public class TimeManager {
	private int time;

	private int numHands;

	private ClientHand hand;

	public static final int timeSliceForPodering=100;
	
	public TimeManager(int totalTimeInMilliseconds, int numHands,
			ClientHand hand) {
		this.time = totalTimeInMilliseconds;
		this.numHands = numHands;
		this.hand = hand;
	}

	/**
	 * 
	 * @return a time slice for the computation of an action of the player who's
	 *         turn it is currently
	 */
	public int getTimeSlice() {
		int temp = computeNormalTimeSlice();
		time -= temp;
		return temp;
	}

	private int computeNormalTimeSlice() {
		int handsLeft = numHands - hand.getHandNumber();
		Stage stage=hand.getCurrentStage();
		int curRound;
		if(stage==Stage.PREFLOP)
			curRound=0;
		else if(stage==Stage.FLOP)
			curRound=1;
		else if(stage==Stage.TURN)
			curRound=2;
		else if(stage==Stage.RIVER)
			curRound=3;
		else
			curRound=4;
		int roundsLeft = 4 - curRound;
		// TODO this could be done better if it would be infered from the
		// gamestate
		int ownActionsPerRound = 4;
		return time / (handsLeft * java.lang.Math.max(roundsLeft,1) * ownActionsPerRound);
	}

	// TODO think about a way to give the timemanager time back. For example if
	// UCT computes several rounds without significant changes in the game tree,
	// it could stop compution an give the TimeManager the time, which was not
	// needed back.
}
