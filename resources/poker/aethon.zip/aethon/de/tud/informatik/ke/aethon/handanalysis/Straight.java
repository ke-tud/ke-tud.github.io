package de.tud.informatik.ke.aethon.handanalysis;

import ca.ualberta.cs.poker.free.dynamics.Card;
import ca.ualberta.cs.poker.free.dynamics.Card.Rank;
import ca.ualberta.cs.poker.free.dynamics.Card.Suit;
import de.tud.informatik.ke.aethon.common.ThisWasBadAndShouldNotHappenException;

public class Straight extends Combinatorics {
	
	// All possible ranks.
	private static final Rank[] ranks = Rank.values();
	
	// Suit of possible flush.
	private Suit flushSuit;
	private int numSuits;
	private boolean suited;
	
	private int numLastStraight;
	private int lastDof;
	
	public Straight() {
		this(Outcome.DEFEAT,0,0,true);
	}
	
	public Straight(Outcome outcome, int const1, int const2, boolean suited) {
		super(outcome,const1,const2);
		this.numSuits = (suited) ? 1 : 4;
		this.suited = suited;
	}
	
	private void count(int highcardIndex, CardSet hole, CardSet board,
			CardSet combined) {
		
		// Wrap ace.
		int beginIndex = (highcardIndex >= Rank.SIX.index) ? highcardIndex
				- Rank.SIX.index : Rank.ACE.index;
		
		// Count number of determinable cards based on the board cards.
		int boardDof = 5 - board.countCards(Rank.toRank(beginIndex),Rank
				.toRank(highcardIndex),flushSuit);
		
		/*
		 * If the degree of freedom is greater then the number of chosable hole
		 * cards it cannot be completed to a straight.
		 */
		if(boardDof > 2)
			return;
		
		/*
		 * Count number of determinable cards based on the board and given hole
		 * cards.
		 */
		int combDof = 5 - combined.countCards(ranks[beginIndex],
				ranks[highcardIndex],flushSuit);
		
		if(boardDof > lastDof)
			numLastStraight = 0;
		lastDof = boardDof;
		
		/*
		 * If the combined set does not contain a straight the opponent might
		 * own it.
		 */
		if(combDof > 0) {
			
			/*
			 * If the degree of freedom equals one there is a card which can be
			 * chosen from the set of unknown cards. If the choice of such a
			 * card leads to a higher straight it has already been counted and
			 * is therefore refused. Otherwise, if the degree of freedom equals
			 * two, only one combination by rank completes the straight and can
			 * only vary over the suits.
			 */
			int numCombs;
			if(boardDof == 1) {
				numCombs = numSuits;
				addToDefeats(numCombs
						* (NUMFREECARDS - getNumDofConstraints(1))
						- numLastStraight);
			} else {
				numCombs = (numSuits - (MAXDOF - combDof)) * numSuits;
				addToDefeats(numCombs);
			}
			numLastStraight = numCombs;
			addToDofConstraint(boardDof,numCombs);
		} else if(suited) {
			addToWins(nC2(NUMFREECARDS - getNumDofConstraints(2)));
			selectWin();
		}
		else {
			
			/*
			 * Considering both board and hole cards a straight have been found.
			 * The only possibility for any opponent is to tie this combination.
			 * If the board cards do not have any degree of freedom both own the
			 * same straight. If the straight must be suited any hole card
			 * preclude an opponent from winning.
			 */
			switch(boardDof) {
			case 0:
				addToTies(nC2(NUMFREECARDS - getNumDofConstraints(2)));
				selectTie();
				break;
			case 1:
				int suitDof = 3;
				
				/*
				 * Find out if the given hole cards are both of the missing rank
				 * at the board. In that case both given hole card ranks are the
				 * same. Therefore the second highest rank is expected to be
				 * null.
				 */
				if(hole.getHighestRank(2) == null)
					suitDof = 2;
				
				addToTies(suitDof * (NUMFREECARDS - getNumDofConstraints(1))
						- numLastStraight);
				addToDofConstraint(1,suitDof);
				selectTie();
				numLastStraight = suitDof;
				break;
			case 2:
				int numCombs = (numSuits - 1) * (numSuits - 1);
				addToTies(numCombs);
				addToDofConstraint(2,numCombs);
				selectTie();
				numLastStraight = numCombs;
				break;
			default:
				new ThisWasBadAndShouldNotHappenException(
						"The degree of freedom have to be between 0 and 2 but was "
								+ boardDof);
			}
		}
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		
		// Indicates if completing a lower implies a higher straight.
		boolean independent = true;
		numLastStraight = 0;
		lastDof = 0;
		
		// Prepare cardset for suited or unsuited straights.
		CardSet boardCopy = board;
		CardSet combinedCopy = combined;
		if(!suited) {
			boardCopy = CardSet.toUnsuited(board);
			combinedCopy = CardSet.toUnsuited(combined);
		}
		
		/*
		 * No straight flush without a flush. In case of an unsuited straight
		 * the result for the flush suit is unpredictable but likewise
		 * unimportant.
		 */
		flushSuit = Flush.getFlushSuit(boardCopy);
		if(flushSuit == null)
			return;
		
		// From A-K-Q-J-T to 5-4-3-2-A
		for(int index = Rank.ACE.index; index >= Rank.FIVE.index; index--) {
			
			/*
			 * A possible straight is independent if completing it does not
			 * imply a higher straight.
			 */
			if(independent)
				count(index,hole,boardCopy,combinedCopy);
			
			/*
			 * The highest card of the current possible straight indicates
			 * independence of the following. If it is a degree of freedom it is
			 * missing on the board. Therefore the next possible straight can
			 * not be subset of the current. But the current highest card may
			 * not be chosen from the set if the degree of freedom for the next
			 * straight flush equals one. On the other hand the highest card of
			 * the current straight may be element of the board cards. In this
			 * case the following straight depends on the same degree of freedom
			 * as the current. If the missing cards are added to the following
			 * possible straight no new combination has been found. In truth it
			 * is the same as the current straight, has already been counted and
			 * can be ignored.
			 */
			independent = !boardCopy.contains(new Card(ranks[index],flushSuit));
		}
	}
}
