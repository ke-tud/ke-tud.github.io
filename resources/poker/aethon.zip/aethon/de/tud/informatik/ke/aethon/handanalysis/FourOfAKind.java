package de.tud.informatik.ke.aethon.handanalysis;

import ca.ualberta.cs.poker.free.dynamics.Card.Rank;

public class FourOfAKind extends Combinatorics {
	
	public FourOfAKind(Outcome outcome, int const1, int const2) {
		super(outcome,const1,const2);
	}
	
	@Override
	protected void countCombs(CardSet hole, CardSet board, CardSet combined) {
		
		// All possible ranks.
		Rank[] ranks = Rank.values();
		
		// From A to 2
		for(int index = Rank.ACE.index; index >= Rank.TWO.index; index--) {
			
			// Count number of determinable cards based on the board cards.
			int boardDof = 4 - board.size(ranks[index]);
			
			/*
			 * If more then two cards are determinable, four of a kind cannot be
			 * completed.
			 */
			if(boardDof > 2)
				continue;
			
			/*
			 * Count number of determinable cards based on the board and given
			 * hole cards.
			 */
			int combDof = 4 - combined.size(ranks[index]);
			
			/*
			 * If the difference is not zero some of the determinable cards are
			 * part of the given hole cards. In case of four of a kind no degree
			 * of freedom must be lost.
			 */
			if(boardDof - combDof == 0) {
				
				/*
				 * If no cards are determinable the board contains four of a
				 * kind. The kickers decide.
				 */
				if(boardDof == 0) {
					HighCard kicker = new HighCard(getOutcome(),
							getNumDofConstraints(1),getNumDofConstraints(2),1);
					kicker.countCombs(hole,null,null);
					
					/*
					 * wins are left out, because a kicker test can only lead to
					 * defeat or tie.
					 */
					if(kicker.getNumTies() > 0)
						selectTie();
					addToTies(kicker.getNumTies());
					addToDefeats(kicker.getNumDefeats());
				} else {
					
					/*
					 * If the degree of freedom equals one there is a card which
					 * can be chosen from the set of unknown cards. Otherwise if
					 * the degree of freedom equals two only one combination
					 * completes the four of a kind.
					 */
					addToDefeats((boardDof == 1) ? NUMFREECARDS
							- getNumDofConstraints(1) : 1);
					increaseDofConstraint(boardDof);
				}
			} else if(combDof == 0) {
				addToWins(nC2(NUMFREECARDS - getNumDofConstraints(2)));
				selectWin();
			}
		}
	}
}
