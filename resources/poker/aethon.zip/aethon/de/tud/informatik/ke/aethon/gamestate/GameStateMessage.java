package de.tud.informatik.ke.aethon.gamestate;

import ca.ualberta.cs.poker.free.dynamics.Card;

public class GameStateMessage {
	
	private static final int HEADER = 0, SEATTAKEN = 1, HANDNUMBER = 2,
			BETTINGSEQUENCE = 3, CARDSEQUENCE = 4;
	public static final char NOACTION = '?';
	private String[] splitMessage;
	
	public GameStateMessage(String currentGameStateMessage) {
		splitMessage = currentGameStateMessage.split(":");
	}
	
	/**
	 * Get a card from the card sequence.
	 */
	private Card[] getCards(String cardSequence) {
		int numCards = cardSequence.length() >> 1;
		Card[] cards = new Card[numCards];
		
		for(int index = 0; index < numCards; index++) {
			int begin = index << 1;
			cards[index] = new Card(cardSequence.substring(begin,begin + 2));
		}
		
		return cards;
	}
	
	private Card[][] getCards(String[] cardSequences) {
		int numPlayers = cardSequences.length;
		Card[][] cards = new Card[numPlayers][2];
		
		for(int index = 0; index < numPlayers; index++) {
			if(cardSequences[index].isEmpty())
				cards[index] = null;
			else
				cards[index] = getCards(cardSequences[index]);
		}
		
		return cards;
	}
	
	public int getHandNumber() {
		return Integer.parseInt(splitMessage[HANDNUMBER]);
	}
	
	public String getHeader() {
		return splitMessage[HEADER];
	}
	
	public Card[][] getHoleCards() {
		int endOfHole = splitMessage[CARDSEQUENCE].indexOf('/');
		if(endOfHole < 0)
			endOfHole = splitMessage[CARDSEQUENCE].length();
		return getCards(splitMessage[CARDSEQUENCE].substring(0,endOfHole)
				.split("\\|",-1));
	}
	
	public Card[] getHoleCards(int seat) {
		int endOfHole = splitMessage[CARDSEQUENCE].indexOf('/');
		if(endOfHole < 0)
			endOfHole = splitMessage[CARDSEQUENCE].length();
		return getCards(splitMessage[CARDSEQUENCE].substring(0,endOfHole)
				.split("\\|",-1)[seat]);
	}
	
	public char getLastAction() {
		int bettingLength = splitMessage[BETTINGSEQUENCE].length();
		
		if(bettingLength == 0)
			return NOACTION;
		
		if(splitMessage[BETTINGSEQUENCE].endsWith("/"))
			return splitMessage[BETTINGSEQUENCE].charAt(bettingLength - 2);
		return splitMessage[BETTINGSEQUENCE].charAt(bettingLength - 1);
	}
	
	public Card[] getLastBoardCards() {
		int endOfBoard = splitMessage[CARDSEQUENCE].lastIndexOf('/');
		return getCards(splitMessage[CARDSEQUENCE].substring(endOfBoard + 1));
	}
	
	public int getNumberOfPlayers() {
		return splitMessage[CARDSEQUENCE].split("\\|",-1).length;
	}
	
	public int getSeatTaken() {
		return Integer.parseInt(splitMessage[SEATTAKEN]);
	}
	
	@Override
	public String toString() {
		String result = "";
		
		for(String segment : splitMessage)
			result += segment + ", ";
		
		return result;
	}
}
