package de.tud.informatik.ke.aethon.common;

import de.tud.informatik.ke.aethon.gamestate.Player;

public abstract class AbstractPot {
	
	protected final int numPlayers;
	protected int[] contributions;
	protected int maxContribution;
	
	public AbstractPot(int numPlayers) {
		this.numPlayers = numPlayers;
		clearPot();
	}
	
	public AbstractPot(AbstractPot pot) {
		numPlayers = pot.numPlayers;
		contributions = new int[numPlayers];
		for(int player = 0; player < numPlayers; player++)
			contributions[player] = pot.contributions[player];
		maxContribution = pot.maxContribution;
	}
	
	/**
	 * Clears the pot. Call this method only if the winners are paid off.
	 */
	public void clearPot() {
		contributions = new int[numPlayers];
		maxContribution = 0;
	}
	
	/**
	 * The <code>player</code> contributes an <code>amount</code> to the
	 * pot.
	 * 
	 * @param player
	 * @param amount
	 */
	public void contribute(Player player, int amount) {
		int seat = player.getSeat();
		contributions[seat] += amount;
		maxContribution = java.lang.Math.max(maxContribution,
				contributions[seat]);
	}
	
	/**
	 * @return the amount to call by the <code>player</code>.
	 */
	public int getAmountToCall(int player) {
		return maxContribution - contributions[player];
	}
	
	/**
	 * @return the total pot size (the sum of all contributions).
	 */
	public double getPotSize() {
		int potsize = 0;
		
		for(int contribution : contributions)
			potsize += contribution;
		return potsize;
	}
	
	/**
	 * Determines the winners and splits the pot.
	 * 
	 * @param players
	 *            are all playing players (including folded).
	 * @param table
	 */
	public abstract void payOffWinners(Player[] players, Table table);
	
	public abstract void splitPot(Player[] players, Table table);
}
