package de.tud.informatik.ke.aethon.gamestate;

public enum Stage {
	SHOWDOWN(null, 0, 0),
	RIVER(SHOWDOWN, 1, Hand.bigBet),
	TURN(RIVER, 1, Hand.bigBet),
	FLOP(TURN, 3, Hand.smallBet),
	PREFLOP(FLOP, 0, Hand.smallBet);
	
	public final Stage next;
	public final int numBoardCards;
	public final int betSize;
	
	private Stage(Stage next, int numBoardCards, int betSize) {
		this.next = next;
		this.numBoardCards = numBoardCards;
		this.betSize = betSize;
	}
}