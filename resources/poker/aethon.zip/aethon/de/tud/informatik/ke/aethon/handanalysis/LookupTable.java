package de.tud.informatik.ke.aethon.handanalysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LookupTable {
	
	private int[] data;
	
	public LookupTable(int[] data) {
		this.data = data.clone();
	}
	
	/**
	 * Creates a lookup table from a file. The file should be loaded less
	 * possible.
	 */
	public LookupTable(File file) {
		loadTableFromFile(file);
	}
	
	private void loadTableFromFile(File file) {
		String[] values = null;
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			values = reader.readLine().split(" ");
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		int numEntries = values.length;
		data = new int[numEntries];
		for(int index = 0; index < numEntries; index++)
			data[index] = Integer.parseInt(values[index]);
	}
	
	public int getEntrie(int index) {
		return data[index];
	}
}
