package de.tud.informatik.ke.aethon.common;

public class Probability {
	
	private double probability;
	private int n;
	private static Probability singleton;
	
	private Probability() {
		probability = 0.0f;
		n = 0;
	}
	
	public static Probability getInstance() {
		if(singleton == null)
			singleton = new Probability();
		return singleton;
	}
	
	public void add(double probability) {
		this.probability += probability;
		n++;
	}
	
	public double get() {
		return (n == 0) ? 0 : probability / n;
	}
	
	public void reset() {
		probability = 0.0;
		n = 0;
	}
}
