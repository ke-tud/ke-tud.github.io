package de.tud.informatik.ke.aethon.movegenerator;

import java.util.Random;

import ca.ualberta.cs.poker.free.dynamics.Card;
import de.tud.informatik.ke.aethon.common.Math;
import de.tud.informatik.ke.aethon.common.SingletonProvider;
import de.tud.informatik.ke.aethon.common.ThisWasBadAndShouldNotHappenException;
import de.tud.informatik.ke.aethon.gamestate.UCTHand;
import de.tud.informatik.ke.aethon.playermodelling.PlayerModel;
import de.tud.informatik.ke.aethon.uct.UCTTree;

/**
 * This class generates Moves to a node. One node corresponds to one
 * MoveGenerator and thus, the node must be given to the constructor.
 * 
 * @author michael
 */
public class MoveGenerator {

	private UCTTree node;

	private long maxNumberOfChildren;

	private Action lastGeneratedAction;

	public MoveGenerator(UCTTree node) {
		this.node = node;
		if (node.getHand().isRandomMove()) {
			maxNumberOfChildren = Math.nCr(node.getHand().getNumDeckCards(),
					node.getHand().getNumCardsToDeal());
		} else {
			maxNumberOfChildren = 3;
			if (!node.getHand().canBet())
				maxNumberOfChildren--;
			if (node.getHand().callIsFree())
				maxNumberOfChildren--;
		}
		lastGeneratedAction = null;
	}

	/**
	 * @return true if all this node's children have already been expanded
	 */
	public boolean allChildrenExpanded() {
		return node.getChildren().size() == maxNumberOfChildren;
	}

	/**
	 * Generates the node's next move which has not yet been generated.
	 * 
	 * @return a new Move
	 */
	public Move generateNextMove() {
		if (node.getHand().isRandomMove()) {
			// Yeah, I know that the following does not neccessarily terminate.
			// Whatever. I hope it does.
			int i = 0;
			while (true) {
				CardDealing randomDealing = new CardDealing(
						drawRandomCardsFromDeck(node.getHand()));
				if (!node.getMoves().contains(randomDealing))
					return randomDealing;
				if (i++ == 200)
					return randomDealing;
			}
		} else {
			// The moves MUST be generated in the order Fold, Call, Raise.
			// Otherwise using lastGeneratedAction to find out, which one is the
			// next to be generated, doesn't work.

			// if (lastGeneratedAction == null) {
			// if (!node.getHand().callIsFree())
			// lastGeneratedAction = Action.FOLD;
			// else
			// lastGeneratedAction = Action.CALL;
			// } else if (lastGeneratedAction == Action.FOLD) {
			// lastGeneratedAction = Action.CALL;
			// } else if (lastGeneratedAction == Action.CALL
			// && node.getHand().canBet()) {
			// lastGeneratedAction = Action.RAISE;
			// } else {
			// throw new ThisWasBadAndShouldNotHappenException(
			// "generateNextMove has been called, although all moves have
			// already been generated. The node where this occured is:\n"
			// + this.node.toString());
			// }

			lastGeneratedAction = nextAction(lastGeneratedAction);
			return lastGeneratedAction;
		}
	}

	private Action nextAction(Action lastAction) {
		if (lastAction == null)
			return node.getHand().callIsFree() ? Action.CALL : Action.FOLD;
		switch (lastAction) {
		case FOLD:
			return Action.CALL;
		case CALL:
			if (node.getHand().canBet())
				return Action.RAISE;
		default:
			throw new ThisWasBadAndShouldNotHappenException(
					"generateNextMove has been called, although all moves have already been generated. The node where this occured is:\n"
							+ this.node.toString());
		}
	}

	/**
	 * Generates a random Move for the given GameState.
	 * 
	 * @param hand
	 *            The Hand for which a new Move shall be generated.
	 * @return the generated Move
	 */
	public static Move generateRandomMove(UCTHand hand, PlayerModel player) {
		Random random = SingletonProvider.getInstance().getRandom();
		if (hand.isRandomMove()) {
			return new CardDealing(drawRandomCardsFromDeck(hand));
		} else {
			double action = random.nextDouble();
			final double foldingProbability = player.getActionPropability(hand
					.getCurrentStage())[0], callingProbability = player
					.getActionPropability(hand.getCurrentStage())[1];
			if (action < foldingProbability && !hand.callIsFree()) {
				return Action.FOLD;
			} else if (action < foldingProbability + callingProbability) {
				return Action.CALL;
			} else {
				if (hand.canBet()) {
					return Action.RAISE;
				} else {
					if (random.nextBoolean() || hand.callIsFree()) {
						return Action.CALL;
					} else {
						return Action.FOLD;
					}
				}
			}
		}
	}

	private static Card[] drawRandomCardsFromDeck(UCTHand hand) {
		int number = hand.getNumCardsToDeal();
		int[] indices = new int[number];
		for (int cardIndex = 0; cardIndex < number; cardIndex++) {
			boolean similarToPreviousCards;
			do {
				indices[cardIndex] = SingletonProvider.getInstance()
						.getRandom().nextInt(hand.getNumDeckCards());
				similarToPreviousCards = false;
				for (int j = 0; j < cardIndex; j++)
					if (indices[cardIndex] == indices[j])
						similarToPreviousCards = true;
			} while (similarToPreviousCards);
		}
		Card[] cards = new Card[number];
		for (int i = 0; i < number; i++)
			cards[i] = hand.getCardFromDeck(indices[i]);
		return cards;
	}
}
