package de.tud.informatik.ke.aethon.uct;

import java.util.Vector;

import de.tud.informatik.ke.aethon.common.SingletonProvider;
import de.tud.informatik.ke.aethon.gamestate.UCTHand;
import de.tud.informatik.ke.aethon.movegenerator.Action;
import de.tud.informatik.ke.aethon.movegenerator.Move;
import de.tud.informatik.ke.aethon.movegenerator.MoveGenerator;
import de.tud.informatik.ke.aethon.playermodelling.PlayerModel;

public class UCT {
	
	/**
	 * The root node from where the algorithm computes a best action.
	 */
	private UCTTree root;
	
	// TODO experiment with this constant to get best performance
	/**
	 * The constants from the UCT selection formula.
	 */
	public static final double constantForVariance = 6.0;
	
	public static final double constantForDerivationSummand = 0.618033989;
	
	public UCT(UCTHand hand, PlayerModel[] players) {
		SingletonProvider.getInstance().setPlayerModel(players);
		clearTree(hand);
	}
	
	/**
	 * performs the algorithm
	 * 
	 * @param milliseconds
	 *            time available to compute
	 */
	public void run(long milliseconds) {
		long startTime = System.currentTimeMillis();
		int simCounter = 0;
		final int numSimsToCheckTime = 100;
		while(true) {
			// if(simCounter<20)
			// System.out.println(this.toString());
			simCounter++;
			if(simCounter == numSimsToCheckTime) {
				simCounter = 0;
				if(System.currentTimeMillis() > startTime + milliseconds)
					return;
			}
			UCTTree nodeToExpand = select(root);
			UCTTree nodeToSimulate = expand(nodeToExpand);
			double[] value = simulate(nodeToSimulate);
			try {
				backpropagate(nodeToSimulate,value);
			} catch(NullPointerException e) {
				System.err.println(this);
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * @return the action that has been evaluated as best so far
	 */
	public Action getResult() {
		// does not work if the first layer is non-deterministic but I
		// think the non-deterministic case should never occur.
		int maxVisits = -1;
		Vector<UCTTree> children = root.getChildren();
		Vector<Move> moves = root.getMoves();
		Move bestMove = null;
		
		for(int i = 0; i < children.size(); i++) {
			int numSimulations = children.elementAt(i).getNumberOfSimulations();
			
			// XXX
			// System.out.println("STAGE: " + root.getHand().getCurrentStage());
			// if (root.getHand().isOurTurn())
			// System.out.println("IT IS OUR TURN ("
			// + root.getHand().getSeatToAct() + ")");
			// else
			// System.out.println("Seat " + root.getHand().getSeatToAct()
			// + " on the turn.");
			// System.out.println("Get result of " + moves.elementAt(i) + ":");
			// System.out.println(children.elementAt(i).getShortInfo());
			
			if(numSimulations > maxVisits) {
				maxVisits = numSimulations;
				bestMove = moves.elementAt(i);
			}
		}
		
		try {
			return (Action)bestMove;
		} catch(ClassCastException e) {
			System.err.println(root);
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * @param node
	 *            the root where the selection starts
	 * @return the node where the tree shall be expanded
	 */
	private UCTTree select(UCTTree node) {
		UCTHand hand = node.getHand();
		node.incNumberOfSimulations();
		if(!node.getMoveGenerator().allChildrenExpanded()
				|| hand.weHaveFolded() || hand.isHandOver())
			return node;
		if(!hand.isRandomMove()) {
			
			UCTTree bestChild = null;
			double bestValue = Double.NEGATIVE_INFINITY;
			for(UCTTree child : node.getChildren()) {
				double value = child.getUCTValue();
				if(value > bestValue) {
					bestValue = value;
					bestChild = child;
				}
			}
			
			if(bestChild == null) {
				String message = "No best child has been selected. The node that caused this was:\n\n";
				message += node.toString() + "\n\n";
				message += "The values of its children are:\n";
				for(UCTTree child : node.getChildren())
					message += child.getShortInfo() + "\n\n";
				throw new NullPointerException(message);
			}
			return select(bestChild);
		} else {
			return select(node.getChildren().elementAt(
					SingletonProvider.getInstance().getRandom().nextInt(
							node.getChildren().size())));
		}
	}
	
	/**
	 * Expands the tree at a given node and returns a child that shall be
	 * simulated. If the node is either a terminal node or we have already
	 * folded, no expansion is made and the node itself is being returned.
	 * 
	 * @param node
	 *            the node that shall be expanded
	 * @return the node that shall be simulated
	 */
	private UCTTree expand(UCTTree node) {
		if(node.getHand().weHaveFolded() || node.getHand().isHandOver())
			return node;
		UCTTree newChild = node.expandNewChild();
		newChild.incNumberOfSimulations();
		return newChild;
	}
	
	/**
	 * @param node
	 *            the node where the simulation starts
	 * @return the value of the simulation for each player
	 */
	private double[] simulate(UCTTree node) {
		UCTHand copy = new UCTHand(node.getHand());
		while(!(copy.isHandOver() || copy.weHaveFolded())) {
			Move move = MoveGenerator.generateRandomMove(copy,SingletonProvider
					.getInstance().getPlayer(copy.getSeatToAct()));
			copy.executeMove(move);
		}
		return trickOrTreat(copy.getValue(copy.weHaveFolded()));
	}
	
	private double[] trickOrTreat(double[] values) {
		final double magic = 1.2;
		double[] temp = new double[values.length];
		for(int i = 0; i < values.length; i++) {
			temp[i] = values[i];
			if(temp[i] > 0)
				temp[i] *= magic;
		}
		return temp;
		
	}
	
	/**
	 * Backpropagates the value, that has been determined by the simulation,
	 * from the leaf (including the leaf itself, too) up in the tree to the
	 * root.
	 * 
	 * @param node
	 * @param values
	 *            the values (for each player) that have been determined by the
	 *            simulation
	 */
	private void backpropagate(UCTTree node, double[] values) {
		if(node == null)
			System.err
					.println("backpropagate() was told to backpropagate values through a null node.");
		
		if(node.getParent() == null) {
			return;
		} else {
			
			node.updateValues(values);
			
			// Try to backpropagate the value
			try {
				backpropagate(node.getParent(),values);
			} catch(NullPointerException e) {
				System.err.println(this);
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Throws away the whole UCTTree and creates a new one based on the given
	 * UCTHand.
	 * 
	 * @param newHand
	 */
	public void clearTree(UCTHand newHand) {
		root = new UCTTree(newHand,null);
	}
	
	/**
	 * Descends into the subtree, that represents the given action and throws
	 * away the other subtrees.
	 * 
	 * @param action
	 * @throws Exception
	 */
	public void descendIntoSubtree(Action action) {
		// feed data to the player model
		Action predicted = getResult();
		
		if(predicted != null)
			SingletonProvider.getInstance().getPlayer(
					root.getHand().getSeatToAct()).update(
					root.getHand().getCurrentStage(),predicted,action);
		
		Vector<UCTTree> children = root.getChildren();
		Vector<Move> moves = root.getMoves();
		for(int i = 0; i < moves.size(); i++) {
			if(moves.elementAt(i) == action) {
				root = children.elementAt(i);
				// delete the reference to the old root, so that the garbage
				// collection can sweep away all the other subtrees
				root.setParent(null);
				return;
			}
		}
		// Child has not been expanded yet.
		root = root.expandNewChild(action);
		root.setParent(null);
	}
	
	@Override
	public String toString() {
		return treeToString(root,"");
	}
	
	private String treeToString(UCTTree root, String indent) {
		if(root == null)
			return "";
		
		String[] lines = root.toString().split("\n");
		String info = "";
		for(String line : lines)
			info += indent + line + "\n";
		indent += "    ";
		
		for(UCTTree node : root.getChildren())
			info += treeToString(node,indent);
		
		return info;
	}
}
