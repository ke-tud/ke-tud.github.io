package de.tud.informatik.ke.aethon.movegenerator;


/**
 * A move is a move in the game tree from a node to one of it's child nodes. It
 * can be either an {@link Action} or a simulated dealing of cards to a player
 * whose cards are not yet known. In the future this could also be a bucket of
 * Actions or random actions.
 * 
 * @author michael
 * @see Action
 * @see CardDealing
 */
public interface Move {
	// Just a definition for a common interface of moves. 
}
