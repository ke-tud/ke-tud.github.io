package de.tud.informatik.ke.aethon.playermodelling;

import de.tud.informatik.ke.aethon.gamestate.Player;
import de.tud.informatik.ke.aethon.gamestate.Stage;
import de.tud.informatik.ke.aethon.movegenerator.Action;

/**
 * <p>
 * {@link SimplePlayer} is a simple implementation of a player model. It
 * predicts the deviation to the action which UCT recommended for a player. For
 * any recommendation of UCT exists a deviation probability to any other Action.
 * </p>
 * <p>
 * Take the actions fold, call and raise for example. A deviation matrix could
 * be: <table>
 * <tr>
 * <th></th>
 * <th>FOLD</th>
 * <th>CALL</th>
 * <th>RAISE</th>
 * </tr>
 * <tr>
 * <th>FOLD</th>
 * <td>5</td>
 * <td>1</td>
 * <td>0</td>
 * </tr>
 * <tr>
 * <th>CALL</th>
 * <td>2</td>
 * <td>10</td>
 * <td>5</td>
 * </tr>
 * <tr>
 * <th>RAISE</th>
 * <td>0</td>
 * <td>10</td>
 * <td>5</td>
 * </tr>
 * </table>
 * </p>
 * <p>
 * The matrix contains the number of performed for a predicted action. Rows are
 * predicted and columns performed actions. Therefore if UCT predicts a fold the
 * model tells us to reckon that the player in truth chooses for five of six
 * cases fold and one of six cases call.
 * </p>
 * <p>
 * {@link SimplePlayer} takes account of tactical changes of the opponent. This
 * is managed by a memory. If to many actions have been performed. The stats
 * behaves like the mean value of all observed action deviations is now
 * collapsed to one action. Therefore a mean value is calculated and the number
 * of values in mind is reduced to the half.
 * </p>
 * 
 * @author Marian
 */
public class SimplePlayer extends Player implements PlayerModel {
	
	private static final int NUMSTAGES = Stage.values().length;
	public static final int NUMACTIONS = Action.values().length;
	private static final int DEFAULTMEMORY = 50;
	
	private int[][] numActionsInMind;
	private int memory;
	
	private double[][][] temper;
	double[][][] deviationProp;
	double[][] actionProp;
	
	/**
	 * Creates a simple player with a specified memory.
	 * 
	 * @param seat
	 * @param name
	 * @param memory
	 *            is the number of samples which are memorised in detail.
	 */
	public SimplePlayer(int seat, String name, int memory) {
		super(seat,name);
		
		numActionsInMind = new int[NUMSTAGES][NUMACTIONS];
		this.memory = memory;
		temper = new double[NUMSTAGES][NUMACTIONS][NUMACTIONS];
		deviationProp = new double[NUMSTAGES][NUMACTIONS][NUMACTIONS];
		actionProp = new double[NUMSTAGES][NUMACTIONS];
		for(int stage = 0; stage < NUMSTAGES; stage++)
			for(int ii = 0; ii < NUMACTIONS; ii++) {
				temper[stage][ii][ii] = 0.5f * memory;
				deviationProp[stage][ii][ii] = 1.0f;
				actionProp[stage][ii] = deviationProp[stage][ii][ii];
				numActionsInMind[stage][ii] = memory >> 1;
			}
	}
	
	/**
	 * Creates a simple player with a default memory.
	 * 
	 * @param seat
	 * @param name
	 */
	public SimplePlayer(int seat, String name) {
		this(seat,name,DEFAULTMEMORY);
	}
	
	/**
	 * <p>
	 * The behaviour of a player is updated. The update depends on the
	 * <code>stage</code> and the <code>predicted</code> and
	 * <code>performed</code> action. If the player is able to keep the action
	 * history in mind, the new value is directly updated. That is increasing
	 * the number of the performed for the predicted action.
	 * </p>
	 * <p>
	 * If there are too many actions to memorise the sum of performed actions is
	 * halved for any predicted action in the current stage. Therefore the old
	 * observations are less important then the new ones. If the tactic of the
	 * player stays nearly the same, no big changes should be observed in the
	 * rows. Otherwise the rows adjust to the new behaviour of the player.
	 * </p>
	 */
	@Override
	public void update(Stage stage, Action predicted, Action performed) {
		int currentStage = stage.ordinal();
		int predictedIndex = predicted.ordinal();
		
		// Remember current temper
		temper[currentStage][predictedIndex][performed.ordinal()]++;
		numActionsInMind[currentStage][predictedIndex]++;
		
		// Forget details about the past
		if(numActionsInMind[currentStage][predictedIndex] == memory) {
			for(int j = 0; j < NUMACTIONS; j++)
				temper[currentStage][predictedIndex][j] *= 0.5f;
			numActionsInMind[currentStage][predictedIndex] = memory >> 1;
		}
			
		double[] normalisation = new double[NUMACTIONS];
		for(int index = 0; index < NUMACTIONS; index++)
			normalisation[index] = 1.0f / numActionsInMind[currentStage][index];
		
		// Calculate propabilities
		for(int expectedIndex = 0; expectedIndex < NUMACTIONS; expectedIndex++)
			for(int actionIndex = 0; actionIndex < NUMACTIONS; actionIndex++)
				deviationProp[currentStage][expectedIndex][actionIndex] = normalisation[expectedIndex]
						* temper[currentStage][expectedIndex][actionIndex];
		
		// XXX
		// System.out.println("SEAT: " + seat);
		// String matrix = "";
		// for(int i = 0; i < NUMACTIONS; i++) {
		// for(int s = 0; s < NUMSTAGES; s++) {
		// for(int j = 0; j < NUMACTIONS; j++) {
		// matrix += "\t" + Math.round(100 * deviationProp[s][i][j])
		// * 0.01;
		// }
		// matrix += "\t";
		// }
		// matrix += "\n";
		// }
		// System.out.println(matrix);
		
		for(int col = 0; col < NUMACTIONS; col++) {
			actionProp[currentStage][col] = 0.0f;
			for(int row = 0; row < NUMACTIONS; row++)
				actionProp[currentStage][col] += deviationProp[currentStage][row][col];
			actionProp[currentStage][col] /= NUMACTIONS;
		}
	}
	
	/**
	 * <p>
	 * This method calculates the probabilities of deviation for an
	 * <code>expected</code> action. According to the upper example the
	 * propabilities for a expected fold would resolve to: <table>
	 * <tr>
	 * <tr>
	 * <th></th>
	 * <th>FOLD</th>
	 * <th>CALL</th>
	 * <th>RAISE</th>
	 * </tr>
	 * <th>FOLD</th>
	 * <td>0.833</td>
	 * <td>0.166</td>
	 * <td>0.0</td>
	 * </tr>
	 * </table>
	 * </p>
	 */
	@Override
	public double getDeviationPropability(Stage stage, Action predicted,
			Action expected) {
		return deviationProp[stage.ordinal()][predicted.ordinal()][expected
				.ordinal()];
	}
	
	/**
	 * <p>
	 * This method calculates the mean probabilities of deviation for all
	 * possible actions. According to the upper example the propabilities would
	 * resolve to: <table>
	 * <tr>
	 * <tr>
	 * <th>FOLD</th>
	 * <th>CALL</th>
	 * <th>RAISE</th>
	 * </tr>
	 * <td>0.184</td>
	 * <td>0.553</td>
	 * <td>0.263</td>
	 * </tr>
	 * </table>
	 * </p>
	 * <p>
	 * The propability for fold for example describes the number of folds in
	 * relation to the number of performed actions.
	 * </p>
	 */
	@Override
	public double[] getActionPropability(Stage stage) {
		return actionProp[stage.ordinal()];
	}
	
}
