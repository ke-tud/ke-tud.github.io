package de.tud.informatik.ke.aethon.common;

/**
 * Provides us with a "n choose r" function that I missed in java.lang.Math
 * 
 * @author michael
 * @author marian
 */
public class Math {
	
	/**
	 * This function calculates n choose r. It makes sure that no extension is
	 * larger then the outcome. Therefore any overflow can only be avoided by
	 * allocating more bits for the result.
	 * 
	 * @param n
	 * @param r
	 * @return the number of combinations to choose r from n elements?
	 */
	public static long nCr(int n, int r) {
		r = java.lang.Math.min(r,n - r);
		
		if(r < 0)
			throw new IllegalArgumentException("nCr(" + n + "," + r
					+ ") and nCr(" + n + "," + (n - r) + ") are undefined.");
		
		long[] binomials = new long[r + 1];
		int length = 1;
		
		binomials[0] = 1;
		while(length <= r) {
			binomials[length] = 1;
			for(int i = length - 1; i >= 1; i--)
				binomials[i] += binomials[i - 1];
			length++;
		}
		
		for(int m = length; m <= n; m++)
			for(int i = length - 1; i >= 1; i--)
				binomials[i] += binomials[i - 1];
		
		return binomials[r];
	}
}
