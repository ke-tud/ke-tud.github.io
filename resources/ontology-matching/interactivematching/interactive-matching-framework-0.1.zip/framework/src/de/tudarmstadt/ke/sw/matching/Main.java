package de.tudarmstadt.ke.sw.matching;

import java.io.File;
import java.net.URI;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.management.relation.Relation;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentProcess;
import org.semanticweb.owl.align.Cell;

import de.tudarmstadt.ke.sw.matching.benchmarking.Benchmark;
import de.tudarmstadt.ke.sw.matching.benchmarking.BenchmarkCase;
import de.tudarmstadt.ke.sw.matching.benchmarking.ConferenceBenchmark;
import de.tudarmstadt.ke.sw.matching.interactivematching.InteractiveAlignmentProcess;
import de.tudarmstadt.ke.sw.matching.interactivematching.impl.DummyAlignmentProcess;
import de.tudarmstadt.ke.sw.matching.interactivematching.impl.InteractiveEvaluator;
import de.tudarmstadt.ke.sw.matching.interactivematching.impl.InteractiveMatcherSelection;
import de.tudarmstadt.ke.sw.matching.interactivematching.impl.InteractiveThreshold;
import de.tudarmstadt.ke.sw.matching.interactivematching.impl.SimpleCell;

import fr.inrialpes.exmo.align.impl.URICell;
import fr.inrialpes.exmo.align.impl.rel.EquivRelation;

public class Main {
    /**
     * @param args
     * @throws AlignmentException
     */
    public static void main(String[] args) throws AlignmentException {

        Benchmark conference = new ConferenceBenchmark();
        for (BenchmarkCase track : conference.getBenchmarkCases()) {
            // BenchmarkCase track = conference.getBenchmarkCases().get(0);

            InteractiveAlignmentProcess iap = getInteractiveMatcherSelection(track);
            //InteractiveAlignmentProcess iap = getInteractiveThresholdAroma(track);
            InteractiveEvaluator eval = new InteractiveEvaluator(
                    track.getRefAlign(), iap);
            eval.eval();
        }
    }

    private static final String wesee = "./benchmarks/results/all-conference-alignments-wesee/";

    private static InteractiveAlignmentProcess getInteractiveMatcherSelection(BenchmarkCase track) throws AlignmentException{
        List<Alignment> list = new LinkedList<Alignment>();
        //a priori bester matcher at pos 0 
        list.add(getConferenceAlignment(track.getRefAlign(), "LogMap"));
        list.add(getConferenceAlignment(track.getRefAlign(), "CODI"));
        list.add(getConferenceAlignment(track.getRefAlign(), "Optima"));                        
        return new InteractiveMatcherSelection(list);
    }
    
    private static InteractiveAlignmentProcess getInteractiveThreshold(
            BenchmarkCase track) throws AlignmentException {
        return new InteractiveThreshold(0.51, getAllConferenceAlignment(
                track.getRefAlign(), wesee));
    }

    private static final String maas = "./benchmarks/results/conference-alignments/MaasMatch/";

    private static InteractiveAlignmentProcess getInteractiveThresholdMaas(
            BenchmarkCase track) throws AlignmentException {
        return new InteractiveThreshold(0.51, getAllConferenceAlignment(
                track.getRefAlign(), maas));
    }

    private static final String aroma = "./benchmarks/results/conference-alignments/AROMA/";

    private static InteractiveAlignmentProcess getInteractiveThresholdAroma(
            BenchmarkCase track) throws AlignmentException {
        return new InteractiveThreshold(0.51, getAllConferenceAlignment(
                track.getRefAlign(), aroma));
    }

    private static final String base1 = "./benchmarks/results/conference-alignments/";

    private static Alignment getConferenceAlignment(URI refAlign, String matcher)
            throws AlignmentException {
        AlignmentProcess process = getAlignmentProcess(new File(base1 + matcher
                + "/" + new File(refAlign).getName()));
        process.align(null, null);
        return process;
    }

    private static AlignmentProcess getAllConferenceAlignment(URI refAlign,
            String base) throws AlignmentException {
        AlignmentProcess process = getAlignmentProcess(new File(base
                + new File(refAlign).getName()));
        process.align(null, null);
        return process;
    }

    private static AlignmentProcess getAlignmentProcess(File file) {
        if (file.exists() == false)
            return null;
        return new DummyAlignmentProcess(file.toURI());
    }
}
