package de.tudarmstadt.ke.sw.matching.interactivematching.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

import de.tudarmstadt.ke.sw.matching.interactivematching.InteractiveAlignmentProcess;
import de.tudarmstadt.ke.sw.matching.interactivematching.Oracle;
import fr.inrialpes.exmo.align.impl.BasicAlignment;

/**
 * Sets the best threshold for one matcher for one track.
 * @author Sven Hertling
 *
 */
public class InteractiveThreshold extends BasicAlignment implements
        InteractiveAlignmentProcess {

    /**
     * Stored oracle.
     */
    private Oracle oracle;
    /**
     * The threshold for this matcher and track.
     */
    private double threshold;
    /**
     * The list of all cells for this matcher.
     */
    private List<Cell> list;


    /**
     * The basic align method which calls the current approach.
     * @param arg0 arg0
     * @param arg1 arg1
     * @throws AlignmentException Exception
     */
    public void align(Alignment arg0, Properties arg1)
            throws AlignmentException {
        // binarySearch();
        fmeasureBased();
    }

    /**
     * The constructor for InteractiveThreshold which gets
     * an initial threshold and an alignment.
     * @param initialThreshold initial threshold
     * @param alignment alignment from the matcher
     */
    public InteractiveThreshold(double initialThreshold, Alignment alignment) {
        super();
        this.threshold = initialThreshold;
        this.list = new LinkedList<Cell>();

        for (Cell cell : alignment) {
            list.add(cell);
        }

        Collections.sort(list, new CellComparator());
        Collections.reverse(list);
    }

    /**
     * Binary search in the list of all cells.
     * @throws AlignmentException Exception
     */
    private void binarySearch() throws AlignmentException {
        int min = 0;
        int max = list.size();

        while (min <= max) {
            final int mid = min + ((max - min) / 2);
            System.out.println("NEU:");

            Cell cellOne = list.get(mid);
            Helper.printCell(cellOne);

            Cell cell = this.oracle.askOracle(cellOne);
            Helper.printCell(cell);
            if (cell.getRelation().getRelation().equals("=")) {
                // cell is correct -> threshold lower
                max = mid + 1;
            } else {
                // cell is false -> threshold higher
                min = mid - 1;
            }
            setAlignment(min);
            // Helper.print(this);
        }
    }

    /**
     * F-measure based search over the list of cells.
     * @throws AlignmentException Exception
     */
    private void fmeasureBased() throws AlignmentException {
      
        List<CellProcessing> processing = new LinkedList<CellProcessing>();
        for (Cell c : this.list) {
            processing.add(CellProcessing.Unprocessed);
        }
        setAlignment(list.size());

        int window = 2;// can be 0,1,2

        // initial
        processWindow(processing, 0, window);
        processWindow(processing, this.list.size() - 1, window);
        processWindow(processing, this.list.size() / 2, window);

        int upper = 0;
        int lower = 0;

        while (upper != -1 || lower != -1) {
            int currentBest = getBestIndex(processing);
            setAlignment(currentBest + 1);

            upper = getUpperBound(processing, currentBest, window);
            if (upper != -1){
                processWindow(processing, upper, window);
            }
            lower = getLowerBound(processing, currentBest, window);
            if (lower != -1){
                processWindow(processing, lower, window);
            }
        }
    }

    /**
     * Gets an upper bound of the current (start) index of the list.
     * @param process how many cells are currently processed
     * @param start the start index to search from
     * @param window the window size
     * @return the index of the upperbound
     */
    private int getUpperBound(List<CellProcessing> process, int start,
            int window) {
        int upperbound = start + window + 1;
        if (upperbound >= process.size()) {
            return -1;
        }
        int inbetween = 0;
        while (process.get(upperbound) == CellProcessing.Unprocessed) {
            inbetween++;
            upperbound++;
        }
        if (inbetween == 0) {
            return -1;
        }
        if (inbetween == 1) {
            return start + window + 1;
        }
        return start + window + (inbetween / 2);
    }

    /**
     * Gets an lower bound of the current (start) index of the list.
     * @param process how many cells are currently processed
     * @param start the start index to search from
     * @param window the window size
     * @return the index of the lower bound
     */
    private int getLowerBound(List<CellProcessing> process, int start,
            int window) {
        int lowerbound = start - window - 1;
        if (lowerbound < 0) {
            return -1;
        }
        int inbetween = 0;
        while (process.get(lowerbound) == CellProcessing.Unprocessed) {
            inbetween++;
            lowerbound--;
        }
        if (inbetween == 0) {
            return -1;
        }
        if (inbetween == 1) {
            return start - window - 1;
        }
        return start - window - (inbetween / 2);
    }

    /**
     * Get the current best index of the list of cells.
     * Calculates the F-measure of every position.
     * @param process the current processed cells
     * @return the current best index
     */
    private int getBestIndex(List<CellProcessing> process) {
        
        double maxfmeasure = 0.0;
        int maxindex = 0;

        int expected = 0;
        for (int i = 0; i < process.size(); i++) {
            if (process.get(i) == CellProcessing.correct) {
                expected++;
            }
        }

        int correct = 0;
        int found = 0;
        for (int i = 0; i < process.size(); i++) {
            if (process.get(i) == CellProcessing.correct) {
                found++;
                correct++;
            } else if (process.get(i) == CellProcessing.incorrect) {
                found++;
            }

            if (process.get(i) != CellProcessing.Unprocessed) {
                // compute fmeasue
                double precision = (double) correct / (double) found;
                double recall = (double) correct / (double) expected;
                double fmeasure = 2 * precision * recall / (precision + recall);

                if (fmeasure > maxfmeasure) {
                    maxfmeasure = fmeasure;
                    maxindex = i;
                }
            }
        }
        return maxindex;
    }

    /**
     * Processes a whole window.
     * @param process how many cells are currently processed
     * @param j the current start index
     * @param window the current window size
     * @throws AlignmentException Exception
     */
    private void processWindow(List<CellProcessing> process, int j, int window)
            throws AlignmentException {
        processCell(j, process);
        for (int i = 1; i < window + 1; i++) {
            processCell(j + i, process);
            processCell(j - i, process);
        }
    }

    /**
     * Process one cell.
     * @param i process the i. cell.
     * @param process the list of all cell with their processing status.
     * @throws AlignmentException exception
     */
    private void processCell(int i, List<CellProcessing> process)
            throws AlignmentException {
        if (i >= process.size() || i < 0) {
            return;
        }
        if (process.get(i) != CellProcessing.Unprocessed) {
            return;
        }
        Cell cell = this.oracle.askOracle(this.list.get(i));
        if (cell.getRelation().getRelation().equals("=")) {
            process.set(i, CellProcessing.correct);
        } else {
            process.set(i, CellProcessing.incorrect);
        }
    }

    /**
     * Sets the oracle for this class.
     */
    public void setOracle(Oracle oracle) {
        this.oracle = oracle;
    }

    /**
     * Sets the alignment with all cells above the min index.
     * @param min the index to start
     */
    private void setAlignment(int min) {

        this.deleteAllCells();

        for (int i = 0; i < min; i++) {
            Cell c = list.get(i);
            try {
                this.addAlignCell(c.getObject1(), c.getObject2(), c
                        .getRelation().getRelation().toString(),
                        c.getStrength());
            } catch (AlignmentException e) {
                e.printStackTrace();
            }
        }
    }

}

/**
 * A helper for comparing Cells.
 * @author Sven Hertling
 */
class CellComparator implements Comparator<Cell> {

    // Returns a negative integer, zero, or a positive integer as the first
    // argument is less than, equal to, or greater than the second.
    @Override
    public int compare(Cell o1, Cell o2) {
        if (o1.getStrength() < o2.getStrength()) {
            return -1;
        } else if (o1.getStrength() > o2.getStrength()) {
            return 1;
        } else {
            return 0;
        }
    }

}
