package de.tudarmstadt.ke.sw.matching.interactivematching.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

import de.tudarmstadt.ke.sw.matching.interactivematching.InteractiveAlignmentProcess;
import de.tudarmstadt.ke.sw.matching.interactivematching.Oracle;

import fr.inrialpes.exmo.align.impl.BasicAlignment;
import fr.inrialpes.exmo.align.impl.URIAlignment;
import fr.inrialpes.exmo.align.impl.URICell;
import fr.inrialpes.exmo.align.impl.eval.PRecEvaluator;
import fr.inrialpes.exmo.align.impl.rel.EquivRelation;

/**
 * A implementation of InteractiveAlignmentProcess.
 * It searches the best matcher for one track.
 * @author Sven Hertling
 *
 */
public class InteractiveMatcherSelection extends BasicAlignment implements
        InteractiveAlignmentProcess {

    /**
     * The stored oracle.
     */
    private Oracle oracle;
    /**
     * all alignments from all matchers.
     */
    private List<Alignment> alignments;

    /**
     * The constructor which gets alignments and not an process.
     *
     * @param _alignments The alignment from all matchers
     * @throws AlignmentException Exception
     */
    public InteractiveMatcherSelection(List<Alignment> _alignments)
            throws AlignmentException {
        // alignments = _alignments;// does not work
        // change to uri alignments
        this.alignments = new LinkedList<Alignment>();
        for (Alignment a : _alignments) {
            URIAlignment uri = new URIAlignment();
            for (Cell c : a) {
                uri.addAlignCell(c.getObject1AsURI(), c.getObject2AsURI(), c
                        .getRelation().getRelation(), c.getStrength());
            }
            this.alignments.add(uri);
        }

    }

    /**
     * The called method which directs to the used approach.
     */
    public void align(Alignment arg0, Properties arg1)
            throws AlignmentException {
        // Annahme: alle matcher haben nur = als relation und nicht !=
        //usePoints();
        useFmeasure();
    }

    /**
     * Use points to find out which matcher is the best.
     * @throws AlignmentException Exception
     */
    private void usePoints() throws AlignmentException {
        setAlignment(0);

        List<Integer> bestAlignment = new LinkedList<Integer>();
        for (int i = 0; i < this.alignments.size(); i++) {
            bestAlignment.add(0);
        }

        List<Cell> cells = getGoodCells();

        for (Cell c : cells) {

            Cell cell = this.oracle.askOracle(c);
            if (cell.getRelation().getRelation().equals("=")) {
                for (int i = 0; i < this.alignments.size(); i++) {
                    if (isCellContained(cell, this.alignments.get(i))) {
                        bestAlignment.set(i, bestAlignment.get(i) + 1);
                    }
                }
            }
            /*
             * System.out.println(c.getObject1AsURI() + "\t" +
             * c.getObject2AsURI()); for(int i = 0; i < this.alignments.size();
             * i++){ System.out.println(bestAlignment.get(i)); }
             */

            // getmaximum
            int value = Integer.MIN_VALUE;
            int position = 0;
            for (int i = 0; i < this.alignments.size(); i++) {
                if (bestAlignment.get(i) > value) {
                    value = bestAlignment.get(i);
                    position = i;
                }
            }
            setAlignment(position);
        }

    }

    /**
     * Use f-measure to find out which matcher is the best.
     * @throws AlignmentException exception
     */
    private void useFmeasure() throws AlignmentException {
        /*
         * for(int i = 0; i < this.alignments.size(); i++){
         * System.out.println("Matcher " + i + ": ");
         * System.out.println(Helper.getString(alignments.get(i))); }
         */
        setAlignment(0);

        Alignment partialReferenceAlignment = new URIAlignment();
        List<Alignment> partialMatcherAlignments = new LinkedList<Alignment>();
        for (int i = 0; i < this.alignments.size(); i++) {
            partialMatcherAlignments.add(new URIAlignment());
        }

        List<Cell> cells = getGoodCells();

        for (Cell c : cells) {
            Cell cell = this.oracle.askOracle(c);
            if (cell.getRelation().getRelation().equals("=")){
                addCell(partialReferenceAlignment, cell);
            }
            for (int i = 0; i < this.alignments.size(); i++) {
                if (isCellContained(cell, this.alignments.get(i))) {
                    partialMatcherAlignments.get(i).addAlignCell(
                            cell.getObject1AsURI(), cell.getObject2AsURI(),
                            "=", 1.0);
                }
            }

            // getmaximum
            double fmeasure = 0;
            int position = 0;
            for (int i = 0; i < this.alignments.size(); i++) {
                PRecEvaluator eval = new PRecEvaluator(
                        partialReferenceAlignment,
                        partialMatcherAlignments.get(i));
                eval.eval(null);
                // System.out.println(eval.getFmeasure());
                if (eval.getFmeasure() > fmeasure) {
                    fmeasure = eval.getFmeasure();
                    position = i;
                }
            }
            setAlignment(position);
        }
    }

    /**
     * Add one cell to the alignment.
     * @param a alignment to which the cell is added
     * @param c the cell to add to the alignment
     * @throws AlignmentException Exception
     */
    private void addCell(Alignment a, Cell c) throws AlignmentException {
        a.addAlignCell(c.getObject1AsURI(), c.getObject2AsURI(), c
                .getRelation().getRelation(), c.getStrength());
    }

    /**
     * Is the cell contained in the alignment.
     * @param cell the cell to check for
     * @param alignment the alignment to check
     * @return if the cell is in the alignment
     * @throws AlignmentException Exception
     */
    private boolean isCellContained(Cell cell, Alignment alignment)
            throws AlignmentException {
        for (Cell c : alignment) {
            if (cell.getObject1AsURI().equals(c.getObject1AsURI())
                    && cell.getObject2AsURI().equals(c.getObject2AsURI()))
                return true;
        }
        return false;
    }

    /**
     * Get all cells which differentiate between all matchers.
     * @return all cells that differ all matcher
     * @throws AlignmentException Exception
     */
    private List<Cell> getGoodCells() throws AlignmentException {

        List<Cell> retList = new LinkedList<Cell>();

        Map<SimpleCell, Integer> map = new HashMap<SimpleCell, Integer>();

        for (Alignment a : this.alignments) {
            // System.out.println(Helper.getString(a));
            for (Cell c : a) {
                SimpleCell sc = new SimpleCell(c.getObject1AsURI(),
                        c.getObject2AsURI());
                Integer count = map.get(sc);
                map.put(sc, count != null ? count + 1 : 1);
            }
        }

        for (Entry<SimpleCell, Integer> entry : map.entrySet()) {
            // System.out.println(entry.getValue() + entry.getKey().toString());
            if (entry.getValue() < this.alignments.size()) {
                retList.add(new URICell(null, entry.getKey().getOne(), entry
                        .getKey().getTwo(), new EquivRelation(), 1.0));
                // System.out.println(entry.getValue() +
                // entry.getKey().toString());
            }
        }

        // System.out.println( Arrays.toString(retList.toArray()));

        // to be sure -> shuffle
        Collections.shuffle(retList);

        return retList;
    }

    /**
     * @inheritDoc Sets the oracle for this MatcherSelection to
     *             <code>this.oracle</code>.
     */
    public void setOracle(Oracle oracle) {
        this.oracle = oracle;
    }

    /**
     * Sets the alignment for this matching process.
     * @param position the position of the matcher
     * in the alignments list of this class.
     * @throws AlignmentException Exception
     */
    private void setAlignment(int position) throws AlignmentException {
        this.deleteAllCells();
        Alignment a = this.alignments.get(position);
        for (Cell c : a) {
            this.addAlignCell(c.getObject1(), c.getObject2(), c.getRelation()
                    .getRelation().toString(), c.getStrength());
        }
    }
}
