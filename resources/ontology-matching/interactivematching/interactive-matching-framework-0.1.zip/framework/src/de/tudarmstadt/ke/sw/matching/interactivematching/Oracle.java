package de.tudarmstadt.ke.sw.matching.interactivematching;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.Cell;

/**
 * The oracle interface which scores a cell.
 *
 * @author Sven Hertling
 *
 */
public interface Oracle {
    /**
     * Asks the oracle if the specified cell is correct. Usually, the cell has
     * only the equivalent relation.
     *
     * @param cell the given cell to score
     * @return the cell which has the same two objects as in the parameter cell
     *         and a strength of 1.0. The relation is variable. It depends on
     *         the scoring.
     */
    Cell askOracle(Cell cell);

    /**
     * Adds an <code>OracleObserver</code>.
     *
     * @param observer
     *            The observer which will be added
     */
    void add(OracleObserver observer);

    /**
     * Returns the alignment which contains all cells that have been already
     * asked.
     *
     * @return the partial alignment
     */
    Alignment getPartialAlignment();
}
