/**
 * This package contains all interfaces for interactive matching.
 * @author Sven Hertling
 */
package de.tudarmstadt.ke.sw.matching.interactivematching;
