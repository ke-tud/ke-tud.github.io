package de.tudarmstadt.ke.sw.matching.interactivematching;

import org.semanticweb.owl.align.AlignmentProcess;

/**
 * This interface describes an interactive matcher.
 * @author Sven Hertling
 */
public interface InteractiveAlignmentProcess extends AlignmentProcess {
     /**
     * This method sets the Oracle for the interactive alignment process.
     * @param oracle the oracle which should be used to ask for a specific Cell
     */
    void setOracle(Oracle oracle);
}
