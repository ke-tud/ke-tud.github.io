package de.tudarmstadt.ke.sw.matching.interactivematching;

/**
 * The oracleObserver interface has only one method which informs the observer
 * before the oracle is asked.
 *
 * @author Sven Hertling
 *
 */
public interface OracleObserver {
    /**
     * This method is called before the oracle is called.
     */
    void beforeAskOracle();
}
