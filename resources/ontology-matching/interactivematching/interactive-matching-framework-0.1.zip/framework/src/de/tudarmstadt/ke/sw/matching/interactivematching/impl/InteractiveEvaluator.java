package de.tudarmstadt.ke.sw.matching.interactivematching.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

import de.tudarmstadt.ke.sw.matching.interactivematching.InteractiveAlignmentProcess;
import de.tudarmstadt.ke.sw.matching.interactivematching.Oracle;
import de.tudarmstadt.ke.sw.matching.interactivematching.OracleObserver;

import fr.inrialpes.exmo.align.impl.URIAlignment;
import fr.inrialpes.exmo.align.impl.eval.PRecEvaluator;
import fr.inrialpes.exmo.align.parser.AlignmentParser;

/**
 * Basic implementation of an interactive evaluator.
 * It calculates f human and a u l.
 * @author Sven Hertling
 */
public class InteractiveEvaluator implements OracleObserver {

    /**
     * report with FHuman?
     */
    private static boolean withFHuman = true;
    
    /**
     * report with AUL?
     */
    private static boolean withAUL = true;

    /**
     * The string of the track.
     */
    private String track;
    /**
     * the reference alignment to test against.
     */
    private Alignment refalign;
    /**
     * the oracle which is used here.
     */
    private Oracle oracle;
    /**
     * the InteractiveAlignmentProcess to evaluate.
     */
    private InteractiveAlignmentProcess iap;

    /**
     * The constructor to initialise. Given is the reference alignment
     * and the InteractiveAlignmentProcess.
     * @param referenceAlignment the reference alignment as an URI
     * @param interactive the InteractiveAlignmentProcess to eval
     */
    public InteractiveEvaluator(URI referenceAlignment,
            InteractiveAlignmentProcess interactive) {
        track = new File(referenceAlignment).getName();
        try {
            refalign = new AlignmentParser(0).parse(referenceAlignment);
        } catch (AlignmentException e) {
            System.err.println("can not parse reference Alignment at "
                    + referenceAlignment);
        }

        oracle = new AutomaticOracle(refalign);
        oracle.add(this);
        interactive.setOracle(oracle);
        iap = interactive;
    }

    /**
     * Starts the evaluation.
     * In the align method the oracle is asked
     * and itself will report to this class, namely
     * will call the beforeAskOracle method.
     * @throws AlignmentException Exception
     */
    public void eval() throws AlignmentException {
        iap.align(null, null);
        beforeAskOracle();
        try {
            writeOut("./fmeasures.csv");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Static newline.
     */
    private static String newline = System.getProperty("line.separator");

    /**
     * Computes the AUL value of a list of doubles.
     * @param list the list to caluclate AUL on
     * @return AUL value
     */
    private Double getAUL(List<Double> list){
        double n = list.size();
        double oneDividedByLogN = 1.0d / log2(n);
        double factor = 0.0d;
        for (int i = 1; i < list.size(); i++) {
            double twoLogs = 0.0d;
            if(i != 1)
                twoLogs = log2(i) - log2(i - 1);
            double fmeasureDelta = (list.get(i) + list.get(i - 1)) / 2.0d;
            factor += twoLogs * fmeasureDelta;
        }
        double ret = oneDividedByLogN * factor;
        return ret;
    }
    
    /**
     * Calculates the log base 2.
     * @param d double value 
     * @return log_2(d)
     */
    private double log2(double d) {
        return Math.log(d) / Math.log(2.0d);
    }
    
    /**
     * Computes the AUL value of a list of doubles.
     * It expands the list to n values
     * @param list the list to caluclate AUL on
     * @param n expand the list to n values.
     * @return AUL value
     */
    private Double getAUL(List<Double> list, int n){
        double expandValue = list.get(list.size() - 1);
        List<Double> expandedList = new LinkedList<Double>(list);
        for(int i = list.size(); i < n; i++) {
            expandedList.add(expandValue);
        }
        
        return getAUL(expandedList);
    }

    /**
     * Writes out all information to one file (csv).
     * If this file exists, it will append all information.
     * @param path The path for the csv file
     * @throws IOException Exception
     */
    private void writeOut(String path) throws IOException {
        DecimalFormat df = new DecimalFormat("0.0000");
        FileWriter out = new FileWriter(new File(path), true);
        out.append(track + ";");
        for (Double d : fmeasure) {
            out.append(df.format(d) + ";");
        }
        if (withAUL) {
            out.append(";");
            out.append(df.format(getAUL(fmeasure, 32)));
        }
        out.append(newline);


        if (withFHuman) {
            out.append(track + "_fHuman" + ";");
            for (Double d : fHuman) {
                out.append(df.format(d) + ";");
            }
            if (withAUL) {
                out.append(";");
                out.append(df.format(getAUL(fHuman, 32)));
            }
            out.append(newline);
        }

        out.flush();
        out.close();
    }

    /**
     * This list stores all f-measure values added by 
     * beforeAskOracle and is consumed by writeOut method at end end.
     */
    private List<Double> fmeasure = new LinkedList<Double>();
    /**
     * This list stores all fHuman values added by 
     * beforeAskOracle and is consumed by writeOut method at end end.
     */
    private List<Double> fHuman = new LinkedList<Double>();

    /**
     * This method is called by the oracle which is created in the constructor.
     * It adds all calculated fmeasure and f human values to the list,
     * which is written to a file at the end of evaluation.
     */
    public void beforeAskOracle() {
        // fmeasure
        PRecEvaluator eval = null;
        try {
            eval = new PRecEvaluator(this.refalign,
                    convertToURIAlignment(this.iap));
            eval.eval(null);
        } catch (AlignmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        fmeasure.add(eval.getFmeasure());

        // FHuman
        PRecEvaluator evalhuman = null;
        try {
            evalhuman = new PRecEvaluator(this.refalign,
                    this.oracle.getPartialAlignment());
            evalhuman.eval(null);
        } catch (AlignmentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        fHuman.add(evalhuman.getFmeasure());
    }

    /**
     * Convert the alignment to a URIAlignment to use the PRecEvaluator.
     * @param a the alignment to convert
     * @return a duplicate of the given alignment as URIAlignment
     * @throws AlignmentException Exception
     */
    private URIAlignment convertToURIAlignment(Alignment a)
            throws AlignmentException {
        URIAlignment uriAlignment = new URIAlignment();
        for (Cell c : a) {
            uriAlignment.addAlignCell(c.getObject1AsURI(), c.getObject2AsURI(),
                    c.getRelation().getRelation(), c.getStrength());
        }
        return uriAlignment;
    }

}
