package de.tudarmstadt.ke.sw.matching.interactivematching.impl;

import java.net.URI;
import java.util.Enumeration;
import java.util.Properties;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.AlignmentProcess;
import org.semanticweb.owl.align.Cell;

import fr.inrialpes.exmo.align.impl.BasicAlignment;
import fr.inrialpes.exmo.align.impl.URIAlignment;
import fr.inrialpes.exmo.align.parser.AlignmentParser;
/**
 * This class represents an AlignmentProcess which is not an matcher,
 * but receives an alignment.
 * @author Sven Hertling
 *
 */
public class DummyAlignmentProcess extends BasicAlignment implements AlignmentProcess {

    /**
     * alignment for this AlignmentProcess
     */
	private Alignment alignment;
	
	/**
	 * The constructor gets an uri of an reference alignment.
	 * @param uri the uri of the reference alignment.
	 */
	public DummyAlignmentProcess(URI uri){
		try {
			alignment =  new AlignmentParser(0).parse(uri);
		} catch (AlignmentException e) {
			e.printStackTrace(System.out);
			System.out.println("CONTINUE...");
			alignment = new URIAlignment();
			//System.err.println("can not parse Alignment at " + uri);
		}
	}

	/**
	 * The align method of the dummy read the alignment and
	 * add it to <code>this</code>.
	 */
	public void align(Alignment arg0, Properties arg1) throws AlignmentException {
		Enumeration<Cell> e = alignment.getElements();
		while (e.hasMoreElements()) {
			Cell c = e.nextElement();
			this.addAlignCell(c.getObject1(), c.getObject2(), c.getRelation().getRelation(), c.getStrength());
		}
	}

}
