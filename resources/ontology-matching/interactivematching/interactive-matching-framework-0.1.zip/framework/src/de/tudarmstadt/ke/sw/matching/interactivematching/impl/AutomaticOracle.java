package de.tudarmstadt.ke.sw.matching.interactivematching.impl;

import java.util.LinkedList;
import java.util.List;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

import de.tudarmstadt.ke.sw.matching.interactivematching.Oracle;
import de.tudarmstadt.ke.sw.matching.interactivematching.OracleObserver;

import fr.inrialpes.exmo.align.impl.URIAlignment;
import fr.inrialpes.exmo.align.impl.URICell;
import fr.inrialpes.exmo.align.impl.rel.IncompatRelation;

/**
 * This class is an implementation of an oracle which gets a reference
 * alignment.
 *
 * @author Sven Hertling
 *
 */
public class AutomaticOracle implements Oracle {

    /**
     * partialAlignment stores the alignment which contains all Cells that are
     * scored by this oracle.
     */
    private Alignment partialAlignment;

    /**
     * this is the reference alignment to answer a question.
     */
    private Alignment refalign;

    /**
     * in this list all observers of this oracle are stored.
     */
    private List<OracleObserver> observers;

    /**
     * The constructor of AutomaticOracle which gets a reference Alignment to
     * implement an oracle.
     *
     * @param referenceAlignment
     *            the reference alignment to use for question answering
     */
    public AutomaticOracle(Alignment referenceAlignment) {
        this.partialAlignment = new URIAlignment();
        this.refalign = referenceAlignment;
        this.observers = new LinkedList<OracleObserver>();
    }

    /**
     * Implementation of askOracle with the reference alignment.
     * @param cell the cell which should be scored
     * @return the scored cell
     */
    public Cell askOracle(Cell cell) {

        notifyObservers();

        try {
            for (Cell refCell : refalign) {
                if (cell.getObject1AsURI().equals(refCell.getObject1AsURI())
                  && cell.getObject2AsURI().equals(refCell.getObject2AsURI())) {
                    this.partialAlignment.addAlignCell(refCell.getObject1AsURI(),
                                                       refCell.getObject2AsURI(),
                                                       "=",
                                                       1.0);
                    return refCell; // other id of the cell - important?
                }
            }
            return new URICell(cell.getId(),
                    cell.getObject1AsURI(),
                    cell.getObject2AsURI(),
                    new IncompatRelation(),
                    1.0);
        } catch (AlignmentException e) { e.printStackTrace(); }
        return null;
    }

    /**
     * This method adds an oracle observer to this oracle.
     * @param observer the observer which should be notified
     */
    public void add(OracleObserver observer) {
        observers.add(observer);
    }

    /**
     * Private method to notify all observers.
     */
    private void notifyObservers() {
        for (OracleObserver o : observers) {
            o.beforeAskOracle();
        }
    }

    /**
     *  Returns the partial alignment.
     *  @return return partial alignment
     */
    public Alignment getPartialAlignment() {
        return this.partialAlignment;
    }

}
