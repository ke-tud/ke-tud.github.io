package de.tudarmstadt.ke.sw.matching.interactivematching.impl;
/**
 * Enum for InteractiveThreshould.
 * It symbolise which cells are processed.
 *
 * @author Sven Hertling
 */
public enum CellProcessing {
    /**
     * The cell is unprocessed.
     */
    Unprocessed,
    /**
     * The cell is correct.
     */
    correct,
    /**
     * The cell is incorrect.
     */
    incorrect
}
