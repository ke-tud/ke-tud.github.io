package de.tudarmstadt.ke.sw.matching.benchmarking;

import java.net.URI;

public class BenchmarkCase implements Comparable {

	private URI ontoOne;
	private URI ontoTwo;
	private URI refAlign;
	private String name;
	
	public BenchmarkCase(String name, URI ontoOne, URI ontoTwo, URI refAlign){
		this.name = name;
		this.ontoOne = ontoOne;
		this.ontoTwo = ontoTwo;
		this.refAlign = refAlign;				
	}
	
	public URI getOntoOne() {
		return ontoOne;
	}

	public URI getOntoTwo() {
		return ontoTwo;
	}

	public URI getRefAlign() {
		return refAlign;
	}

	public String getName() {
		return name;
	}

	public int compareTo(Object arg0) {
		if (arg0 instanceof BenchmarkCase) {
			BenchmarkCase other = (BenchmarkCase) arg0;
			return this.getName().compareTo(other.getName());
		}
		throw new ClassCastException();
	}
}
