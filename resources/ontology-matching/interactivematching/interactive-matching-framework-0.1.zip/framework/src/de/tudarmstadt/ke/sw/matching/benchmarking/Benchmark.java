package de.tudarmstadt.ke.sw.matching.benchmarking;

import java.util.List;

/**
 * An internal interface for all benchmarks.
 * @author Sven Hertling
 *
 */
public interface Benchmark {
    /**
     * Get all benchmark cases.
     * @return list of all bechmark cases
     */
    List<BenchmarkCase> getBenchmarkCases();
     /**
     * Get a nice name for this Benchmark.
     * @return the nice name
     */
     String getName();
}
