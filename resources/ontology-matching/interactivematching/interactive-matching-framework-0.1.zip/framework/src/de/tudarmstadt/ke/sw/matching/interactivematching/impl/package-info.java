/**
 * This package contains basic implementations for interactive matching.
 * @author Sven Hertling
 */
package de.tudarmstadt.ke.sw.matching.interactivematching.impl;
