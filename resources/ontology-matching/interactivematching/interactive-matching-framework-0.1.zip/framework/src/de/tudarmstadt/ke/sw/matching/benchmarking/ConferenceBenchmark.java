package de.tudarmstadt.ke.sw.matching.benchmarking;

import java.io.File;
import java.io.FilenameFilter;
import java.util.LinkedList;
import java.util.List;


public class ConferenceBenchmark implements Benchmark {

	private File benchmarkFolder;

	public ConferenceBenchmark() {
		this.benchmarkFolder = new File("./benchmarks/con11/");
	}

	public List<BenchmarkCase> getBenchmarkCases() {
		
		List<BenchmarkCase> list = new LinkedList<BenchmarkCase>();
		
		if(benchmarkFolder.exists() == false){
			//log
			return list;
		}
		
        File conferenceFolder = new File(benchmarkFolder.getAbsolutePath() + File.separator + "conference");
        File alignmentFolder = new File(benchmarkFolder.getAbsolutePath() + File.separator + "reference-alignment");
        
        if(conferenceFolder.exists() == false || alignmentFolder.exists() == false){
        	//log
			return list;
        }
        

        String[] array = alignmentFolder.list(new FilenameFilter() {
			
			public boolean accept(File dir, String name) {
				return name.endsWith(".rdf");
			}
		});
       
        for(String align : array){
            align = align.substring(0, align.lastIndexOf("."));
            String[] aligments = align.split("-");
            if(aligments.length != 2){
            	//log
            	continue;
            }

            File one = new File(conferenceFolder.getAbsolutePath() + File.separator + aligments[0] + ".owl");
            File two = new File(conferenceFolder.getAbsolutePath() + File.separator + aligments[1] + ".owl");
            File refalign = new File(alignmentFolder.getAbsolutePath() + File.separator + align + ".rdf");
            
            if(one.exists() == false || two.exists() == false || refalign.exists() == false){
            	//log
                continue;
            }
            list.add(new BenchmarkCase(align, one.toURI(), two.toURI(), refalign.toURI()));
        }
        return list;
	}
	
	public String getName() {
		return "Conference";
	}

}
