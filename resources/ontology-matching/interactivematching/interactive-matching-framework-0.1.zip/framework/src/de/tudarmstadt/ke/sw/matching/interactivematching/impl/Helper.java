package de.tudarmstadt.ke.sw.matching.interactivematching.impl;

import org.semanticweb.owl.align.Alignment;
import org.semanticweb.owl.align.AlignmentException;
import org.semanticweb.owl.align.Cell;

/**
 * This is an helper class for showing alignments to std out.
 * @author Sven Hertling
 *
 */
public class Helper {

    /**
     * Print one cell.
     * @param cell the cell to print
     * @throws AlignmentException thrown Exception of cell
     */
	public static void printCell(Cell cell) throws AlignmentException{
		System.out.println("(" + cell.getObject1AsURI() + ", " + cell.getObject2AsURI() + ", " + cell.getRelation().getRelation() + ", " + cell.getStrength() + ")");
	}
	
	/**
	 * Print a hole alignment.
	 * @param alignment the alignment to print.
	 * @throws AlignmentException thrown Exception from getString
	 */
	public static void print(Alignment alignment) throws AlignmentException{
		System.out.println(getString(alignment));
	}
	/**
	 * a newline property
	 */
	private static String newline = System.getProperty("line.separator");
	/**
	 * Get string from alignment.
	 * @param alignment alignment to print
	 * @return the nice string
	 * @throws AlignmentException thrown Exception from cell
	 */
	public static String getString(Alignment alignment) throws AlignmentException {
	        StringBuilder sb = new StringBuilder();
	        sb.append("Alignment ");
	        sb.append(alignment);
	        sb.append(newline);
	        sb.append("{");
	        sb.append(newline);
	        for (Cell cell : alignment) {
	            sb.append("\t");
	            sb.append(cell.getObject1AsURI());

	            sb.append("\t");
	            //sb.append(cell.getRelation().getRelation());
	            sb.append(" " + cell.getStrength());
	            sb.append("\t");

	            sb.append(cell.getObject2AsURI());
	            sb.append(newline);
	        }
	        sb.append("}");
	        return sb.toString();
	}
}
