package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import weka.core.Attribute;
import weka.core.Instances;
import de.tudarmstadt.fegelod.Run;
import de.tudarmstadt.fegelod.util.ARFFWriter;

public class FeatureGenerationPanel extends JPanel {
	
	private ExpaLODGUI theGUI = null;

	private static final long serialVersionUID = -4758121611563758359L;

	private JCheckBox chkDataProperties;
	private JCheckBox chkDirectTypes;
	private JCheckBox chkRelationsBoolean;
	private JCheckBox chkRelationsNumeric;
	private JCheckBox chkQRelationsBoolean;
	private JCheckBox chkQRelationsNumeric;
	private JTextField txtSPARQL;
	private JTextField txtThreshold;
	private JTextField txtOutfile;
	private JComboBox cmbColumn;
	private Instances instances;
	private String originalFilename;
	
	public FeatureGenerationPanel(Instances i, String originalFilename, ExpaLODGUI expaLODGUI) {
		instances = i;
		this.originalFilename = originalFilename;
		theGUI = expaLODGUI;
		initialize();
	}
	
	private void initialize() {
		this.setLayout(new BorderLayout());
		this.add(new OptionsPanel(),BorderLayout.NORTH);
	}
	
	private class OptionsPanel extends JPanel {

		private static final long serialVersionUID = -4943097156442316706L;

		public OptionsPanel() {
			this.setLayout(new GridLayout(10,2));
			this.add(new JLabel("File: " + instances.relationName()));
			this.add(new JLabel(""));

			this.add(new JLabel("SPARQL Endpoint:"));
			txtSPARQL = new JTextField();
			txtSPARQL.setText("http://dbpedia.org/sparql");
			this.add(txtSPARQL);
			
			this.add(new JLabel("Column to expand: "));
			// use actual columns
			Vector<String> columns = new Vector<String>();
			Enumeration<Attribute> e = instances.enumerateAttributes();
			while(e.hasMoreElements())
				columns.add(e.nextElement().name());
			cmbColumn = new JComboBox(columns);
			this.add(cmbColumn);
			
			this.add(new JLabel("Generators:"));
			this.add(new JLabel(""));
			chkDataProperties = new JCheckBox("Data properties");
			this.add(chkDataProperties);
			chkDirectTypes = new JCheckBox("Direct types");
			this.add(chkDirectTypes);
			chkRelationsBoolean = new JCheckBox("Relations (boolean)");
			this.add(chkRelationsBoolean);
			chkRelationsNumeric = new JCheckBox("Relations (numeric)");
			this.add(chkRelationsNumeric);
			chkQRelationsBoolean = new JCheckBox("Qualified relations (boolean)");
			this.add(chkQRelationsBoolean);
			chkQRelationsNumeric = new JCheckBox("Qualified relations (numeric)");
			this.add(chkQRelationsNumeric);
			this.add(new JLabel("Threshold:"));
			txtThreshold = new JTextField();
			txtThreshold.setText("0.95");
			txtThreshold.setSize(0,40);
			this.add(txtThreshold);
			this.add(new JLabel("Output file: "));
			String outputFilename = originalFilename.substring(0,originalFilename.indexOf(".")) + "-preprocessed.arff";
			txtOutfile = new JTextField();
			txtOutfile.setText(outputFilename);
			txtOutfile.setSize(0,200);
			this.add(txtOutfile);
			
			this.add(new JLabel(""));
			JPanel startPanel = new JPanel();
			JButton startButton = new JButton("Start Generation");
			startButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					final Properties prop = new Properties();
					prop.put("sparqlEndpoint", txtSPARQL.getText());
					prop.put("attribute", cmbColumn.getSelectedItem());
					prop.put("threshold", txtThreshold.getText());
					prop.put("generator.dataProperties", Boolean.toString(chkDataProperties.isSelected()));
					prop.put("generator.type", Boolean.toString(chkDirectTypes.isSelected()));
					prop.put("generator.relationBoolean", Boolean.toString(chkRelationsBoolean.isSelected()));
					prop.put("generator.relationNumeric", Boolean.toString(chkRelationsNumeric.isSelected()));
					prop.put("generator.relationTypeBoolean", Boolean.toString(chkQRelationsBoolean.isSelected()));
					prop.put("generator.relationTypeNumeric", Boolean.toString(chkQRelationsNumeric.isSelected()));
					
					System.out.println(prop);
					
					final Run fegelodRun = new Run();
					new Thread() {
						public void run() {
							fegelodRun.runFegelod(instances, prop);
						}
					}.start();
					new ProgressDialog(fegelodRun);
					
					ExplanationPanel panel = new ExplanationPanel();
					panel.setInstances(instances);
					ARFFWriter writer = new ARFFWriter();
					
					File outFile = new File(txtOutfile.getText());
					try {
						writer.writeFile(instances, outFile);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					theGUI.getMainWindow().displayPanel(panel);
				}
			});
			startPanel.add(startButton);
			this.add(startPanel);
		}
	}

}
