package de.tudarmstadt.ke.expalod;

import java.io.File;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;

import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Discretize;
import de.tudarmstadt.ke.expalod.eval.AttributeEvaluation;
import de.tudarmstadt.ke.expalod.eval.EvaluatedAttribute;

public class ExpalodRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Instances instances = new Instances(new FileReader(new File("data/corruption-joined-95.arff")));
		instances.setClassIndex(instances.numAttributes()-1);
		if(instances.classAttribute().isNumeric()) {
			Discretize d = new Discretize();
			d.setIgnoreClass(true);
			d.setAttributeIndices("first-last");
			d.setInputFormat(instances);
			instances = Filter.useFilter(instances, d);
		}
		AttributeEvaluation eval = new AttributeEvaluation();
		List<EvaluatedAttribute> orderAttributes = eval.orderAttributes(instances);
		System.out.println("top hypotheses:");
		DecimalFormat df = new DecimalFormat( "0.0000" );
		df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.ENGLISH));
		for(EvaluatedAttribute EA : orderAttributes) {
			if(Math.abs(EA.getEvaluation())>0.05)
				System.out.println(EA.getAttribute().name() + " (" + df.format(EA.getEvaluation()) + ")");
		}
	}

}
