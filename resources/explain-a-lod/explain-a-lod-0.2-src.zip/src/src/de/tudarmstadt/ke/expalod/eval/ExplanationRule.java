package de.tudarmstadt.ke.expalod.eval;

/**
 * A rule explaining a phenomenon.
 * @author paulheim
 *
 */
public class ExplanationRule implements Comparable {

	public ExplanationRule(String text, double confidence) {
		this.text = text;
		this.accuracy = confidence;
	}
	
	private String text;
	private double accuracy;
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	public double getAccuracy() {
		return accuracy;
	}
	
	public void setAccuracy(double accuracy) {
		this.accuracy = accuracy;
	}

	@Override
	public int compareTo(Object arg0) {
		ExplanationRule other = (ExplanationRule) arg0;
		return - new Double(accuracy).compareTo(other.accuracy);
	}
	
	
}
