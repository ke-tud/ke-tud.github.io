package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

class DatasetInfoPanel extends JPanel {
	/**
	 * 
	 */
	private final ExplanationPanel explanationPanel;

	/**
	 * @param explanationPanel
	 */
	DatasetInfoPanel(ExplanationPanel explanationPanel) {
		this.explanationPanel = explanationPanel;
	}

	private boolean initialized = false;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7830988803796454099L;

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		initialize();
	}
	
	@Override
	public Dimension getPreferredSize() {
		initialize();
		// TODO Auto-generated method stub
		return super.getPreferredSize();
	}
	
	private void initialize() {
		if(initialized)
			return;
		this.removeAll();
		this.setLayout(new BorderLayout());
		this.add(new JLabel("Basic dataset information"),BorderLayout.NORTH);
		if(this.explanationPanel.instances!=null) {
			JPanel infos = new JPanel();
			infos.setLayout(new GridLayout(4,2));
			infos.add(new JLabel("Number of instances:"));
			infos.add(new JLabel(Integer.toString(this.explanationPanel.instances.numInstances())));
			infos.add(new JLabel("Number of generated features:"));
			infos.add(new JLabel(Integer.toString(this.explanationPanel.instances.numAttributes()-2)));
			infos.add(new JLabel("Source attribute:"));
			infos.add(new JLabel(this.explanationPanel.instances.attribute(0).name()));
			infos.add(new JLabel("Target attribute:"));
			infos.add(new JLabel(this.explanationPanel.instances.classAttribute().name()));
			this.add(infos,BorderLayout.CENTER);
			initialized = true;
		}
	}
}