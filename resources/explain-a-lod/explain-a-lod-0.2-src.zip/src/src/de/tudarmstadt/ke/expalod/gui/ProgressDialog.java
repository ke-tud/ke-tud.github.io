package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

import de.tudarmstadt.fegelod.ProgressInformer;

public class ProgressDialog extends JDialog {

	private static final long serialVersionUID = 2114453653253262490L;

	private ProgressInformer progressInformer = null;
	private JProgressBar jpg;
	
	public ProgressDialog(ProgressInformer informer) {
		progressInformer = informer;
		init();
		this.setModalityType(ModalityType.APPLICATION_MODAL);
		this.setVisible(true);
	}
	
	private void init() {
		jpg = new JProgressBar();
		this.setLayout(new BorderLayout());
		this.add(new JLabel("Processing"),BorderLayout.NORTH);
		this.add(jpg,BorderLayout.CENTER);
		this.pack();
		new Thread() {

			@Override
			public void run() {
				while(progressInformer.getPercentComplete()<1) {
					jpg.setValue((int)(progressInformer.getPercentComplete()*100));
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
					}
				}
				setVisible(false);
			}
			
			
		}.start();
	}
}
