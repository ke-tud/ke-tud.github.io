package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ExpaLODMainWindow extends JFrame {
	private ExpaLODMainPanel mainPanel = new ExpaLODMainPanel();
	
	public ExpaLODMainWindow() {
		super("Explain-a-LOD");
		
		// icons
		ImageIcon icon1 = new ImageIcon("resource/icon32x32.gif");
		ImageIcon icon2 = new ImageIcon("resource/icon16x16.gif");
		List<Image> icons = new ArrayList<Image>();
		icons.add(icon1.getImage());
		icons.add(icon2.getImage());
		this.setIconImages(icons);
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.getContentPane().setLayout(new BorderLayout());
		this.add(new MenuButtonPanel(),BorderLayout.NORTH);
		this.add(mainPanel,BorderLayout.CENTER);
		
		this.setSize(600, 450);
		
	}
	
	public ExpaLODMainPanel getMainPanel() {
		return mainPanel;
	}

	public void displayPanel(JPanel panel) {
		this.mainPanel.displayPanel(panel);
	}
}
