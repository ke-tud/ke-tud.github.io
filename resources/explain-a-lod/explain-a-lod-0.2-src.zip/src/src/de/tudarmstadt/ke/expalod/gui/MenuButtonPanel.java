package de.tudarmstadt.ke.expalod.gui;

import java.awt.FlowLayout;
import java.awt.MediaTracker;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class MenuButtonPanel extends JPanel {
	public MenuButtonPanel() {
		super();
		this.setLayout(new FlowLayout(FlowLayout.LEADING));

		ImageIcon ii1 = new ImageIcon("resource/new.png");
		while(ii1.getImageLoadStatus()==MediaTracker.LOADING)
			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		JButton jbNew = new JButton(ii1);
		jbNew.setToolTipText("New dataset");
		jbNew.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ExpaLODGUI.getInstance().getMainWindow().displayPanel(new StartPanel());
			}

		});
		this.add(jbNew);

		ImageIcon ii2 = new ImageIcon("resource/exit.png");
		while(ii2.getImageLoadStatus()==MediaTracker.LOADING)
			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		JButton jbExit = new JButton(ii2);
		jbExit.setToolTipText("Exit");
		jbExit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ExpaLODGUI.getInstance().exit();
			}

		});
		this.add(jbExit);

	}
}
