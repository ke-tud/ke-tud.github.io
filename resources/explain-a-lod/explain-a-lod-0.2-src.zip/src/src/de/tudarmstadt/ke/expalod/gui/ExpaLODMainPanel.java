package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ExpaLODMainPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3208191825869157059L;

	public ExpaLODMainPanel() {
		this.setLayout(new BorderLayout());
		this.add(new JLabel("Welcome to Explain-a-LOD!"),BorderLayout.NORTH);
		StartPanel p = new StartPanel();
		p.setSize(600,200);
		this.add(p,BorderLayout.CENTER);
	}
	
	public void displayPanel(JPanel panel) {
		this.removeAll();
		this.add(panel,BorderLayout.CENTER);
		this.validate();
	}
}
