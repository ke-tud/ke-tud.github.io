package de.tudarmstadt.ke.expalod.logic;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import weka.classifiers.rules.JRip;
import weka.core.Attribute;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Discretize;
import weka.filters.unsupervised.attribute.StringToNominal;
import de.tudarmstadt.fegelod.util.AttributeFilterUtils;
import de.tudarmstadt.ke.expalod.eval.ExplanationRule;
import de.tudarmstadt.ke.expalod.verbalize.AttributeProcessor;
import de.tudarmstadt.ke.expalod.verbalize.AttributeProcessor.AttributeType;
import de.tudarmstadt.ke.expalod.verbalize.OntologyVerbalizer;

public class RipperExplanationGenerator implements
		RuleBasedExplanationGenerator {
	
	private OntologyVerbalizer ontologyVerbalizer = new OntologyVerbalizer();
	
	private double minAccuracy = 0.0;
	private double minSupport = 0.05;
	private int maxNumOfRules = 20;
	
	private boolean numericClassAttribute;
	
	@Override
	public List<ExplanationRule> getRules(Instances instances) {

		List<ExplanationRule> rules = new LinkedList<ExplanationRule>();

		try {
			Instances filteredInstances = null;
			if(instances.classAttribute().isNumeric()) {
				// Discretization: three buckets
				Discretize filter1 = new Discretize();
				// weka.filters.unsupervised.attribute.Discretize -unset-class-temporarily -F -B 3 -M -1.0 -R last
				filter1.setOptions(new String[]{"-unset-class-temporarily","-F","-B","3","-M","-1.0","-R","last"});
				filter1.setIgnoreClass(true);
				filter1.setInputFormat(instances);
				filteredInstances = Filter.useFilter(instances, filter1);
				numericClassAttribute = true;
			} else {
				filteredInstances = instances;
				numericClassAttribute = false;
			}
			
			// convert string attributes to nominals
			// weka.filters.unsupervised.attribute.StringToNominal -R first-last
			StringToNominal filter2 = new StringToNominal();
			filter2.setOptions(new String[]{"-R","first-last"});
			filter2.setInputFormat(filteredInstances);
			filteredInstances = Filter.useFilter(filteredInstances, filter2);

			boolean ok = true;
			while(ok) {
				JRip ripper = new JRip();
				ripper.buildClassifier(filteredInstances);
				String ripperOutput = ripper.toString();
				RipperExplanationRule RER = getFirstRule(ripperOutput, filteredInstances);
				double support = (double)(RER.getPositives() + RER.getNegatives()) / instances.numInstances();
				if(RER.getAccuracy()>minAccuracy && support>minSupport)
					rules.add(RER);
				
				// run until only default rule was found or maximum number of rules reached
				if(RER.getAttributesInBody().size()==0 || rules.size()>=maxNumOfRules)
					ok = false;
				else
					AttributeFilterUtils.removeAttributes(filteredInstances, RER.getAttributesInBody(), false);
			}
		} catch (Exception e) {
			// TODO error handling!
			e.printStackTrace();
			// return what we have so far
			return rules;
		}
		
		Collections.sort(rules);
		return rules;
	}
	
	private RipperExplanationRule getFirstRule(String ripperOutput, Instances instances) {
		System.out.println(ripperOutput);

		// this is somewhat hacked...
		int p1 = ripperOutput.indexOf("(");
		int p2 = ripperOutput.indexOf("\n",p1);
//		int p2 = ripperOutput.indexOf(System.getProperty("line.separator"),p1);
		String rule = ripperOutput.substring(p1, p2);
		
		// separate into body, head, and evaluation
		if(!rule.contains("=>"))
			return new RipperExplanationRule("default", 0, 1);
		String body = rule.substring(0,rule.indexOf("=>")).trim();
		String headPart = rule.substring(rule.indexOf("=>") + 3);
		String head = headPart.substring(0,headPart.indexOf(" ")).trim();
		String eval = headPart.substring(headPart.indexOf(" ")).trim();
		
		String sourceName = instances.attribute(0).name();
		String ruleText = "A " + sourceName + " ";
		
		Set<String> attributesUsed = new HashSet<String>(); 

		// verbalize body and head, track used attributes
		boolean first = true;
		String[] bodyTerms = body.split(" and ");
		for(String term : bodyTerms) {
			term = term.replace("(", "");
			term = term.replace(")", "");
			String[] termParts = term.split(" < | <= | > | >= | = ");
			attributesUsed.add(termParts[0].trim());
			if(!first)
				ruleText += "and ";
			else
				first = false;
			ruleText += verbalizeBodyTerm(term,sourceName) + "<br>";
		}
		ruleText += verbalizeRuleHead(head, numericClassAttribute);
		System.out.println(ruleText);

		// calculate accuracy
		String stotal = eval.substring(eval.indexOf("(")+1,eval.indexOf("/"));
		String snegative = eval.substring(eval.indexOf("/")+1,eval.indexOf(")"));
		int total = (int) Double.parseDouble(stotal);
		int negative = (int) Double.parseDouble(snegative);
		
		RipperExplanationRule ER = new RipperExplanationRule("<html>" + ruleText + "</html>",total-negative,negative);
		// add used attributes
		for(String attName : attributesUsed)
			ER.addBodyAttribute(instances.attribute(attName));
		
		return ER;
	}
	
	private class RipperExplanationRule extends ExplanationRule {

		private List<Attribute> attributesInBody = new LinkedList<Attribute>(); 
		
		private int positives = 0;
		private int negatives = 0;
		
		public RipperExplanationRule(String text, int positives, int negatives) {
			super(text,(double)positives/(positives+negatives));
			this.positives = positives;
			this.negatives = negatives;
		}
		
		public void addBodyAttribute(Attribute att) {
			attributesInBody.add(att);
		}
		
		public List<Attribute> getAttributesInBody() {
			return attributesInBody;
		}
		
		public int getPositives() {
			return positives;
		}
		
		public int getNegatives() {
			return negatives;
		}
	}
	
	private String verbalizeBodyTerm(String term, String sourceName) {
		String[] termParts = term.split(" < | <= | > | >= | = ");
		String operator = "=";
		if(term.contains(" <= "))
			operator = "<=";
		else if(term.contains(" < "))
			operator = "<";
		else if(term.contains(" >= "))
			operator = ">=";
		else if(term.contains(" > "))
			operator = ">";
		AttributeType attType = AttributeProcessor.getAttributeType(termParts[0]);
		// the boolean value of a term with boolean values, i.e. "false" for the term "hasInput=false"
		boolean booleanValue = Boolean.parseBoolean(termParts[1].trim());
		List<String> uris = AttributeProcessor.getURIsFromAttributeName(termParts[0]); 
		switch(attType) {
		case DATA: return "with " + ontologyVerbalizer.getNameForURI(uris.get(0)) + " " + mask(operator) + " " + termParts[1];
		case TYPE: return "which is " + (booleanValue ? "" : "not") + " of type <i>" + ontologyVerbalizer.getNameForURI(uris.get(0)) + "</i>";
		case UNQUALIFIED_IN_BOOLEAN: return "which " + (booleanValue ? "has" : "does not have") + " something which [is/has] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [in/of] that " + sourceName;
		case UNQUALIFIED_OUT_BOOLEAN: return "which " + (booleanValue ? "[is/has]" : "[is not/does not have]") + " <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [of/for] something";
		case UNQUALIFIED_IN_NUM: return "which has " + (operator.contains("<") ? "at most" : "at least") + " " + termParts[1] + " things which [are/have] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "<i> [in/of] that " + sourceName; 
		case UNQUALIFIED_OUT_NUM: return "which [is/has] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [of/for] " + (operator.contains("<") ? "at most" : "at least") + " " + termParts[1] + " things";
		case QUALIFIED_IN_BOOLEAN: return  "which " + (booleanValue ? "has some" : "does not have any") + " " + ontologyVerbalizer.getNameForURI(uris.get(1)) + "</i> which [are/have] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [in/of] that " + sourceName;
		case QUALIFIED_OUT_BOOLEAN: return "which " + (booleanValue ? "[is/has]" : "[is not/does not have]") + " <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [of/for] some <i>" + ontologyVerbalizer.getNameForURI(uris.get(1)) +"</i>";
		case QUALIFIED_IN_NUM: return "which has " + (operator.contains("<") ? "at most" : "at least") + " " + termParts[1] + " " + ontologyVerbalizer.getNameForURI(uris.get(1)) + "</i> which [are/have] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [in/of] that " + sourceName;
		case QUALIFIED_OUT_NUM: return "which [is/has] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [of/for] " + (operator.contains("<") ? "at most" : "at least") + " " + termParts[1] + " <i>" + ontologyVerbalizer.getNameForURI(uris.get(1)) + "</i>";
		}
		
		return null;
	}
	
	private String mask(String s) {
		return s.replace("<","&lt;").replace(">", "&gt;");
	}
	
	private String verbalizeRuleHead(String head, boolean numeric) {
		if(numeric)
			return verbalizeRuleHeadNumeric(head);
		else
			return verbalizeRuleHeadNominal(head);
	}
	
	private String verbalizeRuleHeadNumeric(String head) {
		// examples for low, medium, and high:
		// fertility='(2.705-inf)'
		// fertility='(-inf-1.85]'
		// fertility='(1.85-2.705]'
		
		String[] headParts = head.split("=");
		String modifier = "medium";
		if(headParts[1].startsWith("'(-inf"))
			modifier = "low";
		else if (headParts[1].endsWith("inf)'"))
			modifier = "high";
	
		return " has a " + modifier + " " + headParts[0];
	}
	
	private String verbalizeRuleHeadNominal(String head) {
		String[] headParts = head.split("=");
		
		return " has a " + headParts[1] + " " + headParts[0];
	}
	


}
