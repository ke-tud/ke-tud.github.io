package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import weka.core.Instances;
import de.tudarmstadt.ke.expalod.logic.RipperExplanationGenerator;

public class ExplanationPanel extends JPanel {

	Instances instances;
	private DatasetInfoPanel datasetInfoPanel;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1225101221104990485L;

	public ExplanationPanel() {
	}
	
	public void setInstances(Instances instances) {
		this.instances = instances;
		this.setLayout(new BorderLayout());
		datasetInfoPanel = new DatasetInfoPanel(this);
		this.add(datasetInfoPanel,BorderLayout.NORTH);
		
		JTabbedPane mainPane = new JTabbedPane();
		mainPane.add("Simple explanations", new SimpleExplanationPanel(this));
		mainPane.add("Complex rules", new RulesExplanationPanel(this, new RipperExplanationGenerator()));
		this.add(mainPane,BorderLayout.CENTER);
		this.validate();
	}
}
