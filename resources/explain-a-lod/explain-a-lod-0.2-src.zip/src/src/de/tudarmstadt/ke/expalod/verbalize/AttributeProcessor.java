package de.tudarmstadt.ke.expalod.verbalize;

import java.util.LinkedList;
import java.util.List;

/**
 * This class determines the type of a generated attribute, according to the FeGeLOD 
 * naming conventions. It also extracts the corresponding URIs
 * @author paulheim
 *
 */
public class AttributeProcessor {
	public enum AttributeType {	DATA,
								TYPE,
								UNQUALIFIED_IN_BOOLEAN,
								UNQUALIFIED_IN_NUM,
								UNQUALIFIED_OUT_BOOLEAN,
								UNQUALIFIED_OUT_NUM,
								QUALIFIED_IN_BOOLEAN,
								QUALIFIED_IN_NUM,
								QUALIFIED_OUT_BOOLEAN,
								QUALIFIED_OUT_NUM
								};

	public static AttributeType getAttributeType(String attributeName) {
		System.out.println(attributeName);
		// types
		if(attributeName.indexOf("_uri_type_http://")>0)
			return AttributeType.TYPE;
		
		if(attributeName.contains("_in_boolean")) 
			if(attributeName.indexOf("_type_http://")>0)
				return AttributeType.QUALIFIED_IN_BOOLEAN;
			else
				return AttributeType.UNQUALIFIED_IN_BOOLEAN;
		
		if(attributeName.contains("_out_boolean")) 
			if(attributeName.indexOf("_type_")>0)
				return AttributeType.QUALIFIED_OUT_BOOLEAN;
			else
				return AttributeType.UNQUALIFIED_OUT_BOOLEAN;
		
		if(attributeName.contains("_in_num")) 
			if(attributeName.indexOf("_type_http://")>0)
				return AttributeType.QUALIFIED_IN_NUM;
			else
				return AttributeType.UNQUALIFIED_IN_NUM;
		
		if(attributeName.contains("_out_num")) 
			if(attributeName.indexOf("_type_http://")>0)
				return AttributeType.QUALIFIED_OUT_NUM;
			else
				return AttributeType.UNQUALIFIED_OUT_NUM;
		
		// new naming conventions for qualified relations
		if(attributeName.contains("out_type_boolean")) 
			return AttributeType.QUALIFIED_OUT_BOOLEAN;
		if(attributeName.contains("in_type_boolean"))
			return AttributeType.QUALIFIED_IN_BOOLEAN;
		if(attributeName.contains("out_type_numeric")) 
			return AttributeType.QUALIFIED_OUT_NUM;
		if(attributeName.contains("in_type_numeric"))
			return AttributeType.QUALIFIED_IN_NUM;
		
		// none of the above => data
		if(attributeName.indexOf("_uri_")>0)
			return AttributeType.DATA;
		
		// not recognized
		return null;
	}
	
	/**
	 * For data, relation, and type attributes: one element list with URI of relation or type
	 * For qualified relation type attributes: two element list: relation URI first, type URI second
	 * @param attName
	 * @return
	 */
	public static List<String> getURIsFromAttributeName(String attName) {
		List<String> uriList = new LinkedList<String>();
		
		AttributeType attType = getAttributeType(attName);
		switch(attType) {
		case DATA: uriList.add(getURIFromDataAttribute(attName));
		case TYPE: uriList.add(getURIFromTypeAttribute(attName));
		break;
		case UNQUALIFIED_IN_BOOLEAN:
		case UNQUALIFIED_IN_NUM:
		case UNQUALIFIED_OUT_BOOLEAN:
		case UNQUALIFIED_OUT_NUM: uriList.add(getRelationURIFromUnqualifiedRelationAttribute(attName));
		break;
		case QUALIFIED_IN_BOOLEAN:
		case QUALIFIED_IN_NUM:
		case QUALIFIED_OUT_BOOLEAN:
		case QUALIFIED_OUT_NUM: uriList.add(getRelationURIFromQualifiedRelationAttribute(attName));
		uriList.add(getTypeURIFromQualifiedRelationAttribute(attName));
		break;
		}
		
		return uriList;
	}

	// old: country_uri_http://dbpedia.org/ontology/birthPlace_type_http://dbpedia.org/class/yago/ExpatriateFootballersInGabon_in_boolean
	// new: country_uri_out/in_type_numeric/boolean_http://dbpedia.org/ontology/birthPlace_http://dbpedia.org/class/yago/ExpatriateFootballersInGabon
	private static String getRelationURIFromQualifiedRelationAttribute(String attName) {
		// old naming convention
		if(attName.contains("type_http://"))
			return attName.substring(attName.indexOf("http://"), attName.indexOf("_type_"));
		else
			return attName.substring(attName.indexOf("http://"), attName.lastIndexOf("_http://"));
	}

	private static String getRelationURIFromUnqualifiedRelationAttribute(String attName) {
		// old attribute names
		if(attName.endsWith("_in_boolean"))
			return attName.substring(attName.indexOf("_uri_")+5, attName.lastIndexOf("_in_"));
		else if(attName.endsWith("_out_boolean"))
			return attName.substring(attName.indexOf("_uri_")+5, attName.lastIndexOf("_out_"));
		// new attribute names
		else if(attName.indexOf("_in_boolean")>0)
			return attName.substring(attName.indexOf("_in_boolean_")+12);
		else
			return attName.substring(attName.indexOf("_out_boolean_")+13);
	}

	// old: country_uri_http://dbpedia.org/ontology/birthPlace_type_http://dbpedia.org/class/yago/ExpatriateFootballersInGabon_in_boolean
	// new: country_uri_out/in_type_numeric/boolean_http://dbpedia.org/ontology/birthPlace_http://dbpedia.org/class/yago/ExpatriateFootballersInGabon
	private static String getTypeURIFromQualifiedRelationAttribute(String attName) {
		if(attName.contains("_type_http://"))
			if(attName.contains("_in_"))
				return attName.substring(attName.indexOf("_type_")+6, attName.lastIndexOf("_in_"));
			else
				return attName.substring(attName.indexOf("_type_")+6, attName.lastIndexOf("_out_"));
		else
			return attName.substring(attName.lastIndexOf("http://"));
	}

	private static String getURIFromTypeAttribute(String attName) {
		return attName.substring(attName.indexOf("_type_")+6);
	}

	private static String getURIFromDataAttribute(String attName) {
		return attName.substring(attName.indexOf("_data_")+6);
	}

}
