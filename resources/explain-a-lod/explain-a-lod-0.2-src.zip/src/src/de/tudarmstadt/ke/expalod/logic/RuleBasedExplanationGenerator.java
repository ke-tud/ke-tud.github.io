package de.tudarmstadt.ke.expalod.logic;

import java.util.List;

import weka.core.Instances;
import de.tudarmstadt.ke.expalod.eval.ExplanationRule;

public interface RuleBasedExplanationGenerator {
	public List<ExplanationRule> getRules(Instances instances);
}
