package de.tudarmstadt.ke.expalod.gui;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JOptionPane;

import weka.core.Instances;
import weka.core.converters.CSVLoader;

public class ExpaLODGUI {
	
	private static ExpaLODGUI instance = new ExpaLODGUI();
	private ExpaLODMainWindow mainWindow;

	/**
	 * 
	 */
	public ExpaLODGUI() {
		mainWindow = new ExpaLODMainWindow();
	}
	
	public ExpaLODMainPanel getMainWindow() {
		return mainWindow.getMainPanel();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		getInstance();
	}
	
	public static ExpaLODGUI getInstance() {
		return instance;
	}
	
	public void endExpaLOD() {
		System.exit(0);
	}
	
	public void loadARFFFile(File f) {
		Instances instances = null;
		try {
			instances = new Instances(new FileReader(f));
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog(mainWindow, "File not found", e.getMessage(), JOptionPane.ERROR_MESSAGE);
			return;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(mainWindow, "Error reading file", e.getMessage(), JOptionPane.ERROR_MESSAGE);
		}

		instances.setClassIndex(instances.numAttributes()-1);
		
		ExplanationPanel panel = new ExplanationPanel();
		panel.setInstances(instances);
		mainWindow.displayPanel(panel);
	}

	public void loadCSVFile(File selectedFile) {
		CSVLoader loader = new CSVLoader();
		Instances instances = null;
		try {
			loader.setSource(selectedFile);
			instances = loader.getDataSet();
		} catch(Exception e) {
			e.printStackTrace();
			// TODO better error handling
		}
		
		FeatureGenerationPanel panel = new FeatureGenerationPanel(instances,selectedFile.getAbsolutePath(),this);
		mainWindow.displayPanel(panel);
	}

	public void exit() {
		System.exit(0);
	}

}
