package de.tudarmstadt.ke.expalod.verbalize;

import java.util.Enumeration;
import java.util.List;

import com.hp.hpl.jena.sparql.function.library.e;

import weka.core.Attribute;
import weka.core.Instances;
import de.tudarmstadt.ke.expalod.eval.EvaluatedAttribute;

/**
 * Create a text explanation for a simple correlation.
 * @author paulheim
 *
 */
public class SimpleCorrelationVerbalizer {
	private OntologyVerbalizer ontologyVerbalizer = new OntologyVerbalizer();

	private Attribute classAttribute;
	
	/**
	 * Generate a text explanation
	 * @param EA an evaluated attribute, i.e., an attribute with a computed correlation.
	 * @param instances The instance set.
	 * @return
	 */
	public String generateExplanation(EvaluatedAttribute EA, Instances instances) {
		String sourceName = instances.attribute(0).name();
		String targetName = instances.classAttribute().name();
		classAttribute = instances.classAttribute();
		
		System.out.println(AttributeProcessor.getAttributeType(EA.getAttribute().name()));
		if(AttributeProcessor.getAttributeType(EA.getAttribute().name())!=null)
			switch(AttributeProcessor.getAttributeType(EA.getAttribute().name())) {
			case TYPE: return generateExplanationForTypeAttribute(EA, sourceName, targetName);
			case DATA: if(!EA.getAttribute().isNominal()) 
						return generateExplanationForDataAttribute(EA, sourceName, targetName);
					   break;
			case UNQUALIFIED_IN_BOOLEAN: return generateExplanationForUnqualifiedRelationInBoolean(EA, sourceName, targetName);
			case UNQUALIFIED_IN_NUM: return generateExplanationForUnqualifiedRelationInNum(EA, sourceName, targetName);
			case UNQUALIFIED_OUT_BOOLEAN: return generateExplanationForUnqualifiedRelationOutBoolean(EA, sourceName, targetName);
			case UNQUALIFIED_OUT_NUM: return generateExplanationForUnqualifiedRelationOutNum(EA, sourceName, targetName);
			case QUALIFIED_IN_BOOLEAN: return generateExplanationForQualifiedRelationInBoolean(EA, sourceName, targetName);
			case QUALIFIED_IN_NUM: return generateExplanationForQualifiedRelationInNum(EA, sourceName, targetName);
			case QUALIFIED_OUT_BOOLEAN: return generateExplanationForQualifiedRelationOutBoolean(EA, sourceName, targetName);
			case QUALIFIED_OUT_NUM: return generateExplanationForQualifiedRelationOutNum(EA, sourceName, targetName);
		}
		
		return null;
	}
	
	private String generateExplanationForDataAttribute(EvaluatedAttribute EA,
			String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		return "<html>A " + sourceName + " with a high value of <i>" + ontologyVerbalizer.getNameForURI(AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name()).get(0)) + "</i><br>has " + qualifier + " " + targetName + "</html>";
	}

	private String generateExplanationForTypeAttribute(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		return "<html>A " + sourceName + " of type <i>" + ontologyVerbalizer.getNameForURI(AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name()).get(0)) + "</i><br>has " + qualifier + " " + targetName + "</html>";
	}
	
	private String generateExplanationForUnqualifiedRelationInBoolean(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		return "<html>A " + sourceName + " that has something which [is/has] <i>" + ontologyVerbalizer.getNameForURI(AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name()).get(0))  + "</i> [in/of] that " + sourceName + "<br>has " + qualifier + " " + targetName + "</html>";
	}
	
	private String generateExplanationForUnqualifiedRelationInNum(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		return "<html>A " + sourceName + " that has many things which [are/have] <i>" + ontologyVerbalizer.getNameForURI(AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name()).get(0))  + "<i> [in/of] that " + sourceName + "<br>has " + qualifier + " " + targetName + "</html>";
	}
	
	private String generateExplanationForQualifiedRelationInBoolean(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		List<String> uris = AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name());
		return "<html>A " + sourceName + " that has some <i>" + ontologyVerbalizer.getNameForURI(uris.get(1)) + "</i> which [are/have] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [in/of] that " + sourceName + "<br>has " + qualifier + " " + targetName + "</html>";   
	}
	
	private String generateExplanationForQualifiedRelationInNum(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		List<String> uris = AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name());
		return "<html>A " + sourceName + " that has many <i>" + ontologyVerbalizer.getNameForURI(uris.get(1)) + "</i> which [are/have] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [in/of] that " + sourceName + "<br>has " + qualifier + " " + targetName + "</html>";   
	}
	
	private String generateExplanationForUnqualifiedRelationOutBoolean(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		return "<html>A " + sourceName + " which [is/has] <i>" + ontologyVerbalizer.getNameForURI(AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name()).get(0))  + "</i> [of/for] something<br>has " + qualifier + " " + targetName + "</html>";
	}
	
	private String generateExplanationForUnqualifiedRelationOutNum(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		return "<html>A " + sourceName + " which [is/has] <i>" + ontologyVerbalizer.getNameForURI(AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name()).get(0))  + "</i> [of/for] many things<br>has " + qualifier + " " + targetName + "</html>";
	}
	
	private String generateExplanationForQualifiedRelationOutBoolean(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		List<String> uris = AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name());
		return "<html>A " + sourceName + " which [is/has] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [of/for] some <i>" + ontologyVerbalizer.getNameForURI(uris.get(1)) +"</i><br>has " + qualifier + " " + targetName + "</html>";
	}
	
	private String generateExplanationForQualifiedRelationOutNum(EvaluatedAttribute EA, String sourceName, String targetName) {
		String qualifier = getQualifier(EA);
		List<String> uris = AttributeProcessor.getURIsFromAttributeName(EA.getAttribute().name());
		return "<html>A " + sourceName + " which [is/has] <i>" + ontologyVerbalizer.getNameForURI(uris.get(0))  + "</i> [of/for] many <i>" + ontologyVerbalizer.getNameForURI(uris.get(1)) + "</i><br>has " + qualifier + " " + targetName + "</html>";
	}
	
	/**
	 * TODO works only for nominal attributes with two values
	 * check that!
	 * @param EA
	 * @return
	 */
	private String getQualifier(EvaluatedAttribute EA) {
		if(classAttribute.isNumeric())
			return EA.getEvaluation()<0 ? "low" : "high"; 
		else {
			Enumeration e = classAttribute.enumerateValues();
			if(EA.getEvaluation()<0) {
				// first value
				return e.nextElement().toString();
			} else {
				// last value
				String s = e.nextElement().toString();
				while(e.hasMoreElements())
					s = e.nextElement().toString();
				return s;
			}
		}
	}
}
