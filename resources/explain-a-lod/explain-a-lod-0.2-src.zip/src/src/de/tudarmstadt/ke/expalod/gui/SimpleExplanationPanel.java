package de.tudarmstadt.ke.expalod.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import de.tudarmstadt.ke.expalod.eval.AttributeEvaluation;
import de.tudarmstadt.ke.expalod.eval.EvaluatedAttribute;
import de.tudarmstadt.ke.expalod.verbalize.SimpleCorrelationVerbalizer;

public class SimpleExplanationPanel extends JPanel {
	
	// TODO configuration option!
	private double threshold = 0.05;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3214237450663161728L;
	private ExplanationPanel explanationPanel;

	public SimpleExplanationPanel(ExplanationPanel EP) {
		explanationPanel = EP;
		
		JPanel explanations = new JPanel();
		explanations.setLayout(new GridBagLayout());
// 		explanations.setLayout(new BoxLayout(explanations,BoxLayout.Y_AXIS));
		
		// generate evaluation
		AttributeEvaluation eval = new AttributeEvaluation();
		List<EvaluatedAttribute> orderAttributes = eval.orderAttributes(EP.instances);
		SimpleCorrelationVerbalizer SCV = new SimpleCorrelationVerbalizer();
		int n = 0;
		for(EvaluatedAttribute EA : orderAttributes) {
			if(Math.abs(EA.getEvaluation())>=threshold) {
				String explanation = SCV.generateExplanation(EA, EP.instances);
				if(explanation!=null) {
					SimpleExplanationLabel SEL = new SimpleExplanationLabel(explanation,EA.getEvaluation());
					GridBagConstraints GBC = new GridBagConstraints();
					GBC.fill = GridBagConstraints.HORIZONTAL;
					GBC.gridx = 0;
					GBC.gridy = n;
					explanations.add(SEL,GBC);
					GBC.gridy++;
					explanations.add(Box.createRigidArea(new Dimension(0,10)),GBC);
					n+=2;
				}
			}
		}
		
		this.setLayout(new BorderLayout());
		JScrollPane pane = new JScrollPane(explanations);
		pane.setViewportBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		
		this.add(pane,BorderLayout.CENTER);
	}
	
	private class SimpleExplanationLabel extends JPanel {

		private double absCorrelation;
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		
		public SimpleExplanationLabel(String expText, double correlation) {
			DecimalFormat df = new DecimalFormat( "0.0000" );
			df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.ENGLISH));
			
			JLabel text = new JLabel(expText);
			JLabel strength = new JLabel("Correlation: " + df.format(correlation));
			absCorrelation = Math.abs(correlation);
			strength.setFont(text.getFont().deriveFont(Font.ITALIC));
			this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
			this.add(text);
			this.add(strength);
			this.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		}
		
		@Override
		public Color getBackground() {
			int r = (int) ((1-absCorrelation) * 255);
			int g = (int) (absCorrelation * 255);
			int b = 0;
			return new Color(r,g,b).brighter().brighter();
		}
	}
}
