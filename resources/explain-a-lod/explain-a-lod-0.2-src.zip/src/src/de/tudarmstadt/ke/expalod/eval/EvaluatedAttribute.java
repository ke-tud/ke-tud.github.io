package de.tudarmstadt.ke.expalod.eval;

import weka.core.Attribute;

public class EvaluatedAttribute implements Comparable<EvaluatedAttribute> {

	private Attribute attribute;
	private Double evaluation;

	public EvaluatedAttribute(Attribute att, double eval) {
		attribute = att;
		evaluation = eval;
	}

	public int compareTo(EvaluatedAttribute other) {
		return evaluation.compareTo(other.evaluation);
	}

	public Attribute getAttribute() {
		return attribute;
	}

	public void setAttribute(Attribute attribute) {
		this.attribute = attribute;
	}

	public Double getEvaluation() {
		// for true/false attributes, if "true" is the first value, the correlation
		// is multiplied by -1, since "true" equals 0 and "false" equals 1 in that case.
		if(attribute.value(0).equalsIgnoreCase("true"))
			return -evaluation;
		return evaluation;
	}

	public void setEvaluation(Double evaluation) {
		this.evaluation = evaluation;
	}
}
