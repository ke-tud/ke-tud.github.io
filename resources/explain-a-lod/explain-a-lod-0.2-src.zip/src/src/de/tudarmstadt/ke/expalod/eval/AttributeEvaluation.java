package de.tudarmstadt.ke.expalod.eval;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.List;

import weka.attributeSelection.CfsSubsetEval;
import weka.attributeSelection.GainRatioAttributeEval;
import weka.attributeSelection.SymmetricalUncertAttributeEval;
import weka.core.Attribute;
import weka.core.Instances;

public class AttributeEvaluation {

	public List<EvaluatedAttribute> orderAttributes(Instances instances) {
		List<EvaluatedAttribute> lstEvaluations = computeSignificance(instances);
		
		// sort in descending order
		Collections.sort(lstEvaluations, new Comparator<EvaluatedAttribute>() {
			@Override
			public int compare(EvaluatedAttribute o1, EvaluatedAttribute o2) {
				return - (new Double(Math.abs(o1.getEvaluation())).compareTo(Math.abs(o2.getEvaluation())));
			}
		});
		return lstEvaluations;
	}
	
	private List<EvaluatedAttribute> computeGainRatio(Instances instances) {
		List<EvaluatedAttribute> lstEvaluations = new ArrayList<EvaluatedAttribute>();
		
		GainRatioAttributeEval eval = new GainRatioAttributeEval();
		try {
			instances.deleteStringAttributes();
			eval.buildEvaluator(instances);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
			System.exit(-1);
		}
		
	
		Enumeration ea = instances.enumerateAttributes();
		while(ea.hasMoreElements()) {
			Attribute att = (Attribute) ea.nextElement();
			try {
				lstEvaluations.add(new EvaluatedAttribute(att,eval.evaluateAttribute(att.index())));
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
				e.printStackTrace();
				System.exit(-1);
			}
		}
		
		return lstEvaluations;
	}
	
	private List<EvaluatedAttribute> computeSymmetricalUncertainty(Instances instances) {
		List<EvaluatedAttribute> lstEvaluations = new ArrayList<EvaluatedAttribute>();
		
		SymmetricalUncertAttributeEval eval = new SymmetricalUncertAttributeEval();
		try {
			instances.deleteStringAttributes();
			eval.buildEvaluator(instances);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
			System.exit(-1);
		}
		

		Enumeration ea = instances.enumerateAttributes();
		while(ea.hasMoreElements()) {
			Attribute att = (Attribute) ea.nextElement();
			try {
				lstEvaluations.add(new EvaluatedAttribute(att,eval.evaluateAttribute(att.index())));
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
				e.printStackTrace();
				System.exit(-1);
			}
		}
		
		return lstEvaluations;
	}
	
	private List<EvaluatedAttribute> computeSignificance(Instances i) {
		Instances instances = new Instances(i);
		
		List<EvaluatedAttribute> lstEvaluations = new ArrayList<EvaluatedAttribute>();

		CfsSubsetEval eval = new CfsSubsetEval();
		try {
			instances.deleteStringAttributes();
			eval.buildEvaluator(instances);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			e.printStackTrace();
			System.exit(-1);
		}
		
	
		Enumeration ea = instances.enumerateAttributes();
		while(ea.hasMoreElements()) {
			Attribute att = (Attribute) ea.nextElement();
			if(att.index() != instances.classIndex()) {
				lstEvaluations.add(new EvaluatedAttribute(att, getPearsonCorrelation(instances.attributeToDoubleArray(instances.classIndex()), instances.attributeToDoubleArray(att.index()) )));
			}
		}
		
		return lstEvaluations;
	}
	
    private static double getPearsonCorrelation(double[] scores1,double[] scores2){
        double result = 0;
        double sum_sq_x = 0;
        double sum_sq_y = 0;
        double sum_coproduct = 0;
        double mean_x = scores1[0];
        double mean_y = scores2[0];
        for(int i=2;i<scores1.length+1;i+=1){
        	if(!Double.isNaN(scores1[i-1]) && !Double.isNaN(scores2[i-1])) {
                double sweep =Double.valueOf(i-1)/i;
                double delta_x = scores1[i-1]-mean_x;
                double delta_y = scores2[i-1]-mean_y;
                sum_sq_x += delta_x * delta_x * sweep;
                sum_sq_y += delta_y * delta_y * sweep;
                sum_coproduct += delta_x * delta_y * sweep;
                mean_x += delta_x / i;
                mean_y += delta_y / i;
        	}
        }
        double pop_sd_x = (double) Math.sqrt(sum_sq_x/scores1.length);
        double pop_sd_y = (double) Math.sqrt(sum_sq_y/scores1.length);
        double cov_x_y = sum_coproduct / scores1.length;
        result = cov_x_y / (pop_sd_x*pop_sd_y);
        return result;
    }

}
