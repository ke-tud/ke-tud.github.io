package de.tudarmstadt.ke.expalod.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.filechooser.FileFilter;

public class StartPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6989463581183560505L;

	public StartPanel() {
		super();
		final StartPanel me = this;
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(Box.createRigidArea(new Dimension(10,10)));
		JButton csvButton = new JButton("Load new CSV file", new ImageIcon("resource/excel.gif"));
		csvButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		this.add(csvButton);
		csvButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jfc = new JFileChooser(new File("data"));
				jfc.addChoosableFileFilter(new FileFilter() {
					
					@Override
					public String getDescription() {
						return "*.csv";
					}
					
					@Override
					public boolean accept(File f) {
						return (f.getName().endsWith(".csv") || f.isDirectory());
					}
				});
				int n = jfc.showOpenDialog(me);
				if(n==JFileChooser.APPROVE_OPTION)
					ExpaLODGUI.getInstance().loadCSVFile(jfc.getSelectedFile());
			}
		});
		this.add(Box.createRigidArea(new Dimension(10,10)));
		JButton arffButton = new JButton("Load preprocessed ARFF file", new ImageIcon("resource/weka.gif"));
		this.add(arffButton);
		arffButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		arffButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jfc = new JFileChooser(new File("data"));
				jfc.addChoosableFileFilter(new FileFilter() {
					
					@Override
					public String getDescription() {
						return "*.arff";
					}
					
					@Override
					public boolean accept(File f) {
						return (f.getName().endsWith(".arff") || f.isDirectory());
					}
				});
				int n = jfc.showOpenDialog(me);
				if(n==JFileChooser.APPROVE_OPTION)
					ExpaLODGUI.getInstance().loadARFFFile(jfc.getSelectedFile());
			}
		});
	}
}
