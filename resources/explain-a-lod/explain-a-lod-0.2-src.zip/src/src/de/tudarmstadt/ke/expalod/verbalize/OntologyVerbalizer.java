package de.tudarmstadt.ke.expalod.verbalize;

public class OntologyVerbalizer {
	
	/** TODO: resolve URI, get labels, cache! **/
	public String getNameForURI(String uri) {
		System.out.println(uri);
		String relevantFragment = "";
		
		if(uri.indexOf("#")>0)
			relevantFragment = uri.substring(uri.lastIndexOf("#")+1);
		else
			relevantFragment = uri.substring(uri.lastIndexOf("/")+1);
		
		return relevantFragment;
	}
}
