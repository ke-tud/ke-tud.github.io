package de.tudarmstadt.fegelod.entityrecognition;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.Utils;
import weka.filters.SimpleFilter;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import de.tudarmstadt.fegelod.sparql.SPARQLEndpointQueryRunner;

public class SPARQLBasedEntityRecognition extends SimpleFilter {

	private static final long serialVersionUID = -5575703405185991751L;
	private String attributeNameToExpand;
	
	private List<String> types = new LinkedList<String>();
	
	private SPARQLEndpointQueryRunner queryRunner;
	
	private Map<String,String> cache = new HashMap<String,String>();
	
	private List<String> nonCapitalizedWords = new LinkedList<String>();

	public SPARQLBasedEntityRecognition() {
		super();
		for(String s : new String[]{"a", "an", "the", "but", "as", "if", "and", "or", "nor", "at", "of", "in", "from"}) {
			nonCapitalizedWords.add(s);
		}
	}
	
	@Override
	protected Instances determineOutputFormat(Instances instances) throws Exception {
		return createAttribute(instances);
	}

	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        vector.addElement(
            new Option(
        	"\tattribute name of the attribute to create URIs for)",
        	"A", 1, "-A <att-name>"));
        
        vector.addElement(
            new Option(
        	"\tTypes to check (such as dbpedia:City) as comma separated list - if not given, no typechecking will be applied",
        	"T", 1, "-T <type-uri>"));

        vector.addElement(
            new Option(
        	"\tURL of the SPARQL endpoint to use for querying",
        	"E", 1, "-E <endpoint-url>"));

        return vector.elements();
	}
	
	@Override
	public void setOptions(String[] options) throws Exception {
		boolean foundAttribute = false;
		boolean foundEndpoint = false;
		String attName = Utils.getOption('A', options);
        if(attName.length()!=0) {
        	foundAttribute = true;
        	attributeNameToExpand = attName;
        }
		String endpoint = Utils.getOption('E', options);
        if(endpoint.length()!=0) {
        	foundEndpoint = true;
        	queryRunner = new SPARQLEndpointQueryRunner(endpoint);
        }
        String typeURI = Utils.getOption('T', options);
        if(typeURI.length()!=0) {
        	if(!typeURI.contains(","))
        		types.add(typeURI);
        	else {
        		StringTokenizer stk = new StringTokenizer(typeURI,",");
        		while(stk.hasMoreElements())
        			types.add(stk.nextToken());
        	}
        }
        if(!foundAttribute) {
        	throw new IllegalArgumentException("Missing option -A");
        }
        if(!foundEndpoint) {
        	throw new IllegalArgumentException("Missing option -E");
        }
	}

	@Override
	public String globalInfo() {
		return "Adds URIs for an LOD endpoint for the values of a given attribute."; 
	}

	@Override
	protected boolean hasImmediateOutputFormat() {
		return false;
	}

	@Override
	public Instances process(Instances instances) throws Exception {
		instances = createAttribute(instances);
		Attribute oldatt = instances.attribute(attributeNameToExpand);
		Attribute newatt = instances.attribute(attributeNameToExpand + "_uri");
		float total = instances.numInstances();
		int found = 0;
		Enumeration einstances = instances.enumerateInstances();
		while(einstances.hasMoreElements()) {
			Instance i = (Instance) einstances.nextElement();
			String value = i.stringValue(oldatt);
			System.out.println("process " + value);
			String newValue = identify(value);
			if(newValue.length()>0)
				found++;
			i.setValue(newatt, newValue);
		}
		System.out.println("identified " + found/total * 100 + "%.");
		
		return instances;
	}
	
	private String identify(String value) {
		if(cache.containsKey(value)) 
			return cache.get(value);
		String guessedURI = guess(upperAllFirstChars(value));
		if(guessedURI!=null && types.size()>0) {
			boolean foundType = false;
			// perform typecheck
			for(String type : types) {
				String query = getSPARQLTypecheckQuery(guessedURI,type);
				if(queryRunner.runAskQuery(query)) {
					foundType = true;
				}
			}
			if(!foundType) {
				System.out.println("discarding " + guessedURI + " after type check");
				guessedURI = null;
			}
		}
		if(guessedURI!=null) {
			cache.put(value,guessedURI);
			return guessedURI;
		} else
			return "";
	}
	
	private String upperAllFirstChars(String s) {
		String ret = "";
		StringTokenizer stk = new StringTokenizer(s," ");
		while(stk.hasMoreElements()) {
			if(ret.length()>0)
				ret += " ";
			String tok = stk.nextToken();
			if(nonCapitalizedWords.contains(tok))
				ret += tok;
			else
				ret += upperFirstChar(tok);
		}
		return ret;
	}
	
	private String upperFirstChar(String s) {
		return s.substring(0,1).toUpperCase() + s.substring(1);
	}
	

	/**
	 * Performs a rough guess. Given a value, it tests if
	 * <http://dbpedia.org/resource/value> is a correct concept or wikipedia:redirects
	 * to a correct concept. 
	 * Preprocess: 
	 * @param value The name of the concept
	 * @return null if no guess was found
	 */
	private String guess(String value) {
		value = value.replace(' ','_');

		try {
			value = URLEncoder.encode(value,"utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		// check for resource or redirect
		String uri = "http://dbpedia.org/resource/" + value;
		String query = 	"SELECT DISTINCT ?r where {<" + uri + "> ?p ?o ." + 
						"OPTIONAL { <" + uri + "> <http://dbpedia.org/ontology/wikiPageRedirects> ?r.}}";
		ResultSet RS = queryRunner.runSelectQuery(query);
		
		if(RS.hasNext()) {
			QuerySolution QS = RS.next();
			// found a redirect -> return the redirect
			if(QS.getResource("r")!=null && QS.getResource("r").getURI().length()>0)
				return QS.getResource("r").getURI();
			else
				// found something, but no redirect -> return the uri itself
				return uri;
		}
		
		// no solution found
		// first heuristic: three-letter-words or letters mixed with numbers
		// are probably an abbreviation (to capitalize)
		StringTokenizer stk = new StringTokenizer(value,"_");
		String newValue = "";
		while(stk.hasMoreElements()) {
			String s = stk.nextToken();
			if((s.length()<=3 || s.matches(".*[0-9]+.*")) && !nonCapitalizedWords.contains(s))
				s = s.toUpperCase();
			if(newValue.length()>0)
				newValue += "_";
			newValue += s;
		}
		// non-tokenizable
		if(!value.contains("_"))
			newValue = value.toUpperCase();
		if(!value.equals(newValue))
			return guess(newValue);
		
		// no solution found: try again with smaller substring
		if(value.indexOf('_')>0) {
			value = value.substring(0,value.lastIndexOf('_'));
			return guess(value);
		}
		return null;
	}

	private Instances createAttribute(Instances instances) {
		if(attributeNameToExpand==null)
			throw new IllegalStateException("Not initialized. Call setOptions first.");
		int i = instances.attribute(attributeNameToExpand).index();
		Attribute a = new Attribute(attributeNameToExpand + "_uri", (FastVector)null,i+1);
		instances.insertAttributeAt(a, i+1);
		return instances;
	}
	
	private String getSPARQLTypecheckQuery(String uri, String type) {
		return 	"PREFIX rdf:  <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
				"ASK {<" + uri + "> rdf:type <"  + type + ">}";
	}

}
