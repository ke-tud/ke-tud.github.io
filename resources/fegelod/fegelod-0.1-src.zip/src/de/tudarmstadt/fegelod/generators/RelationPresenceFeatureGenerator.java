package de.tudarmstadt.fegelod.generators;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Option;
import weka.core.Utils;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import de.tudarmstadt.fegelod.util.AttributeTypeGuesser.attributeType;

/**
 * This generator creates a binary attribute (true|false) for incoming and outgoing
 * relations
 * e.g. for the triple
 * 	<http://foo.bar/s> <http://foo.bar/p> <http://foo.bar/o>
 * the relation uri_out_boolean_http://foo.bar/p would be set to true.
 * 
 * @author paulheim
 *
 */
public class RelationPresenceFeatureGenerator extends
		AbstractLODFeatureGenerator {

	private static final long serialVersionUID = -7091662773052559301L;
	
	private FastVector attributeValues = new FastVector();
	
	private String propertyNamespace;
	
	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        Enumeration<?> e = super.listOptions();
        while(e.hasMoreElements())
        	vector.add((Option)e.nextElement());
        
        vector.addElement(
    		new Option(
    		"\tuse only properties from a given namespace",
    		"PNS", 1, "-PNS <string>"));
        
        return vector.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		super.setOptions(options);
		
		String pn = Utils.getOption("PNS", options);
		if(pn!=null && pn.length()>0)
			propertyNamespace = pn;
	}
	
	public RelationPresenceFeatureGenerator() {
		attributeValues.addElement("true");
		attributeValues.addElement("false");
	}

	@Override
	protected void processInstance(Instance instance) {
		String uri = instance.stringValue(attributeToExpand);
		// incoming
		ResultSet RS1 = queryRunner.runSelectQuery(getSPARQLQueryIncoming(uri));
		while(RS1.hasNext()) {
			QuerySolution sol = RS1.next();
			String attName = attributeToExpand.name() + "_in_boolean_" + sol.get("p").toString();
			Attribute thisAtt = instances.attribute(attName);
			if(thisAtt==null) {
				thisAtt = createAttribute(attName, attributeType.nominal, attributeValues, "false");
			}
			instance.setValue(thisAtt, "true");
		}
		// outgoing
		ResultSet RS2 = queryRunner.runSelectQuery(getSPARQLQueryOutgoing(uri));
		while(RS2.hasNext()) {
			QuerySolution sol = RS2.next();
			String attName = attributeToExpand.name() + "_out_boolean_" + sol.get("p").toString();
			Attribute thisAtt = instances.attribute(attName);
			if(thisAtt==null) {
				thisAtt = createAttribute(attName, attributeType.nominal, attributeValues, "false");
			}
			instance.setValue(thisAtt, "true");
		}
	}
	
	@Override
	public String globalInfo() {
		return "This generator creates a binary attribute (true|false) for incoming and outgoing relations, depending on whether the relation is present or not.";
	}

	private String getSPARQLQueryOutgoing(String uri) {
		if(propertyNamespace!=null)
			return 	"SELECT DISTINCT ?p " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {<" + uri + "> ?p ?o . FILTER(REGEX(STR(?p),'^" + propertyNamespace + "'))}";
		else
			return 	"SELECT DISTINCT ?p " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {<" + uri + "> ?p ?o .}";
	}
	
	private String getSPARQLQueryIncoming(String uri) {
		if(propertyNamespace!=null)
			return 	"SELECT DISTINCT ?p " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {?s ?p <" + uri + ">. FILTER(REGEX(STR(?p),'^" + propertyNamespace + "'))}";
		else
			return 	"SELECT DISTINCT ?p " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {?s ?p <" + uri + ">.}";
	}
	
}
