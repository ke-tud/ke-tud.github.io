package de.tudarmstadt.fegelod.generators;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Option;
import weka.core.Utils;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import de.tudarmstadt.fegelod.util.AttributeTypeGuesser.attributeType;

/**
 * Generates a binary feature (true|false) for each type that the instance has.
 * e.g., x rdf:type <http://foo/bar> for the attribute att with value x would lead to
 * att_type_http://foo/bar = true for the instance x
 * 
 * @author paulheim
 *
 */
public class SimpleTypeFeatureGenerator extends AbstractLODFeatureGenerator {

	private static final long serialVersionUID = 2706971567583052123L;

	private FastVector attributeValues = new FastVector();
	
	private String typeNamespace;
	
	public SimpleTypeFeatureGenerator() {
		attributeValues.addElement("true");
		attributeValues.addElement("false");
	}
	
	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        Enumeration<?> e = super.listOptions();
        while(e.hasMoreElements())
        	vector.add((Option)e.nextElement());
        
        vector.addElement(
    		new Option(
    		"\tuse only types from a given namespace",
    		"TNS", 1, "-TNS <string>"));
        
        return vector.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		super.setOptions(options);
		
		String tn = Utils.getOption("TNS", options);
		if(tn!=null && tn.length()>0)
			typeNamespace = tn;

	}
	
	@Override
	protected void processInstance(Instance instance) {
		String uri = instance.stringValue(attributeToExpand);
		// incoming
		ResultSet RS = queryRunner.runSelectQuery(getSPARQLQuery(uri));
		while(RS.hasNext()) {
			QuerySolution sol = RS.next();
			String attName = attributeToExpand.name() + "_type_" + sol.get("t").toString();
			Attribute thisAtt = instances.attribute(attName);
			if(thisAtt==null) {
				thisAtt = createAttribute(attName, attributeType.nominal, attributeValues, "false");
			}
			instance.setValue(thisAtt, "true");
		}
	}

	@Override
	public String globalInfo() {
		return "Creates a binary attribute (true|false) for each <rdf:type> that an instance has."; 
	}

	private String getSPARQLQuery(String uri) {
		if(typeNamespace!=null)
			return 	"SELECT DISTINCT ?t " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {<" + uri + "> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?t . FILTER(REGEX(STR(?t),'^" + typeNamespace + "'))}";
		else
			return 	"SELECT DISTINCT ?t " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {<" + uri + "> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?t .}";
	}
}
