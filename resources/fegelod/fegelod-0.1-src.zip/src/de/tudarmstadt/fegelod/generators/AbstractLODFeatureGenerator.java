package de.tudarmstadt.fegelod.generators;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.Capabilities;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.Utils;
import weka.filters.SimpleFilter;
import de.tudarmstadt.fegelod.sparql.SPARQLQueryRunner;
import de.tudarmstadt.fegelod.util.AttributeTypeGuesser;
import de.tudarmstadt.fegelod.util.AttributeTypeGuesser.attributeType;

/**
 * This class is an abstract base class for all LOD-based Feature Generators
 * @author paulheim
 *
 */
public abstract class AbstractLODFeatureGenerator extends SimpleFilter {

	private static final long serialVersionUID = -2290891847523230275L;
	
	protected String attributeNameToExpand = null;
	protected Attribute attributeToExpand = null;
	
	protected Instances instances = null;
	
	protected SPARQLQueryRunner queryRunner = null;
	
	/**
	 * This map serves as a cache: it maps a value to the first instance which has this
	 * value. All subsequent instances can copy their attributes from this one.
	 */
	private Map<String,Instance> alreadyEncountered = new HashMap<String, Instance>();
	
	/**
	 * This list keeps track of all the attributes created.
	 */
	private List<Attribute> generatedAttributes = new LinkedList<Attribute>();

	@Override
	protected boolean hasImmediateOutputFormat() {
		return false;
	}
	
	@Override
	protected Instances determineOutputFormat(Instances instances) throws Exception {
		// as we cannot do this before the filter has hactually run, we apply the filter
		// whenever either this method or the process method is called
		if(this.instances == null) {
			this.instances = instances;
			doProcess();
		}
		return this.instances;
	}
	
	@Override
	public Capabilities getCapabilities() {
		Capabilities result = super.getCapabilities();
		result.enableAllAttributes();
		result.enableAllClasses();
		return result;
	}


	@Override
	public Instances process(Instances instances) throws Exception {
		if(this.instances == null) {
			this.instances = instances;
			doProcess();
		}
		return this.instances;
	}
	
	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        vector.addElement(
            new Option(
        	"\tattribute name of the attribute to create features for)",
        	"A", 1, "-A <att-name>"));
        
        return vector.elements();
	}
	
	@Override
	public void setOptions(String[] options) throws Exception {
		boolean foundAttribute = false;
		String attName = Utils.getOption('A', options);
        if(attName.length()!=0) {
        	foundAttribute = true;
        	attributeNameToExpand = attName;
        }
        if(!foundAttribute) {
        	throw new IllegalArgumentException("Missing option -A");
        }
	}
	
	public void setSPARQLQueryRunner(SPARQLQueryRunner queryRunner) {
		this.queryRunner = queryRunner;
	}
	
	/**
	 * starts the processing
	 * @param instances
	 * @return
	 */
	protected Instances doProcess() {
		attributeToExpand = instances.attribute(attributeNameToExpand);
		if(attributeToExpand==null)
			throw new IllegalStateException("Attribute " + attributeNameToExpand + " does not exist in dataset.");
		
		Enumeration<?> einstances = instances.enumerateInstances();
		while(einstances.hasMoreElements()) {
			Instance instance = (Instance) einstances.nextElement();
			if(instance.isMissing(attributeToExpand))
				continue;
			if(alreadyEncountered.containsKey(instance.stringValue(attributeToExpand))) {
				// copy values from cache
				Instance copyInstance = alreadyEncountered.get(instance.stringValue(attributeToExpand));
				for(Attribute att : generatedAttributes) {
					instance.setValue(att, copyInstance.value(att));
				}
			} else {
				System.out.println("process " + instance.stringValue(attributeToExpand));
				processInstance(instance);
				// put instance in cache
				alreadyEncountered.put(instance.stringValue(attributeToExpand), instance);
			}
		}
		
		return instances;
	}
	
	protected abstract void processInstance(Instance instance);

	/**
	 * Creates a new attribute
	 * @param name the attribute to create
	 * @param type the type of the attribute to create.
	 * @param values The value space of the attribute (only nominal attributes)
	 * @param defaultValue the default value. null creates missing values.
	 * @return
	 */
	protected Attribute createAttribute(String name, AttributeTypeGuesser.attributeType type,  FastVector values, String defaultValue) {
		// insert at the end of the generated attributes
		int newIndex = attributeToExpand.index() + generatedAttributes.size() + 1;

		Attribute att = null;
		if(type==attributeType.numeric)
			att = new Attribute(name, newIndex);
		else if(type==attributeType.date)
			att = new Attribute(name, "yyyy-MM-dd", newIndex);
		else if(type==attributeType.nominal||type==attributeType.string) {
			att = new Attribute(name, values, newIndex);
		} else
			throw new IllegalArgumentException("Type " + type + " not supported.");
		
		generatedAttributes.add(att);
		instances.insertAttributeAt(att, newIndex);
		
		if(defaultValue!=null)
			setMissingValuesToDefault(instances, att, defaultValue);
		
		return att;
	}
	
	private void setMissingValuesToDefault(Instances instances, Attribute att, String defaultValue) {
		Enumeration<?> einstances = instances.enumerateInstances();
		while(einstances.hasMoreElements()) {
			Instance instance = (Instance) einstances.nextElement();
			if(instance.isMissing(att) && !instance.isMissing(attributeToExpand))
				if(att.isNumeric())
					instance.setValue(att, Double.parseDouble(defaultValue));
				else
					instance.setValue(att, defaultValue);
		}
	}
}
