package de.tudarmstadt.fegelod.generators;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Option;
import weka.core.Utils;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Literal;

import de.tudarmstadt.fegelod.util.AttributeTypeGuesser;
import de.tudarmstadt.fegelod.util.AttributeTypeGuesser.attributeType;

/**
 * Generates an attribute for each data property.
 * 
 * e.g., for the triple <http://foo.bar/x> <http://foo.bar/y> 12^^xsd:int,
 * where <http://foo.bar/x> is the value of the attribute to expand,
 * a new attribute http://foo.bar/y with value 12 would be inserted
 * 
 * All instances which do not have that attribute get a ? entry.
 * 
 * String-valued data properties are used optionally ("-S true").
 * 
 * Note: for attributes with multiple values, one value is randomly chosen.
 * 
 * @author paulheim
 *
 */
public class DataPropertyFeatureGenerator extends AbstractLODFeatureGenerator {

	private static final long serialVersionUID = 8357512091275567443L;
	
	private AttributeTypeGuesser attributeTypeGuesser = new AttributeTypeGuesser();
	
	private boolean useStringAttributes;
	
	private String propertyNamespace;
	
	@Override
	public String globalInfo() {
		return "Creates features for datatype attributes of a resource";
	}

	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        Enumeration<?> e = super.listOptions();
        while(e.hasMoreElements())
        	vector.add((Option)e.nextElement());
        
        vector.addElement(
            new Option(
        	"\tuse string attributes for building nominal attributes (default: false)",
        	"S", 1, "-S <true|false>"));
        
        vector.addElement(
    		new Option(
    		"\tuse only properties from a given namespace",
    		"PNS", 1, "-PNS <string>"));
        
        return vector.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		super.setOptions(options);
		
		String useStrings = Utils.getOption('S', options);
		useStringAttributes = useStrings.length()>0 && useStrings.equalsIgnoreCase("true");
	
		String pn = Utils.getOption("PNS", options);
		if(pn!=null && pn.length()>0)
			propertyNamespace = pn;
	}
	
	@Override
	protected void processInstance(Instance instance) {
		String uri = instance.stringValue(attributeToExpand);
		ResultSet RS = queryRunner.runSelectQuery(getSPARQLQuery(uri));
		while(RS.hasNext()) {
			QuerySolution sol = RS.next();
			String attName = attributeToExpand.name() + "_data_" + sol.get("p").toString();
			Attribute thisAtt = instances.attribute(attName);
			Literal attValueLiteral = sol.getLiteral("v"); 
			if(thisAtt==null) {
				// create attribute, if not present yet
				// semi-intelligently typed
				attributeType attType = attributeTypeGuesser.guessAttributeType(attValueLiteral);
				if(useStringAttributes || !attType.equals(attributeType.string))
					thisAtt = createAttribute(attName, attType, null, null);
			}
			// the second condition ensures that each attribute is only filled once
			if(thisAtt!=null  && instance.isMissing(thisAtt)) {
				if(thisAtt.isNumeric()) {
					try {
						instance.setValue(thisAtt, Double.parseDouble(sol.getLiteral("v").getString()));
					} catch (java.lang.NumberFormatException ex) {
						// do nothing - just skip it
					}
				}
				if(thisAtt.isString()) {
					String value = sol.getLiteral("v").getString();
					instance.setValue(thisAtt, value);
				}
			}
		}
		
	}
	
	private String getSPARQLQuery(String uri) {
		String filters = "";
		if(!useStringAttributes)
			filters += " && DATATYPE(?v)!=<http://www.w3.org/2001/XMLSchema#string>";
		if(propertyNamespace!=null)
			filters += " && REGEX(STR(?p),'^" + propertyNamespace + "')";
		
		return 	"SELECT ?p ?v " + 
				"FROM <http://dbpedia.org> " +
				"WHERE {<" + uri + "> ?p ?v . FILTER(isLITERAL(?v) " + filters + ")}";
	}

}
