package de.tudarmstadt.fegelod.generators;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Option;
import weka.core.Utils;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import de.tudarmstadt.fegelod.util.AttributeTypeGuesser.attributeType;

/**
 * This generator creates a binary attribute (true|false) for outgoing data
 * relations to a literal of a certain type
 * e.g. for the triple
 * 	<http://foo.bar/s> <http://foo.bar/p> "123"^^xsd:int
 * the relation uri_out_datatype_boolean_http://foo.bar/p_http://www.w3.org/2001/XMLSchema#int
 * would be set to "true".
 * 
 * @author paulheim
 *
 */
public class RelationDatatypePresenceFeatureGenerator extends
		AbstractLODFeatureGenerator {

	private static final long serialVersionUID = 999257341031449719L;

	private FastVector attributeValues = new FastVector();
	
	private String propertyNamespace;
	
	public RelationDatatypePresenceFeatureGenerator() {
		attributeValues.addElement("true");
		attributeValues.addElement("false");
	}

	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        Enumeration<?> e = super.listOptions();
        while(e.hasMoreElements())
        	vector.add((Option)e.nextElement());
        
        vector.addElement(
    		new Option(
    		"\tuse only properties from a given namespace",
    		"PNS", 1, "-PNS <string>"));
        
        return vector.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		super.setOptions(options);
		
		String pn = Utils.getOption("PNS", options);
		if(pn!=null && pn.length()>0)
			propertyNamespace = pn;
	}
	
	@Override
	protected void processInstance(Instance instance) {
		String uri = instance.stringValue(attributeToExpand);
		ResultSet RS = queryRunner.runSelectQuery(getSPARQLQueryOutgoing(uri));
		while(RS.hasNext()) {
			QuerySolution sol = RS.next();
			String datatype = sol.getLiteral("o").getDatatypeURI();
			if(datatype!=null) {
				String attName = attributeToExpand.name() + "_out_datatype_boolean_" + sol.get("p").toString() + "_" + datatype;
				Attribute thisAtt = instances.attribute(attName);
				if(thisAtt==null) {
					createAttribute(attName, attributeType.nominal, attributeValues, "false");
				}
				instance.setValue(thisAtt, "true");
			}
		}
	}
	
	@Override
	public String globalInfo() {
		return "This generator creates a binary attribute (true|false) for incoming and outgoing relations from/to an object from a certain type.";
	}

	private String getSPARQLQueryOutgoing(String uri) {
		String filters = "";
		if(propertyNamespace!=null)
			filters += " && REGEX(STR(?p),'^" + propertyNamespace + "')";

		return 	"SELECT DISTINCT ?p ?o " + 
				"FROM <http://dbpedia.org> " +
				"WHERE {<" + uri + "> ?p ?o . FILTER(isLITERAL(?o) " + filters + ")}";
	}
	

}
