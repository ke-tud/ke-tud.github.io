package de.tudarmstadt.fegelod.generators;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Option;
import weka.core.Utils;

import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;

import de.tudarmstadt.fegelod.util.AttributeTypeGuesser.attributeType;

/**
 * This generator creates a binary attribute (true|false) for incoming and outgoing
 * relations from/to an object from a certain type
 * e.g. for the triples
 * 	<http://foo.bar/s> <http://foo.bar/p> <http://foo.bar/o>
 *  <http://foo.bar/o> rdf:type <http://foo.bar/t>
 * the relation uri_in_type_boolean_http://foo.bar/p_type_http://foo.bar/t would be set to "true".
 * 
 * @author paulheim
 *
 */
public class RelationTypePresenceFeatureGenerator extends
		AbstractLODFeatureGenerator {

	private static final long serialVersionUID = 999257341031449719L;

	private FastVector attributeValues = new FastVector();
	
	private String propertyNamespace;
	private String typeNamespace;
	
	public RelationTypePresenceFeatureGenerator() {
		attributeValues.addElement("true");
		attributeValues.addElement("false");
	}

	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        Enumeration<?> e = super.listOptions();
        while(e.hasMoreElements())
        	vector.add((Option)e.nextElement());
        
        vector.addElement(
    		new Option(
    		"\tuse only properties from a given namespace",
    		"PNS", 1, "-PNS <string>"));
        
        vector.addElement(
    		new Option(
    		"\tuse only types from a given namespace",
    		"TNS", 1, "-TNS <string>"));
        
        return vector.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		super.setOptions(options);
		
		String pn = Utils.getOption("PNS", options);
		if(pn!=null && pn.length()>0)
			propertyNamespace = pn;

		String tn = Utils.getOption("TNS", options);
		if(tn!=null && tn.length()>0)
			typeNamespace = tn;

	}
	
	@Override
	protected void processInstance(Instance instance) {
		String uri = instance.stringValue(attributeToExpand);
		// incoming
		ResultSet RS1 = queryRunner.runSelectQuery(getSPARQLQueryIncoming(uri));
		while(RS1.hasNext()) {
			QuerySolution sol = RS1.next();
			String attName = attributeToExpand.name() + "_in_type_boolean_" + sol.get("p").toString() + "_" + sol.get("t").toString();
			Attribute thisAtt = instances.attribute(attName);
			if(thisAtt==null) {
				thisAtt = createAttribute(attName, attributeType.nominal, attributeValues, "false");
			}
			instance.setValue(thisAtt, "true");
		}
		// outgoing
		ResultSet RS2 = queryRunner.runSelectQuery(getSPARQLQueryOutgoing(uri));
		while(RS2.hasNext()) {
			QuerySolution sol = RS2.next();
			String attName = attributeToExpand.name() + "_out_type_boolean_" + sol.get("p").toString() + "_" + sol.get("t").toString();
			Attribute thisAtt = instances.attribute(attName);
			if(thisAtt==null) {
				thisAtt = createAttribute(attName, attributeType.nominal, attributeValues, "false");
			}
			instance.setValue(thisAtt, "true");
		}
	}
	
	@Override
	public String globalInfo() {
		return "This generator creates a binary attribute (true|false) for incoming and outgoing relations from/to an object from a certain type.";
	}

	private String getSPARQLQueryIncoming(String uri) {
		String filters = "";
		if(propertyNamespace!=null)
			if(filters.length()==0)
				filters += " REGEX(STR(?p),'^" + propertyNamespace + "')";
			else
				filters += " && REGEX(STR(?p),'^" + propertyNamespace + "')";
		if(typeNamespace!=null)
			if(filters.length()==0)
				filters += " REGEX(STR(?t),'^" + typeNamespace + "')";
			else
				filters += " && REGEX(STR(?t),'^" + typeNamespace + "')";
				

		if(filters!="")
			return 	"SELECT DISTINCT ?p ?t " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {?s ?p <" + uri + ">. ?s <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?t . FILTER(" + filters + ")}";
		else
			return 	"SELECT DISTINCT ?p ?t " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {?s ?p <" + uri + ">. ?s <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?t .}";
	}

	private String getSPARQLQueryOutgoing(String uri) {
		String filters = "";
		if(propertyNamespace!=null)
			if(filters.length()==0)
				filters += " REGEX(STR(?p),'^" + propertyNamespace + "')";
			else
				filters += " && REGEX(STR(?p),'^" + propertyNamespace + "')";
		if(typeNamespace!=null)
			if(filters.length()==0)
				filters += " REGEX(STR(?t),'^" + typeNamespace + "')";
			else
				filters += " && REGEX(STR(?t),'^" + typeNamespace + "')";

		if(filters!="")
			return 	"SELECT DISTINCT ?p ?t " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {<" + uri + "> ?p ?o . ?o <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?t . FILTER(" + filters + ")}";
		else
			return 	"SELECT DISTINCT ?p ?t " + 
					"FROM <http://dbpedia.org> " +
					"WHERE {<" + uri + "> ?p ?o . ?o <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> ?t .}";
	}
	

}
