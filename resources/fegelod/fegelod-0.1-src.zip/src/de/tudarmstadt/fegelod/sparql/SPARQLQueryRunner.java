package de.tudarmstadt.fegelod.sparql;

import com.hp.hpl.jena.query.ResultSet;

public interface SPARQLQueryRunner {
	public ResultSet runSelectQuery(String query);
	public boolean runAskQuery(String query);
}
