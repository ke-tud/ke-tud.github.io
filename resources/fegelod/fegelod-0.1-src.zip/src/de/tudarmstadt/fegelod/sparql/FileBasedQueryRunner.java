package de.tudarmstadt.fegelod.sparql;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;

public class FileBasedQueryRunner implements SPARQLQueryRunner {

	Model model;
	
	public FileBasedQueryRunner(String filename, String schemaFilename) {
		Model instanceModel = ModelFactory.createDefaultModel();
		Model schemaModel = ModelFactory.createDefaultModel();
		FileInputStream FIS1;
		FileInputStream FIS2;
		try {
			FIS1 = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("File " + filename + " does not exist.");
		}
		try {
			FIS2 = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("File " + schemaFilename + " does not exist.");
		}
		if(filename.endsWith("n3"))
			instanceModel.read(FIS1,null,"N-TRIPLES");
		else
			instanceModel.read(FIS1,null);
		if(schemaFilename.endsWith("n3"))
			schemaModel.read(FIS2,null,"N-TRIPLES");
		else
			schemaModel.read(FIS2,null);
		
		model = ModelFactory.createRDFSModel(schemaModel, instanceModel);
	}
	
	public FileBasedQueryRunner(String filename) {
		model = ModelFactory.createDefaultModel();
		FileInputStream FIS;
		try {
			FIS = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("File " + filename + " does not exist.");
		}
		if(filename.endsWith("n3"))
			model.read(FIS,null,"N-TRIPLES");
		else
			model.read(FIS,null);
	}
	
	@Override
	public ResultSet runSelectQuery(String query) {
		Query q = QueryFactory.create(query);
		QueryExecution qexec = QueryExecutionFactory.create(q, model);
		return qexec.execSelect();
	}
	
	@Override 
	public boolean runAskQuery(String query) {
		Query q = QueryFactory.create(query);
		QueryExecution qexec = QueryExecutionFactory.create(q, model);
		return qexec.execAsk();
	}

}
