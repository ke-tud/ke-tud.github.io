package de.tudarmstadt.fegelod.sparql;

import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.sparql.engine.http.QueryExceptionHTTP;

public class SPARQLEndpointQueryRunner implements SPARQLQueryRunner {
	private String endpoint;
	
	public SPARQLEndpointQueryRunner(String endpoint) {
		this.endpoint = endpoint;
	}
	
	public ResultSet runSelectQuery(String query) {
		Query q = QueryFactory.create(query);
		QueryExecution qexec = QueryExecutionFactory.sparqlService(endpoint, q);
		// retry every 100 millis if the endpoint goes down
		while(true) {
			int retries = 0;
			try {
				return qexec.execSelect();
			}
			catch(Exception ex) {
				retries++;
				if(retries>10) {
					ex.printStackTrace();
					System.exit(-1);
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
			}
		}
	}

	public boolean runAskQuery(String query) {
		Query q = QueryFactory.create(query);
		QueryExecution qexec = QueryExecutionFactory.sparqlService(endpoint, q);
		// retry every 100 millis if the endpoint goes down
		while(true) {
			int retries = 0;
			try {
				return qexec.execAsk();
			}
			catch(Exception ex) {
				retries++;
				if(retries>10) {
					ex.printStackTrace();
					System.exit(-1);
				}
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
			}
		}
	}

}
