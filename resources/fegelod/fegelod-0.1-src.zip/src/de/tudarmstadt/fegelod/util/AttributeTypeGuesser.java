package de.tudarmstadt.fegelod.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import com.hp.hpl.jena.rdf.model.Literal;

/**
 * Gets a literal, guesses an appropriate value for the corresponding WEKA attribute
 * @author paulheim
 */

public class AttributeTypeGuesser {
	
	private Collection<String> numericTypes;
	private Collection<String> dateTypes;
	
	public AttributeTypeGuesser() {
		numericTypes = new HashSet<String>();
		numericTypes.add("http://www.w3.org/2001/XMLSchema#decimal");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#integer");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#long");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#int");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#short");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#byte");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#float");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#double");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#unsignedLong");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#unsignedInt");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#unsignedShort");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#unsignedByte");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#positiveInteger");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#negativeInteger");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#nonPositiveInteger");
		numericTypes.add("http://www.w3.org/2001/XMLSchema#nonNegativeInteger");
		dateTypes = new HashSet<String>();
		dateTypes.add("http://www.w3.org/2001/XMLSchema#date");
	}
	
	public static enum attributeType {numeric,string,nominal,date};
	
	public attributeType guessAttributeType(Literal literal) {
		if(numericTypes.contains(literal.getDatatypeURI()))
			return attributeType.numeric;
		// an even rougher guess
		try {
			Double.parseDouble(literal.getString());
			System.out.println("rough numeric");
			return attributeType.numeric;
		} catch (NumberFormatException e) {
		}
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			sdf.parse(literal.toString());
			System.out.println("rough date");
			return attributeType.date;
		} catch (ParseException e) {
		}
//		if(dateTypes.contains(literal.getDatatypeURI()))
//			return attributeType.date;
		return attributeType.string;
	}

	
}
