package de.tudarmstadt.fegelod.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;

import weka.core.Instances;

/**
 * A file writer for CSV files, uses UTF-8 (unlike WEKA built-in writers)
 * @author paulheim
 *
 */
public class ARFFWriter {
	public void writeFile(Instances instances, File file) throws IOException {
		Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file),Charset.forName("UTF-8")));
		out.write("@RELATION " + instances.relationName() + "\r\n\r\n");
		
		for(int i=0;i<instances.numAttributes();i++)
			out.write(instances.attribute(i).toString() + "\r\n");
		
		out.write("\r\n@DATA\r\n");

		for(int j=0;j<instances.numInstances();j++)
			out.write(instances.instance(j).toString() + "\r\n");
		
		out.flush();
		out.close();
	}
}
