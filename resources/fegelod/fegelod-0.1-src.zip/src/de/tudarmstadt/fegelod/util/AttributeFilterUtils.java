package de.tudarmstadt.fegelod.util;

import java.util.Collection;
import java.util.Enumeration;
import java.util.LinkedList;

import weka.core.Attribute;
import weka.core.Instances;

public class AttributeFilterUtils {
	public static void removeAttributes(Instances instances, Collection<Attribute> candidatesForDeletion, boolean removeClassAsWell) {
		// argh... we have to maintain our own index shift...
		int indexShift = 0;
		for(Attribute att : candidatesForDeletion) {
			if(removeClassAsWell || (instances.classIndex()<0 || !att.equals(instances.classAttribute())))
				instances.deleteAttributeAt(att.index()-indexShift);
			indexShift++;
		}
	}
	
	/**
	 * Removes all attributes from instances2 that are also contained in instances1
	 * @param instances1
	 * @param instances2
	 */
	public static void removeDuplicateAttributes(Instances instances1, Instances instances2) {
		Collection<Attribute> attributesToRemove = new LinkedList<Attribute>();
		Enumeration e = instances2.enumerateAttributes();
		while(e.hasMoreElements()) {
			Attribute att = (Attribute) e.nextElement();
			if(instances1.attribute(att.name())!=null)
				attributesToRemove.add(att);
		}
		removeAttributes(instances2, attributesToRemove, true);
	}
}
