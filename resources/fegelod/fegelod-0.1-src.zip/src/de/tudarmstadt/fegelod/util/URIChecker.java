package de.tudarmstadt.fegelod.util;

import java.io.File;
import java.io.FileReader;
import java.util.Collection;
import java.util.Enumeration;
import java.util.LinkedList;

import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;

import com.hp.hpl.jena.query.ResultSet;

import de.tudarmstadt.fegelod.sparql.SPARQLEndpointQueryRunner;

/**
 * This class is used for checking for valid URIs.
 * @author paulheim
 *
 */
public class URIChecker {
	
	private SPARQLEndpointQueryRunner sparqlQueryRunner;
	
	/**
	 * Checks instances for valid URIs in an attribute.
	 * @param instances
	 * @param attribute
	 * @return List of attribute values with non-valid URIs
	 */
	public Collection<String> checkURIs(Instances instances, Attribute attribute) {
		Collection<String> ret = new LinkedList<String>();
		
		Enumeration<?> einstances = instances.enumerateInstances();
		while(einstances.hasMoreElements()) {
			Instance instance = (Instance) einstances.nextElement();
			String uri = instance.stringValue(attribute);
			String query = 	"select ?p ?v " + 
							"WHERE {<" + uri +"> ?p ?v " + 
							"OPTIONAL {<" + uri +"> <http://dbpedia.org/ontology/wikiPageRedirects> ?r .} FILTER(!BOUND(?r))}";
			ResultSet RS = sparqlQueryRunner.runSelectQuery(query);
			if(!RS.hasNext())
				ret.add(uri);
		}
		return ret;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		URIChecker checker = new URIChecker();
		checker.sparqlQueryRunner = new SPARQLEndpointQueryRunner("http://dbpedia.org/sparql");
		
		Instances instances = new Instances(new FileReader(new File("data/mercer_cities.arff")));
		Attribute att = instances.attribute("uri");
		
		Collection<String> invalidURIs = checker.checkURIs(instances, att);
		System.out.println("invalid URIs:");
		for(String s : invalidURIs) {
			System.out.println(s);
		}
		
	}

}
