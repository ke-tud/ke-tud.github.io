package de.tudarmstadt.fegelod.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;

import weka.attributeSelection.GainRatioAttributeEval;
import weka.core.Attribute;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Discretize;
import weka.filters.unsupervised.attribute.RemoveType;

public class AttributeStatistics {
	
	/**
	 * InfoGainRatio(0%-1%)
	 * InfoGainRatio(1%-2%) ...
	 * @param instances
	 */
	public static void printAttributeStatisticsByPercent(Instances instances) {
		try {
			// first step: remove all string attributes
			RemoveType preFilter = new RemoveType();
			preFilter.setOptions(new String[]{"-T","string"});
			preFilter.setInputFormat(instances);
			instances = Filter.useFilter(instances, preFilter);
			
			// second step: default discretization
			Discretize discretizeFilter = new Discretize();
			discretizeFilter.setOptions(new String[]{"-unset-class-temporarily"});
			discretizeFilter.setInputFormat(instances);
			instances = Filter.useFilter(instances,discretizeFilter);
			
			// the actual computation
			Enumeration eattributes = instances.enumerateAttributes();
			List<Double> values = new ArrayList<Double>();
			GainRatioAttributeEval eval = new GainRatioAttributeEval();
			eval.setMissingMerge(false);
			eval.buildEvaluator(instances);
			while(eattributes.hasMoreElements()) {
				Attribute a = (Attribute) eattributes.nextElement();
				if(!instances.classAttribute().equals(a))
					values.add(eval.evaluateAttribute(a.index()));
			}
			List<Double> collapsed = collapseListToPercentages(values);
			for(int i=0;i<collapsed.size();i++) {
				//System.out.println(i + "," + collapsed.get(i));
				System.out.println(collapsed.get(i));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
	}
	
	private static List<Double> collapseListToPercentages(List<Double> values) {
		Collections.sort(values);
		double bucketSize = values.size()/99.0;
		List<Double> ret = new LinkedList<Double>();
		List<Double> currentBucket = new LinkedList<Double>();
		for(int i=0;i<values.size();i++) {
			Double value = values.get(i);
			currentBucket.add(value);
			if(i % bucketSize <=1) {
				ret.add(average(currentBucket));
				currentBucket.clear();
			}
		}
		// treat last bucket
		if(currentBucket.size()>0)
			ret.add(average(currentBucket));
		return ret;
	}
	
	private static double average(List<Double> values) {
		double ret = 0;
		for(double d : values) {
			ret += d/values.size();
		}
		return ret;
	}
}
