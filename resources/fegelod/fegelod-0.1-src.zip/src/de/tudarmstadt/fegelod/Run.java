package de.tudarmstadt.fegelod;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import weka.core.Instances;
import de.tudarmstadt.fegelod.entityrecognition.SPARQLBasedEntityRecognition;
import de.tudarmstadt.fegelod.filters.SimpleCutoffFilter;
import de.tudarmstadt.fegelod.generators.AbstractLODFeatureGenerator;
import de.tudarmstadt.fegelod.generators.DataPropertyFeatureGenerator;
import de.tudarmstadt.fegelod.generators.RelationNumericFeatureGenerator;
import de.tudarmstadt.fegelod.generators.RelationPresenceFeatureGenerator;
import de.tudarmstadt.fegelod.generators.RelationTypeNumericFeatureGenerator;
import de.tudarmstadt.fegelod.generators.RelationTypePresenceFeatureGenerator;
import de.tudarmstadt.fegelod.generators.SimpleTypeFeatureGenerator;
import de.tudarmstadt.fegelod.sparql.SPARQLEndpointQueryRunner;
import de.tudarmstadt.fegelod.sparql.SPARQLQueryRunner;
import de.tudarmstadt.fegelod.util.ARFFWriter;

public class Run {
	
	private static String inFile;
	private static String outFile;
	
	private static String attName;
	private static String validTypes;
	
	private static Float threshold;
	
	private static Instances instances;
	
	private static List<AbstractLODFeatureGenerator> generators = new LinkedList<AbstractLODFeatureGenerator>();
	
	/**
	 * Argument: location of the property file
	 * @param args
	 */
	public static void main(String[] args) {
		if(args.length<0) {
			System.out.println("Usage: java de.tudarmstadt.fegelod.Run <property-file>");
			System.exit(-1);
		}
		String propFile = args[0];
		Properties prop = new Properties();
		try {
			prop.load(new FileReader(propFile));
		} catch (IOException ex) {
			System.out.println(propFile + " not found");
			System.exit(-1);
		}
		
		inFile = (String) prop.get("inputFile");
		outFile = (String) prop.get("outputFile");
		attName = (String) prop.get("attribute");
		validTypes = (String) prop.get("validTypes");
		
		try {
			instances = new Instances(new FileReader(inFile));
			instances.setClassIndex(instances.numAttributes()-1);
		} catch (FileNotFoundException e) {
			System.out.println("File not found: " + inFile);
			System.exit(-1);
		} catch (IOException e) {
			System.out.println("Error reading from file: " + inFile);
			System.out.println(e.getMessage());
			System.exit(-1);
		}
		
		// DBPedia is hard wired at the moment
		SPARQLQueryRunner queryRunner = new SPARQLEndpointQueryRunner("http://dbpedia.org/sparql");
		try {
			if(prop.get("generator.dataProperties").equals("true")) {
				AbstractLODFeatureGenerator generator = new DataPropertyFeatureGenerator();
				generator.setSPARQLQueryRunner(queryRunner);
				generator.setOptions(new String[]{"-A",attName + "_uri","-S","false","-PNS",""});
				generators.add(generator);
			}
			
			if(prop.get("generator.type").equals("true")) {
				AbstractLODFeatureGenerator generator = new SimpleTypeFeatureGenerator();
				generator.setSPARQLQueryRunner(queryRunner);
				generator.setOptions(new String[]{"-A",attName + "_uri","-TNS",""});
				generators.add(generator);
			}
			
			if(prop.get("generator.relationBoolean").equals("true")) {
				AbstractLODFeatureGenerator generator = new RelationPresenceFeatureGenerator();
				generator.setSPARQLQueryRunner(queryRunner);
				generator.setOptions(new String[]{"-A",attName + "_uri","-PNS",""});
				generators.add(generator);
			}

			if(prop.get("generator.relationNumeric").equals("true")) {
				AbstractLODFeatureGenerator generator = new RelationNumericFeatureGenerator();
				generator.setSPARQLQueryRunner(queryRunner);
				generator.setOptions(new String[]{"-A",attName + "_uri"});
				generators.add(generator);
			}
			
			if(prop.get("generator.relationTypeBoolean").equals("true")) {
				AbstractLODFeatureGenerator generator = new RelationTypePresenceFeatureGenerator();
				generator.setSPARQLQueryRunner(queryRunner);
				generator.setOptions(new String[]{"-A",attName + "_uri","-TNS","","-PNS",""});
				generators.add(generator);
			}

			if(prop.get("generator.relationTypeNumeric").equals("true")) {
				AbstractLODFeatureGenerator generator = new RelationTypeNumericFeatureGenerator();
				generator.setSPARQLQueryRunner(queryRunner);
				generator.setOptions(new String[]{"-A",attName + "_uri","-S","true"});
				generators.add(generator);
			}

		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			System.exit(-1);
		}
		
		threshold = Float.parseFloat((String)prop.get("threshold")); 

		performER();
		performGeneration();
		performFilter();
		
		try {
			new ARFFWriter().writeFile(instances, new File(outFile));
		} catch (IOException e) {
			System.out.println("Error writing to file: " + outFile);
			System.exit(-1);
		}
	}
	
	private static void performER() {
		instances.setClassIndex(instances.numAttributes()-1);

		SPARQLBasedEntityRecognition er = new SPARQLBasedEntityRecognition();
		try {
			er.setOptions(new String[]{"-A",attName,"-E","http://dbpedia.org/sparql","-T",validTypes});
			instances = er.process(instances);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			System.exit(-1);
		}
	}
	
	private static void performGeneration() {
		System.out.println(generators.size() + " generators");
		for(AbstractLODFeatureGenerator generator : generators) {
			try {
				generator.setInputFormat(instances);
				instances = generator.process(instances);
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
				System.exit(-1);
			}
		}
	}
	
	private static void performFilter() {
		SimpleCutoffFilter postFilter = new SimpleCutoffFilter();
		System.out.println("filtering: " + threshold);
		try {
			postFilter.setOptions(new String[]{"-P",threshold.toString()});
			instances = postFilter.process(instances);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			System.exit(-1);
		}
	}
}
