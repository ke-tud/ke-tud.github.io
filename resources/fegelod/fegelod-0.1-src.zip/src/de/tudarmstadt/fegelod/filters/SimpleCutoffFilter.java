package de.tudarmstadt.fegelod.filters;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import weka.core.Attribute;
import weka.core.AttributeStats;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.Utils;
import weka.filters.SimpleFilter;
import de.tudarmstadt.fegelod.util.AttributeFilterUtils;

/**
 * This filter is used to remove attributes that, for a given threshold p,
 * - have more than p% unknown values
 * - have more than p% same values
 * - have more than p% distinct values
 * @author paulheim
 *
 */
public class SimpleCutoffFilter extends SimpleFilter {

	private static final long serialVersionUID = -9137930800503297583L;
	private float percentValue;

	@Override
	protected Instances determineOutputFormat(Instances instances) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Enumeration<?> listOptions() {
        Vector<Option> vector = new Vector<Option>();

        vector.addElement(
            new Option(
        	"\tMaximum allowed percentage of unknown, distinct, or same values",
        	"P", 1, "-P <value>"));
        
        return vector.elements();
	}
	
	@Override
	public void setOptions(String[] options) throws Exception {
		boolean foundPercent = false;
		String percent = Utils.getOption('P', options);
        if(percent.length()!=0) {
        	foundPercent = true;
        	percentValue = Float.valueOf(percent);
        }
		if(!foundPercent) {
        	throw new IllegalArgumentException("Missing option -P");
        }
	}

	@Override
	public String globalInfo() {
		return "Removes Attributes with more than p% unknown, distinct, or same values.";
	}

	@Override
	protected boolean hasImmediateOutputFormat() {
		return false;
	}

	@Override
	public Instances process(Instances instances) throws Exception {
		Enumeration atts = instances.enumerateAttributes();
		List<Attribute> candidatesForDeletion = new ArrayList<Attribute>();
		while(atts.hasMoreElements()) {
			Attribute att = (Attribute) atts.nextElement();
			AttributeStats stats = instances.attributeStats(att.index());
			// too many missing values
			if((float)stats.missingCount/instances.numInstances()>percentValue) {
				if(instances.classIndex()<0 || !att.equals(instances.classAttribute()))
					candidatesForDeletion.add(att);
			}
			// nominals with too many values
			else if(att.isNominal() && ((float)stats.uniqueCount/instances.numAttributes()>percentValue)) {
				if(instances.classIndex()<0 || !att.equals(instances.classAttribute()))
					candidatesForDeletion.add(att);
			}
			// nominals? with too many identical values
			// else if(att.isNominal() && hasMoreIdenticalValues(instances, att)) {
			else if(hasMoreIdenticalValues(instances, att)) {
				if(instances.classIndex()<0 || !att.equals(instances.classAttribute()))
					candidatesForDeletion.add(att);
			}
		}
		AttributeFilterUtils.removeAttributes(instances, candidatesForDeletion, false);
		return instances;
	}
	
	/**
	 * Finds out if an attribute has a percentage of identical values larger than p.
	 * @param instances
	 * @param att
	 * @return
	 */
	private boolean hasMoreIdenticalValues(Instances instances, Attribute att) {
		if(att.isNumeric()) {
			Map<Double,Float> count = new HashMap<Double,Float>();
			Enumeration einstances = instances.enumerateInstances();
			while(einstances.hasMoreElements()) {
				Instance instance = (Instance) einstances.nextElement();
				if(!count.containsKey(instance.value(att)))
					count.put(instance.value(att),0.0f);
				count.put(instance.value(att),count.get(instance.value(att))+1);
			}
			for(Float f : count.values())
				if(f/instances.numInstances()>percentValue)
					return true;
			return false;
		} else {
			Map<String,Float> count = new HashMap<String,Float>();
			Enumeration einstances = instances.enumerateInstances();
			while(einstances.hasMoreElements()) {
				Instance instance = (Instance) einstances.nextElement();
				if(!count.containsKey(instance.stringValue(att)))
					count.put(instance.stringValue(att),0.0f);
				count.put(instance.stringValue(att),count.get(instance.stringValue(att))+1);
			}
			for(Float f : count.values())
				if(f/instances.numInstances()>percentValue)
					return true;
			return false;
		}
	}
}
