package weka.classifiers.pla.addon;

import java.io.Serializable;
import java.util.Enumeration;

import weka.classifiers.pla.weight.PerceptronWeight;
import weka.core.Capabilities;
import weka.core.CapabilitiesHandler;
import weka.core.Debug;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.RevisionUtils;

public abstract class Addon implements Serializable, OptionHandler, RevisionHandler, CapabilitiesHandler {

	/** Serialisation ID */
	private static final long serialVersionUID = 7213373038507298216L;

	/** Addons can manipulate p (but not the pointer to it) */
	private PerceptronWeight p;

	private Debug logger;

	/**
	 * Save p to have access by getWeight()
	 * 
	 * @throws Exception
	 */
	public final void init(PerceptronWeight p, Debug logger) throws Exception {
		this.p = p;
		this.logger = logger;
		this.init();
	}

	/**
	 * Init whatever has to be set by the implementing addon.
	 * 
	 * @throws Exception
	 */
	protected abstract void init() throws Exception;

	/**
	 * @return A short description of the implementation of this class.
	 */
	public abstract String globalInfo();

	public abstract Enumeration<Option> listOptions();

	@Override
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 1.0 $");
	}

	public Capabilities getCapabilities() {
		Capabilities result = new Capabilities(this);
		result.enableAll();

		return result;
	}

	/**
	 * @return The PerceptronWeight the implementing addon can use.
	 */
	protected PerceptronWeight getWeight() {
		return this.p;
	}

	protected Debug getLogger() {
		return this.logger;
	}

}
