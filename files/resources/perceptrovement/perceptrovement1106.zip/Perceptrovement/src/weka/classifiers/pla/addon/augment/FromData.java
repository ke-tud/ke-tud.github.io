package weka.classifiers.pla.addon.augment;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.SelectedTag;
import weka.core.Tag;
import weka.core.Utils;

public class FromData extends Augment {

	private static final long serialVersionUID = -2046331463349817778L;

	/** Augment average Euclidean length */
	public static final int VARIANT_AVERAGE = 0;
	/** Augment maximum Euclidean length */
	public static final int VARIANT_MAX = 1;

	/** Tags to select variation in GUI and via command line */
	public static final Tag[] TAGS_VARIANT = { new Tag(VARIANT_AVERAGE, "Average length"), new Tag(VARIANT_MAX, "Maximum length"), };

	/** Default variant */
	private int variant = VARIANT_AVERAGE;

	@Override
	protected void initAfterReset() throws Exception {
		switch (getVariant().getSelectedTag().getID()) {
		case VARIANT_AVERAGE:
			// Augment average euclidean length of all training data points.
			setSquaredDimension(getWeight().averageSquare());
			break;
		case VARIANT_MAX:
			// Augment maximum euclidean length of all training data points.
			setSquaredDimension(getWeight().maxSquare());
			break;

		default:
			throw new Exception("Invalid variant to augment chosen.");
		}
	}

	@Override
	public String globalInfo() {
		return "Derive augmented dimension from data.";
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-V");
		result.add(getVariant().toString());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tVariants: 0=Average/1=Maximum.\n" + "\t(default 0)", "V", 1, "-V <num>"));

		return result.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('V', options);
		if (tmp.length() != 0) {
			setVariant(new SelectedTag(Integer.parseInt(tmp), TAGS_VARIANT));
		}
		else {
			setVariant(new SelectedTag(VARIANT_AVERAGE, TAGS_VARIANT));
		}
	}

	/**
	 * @return
	 */
	public String variantTipText() {
		return "Variants: 0=Average/1=Maximum.";
	}

	/**
	 * @return
	 */
	public SelectedTag getVariant() {
		return new SelectedTag(this.variant, TAGS_VARIANT);
	}

	/**
	 * @param variant
	 */
	public void setVariant(SelectedTag variant) {
		if (variant.getTags() == TAGS_VARIANT) {
			this.variant = variant.getSelectedTag().getID();
		}
	}

}
