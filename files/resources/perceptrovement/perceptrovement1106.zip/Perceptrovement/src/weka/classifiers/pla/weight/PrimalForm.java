package weka.classifiers.pla.weight;

import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;

import weka.core.Instance;
import weka.core.Instances;

/**
 * @author Tobias Krönke
 */
public class PrimalForm extends PerceptronWeight {

	/** Serialisation ID */
	private static final long serialVersionUID = 4886112753410806380L;

	private int classIndex;
	/** Stores the weights (+ augmented bias in the last element) */
	protected double[] m_weights;
	/** The weights for each pattern to be added to the weight */
	private double[] alphas;
	/** Indices of the SVs */
	private ArrayList<Integer> indexSV;

	@Override
	public void prepare(Instances data) {
		super.prepare(data);

		this.classIndex = data.classIndex();
		this.m_weights = new double[data.numAttributes() + 1];
		this.alphas = new double[data.numInstances()];
		this.indexSV = new ArrayList<Integer>(data.numInstances());
		this.sf = 1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public PrimalForm clone() throws CloneNotSupportedException {
		PrimalForm w = (PrimalForm) super.clone();

		w.m_weights = this.m_weights.clone();
		w.alphas = this.alphas.clone();
		w.indexSV = (ArrayList<Integer>) this.indexSV.clone();

		return w;
	}

	/**
	 * Set alphas[index] to v. Maintain indices of the SVs. Does not update euclideanLength.
	 * 
	 * @param index
	 * @param v
	 */
	private void alphasSet(int index, double v) {
		//assert (this.alphas[index] != v) : "Useless setting.";
		if (this.alphas[index] == 0 && v != 0) {
			assert !(this.indexSV.contains(new Integer(index))) : "SV to be freshly added was already registered as an SV: " + index + " " + v + " "
					+ this.indexSV;
			this.indexSV.add(index);
		}
		else if (this.alphas[index] != 0 && v == 0) {
			boolean removingWorked = false;
			removingWorked = this.indexSV.remove(new Integer(index));
			assert removingWorked : "SV to be removed wasn't registered as an SV!";
		}
		double oldAlpha = this.alphas[index];
		double add = this.sf * (v - oldAlpha);
		addToPrimalWeight(index, add);
		this.alphas[index] = v;
	}

	@Override
	public void safeAdd(int index, double factor) throws Exception {
		if (factor != 0) {
			double oldAlpha = this.alphas[index];
			alphasSet(index, oldAlpha + 1 / this.sf * factor);
		}
	}

	@Override
	public boolean updateWeight(int index, double factor, double oldOutput) throws Exception {
		if (factor != 0) {
			double oldAlpha = this.alphas[index];
			alphasSet(index, oldAlpha + 1 / this.sf * factor);

			getBudget().budgetMaintenance();

			return true;
		}
		else {
			return false;
		}
	}

	private boolean primalWeightNotZero() {
		for (int i = 0; i < this.m_weights.length; i++) {
			if (this.m_weights[i] != 0 && i != this.classIndex) {
				return true;
			}
		}
		return false;
	}

	/** Delayed scaling by saving a scaling factor */
	private double sf = 1;
	private static final double sfEpsilon = Math.pow(10, -300);

	private void invokeScalingFactor() {
		if (this.sf == 0) {
			this.indexSV.clear();
			this.alphas = new double[this.alphas.length];
		}
		else {
			for (int i : getIndexSV()) {
				this.alphas[i] *= this.sf;
				if (this.alphas[i] == 0) {
					boolean removingWorked = false;
					removingWorked = this.indexSV.remove(new Integer(i));
					assert removingWorked : "SV to be removed wasn't registered as an SV!";
				}
			}
		}
		this.sf = 1;
	}

	@Override
	public boolean scale(double factor) throws Exception {
		assert factor >= 0 : "Factor was < 0: " + factor;
		boolean lengthWasUpToDate = this.lengthUpToDate;
		if (factor != 1 && primalWeightNotZero()) {
			//			for (int i : getIndexSV()) {
			//				alphasSet(i, this.alphas[i] * factor);
			//			}
			for (int k = 0; k < this.m_weights.length; k++) {
				if (k != this.classIndex) {
					this.m_weights[k] *= factor;
				}
			}

			if (lengthWasUpToDate) {
				this.euclideanLength *= Math.abs(factor);
				this.lengthUpToDate = true;
			}

			this.sf *= factor;
			//getLogger().log(Double.toString(this.sf));
			if (this.sf <= sfEpsilon) {
				invokeScalingFactor();
			}

			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public void remove(int index) throws Exception {
		alphasSet(index, 0);
	}

	private void addToPrimalWeight(int index, double factor) {
		if (factor != 0) {
			Instance instance = this.train[index];
			int n1 = instance.numValues();
			for (int p1 = 0; p1 < n1; p1++) {
				int indS = instance.index(p1);
				if (indS != this.classIndex && !instance.isMissingSparse(p1)) {
					double m = factor * (instance.valueSparse(p1));
					this.m_weights[indS] += m;
				}
			}

			// update the bias
			this.m_weights[this.m_weights.length - 1] += factor * getAugment().getDimension();

			// update the length on future access
			this.lengthUpToDate = false;
		}
	}

	/**
	 * @param inst
	 * @param index
	 * @return
	 * @throws Exception
	 */
	@Override
	public double perceptronOutput(Instance inst, int index) throws Exception {
		return dotProduct(inst, index, this.m_weights, this.classIndex);
	}

	public double dotProduct(Instance inst1, int index, double[] weights, int classIndex) throws Exception {
		// From SPegasos
		double result = 0;

		// Sparse w' * x
		int n1 = inst1.numValues();
		int n2 = weights.length - 1;

		for (int p1 = 0, p2 = 0; p1 < n1 && p2 < n2;) {
			int ind1 = inst1.index(p1);
			int ind2 = p2;
			if (ind1 == ind2) {
				if (ind1 != classIndex && !inst1.isMissingSparse(p1)) {
					result += inst1.valueSparse(p1) * weights[p2];
				}
				p1++;
				p2++;
			}
			else if (ind1 > ind2) {
				p2++;
			}
			else {
				p1++;
			}
		}

		// Lambda trick
		if (index >= 0) {
			result += this.alphas[index] * this.sf * getLambdaToUse(index);
		}

		// Augmented bias
		result += this.m_weights[this.m_weights.length - 1];

		return result;
	}

	private boolean lengthUpToDate = false;

	@Override
	public double calcEuclideanLength() throws Exception {
		// From SPegasos
		double norm = 0;
		for (int k = 0; k < this.m_weights.length; k++) {
			if (k != this.classIndex) {
				norm += (this.m_weights[k] * this.m_weights[k]);
			}
		}

		for (int s : getIndexSV()) {
			norm += this.sf * this.alphas[s] * this.sf * this.alphas[s] * getLambdaToUse(s);
		}

		double len = Math.sqrt(norm);
		setEuclideanLength(len);
		this.lengthUpToDate = true;

		return len;
	}

	@Override
	public double getEuclideanLength() throws Exception {
		if (this.lengthUpToDate) {
			return this.euclideanLength;
		}
		else {
			return calcEuclideanLength();
		}
	}

	@Override
	public double dotProduct(int id1, int id2, Instance inst1) throws Exception {
		double res = getAugment().getAugmentedAddToKernel();
		double kernelProductOnly = (id1 == id2) ? this.kernelSquareCache[id1] : this.kernel.eval(id1, id2, inst1);
		res += kernelProductOnly;
		if (id1 == id2) {
			res += Math.abs(getLambda()) * (getLambda() < 0 ? kernelProductOnly : 1);
		}
		return res;
	}

	@Override
	public double added(int instIndex) {
		return this.alphas[instIndex] * this.sf;
	}

	@Override
	public double[] getLinearWeight() {
		double[] res = { 0 };

		if (noModelYet()) {
			return res;
		}
		else {
			res = new double[this.data.numAttributes() + numInstances()];

			for (int i : this.indexSV) {
				addToWeight(i, res);
			}
		}

		return res;
	}

	/**
	 * Add instance i to the weight vector res. Take lambda trick (w/o scale) and augmentation into consideration.
	 * 
	 * @param i
	 * @param res
	 */
	private void addToWeight(int i, double[] res) {
		Instance xi = this.train[i];
		double a = this.alphas[i] * this.sf;
		res[0] += a * Math.sqrt(getAugment().getAugmentedAddToKernel());
		int index = 0;
		for (int d = 0; d < xi.numAttributes(); d++) {
			if (d != xi.classIndex()) {
				index++;
				res[index] += a * xi.value(d);
			}
		}
		res[index + 1 + i] += a * Math.sqrt(Math.abs(getLambda()));
	}

	@Override
	public boolean noModelYet() {
		return super.noModelYet() || this.alphas == null || this.indexSV == null;
	}

	@Override
	public String toString() {
		if (noModelYet()) {
			return "0";
		}
		else {
			StringBuffer text = new StringBuffer();

			text.append("alphas: " + this.sf + " * " + Arrays.toString(this.alphas) + "\n");
			text.append("sv-inds: " + this.indexSV + "\n");
			text.append("svs: " + this.indexSV + "\n");
			for (int i : this.indexSV) {
				text.append(this.train[i] + "\n");
			}
			text.append("w (primal linear): " + Arrays.toString(this.m_weights) + "\n");

			return text.toString();
		}
	}

	/**
	 * @return the number of actually used SVs
	 */
	@Override
	public int getCountSV() {
		if (noModelYet()) {
			return 0;
		}
		else {
			return this.indexSV.size();
		}
	}

	@Override
	public int indexSVGet(int i) {
		return this.indexSV.get(i);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Integer> getIndexSV() {
		if (this.indexSV != null) {
			return (ArrayList<Integer>) this.indexSV.clone();
		}
		else {
			return new ArrayList<Integer>();
		}
	}

	@Override
	public String globalInfo() {
		return "Linear weight in primal form.";
	}

	/**
	 * Return i's label on the fly. Slower than storing each label.
	 * 
	 * @param i
	 * @return
	 */
	private int testGetLable(int i) {
		return (this.data.instance(i).classValue() <= 0) ? -1 : 1;
	}

	public static void main(String[] args) throws Exception {
		// Benchmark that shows that one should recognize the data first.

		PrimalForm d = new PrimalForm();
		Reader r = new FileReader("data/weka/iris2.arff");
		Instances i = new Instances(r);
		i.setClassIndex(4);
		d.prepare(i);

		for (int j = 0; j < 1; j++) {
			long tStart = System.currentTimeMillis();
			d.recognize(i);
			long t = System.currentTimeMillis() - tStart;
			System.out.println(t);
		}

		int dummy = 0;
		for (int j = 0; j < 10000000; j++) {
			dummy = d.testGetLable(1);
			dummy = d.classLableGet(1);
		}
		System.out.println(dummy);

		int sum = 0;
		long tStart = System.currentTimeMillis();
		for (int j = 0; j < 1000000000; j++) {
			sum += d.testGetLable(1);
		}
		long t = System.currentTimeMillis() - tStart;
		System.out.println(sum);
		System.out.println(t);

		sum = 0;
		tStart = System.currentTimeMillis();
		for (int j = 0; j < 1000000000; j++) {
			sum += d.classLableGet(1);
		}
		t = System.currentTimeMillis() - tStart;
		System.out.println(sum);
		System.out.println(t);

		sum = 0;
		tStart = System.currentTimeMillis();
		for (int j = 0; j < 1000000000; j++) {
			sum += d.testGetLable(1);
		}
		t = System.currentTimeMillis() - tStart;
		System.out.println(sum);
		System.out.println(t);
	}
}
