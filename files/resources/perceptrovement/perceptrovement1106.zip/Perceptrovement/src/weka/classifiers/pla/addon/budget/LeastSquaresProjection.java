package weka.classifiers.pla.addon.budget;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;
import weka.core.matrix.Matrix;

public class LeastSquaresProjection extends HeuristicSelection {

	private static final long serialVersionUID = 8356066739527755195L;

	/** Selected SV gets replaces by max. nrRegressionSV randomly selected SVs */
	private int nrRegressionSV = Integer.MAX_VALUE;
	/** Ridge regression factor for kernel-matrix regularisation */
	private double ridge = 0.01;

	@Override
	protected void getRidOfOneSV() throws Exception {
		// Index of SV p to replace by the other SVs
		int p = select();

		// Get all direct SV indices and remove the one to be removed from the list
		ArrayList<Integer> regressionSVIndices = new ArrayList<Integer>(getWeight().getCountSV());
		for (int i = 0; i < getWeight().getCountSV(); i++) {
			regressionSVIndices.add(getWeight().indexSVGet(i));
		}
		regressionSVIndices.remove(new Integer(p));

		// Might not regress selected SV by all other SVs for performance reasons
		while (regressionSVIndices.size() > getNrRegressionSV()) {
			regressionSVIndices.remove(this.remover.nextInt(regressionSVIndices.size()));
		}

		// Temp variable to save the outer current direct index
		int directI;
		// Temp variable to save the inner current direct index
		int directJ;
		// Temp variable to save the current dot-product
		double prod;

		// All kernel-products of p with all the other SVs
		Matrix k = new Matrix(regressionSVIndices.size(), 1);
		for (int i = 0; i < regressionSVIndices.size(); i++) {
			directI = regressionSVIndices.get(i);
			prod = getWeight().dotProduct(directI, p);
			k.set(i, 0, prod);
		}

		// Kernel matrix of all SVs, except for p.
		Matrix K = new Matrix(regressionSVIndices.size(), regressionSVIndices.size());
		for (int i = 0; i < regressionSVIndices.size(); i++) {
			directI = regressionSVIndices.get(i);
			for (int j = i; j < regressionSVIndices.size(); j++) {
				directJ = regressionSVIndices.get(j);
				prod = getWeight().dotProduct(directI, directJ);
				K.set(i, j, prod);
				K.set(j, i, prod);
			}
		}

		// How much p was added to getWeight()
		double alphaP = getWeight().added(p);
		// Changes to the coefficients of all SVs (except p)
		Matrix deltaAlpha;
		try {
			// Change the coefficients of all SVs (except p) to best represent p by ridge regression
			deltaAlpha = K.plus(Matrix.identity(K.getRowDimension(), K.getColumnDimension()).times(getRidge())).solve(k.times(alphaP));
		}
		catch (Exception e) {
			System.out.println(K.toMatlab());
			throw e;
		}
		// Apply deltaAlpha (∆a* in the report)
		for (int i = 0; i < regressionSVIndices.size(); i++) {
			directI = regressionSVIndices.get(i);
			getWeight().safeAdd(directI, deltaAlpha.get(i, 0));
		}

		// Remove p from getWeight() as an SV
		getWeight().remove(p);
	}

	@Override
	public String globalInfo() {
		return "Project selected SV onto the others by least-squares ridge regression.";
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tRidge regression regularization factor.\n" + "\t(default 0.01)", "R", 1, "-R <num>"));
		result.addElement(new Option("\tMax. nr. of random SVs to fit removed SV.\n" + "\t(default Integer.MAX_VALUE)", "Q", 1, "-Q <num>"));

		Enumeration<Option> enu = super.listOptions();
		while (enu.hasMoreElements()) {
			result.addElement(enu.nextElement());
		}
		return result.elements();
	}

	@Override
	public String[] getOptions() {
		int i;
		Vector<String> result;
		String[] options;

		result = new Vector<String>();
		options = super.getOptions();
		for (i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		result.add("-Q");
		result.add("" + getNrRegressionSV());

		result.add("-R");
		result.add("" + getRidge());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('Q', options);
		if (tmp.length() != 0) {
			setNrRegressionSV(Integer.parseInt(tmp));
		}
		else {
			setNrRegressionSV(Integer.MAX_VALUE);
		}
		tmp = Utils.getOption('R', options);
		if (tmp.length() != 0) {
			setRidge(Double.parseDouble(tmp));
		}
		else {
			setRidge(0.01);
		}

		super.setOptions(options);
	}

	public String nrRegressionSVTipText() {
		return "Heuristically selected SV gets replaces by max. nrRegressionSV randomly selected SVs.";
	}

	/**
	 * @param nrRegressionSV
	 *            the nrRegressionSV to set
	 */
	public void setNrRegressionSV(int nrRegressionSV) {
		this.nrRegressionSV = nrRegressionSV;
	}

	/**
	 * @return the nrRegressionSV
	 */
	public int getNrRegressionSV() {
		return this.nrRegressionSV;
	}

	public String ridgeTipText() {
		return "Ridge regression regularization factor.";
	}

	public double getRidge() {
		return this.ridge;
	}

	public void setRidge(double ridge) {
		this.ridge = ridge;
	}

}
