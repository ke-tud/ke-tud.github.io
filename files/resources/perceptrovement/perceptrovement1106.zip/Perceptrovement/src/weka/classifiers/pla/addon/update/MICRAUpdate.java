package weka.classifiers.pla.addon.update;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public class MICRAUpdate extends Update {

	private static final long serialVersionUID = -6587270482773057002L;

	/** */
	private double zeta = 0.875;
	/** */
	private double etaZero = 2;
	/** */
	private double beta = 1;
	/** */
	private double delta = 0;

	/** */
	private double R;
	/** */
	private double etaHat;

	@Override
	public void init() throws Exception {
		// Define ...
		this.R = Math.sqrt(getWeight().maxSquare());
		this.etaHat = getEtaZero() * Math.pow(getBeta() / this.R, -getDelta()) / this.R;
	}

	@Override
	public boolean updateWeight(int n, int yN, double lossN, double outputN, double margin, int uN, int t) throws Exception {
		double factor;

		// Less than or equal beta_t in the paper of MICRA.
		if (yN * outputN <= margin) {
			double currentEta = getWeight().getEuclideanLength() * this.etaHat * Math.pow(t, -this.zeta);
			factor = yN * currentEta;
		}
		else {
			factor = 0;
		}

		return getWeight().updateWeight(n, factor, outputN);
	}

	@Override
	public String globalInfo() {
		return "Mistake controlled update rate.";
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tEta_0 (\"Base\"-Rate).\n" + "\t(default 2)", "L", 1, "-L <num>"));
		result.addElement(new Option("\tZeta.\n" + "\t(default 0.875)", "Z", 1, "-Z <num>"));
		result.addElement(new Option("\tBeta.\n" + "\t(default 1)", "B", 1, "-B <num>"));
		result.addElement(new Option("\tDelta.\n" + "\t(default 0)", "D", 1, "-D <num>"));

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-L");
		result.add("" + getEtaZero());

		result.add("-Z");
		result.add("" + getZeta());

		result.add("-B");
		result.add("" + getBeta());

		result.add("-D");
		result.add("" + getDelta());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('L', options);
		if (tmp.length() != 0) {
			setEtaZero(Double.parseDouble(tmp));
		}
		else {
			setEtaZero(2);
		}
		tmp = Utils.getOption('Z', options);
		if (tmp.length() != 0) {
			setZeta(Double.parseDouble(tmp));
		}
		else {
			setZeta(0.875);
		}
		tmp = Utils.getOption('B', options);
		if (tmp.length() != 0) {
			setBeta(Double.parseDouble(tmp));
		}
		else {
			setBeta(1);
		}
		tmp = Utils.getOption('D', options);
		if (tmp.length() != 0) {
			setDelta(Double.parseDouble(tmp));
		}
		else {
			setDelta(0.0);
		}
	}

	/**
	 * @return
	 */
	public String zetaTipText() {
		return "Zeta: time degradation.";
	}

	/**
	 * @return the zeta
	 */
	public double getZeta() {
		return this.zeta;
	}

	/**
	 * @param zeta
	 *            the zeta to set
	 */
	public void setZeta(double zeta) {
		this.zeta = zeta;
	}

	/**
	 * @return
	 */
	public String etaZeroTipText() {
		return "Base rate.";
	}

	/**
	 * @return the eta
	 */
	public double getEtaZero() {
		return this.etaZero;
	}

	/**
	 * @param etaZero
	 *            the etaZero to set
	 */
	public void setEtaZero(double etaZero) {
		this.etaZero = etaZero;
	}

	/**
	 * @return
	 */
	public String betaTipText() {
		return "Beta.";
	}

	/**
	 * @param beta
	 *            the beta to set
	 */
	public void setBeta(double beta) {
		this.beta = beta;
	}

	/**
	 * @return the beta
	 */
	public double getBeta() {
		return this.beta;
	}

	/**
	 * @return
	 */
	public String deltaTipText() {
		return "Delta.";
	}

	/**
	 * @param delta
	 *            the delta to set
	 */
	public void setDelta(double delta) {
		this.delta = delta;
	}

	/**
	 * @return the delta
	 */
	public double getDelta() {
		return this.delta;
	}

}
