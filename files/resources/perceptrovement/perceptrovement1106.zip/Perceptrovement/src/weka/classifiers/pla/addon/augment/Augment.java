package weka.classifiers.pla.addon.augment;

import weka.classifiers.pla.addon.Addon;
import weka.core.Utils;

public abstract class Augment extends Addon {

	private static final long serialVersionUID = 1738988619034207063L;

	/** The square of the augmented dimension that is set in init() */
	private double squaredDimension = 0;
	/** The augmented dimension */
	private double dimension = 0;

	/**
	 * @return What gets added to each kernel product due to augmentation.
	 */
	public final double getAugmentedAddToKernel() {
		return getSquaredDimension();
	}

	@Override
	protected final void init() throws Exception {
		// Reset augmentation (important if calculated from new data)
		setSquaredDimension(0);

		initAfterReset();
	}

	/**
	 * Reset has to be enforced, because otherwise, the augmentation might be calculated from augmentated data! Hence a
	 * special init(AfterReset) for augmentation addons.
	 * 
	 * @throws Exception
	 */
	protected abstract void initAfterReset() throws Exception;

	/**
	 * Creates a new instance of a Augment given its class name and (optional) arguments to pass to its setOptions
	 * method.
	 * 
	 * @param augmentName
	 *            the fully qualified class name of the Augment
	 * @param options
	 *            an array of options suitable for passing to setOptions. May be null.
	 * @return the newly created Augment, ready for use.
	 * @throws Exception
	 *             if the Augment name is invalid, or the options supplied are not acceptable to the Augment
	 */
	public static Augment forName(String augmentName, String[] options) throws Exception {

		return (Augment) Utils.forName(Augment.class, augmentName, options);
	}

	/**
	 * @param squaredDimension
	 *            the squaredDimension to set
	 */
	protected final void setSquaredDimension(double squaredDimension) {
		this.squaredDimension = squaredDimension;
		this.dimension = Math.sqrt(squaredDimension);
	}

	/**
	 * @return the squaredDimension
	 */
	public final double getSquaredDimension() {
		return this.squaredDimension;
	}

	/**
	 * @return the dimension
	 */
	public final double getDimension() {
		return this.dimension;
	}

}
