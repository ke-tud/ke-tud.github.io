package weka.classifiers.pla.addon.augment;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;

public class RealNumber extends Augment {

	private static final long serialVersionUID = 588358792661726491L;

	/** Just a fixed number given to augment */
	private double number = 1;

	@Override
	public void initAfterReset() throws Exception {
		// The squared number gets added to every kernel product.
		setSquaredDimension(getNumber() * getNumber());
	}

	@Override
	public String globalInfo() {
		return "Augment with any real number.";
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tValue of extra dimension number.\n" + "\t(default 1)", "N", 1, "-N <num>"));

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-N");
		result.add("" + getNumber());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('N', options);
		if (tmp.length() != 0) {
			setNumber(Double.parseDouble(tmp));
		}
		else {
			setNumber(1);
		}
	}

	/**
	 * @return
	 */
	public String numberTipText() {
		return "Value of extra dimension to be augmented.";
	}

	/**
	 * @param number
	 *            the number to set
	 */
	public void setNumber(double number) {
		this.number = number;
	}

	/**
	 * @return the number
	 */
	public double getNumber() {
		return this.number;
	}

}
