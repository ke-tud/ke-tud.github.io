package weka.classifiers.pla;

import java.util.Enumeration;
import java.util.Vector;

import weka.classifiers.Classifier;
import weka.classifiers.functions.supportVector.Kernel;
import weka.classifiers.functions.supportVector.PolyKernel;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.SelectedTag;
import weka.core.Utils;

public class DummyClassifier extends Classifier implements OptionHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2987079239815384757L;

	/** the kernel to use */
	protected Kernel m_kernel = new PolyKernel();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//		runClassifier(new VotedPerceptron(), args);
		Vector<Double> a = new Vector<Double>(5, 5);
		a.set(0, 1.3);
		a.get(5);
		a.set(5, 5.5);
	}

	@Override
	public void buildClassifier(Instances data) throws Exception {
		// TODO Auto-generated method stub

	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		Enumeration<Option> enm;

		result.addElement(new Option("\tThe Kernel to use.\n" + "\t(default: weka.classifiers.functions.supportVector.PolyKernel)", "K", 1,
				"-K <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to kernel " + this.getKernel().getClass().getName() + ":"));

		enm = ((OptionHandler) this.getKernel()).listOptions();
		while (enm.hasMoreElements()) {
			result.addElement((Option) enm.nextElement());
		}

		return result.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmpStr;
		String[] tmpOptions;

		tmpStr = Utils.getOption('K', options);
		tmpOptions = Utils.splitOptions(tmpStr);
		if (tmpOptions.length != 0) {
			tmpStr = tmpOptions[0];
			tmpOptions[0] = "";
			this.setKernel(Kernel.forName(tmpStr, tmpOptions));
		}

		super.setOptions(options);
	}

	@Override
	public String[] getOptions() {

		String[] options = new String[22];
		int current = 0;
		options[current++] = "-K";
		options[current++] = this.getKernel().getClass().getName() + " " + Utils.joinOptions(this.getKernel().getOptions());

		while (current < options.length) {
			options[current++] = "";
		}
		return options;
	}

	public String kernelTipText() {
		return "The kernel to use.";
	}

	public void setKernel(Kernel value) {
		this.m_kernel = value;
	}

	public Kernel getKernel() {
		return this.m_kernel;
	}

}
