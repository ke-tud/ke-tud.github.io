package weka.classifiers.pla.addon.budget;

public class JustRemove extends HeuristicSelection {

	private static final long serialVersionUID = 1129624203953689177L;

	@Override
	protected void getRidOfOneSV() throws Exception {
		// Select an SV heuristically ...
		int index = select();
		// ... and just remove it
		getWeight().remove(index);
	}

	@Override
	public String globalInfo() {
		return "Just remove SV according to the heuristic selection.";
	}

}
