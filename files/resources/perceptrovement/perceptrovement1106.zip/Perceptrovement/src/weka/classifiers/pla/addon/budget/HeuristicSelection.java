package weka.classifiers.pla.addon.budget;

import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import weka.core.Option;
import weka.core.SelectedTag;
import weka.core.Tag;
import weka.core.Utils;

public abstract class HeuristicSelection extends Budget {

	private static final long serialVersionUID = 3027558780212774678L;

	/** Select the SV by min(alpha² * ||SV||²) */
	public static final int HEURISTIC_MINADDEDSQUARE = 0;
	/** Select the SV by min(alpha²) */
	public static final int HEURISTIC_MINCOEFF = 1;
	/** Select the SV with the lowest index in the training list */
	public static final int HEURISTIC_OLDEST = 2;
	/** Randomly select the SV (only different from HEURISTIC_OLDEST in a live learning setting) */
	public static final int HEURISTIC_RANDOM = 3;
	/** Select the SV by min(||SV||²) */
	public static final int HEURISTIC_MINSVSQUARE = 4;
	/** Select the most confidently classified SV */
	public static final int HEURISTIC_CONFIDENT = 5;
	/** Select the SV with the highest index in the training list */
	public static final int HEURISTIC_NEWEST = 6;

	/** Tags to select heuristic in GUI and via command line */
	public static final Tag[] TAGS_HEURISTIC = { new Tag(HEURISTIC_MINADDEDSQUARE, "Min added square"), new Tag(HEURISTIC_MINCOEFF, "Min |coeff|"),
			new Tag(HEURISTIC_OLDEST, "Least recent"), new Tag(HEURISTIC_RANDOM, "Random"), new Tag(HEURISTIC_MINSVSQUARE, "Min SV square"),
			new Tag(HEURISTIC_CONFIDENT, "Most confident SV"), new Tag(HEURISTIC_NEWEST, "Most recent") };

	/** Default heuristic */
	private int heuristic = HEURISTIC_MINADDEDSQUARE;

	/** Seed for HEURISTIC_RANDOM */
	private int seed = 1;
	/** Randomly generate SV-indices */
	protected Random remover;

	@Override
	protected void init() {
		this.remover = new Random(getSeed());
	}

	/**
	 * @return Heuristically selected index of an SV in the training list.
	 * @throws Exception
	 */
	protected int select() throws Exception {
		int index;

		// Return index according to selected variant.
		switch (getHeuristic().getSelectedTag().getID()) {
		case HEURISTIC_MINADDEDSQUARE:
			index = minAddedSquare();
			break;
		case HEURISTIC_MINCOEFF:
			index = minCoefficient();
			break;
		case HEURISTIC_OLDEST:
			index = oldestSV();
			break;
		case HEURISTIC_RANDOM:
			index = randomSV();
			break;
		case HEURISTIC_MINSVSQUARE:
			index = minSVSquare();
			break;
		case HEURISTIC_CONFIDENT:
			index = mostConfidentSV();
			break;
		case HEURISTIC_NEWEST:
			index = newestSV();
			break;

		default:
			throw new Exception("Unknown heuristic SV selection selected.");
		}

		return index;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_MINADDEDSQUARE
	 * @return The SV's index.
	 * @throws Exception
	 */
	private final int minAddedSquare() throws Exception {
		int dirInd;
		double min = Double.MAX_VALUE;
		int minDirInd = getWeight().indexSVGet(0);

		double toMinimize;

		for (int i = 0; i < getWeight().getCountSV(); i++) {
			dirInd = getWeight().indexSVGet(i);
			toMinimize = getWeight().dotProduct(dirInd, dirInd);
			toMinimize *= getWeight().added(dirInd) * getWeight().added(dirInd);

			if (toMinimize < min) {
				min = toMinimize;
				minDirInd = dirInd;
			}
		}

		return minDirInd;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_MINCOEFF
	 * @return The SV's index.
	 * @throws Exception
	 */
	private final int minCoefficient() throws Exception {
		int dirInd;
		double min = Double.MAX_VALUE;
		int minDirInd = getWeight().indexSVGet(0);

		double toMinimize;
		double coeff;

		for (int i = 0; i < getWeight().getCountSV(); i++) {
			dirInd = getWeight().indexSVGet(i);
			coeff = getWeight().added(dirInd);
			toMinimize = coeff * coeff;

			if (toMinimize < min) {
				min = toMinimize;
				minDirInd = dirInd;
			}
		}

		return minDirInd;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_OLDEST
	 * @return The SV's index.
	 * @throws Exception
	 */
	private final int oldestSV() {
		int indirectIndex = 0;
		int directIndex = getWeight().indexSVGet(indirectIndex);
		return directIndex;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_RANDOM
	 * @return The SV's index.
	 * @throws Exception
	 */
	private final int randomSV() {
		int indirectIndex = this.remover.nextInt(getWeight().getCountSV());
		int directIndex = getWeight().indexSVGet(indirectIndex);
		return directIndex;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_MINSVSQUARE
	 * @return The SV's index.
	 * @throws Exception
	 */
	private int minSVSquare() throws Exception {
		int dirInd;
		double min = Double.MAX_VALUE;
		int minDirInd = getWeight().indexSVGet(0);

		double toMinimize;

		for (int i = 0; i < getWeight().getCountSV(); i++) {
			dirInd = getWeight().indexSVGet(i);
			toMinimize = getWeight().dotProduct(dirInd, dirInd);

			if (toMinimize < min) {
				min = toMinimize;
				minDirInd = dirInd;
			}
		}

		return minDirInd;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_CONFIDENT
	 * @return The SV's index.
	 * @throws Exception
	 */
	private final int mostConfidentSV() throws Exception {
		int dirInd;
		double max = Double.NEGATIVE_INFINITY;
		int maxDirInd = getWeight().indexSVGet(0);

		double toMaximize;

		for (int i = 0; i < getWeight().getCountSV(); i++) {
			dirInd = getWeight().indexSVGet(i);
			toMaximize = getWeight().perceptronOutput(dirInd) * getWeight().classLableGet(dirInd);
			if (toMaximize > max) {
				max = toMaximize;
				maxDirInd = dirInd;
			}
		}

		return maxDirInd;
	}

	/**
	 * @see HeuristicSelection.HEURISTIC_NEWEST
	 * @return The SV's index.
	 * @throws Exception
	 */
	private final int newestSV() {
		int indirectIndex = getWeight().getCountSV() - 1;
		int directIndex = getWeight().indexSVGet(indirectIndex);
		return directIndex;
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tRandom seed used to randomly select an SV.\n" + "\t(default 1)", "S", 1, "-S <num>"));
		result.addElement(new Option(
				"\tHeuristic: 0=Min added square/1=Min |coeff|/2=Least recent/3=Random/4=Min SV square/5=Most confident SV/6=Most recent.\n" + "\t(default 0)",
				"H", 1, "-H <num>"));

		Enumeration<Option> enu = super.listOptions();
		while (enu.hasMoreElements()) {
			result.addElement(enu.nextElement());
		}
		return result.elements();
	}

	@Override
	public String[] getOptions() {
		int i;
		Vector<String> result;
		String[] options;

		result = new Vector<String>();
		options = super.getOptions();
		for (i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		result.add("-S");
		result.add("" + getSeed());

		result.add("-H");
		result.add(getHeuristic().toString());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('S', options);
		if (tmp.length() != 0) {
			setSeed(Integer.parseInt(tmp));
		}
		else {
			setSeed(1);
		}
		tmp = Utils.getOption('H', options);
		if (tmp.length() != 0) {
			setHeuristic(new SelectedTag(Integer.parseInt(tmp), TAGS_HEURISTIC));
		}
		else {
			setHeuristic(new SelectedTag(HEURISTIC_MINADDEDSQUARE, TAGS_HEURISTIC));
		}

		super.setOptions(options);
	}

	public String seedTipText() {
		return "Random seed used to randomly select an SV.";
	}

	public int getSeed() {
		return this.seed;
	}

	public void setSeed(int seed) {
		this.seed = seed;
	}

	/**
	 * @return
	 */
	public String heuristicTipText() {
		return "Heuristic: 0=Min added square/1=Min |coeff|/2=Least recent/3=Random/4=Min SV square/5=Most confident SV/6=Most recent.";
	}

	/**
	 * @return
	 */
	public SelectedTag getHeuristic() {
		return new SelectedTag(this.heuristic, TAGS_HEURISTIC);
	}

	/**
	 * @param heuristic
	 */
	public void setHeuristic(SelectedTag heuristic) {
		if (heuristic.getTags() == TAGS_HEURISTIC) {
			this.heuristic = heuristic.getSelectedTag().getID();
		}
	}

}
