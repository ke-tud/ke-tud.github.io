package weka.classifiers.pla;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import weka.classifiers.RandomizableClassifier;
import weka.classifiers.pla.addon.margin.MICRAMargin;
import weka.classifiers.pla.addon.margin.Margin;
import weka.classifiers.pla.addon.margin.UnevenMargin;
import weka.classifiers.pla.addon.update.ConstantUpdate;
import weka.classifiers.pla.addon.update.MICRAUpdate;
import weka.classifiers.pla.addon.update.Update;
import weka.classifiers.pla.weight.DualForm;
import weka.classifiers.pla.weight.PerceptronWeight;
import weka.core.AdditionalMeasureProducer;
import weka.core.Capabilities;
import weka.core.Debug;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.RevisionUtils;
import weka.core.SelectedTag;
import weka.core.Tag;
import weka.core.Utils;
import weka.core.Capabilities.Capability;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.NominalToBinary;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;

/**
 * @author Tobias Krönke
 */
public class Perceptrovement extends RandomizableClassifier implements AdditionalMeasureProducer {

	/** Serialisation ID */
	private static final long serialVersionUID = -85514001655345727L;

	/** Normal perceptron */
	public static final int VARIANT_CLASSICAL = 0;
	/** Use the longest surviving perceptron to classify new data */
	public static final int VARIANT_SURVIVOR = 1;
	/** Voted perceptron */
	public static final int VARIANT_VOTED = 2;

	/** Tags to select variation in GUI and via command line */
	public static final Tag[] TAGS_VARIANT = { new Tag(VARIANT_CLASSICAL, "Classical"), new Tag(VARIANT_SURVIVOR, "Survivor"), new Tag(VARIANT_VOTED, "Voted") };

	/** Default variant */
	private int variant = VARIANT_CLASSICAL;

	/** Max. number of epochs */
	private int numIterations = 100;
	/** Counts how many epochs actually were made */
	private int numIterationsNeeded = 0;
	/** Number of "reduced epochs" (MICRA) */
	private int reducedIter = 0;

	/** Filter to replace missing values by statistical means */
	private ReplaceMissingValues replaceMissingTrainingValues;
	/** Filter to transform nominal attributes into binary (0,1) ones */
	private NominalToBinary trainingNominalToBinary;

	/** The model by adding SVs */
	private PerceptronWeight weight = new DualForm();
	/** The surviving model */
	private PerceptronWeight weightSurvivor;
	/** The voted model */
	private ArrayList<PerceptronWeight> weightVoters;
	/** The votes */
	private ArrayList<Integer> weightVotes;

	/** How often an update was made with each example */
	private int[] updateCount;
	/** Total number of "true" updates */
	private int totalUpdateCount;
	/** Alpha bound as in Khardon */
	private int alphaBound = Integer.MAX_VALUE;

	/** Count surviving updates of current w */
	private int tally;
	/** Longest streak of surviving updates */
	private int bestTally;
	/** Current vote */
	private int currentVote;

	/**  */
	private Update update = new ConstantUpdate();
	/**  */
	private Margin margin = new UnevenMargin();

	/** */
	private Debug logger;

	/**
	 * Reset internal helper variables for building a new classifier.
	 */
	private void reset() {
		this.numIterationsNeeded = 0;
		this.bestTally = 0;
		this.tally = 0;
		this.currentVote = 0;
	}

	/**
	 * @param insts
	 * @throws Exception
	 */
	private void prepareTraining(Instances insts) throws Exception {

		// Can classifier handle the data?
		getCapabilities().testWithFail(insts);

		// Remove instances with missing class
		insts = new Instances(insts);
		insts.deleteWithMissingClass();

		// Filter data to be compatible with the PerceptronWeight
		Instances data = new Instances(insts);

		this.replaceMissingTrainingValues = new ReplaceMissingValues();
		this.replaceMissingTrainingValues.setInputFormat(data);
		data = Filter.useFilter(data, this.replaceMissingTrainingValues);

		this.trainingNominalToBinary = new NominalToBinary();
		this.trainingNominalToBinary.setInputFormat(data);
		data = Filter.useFilter(data, this.trainingNominalToBinary);

		// Randomise training data
		data.randomize(new Random(this.m_Seed));

		int m = insts.numInstances();
		int spaceReq = m;

		// Initialise the weight before using it for survival or voting
		getWeight().init(data, this.logger);

		if (getSurvivor()) {
			this.weightSurvivor = getWeight().clone();
		}
		if (getVoted()) {
			this.weightVoters = new ArrayList<PerceptronWeight>(spaceReq);
			this.weightVotes = new ArrayList<Integer>(spaceReq);

			this.weightVoters.add(getWeight());
			this.weightVotes.add(this.currentVote);
		}
	}

	/**
	 * @throws Exception
	 */
	private void initAddons() throws Exception {
		// For updates that depend on updateCount
		this.totalUpdateCount = 0;
		this.updateCount = new int[getWeight().getTrainIndices().size()];

		// Special MICRA initial update
		if (getMargin() instanceof MICRAMargin || getUpdate() instanceof MICRAUpdate) {
			int ind = 0;
			double output = getWeight().perceptronOutput(ind);
			boolean weightChanged = getWeight().updateWeight(ind, getWeight().classLableGet(ind), output);
			if (weightChanged) {
				this.updateCount[ind]++;
				this.totalUpdateCount++;
			}
		}
		getMargin().init(getWeight(), this.logger);
		getUpdate().init(getWeight(), this.logger);
	}

	@Override
	public void buildClassifier(Instances insts) throws Exception {
		this.logger = new Debug();
		this.logger.setEnabled(getDebug());

		// Init by user non-setable "parameters" that might change during execution
		reset();

		// Fit training data to my model
		prepareTraining(insts);

		// Init my perceptron addons
		initAddons();

		// Learn perceptron while the weight gets changed
		boolean weightChanged = false;
		for (int i = 0; i < getIter(); i++) {
			weightChanged = iteration(i);
			// Simulate further iterations that are skipped, as the weight should'nt change anymore
			if (!weightChanged) {
				// What the voters or the current weight could have gained in further iterations
				int pointsLeft = (getIter() - this.numIterationsNeeded) * getWeight().numInstances();
				if (getVoted()) {
					this.weightVotes.set(this.weightVotes.size() - 1, this.weightVotes.get(this.weightVotes.size() - 1) + pointsLeft);
				}
				else if (getSurvivor()) {
					if (this.tally + pointsLeft > this.bestTally) {
						this.bestTally = this.tally + pointsLeft;
						this.weightSurvivor = getWeight().clone();
					}
				}
				break;
			}
		}

		// Learning finished
		getWeight().clean();
	}

	/**
	 * @param i
	 *            Current iteration run, starting from 0
	 * @return true iff any pattern was added to the weight during the iteration
	 * @throws Exception
	 */
	protected boolean iteration(int i) throws Exception {
		this.numIterationsNeeded++;
		this.logger.log("Iteration " + (i + 1));
		boolean addedToWeight;

		// Store those examples that changed the weight for further reduced epochs
		ArrayList<Integer> reduced = singleEpoch(getWeight().getTrainIndices());

		if (reduced.size() == 0) {
			// Nothing changed in this iteration
			addedToWeight = false;
		}
		else {
			// Reduced epochs
			addedToWeight = true;
			ArrayList<Integer> tmp;
			for (int r = 0; r < getReducedIter(); r++) {
				tmp = singleEpoch(reduced);
				if (tmp.size() == 0) {
					break;
				}
			}
		}

		return addedToWeight;
	}

	/**
	 * @param dataIndices
	 * @return Indices of those patterns, that resulted in changing the weight.
	 * @throws Exception
	 */
	private ArrayList<Integer> singleEpoch(ArrayList<Integer> dataIndices) throws Exception {
		ArrayList<Integer> updated = new ArrayList<Integer>(dataIndices.size());

		for (int j : dataIndices) {
			// Update classifier on each index ...
			if (updateClassifier(j)) {
				// ... and save those, that changed the weight
				updated.add(j);
			}
		}

		return updated;
	}

	/**
	 * @param inst
	 * @param n
	 * @return true iff the weight changed (may it be updating, budgeting, etc.).
	 * @throws Exception
	 */
	private boolean updateClassifier(int n) throws Exception {
		boolean weightChanged = false;

		int yN = getWeight().classLableGet(n);
		double outputN = getWeight().perceptronOutput(n);
		double currentMargin = this.margin.getCurrentMargin(n, yN, this.totalUpdateCount);
		double diffToMargin = currentMargin - yN * outputN;
		// Hinge loss, that might be prone to outliers.
		double lossN = Math.max(0.0, diffToMargin);

		weightChanged = this.update.boundUpdateWeight(getAlphaBound(), n, yN, lossN, outputN, currentMargin, this.updateCount[n], this.totalUpdateCount);

		/*
		this.logger.log("\nJust tried to update:");
		this.logger.log("n = " + n);
		this.logger.log("yN = " + yN);
		this.logger.log("output = " + outputN);
		this.logger.log("currentMargin = " + currentMargin);
		this.logger.log("diffToMargin = " + diffToMargin);
		this.logger.log("loss = " + lossN);
		this.logger.log("weightChanged = " + weightChanged);
		*/

		// Manage longest surviving and voted perceptron
		if (weightChanged) {
			this.updateCount[n]++;
			this.totalUpdateCount++;
			this.currentVote = 0;
			this.tally = 0;
		}
		else if (!weightChanged) {
			if (getSurvivor()) {
				this.tally++;
				if (this.tally > this.bestTally) {
					this.bestTally = this.tally;
					this.weightSurvivor = getWeight().clone();
				}
			}
			else if (getVoted()) {
				if (this.currentVote <= 0) {
					this.currentVote = 1;
					this.weightVoters.add(getWeight().clone());
					this.weightVotes.add(this.currentVote);
				}
				else {
					this.currentVote++;
					int lastIndex = this.weightVotes.size() - 1;
					this.weightVotes.set(lastIndex, this.currentVote);
				}
			}
		}

		assert this.totalUpdateCount == sum(this.updateCount) : "Weight changes not counted correctly!";

		return weightChanged;
	}

	public static int sum(int[] array) {
		int sum = 0;
		for (int i : array) {
			sum += i;
		}
		return sum;
	}

	/**
	 * @param inst
	 * @return
	 * @throws Exception
	 */
	protected Instance prepareForPrediction(Instance inst) throws Exception {

		// Filter instance
		this.replaceMissingTrainingValues.input(inst);
		this.replaceMissingTrainingValues.batchFinished();
		inst = this.replaceMissingTrainingValues.output();

		this.trainingNominalToBinary.input(inst);
		this.trainingNominalToBinary.batchFinished();
		inst = this.trainingNominalToBinary.output();

		return new Instance(inst);
	}

	/**
	 * Outputs the distribution (as logical output).
	 * 
	 * @param inst
	 *            the instance for which distribution is to be computed
	 * @return the distribution
	 * @throws Exception
	 *             if something goes wrong
	 */
	@Override
	public double[] distributionForInstance(Instance inst) throws Exception {
		inst = prepareForPrediction(inst);

		double[] result = new double[2];

		if (getVoted()) {
			// Voted perceptrons
			int VOTES = 0;
			int yhat = 0;

			PerceptronWeight oldWeight = null;
			double oldOutput = 0;
			for (int i = 1; i < this.weightVoters.size(); i++) {
				assert (this.weightVotes.get(i) > 0) : "Found voting perceptron with 0-vote!";
				//				yhat = (int) Math.signum(this.weightVoters.get(i).perceptronOutput(inst, -1));
				oldOutput = this.weightVoters.get(i).perceptronDiffOutput(inst, -1, oldWeight, oldOutput);
				yhat = (int) Math.signum(oldOutput);
				VOTES += this.weightVotes.get(i) * yhat;
				oldWeight = this.weightVoters.get(i);
			}
			result[1] = 1 / (1 + Math.exp(-VOTES));
		}
		else {
			// Single perceptron (normalise the weight for comparable multi-class classification)
			double norm = getWeightToUse().getEuclideanLength();
			norm = norm == 0 ? 1 : norm;
			double output = getWeightToUse().perceptronOutput(inst, -1) / norm;
			result[1] = 1 / (1 + Math.exp(-output));
		}

		result[0] = 1 - result[1];
		return result;
	}

	@Override
	public Capabilities getCapabilities() {
		Capabilities result = new Capabilities(this);

		result.disableAll();

		// Attributes
		result.enable(Capability.NOMINAL_ATTRIBUTES);
		result.enable(Capability.NUMERIC_ATTRIBUTES);
		result.enable(Capability.DATE_ATTRIBUTES);
		result.enable(Capability.MISSING_VALUES);

		// Binary classes
		result.enable(Capability.BINARY_CLASS);
		result.enable(Capability.MISSING_CLASS_VALUES);

		// At least one for voting or surviving
		result.setMinimumNumberInstances(1);

		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tMaximum number of iterations.\n" + "\t(default 100)", "I", 1, "-I <num>"));
		result.addElement(new Option("\tN (Reduced Epochen).\n" + "\t(default 0)", "N", 1, "-N <num>"));
		result.addElement(new Option("\tAugment the data: 0=0/1=1/2=Average length/3=Maximum length.\n" + "\t(default 1)", "R", 1, "-R <num>"));
		result.addElement(new Option("\tVariants: 0=Classic/1=Survivor/2=Voted.\n" + "\t(default 0)", "V", 1, "-V <num>"));
		result.addElement(new Option("\tAlpha-bound.\n" + "\t(default Integer.MAX_VALUE)", "A", 1, "-A <num>"));

		result.addElement(new Option("\tThe Update to use.\n" + "\t(default: weka.classifiers.pla.addon.update.ConstantUpdate)", "U", 1,
				"-U <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to update " + getUpdate().getClass().getName() + ":"));

		Enumeration<Option> enup = getUpdate().listOptions();
		while (enup.hasMoreElements()) {
			result.addElement(enup.nextElement());
		}

		result.addElement(new Option("\tThe Margin to use.\n" + "\t(default: weka.classifiers.pla.addon.margin.UnevenConstantMargin)", "G", 1,
				"-G <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to margin " + getMargin().getClass().getName() + ":"));

		Enumeration<Option> enma = getMargin().listOptions();
		while (enma.hasMoreElements()) {
			result.addElement(enma.nextElement());
		}

		result.addElement(new Option("\tThe weight as a sum of weighted SVs.\n" + "\t(default: weka.classifiers.pla.weight.DualForm)", "W", 1,
				"-W <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to weight " + getWeight().getClass().getName() + ":"));

		Enumeration<Option> enw = getWeight().listOptions();
		while (enw.hasMoreElements()) {
			result.addElement(enw.nextElement());
		}

		Enumeration<Option> enu = super.listOptions();
		while (enu.hasMoreElements()) {
			result.addElement(enu.nextElement());
		}
		return result.elements();
	}

	@Override
	public String[] getOptions() {
		int i;
		Vector<String> result;
		String[] options;

		result = new Vector<String>();

		result.add("-I");
		result.add("" + getIter());

		result.add("-N");
		result.add("" + getReducedIter());

		result.add("-V");
		result.add(getVariant().toString());

		result.add("-A");
		result.add("" + getAlphaBound());

		result.add("-U");
		result.add("" + getUpdate().getClass().getName() + " " + Utils.joinOptions(getUpdate().getOptions()));

		result.add("-G");
		result.add("" + getMargin().getClass().getName() + " " + Utils.joinOptions(getMargin().getOptions()));

		result.add("-W");
		result.add("" + getWeight().getClass().getName() + " " + Utils.joinOptions(getWeight().getOptions()));

		options = super.getOptions();
		for (i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('I', options);
		if (tmp.length() != 0) {
			setIter(Integer.parseInt(tmp));
		}
		else {
			setIter(100);
		}
		tmp = Utils.getOption('N', options);
		if (tmp.length() != 0) {
			setReducedIter(Integer.parseInt(tmp));
		}
		else {
			setReducedIter(0);
		}
		tmp = Utils.getOption('V', options);
		if (tmp.length() != 0) {
			setVariant(new SelectedTag(Integer.parseInt(tmp), TAGS_VARIANT));
		}
		else {
			setVariant(new SelectedTag(VARIANT_CLASSICAL, TAGS_VARIANT));
		}
		tmp = Utils.getOption('A', options);
		if (tmp.length() != 0) {
			setAlphaBound(Integer.parseInt(tmp));
		}
		else {
			setAlphaBound(Integer.MAX_VALUE);
		}

		String updateString = Utils.getOption('U', options);
		String[] updateOptions = Utils.splitOptions(updateString);
		if (updateOptions.length != 0) {
			updateString = updateOptions[0];
			updateOptions[0] = "";
			setUpdate(Update.forName(updateString, updateOptions));
		}

		String marginString = Utils.getOption('G', options);
		String[] marginOptions = Utils.splitOptions(marginString);
		if (marginOptions.length != 0) {
			marginString = marginOptions[0];
			marginOptions[0] = "";
			setMargin(Margin.forName(marginString, marginOptions));
		}

		String weightString = Utils.getOption('W', options);
		String[] weightOptions = Utils.splitOptions(weightString);
		if (weightOptions.length != 0) {
			weightString = weightOptions[0];
			weightOptions[0] = "";
			setWeight(PerceptronWeight.forName(weightString, weightOptions));
		}

		super.setOptions(options);
	}

	@Override
	public Enumeration<String> enumerateMeasures() {
		Vector<String> v = new Vector<String>();

		// Number of SVs in the final classical perceptron
		v.add("measureCountSV");
		// Iters done
		v.add("measureNumIterationsNeeded");

		return v.elements();
	}

	@Override
	public double getMeasure(String measure) {
		if (measure.equals("measureCountSV")) {
			return getWeight().getCountSV();
		}
		else if (measure.equals("measureNumIterationsNeeded")) {
			return this.numIterationsNeeded;
		}
		else {
			return 0;
		}
	}

	@Override
	public String toString() {
		StringBuffer text = new StringBuffer();

		text.append("# SVs: " + getWeightToUse().getCountSV() + "\n");
		text.append("Weight: " + "\n" + getWeightToUse() + "\n");
		//		text.append("w (linear): " + Arrays.toString(getWeightToUse().getLinearWeight()) + "\n");
		//		try {
		//			text.append("|w| by get: " + getWeightToUse().getEuclideanLength() + "\n");
		//			text.append("|w| by calc: " + getWeightToUse().calcEuclideanLength() + "\n");
		//		}
		//		catch (Exception e1) {
		//			text.append("|w| by get: Exception occured!\n");
		//			text.append("|w| by calc: Exception occured!\n");
		//			e1.printStackTrace();
		//		}
		text.append("Iterations needed: " + this.numIterationsNeeded + "\n");
		if (getSurvivor()) {
			text.append("Survivor lasted: " + this.bestTally + "\n");
		}

		return text.toString();
	}

	public String globalInfo() {
		return "Perceptron-like algorithm composition.";
	}

	@Override
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 1.0 $");
	}

	public PerceptronWeight getWeight() {
		return this.weight;
	}

	public PerceptronWeight getWeightToUse() {
		if (getSurvivor() && this.weightSurvivor != null) {
			return this.weightSurvivor;
		}
		else {
			return this.weight;
		}
	}

	public void setWeight(PerceptronWeight weight) {
		this.weight = weight;
	}

	/**
	 * @return
	 */
	public String iterTipText() {
		return "Iterations.";
	}

	/**
	 * @return
	 */
	public int getIter() {
		return this.numIterations;
	}

	/**
	 * @param v
	 */
	public void setIter(int v) {
		this.numIterations = v;
	}

	/**
	 * @return
	 */
	public String reducedIterTipText() {
		return "Reduced epochs.";
	}

	/**
	 * @return the reducedIter
	 */
	public int getReducedIter() {
		return this.reducedIter;
	}

	/**
	 * @param reducedIter
	 *            the reducedIter to set
	 */
	public void setReducedIter(int reducedIter) {
		this.reducedIter = reducedIter;
	}

	/**
	 * @return
	 */
	public String variantTipText() {
		return "Variants: 0=Classic/1=Survivor/2=Voted.";
	}

	/**
	 * @return
	 */
	public SelectedTag getVariant() {
		return new SelectedTag(this.variant, TAGS_VARIANT);
	}

	/**
	 * @param variant
	 */
	public void setVariant(SelectedTag variant) {
		if (variant.getTags() == TAGS_VARIANT) {
			this.variant = variant.getSelectedTag().getID();
		}
	}

	/**
	 * @return if using longest survivor
	 */
	public boolean getSurvivor() {
		return this.variant == VARIANT_SURVIVOR;
	}

	/**
	 * @return if using voted model
	 */
	public boolean getVoted() {
		return this.variant == VARIANT_VOTED;
	}

	/**
	 * @return
	 */
	public String marginTipText() {
		return "Margin type.";
	}

	/**
	 * @return the margin
	 */
	public Margin getMargin() {
		return this.margin;
	}

	/**
	 * @param margin
	 *            the margin to set
	 */
	public void setMargin(Margin margin) {
		this.margin = margin;
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter GUI
	 */
	public String updateTipText() {
		return "The update method to use.";
	}

	/**
	 * @param update
	 *            the update to set
	 */
	public void setUpdate(Update update) {
		this.update = update;
	}

	/**
	 * @return the update
	 */
	public Update getUpdate() {
		return this.update;
	}

	/**
	 * @return
	 */
	public String alphaBoundTipText() {
		return "Bound on how often a SV may result in a weight change.";
	}

	/**
	 * @return the alphaBound
	 */
	public int getAlphaBound() {
		return this.alphaBound;
	}

	/**
	 * @param alphaBound
	 *            the alphaBound to set
	 */
	public void setAlphaBound(int alphaBound) {
		this.alphaBound = alphaBound;
	}

}
