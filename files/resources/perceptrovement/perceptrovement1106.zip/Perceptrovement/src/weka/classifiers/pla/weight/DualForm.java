package weka.classifiers.pla.weight;

import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import weka.classifiers.functions.supportVector.Kernel;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public class DualForm extends PerceptronWeight {

	/** Serialisation ID */
	private static final long serialVersionUID = 4886112753410806380L;

	/** The weights for each pattern to be added to the weight */
	private double[] alphas;
	/** Indices of the SVs */
	private ArrayList<Integer> indexSV;

	@Override
	public void prepare(Instances data) {
		super.prepare(data);

		this.alphas = new double[data.numInstances()];
		this.indexSV = new ArrayList<Integer>(data.numInstances());
	}

	@SuppressWarnings("unchecked")
	@Override
	public DualForm clone() throws CloneNotSupportedException {
		DualForm w = (DualForm) super.clone();

		w.alphas = this.alphas.clone();
		w.indexSV = (ArrayList<Integer>) this.indexSV.clone();

		return w;
	}

	/**
	 * Set alphas[index] to v. Maintain indices of the SVs. Updates euclideanLength with oldOutput.
	 * 
	 * @param index
	 * @param v
	 * @param oldOutput
	 * @throws Exception
	 */
	private void alphasSet(int index, double v, double oldOutput) throws Exception {
		double oldAlpha = this.alphas[index];
		double factor = v - oldAlpha;
		double oldSquare = getEuclideanLength() * getEuclideanLength();
		double qK = this.dotProduct(index, index);
		double inSqrt = oldSquare + factor * (2 * oldOutput + factor * qK);
		if (inSqrt < 0 && inSqrt > -Math.pow(10, -15) && v == 0) {
			inSqrt = 0;
		}
		setEuclideanLength((Math.sqrt(inSqrt)));
		assert !(Double.isNaN(getEuclideanLength())) : "Calculating weight length failed: " + Double.toString(v) + " " + Double.toString(oldOutput) + " "
				+ Double.toString(oldAlpha) + " " + Double.toString(factor) + " " + Double.toString(oldSquare) + " " + Double.toString(qK) + " "
				+ Double.toString(oldSquare + factor * (2 * oldOutput + factor * qK));
		// PA & MICRAMargin don't like each other
		if (Double.isNaN(getEuclideanLength())) {
			calcEuclideanLength();
		}

		this.alphasSet(index, v);
	}

	/**
	 * Set alphas[index] to v. Maintain indices of the SVs. Does not update euclideanLength.
	 * 
	 * @param index
	 * @param v
	 */
	private void alphasSet(int index, double v) {
		//assert (this.alphas[index] != v) : "Useless setting.";
		if (this.alphas[index] == 0 && v != 0) {
			assert !(this.indexSV.contains(new Integer(index))) : "SV to be freshly added was already registered as an SV!";
			this.indexSV.add(index);
		}
		else if (this.alphas[index] != 0 && v == 0) {
			boolean removingWorked = false;
			removingWorked = this.indexSV.remove(new Integer(index));
			assert removingWorked : "SV to be removed wasn't registered as an SV!";
		}
		this.alphas[index] = v;
	}

	@Override
	public void safeAdd(int index, double factor) throws Exception {
		if (factor != 0) {
			double oldAlpha = this.alphas[index];
			double oldOutput = this.perceptronOutput(index);
			this.alphasSet(index, oldAlpha + factor, oldOutput);
		}
	}

	@Override
	public boolean updateWeight(int index, double factor, double oldOutput) throws Exception {
		if (factor != 0) {
			double oldAlpha = this.alphas[index];
			this.alphasSet(index, oldAlpha + factor, oldOutput);

			getBudget().budgetMaintenance();

			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public boolean scale(double factor) throws Exception {
		if (factor != 1 && getEuclideanLength() != 0) {
			for (int i : getIndexSV()) {
				this.alphasSet(i, this.alphas[i] * factor);
			}
			this.euclideanLength *= factor;

			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public void remove(int index) throws Exception {
		double oldOutput = this.perceptronOutput(index);
		this.alphasSet(index, 0, oldOutput);
	}

	@Override
	public double perceptronOutput(Instance inst, int index) throws Exception {
		double output = 0;

		for (int i : this.indexSV) {
			assert (this.alphas[i] != 0) : "Registered SV has alpha = 0.";
			output += this.alphas[i] * this.dotProduct(index, i, inst);
		}

		return output;
	}

	public static Collection<Integer> union(Collection<Integer> coll1, Collection<Integer> coll2) {
		Set<Integer> union = new HashSet<Integer>(coll1);
		union.addAll(new HashSet<Integer>(coll2));
		return new ArrayList<Integer>(union);
	}

	@Override
	public double perceptronDiffOutput(Instance inst, int index, PerceptronWeight oldWeight, double oldOutput) throws Exception {
		double diff;
		double newOutput = oldOutput;

		if (oldWeight == null) {
			newOutput = perceptronOutput(inst, index);
		}
		else {
			//			for (int i : union(this.indexSV, ((DualForm) oldWeight).indexSV)) { // quite slow
			for (int i = 0; i < this.alphas.length; i++) {
				diff = this.alphas[i] - ((DualForm) oldWeight).alphas[i];
				if (diff != 0) {
					newOutput += diff * this.dotProduct(index, i, inst);
				}
			}
		}

		return newOutput;
	}

	@Override
	public double calcEuclideanLength() throws Exception {
		double res = 0;

		if (!noModelYet()) {
			for (int i : this.indexSV) {
				for (int j : this.indexSV) {
					assert (this.alphas[i] != 0 && this.alphas[j] != 0) : "Registered SV has alpha = 0.";
					if (i > j) {
						res += 2 * this.alphas[i] * this.alphas[j] * this.dotProduct(i, j, this.train[i]);
					}
					else if (i == j) {
						res += this.alphas[i] * this.alphas[j] * this.dotProduct(i, j, this.train[i]);
					}
				}
			}
			assert res >= 0;
		}

		res = Math.sqrt(res);
		setEuclideanLength(res);

		return res;
	}

	@Override
	public double dotProduct(int id1, int id2, Instance inst1) throws Exception {
		double res = getAugment().getAugmentedAddToKernel();
		double kernelProductOnly = (id1 == id2) ? this.kernelSquareCache[id1] : getKernel().eval(id1, id2, inst1);
		res += kernelProductOnly;
		if (id1 == id2) {
			res += Math.abs(getLambda()) * (getLambda() < 0 ? kernelProductOnly : 1);
		}
		return res;
	}

	@Override
	public double added(int instIndex) {
		return this.alphas[instIndex];
	}

	@Override
	public double[] getLinearWeight() {
		double[] res = { 0 };

		if (noModelYet()) {
			return res;
		}
		else {
			res = new double[this.data.numAttributes() + numInstances()];

			for (int i : this.indexSV) {
				addToWeight(i, res);
			}
		}

		return res;
	}

	/**
	 * Add instance i to the weight vector res. Take lambda trick (w/o scale) and augmentation into consideration.
	 * 
	 * @param i
	 * @param res
	 */
	private void addToWeight(int i, double[] res) {
		Instance xi = this.train[i];
		double a = this.alphas[i];
		res[0] += a * Math.sqrt(getAugment().getAugmentedAddToKernel());
		int index = 0;
		for (int d = 0; d < xi.numAttributes(); d++) {
			if (d != xi.classIndex()) {
				index++;
				res[index] += a * xi.value(d);
			}
		}
		res[index + 1 + i] += a * Math.sqrt(Math.abs(getLambda()));
	}

	@Override
	public boolean noModelYet() {
		return super.noModelYet() || this.alphas == null || this.indexSV == null;
	}

	@Override
	public String toString() {
		if (noModelYet()) {
			return "0";
		}
		else {
			StringBuffer text = new StringBuffer();

			text.append("alphas: " + Arrays.toString(this.alphas) + "\n");
			text.append("sv-inds: " + this.indexSV + "\n");
			text.append("svs: " + this.indexSV + "\n");
			for (int i : this.indexSV) {
				text.append(this.train[i] + "\n");
			}
			int numEval = 0;
			int numCacheHits = -1;
			if (getKernel() != null) {
				numEval = getKernel().numEvals();
				numCacheHits = getKernel().numCacheHits();
			}
			text.append("\n\nReal number of kernel evaluations: " + numEval);
			if (numCacheHits >= 0 && numEval > 0) {
				double hitRatio = 1 - numEval * 1.0 / (numCacheHits + numEval);
				text.append(" (" + Utils.doubleToString(hitRatio * 100, 7, 3).trim() + "% cached over all)");
			}

			return text.toString();
		}
	}

	/**
	 * @return the number of actually used SVs
	 */
	@Override
	public int getCountSV() {
		if (noModelYet()) {
			return 0;
		}
		else {
			return this.indexSV.size();
		}
	}

	@Override
	public int indexSVGet(int i) {
		return this.indexSV.get(i);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Integer> getIndexSV() {
		if (this.indexSV != null) {
			return (ArrayList<Integer>) this.indexSV.clone();
		}
		else {
			return new ArrayList<Integer>();
		}
	}

	@Override
	public String globalInfo() {
		return "Kernelized weight in dual form.";
	}

	@SuppressWarnings("unchecked")
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tThe Kernel to use.\n" + "\t(default: weka.classifiers.functions.supportVector.PolyKernel)", "K", 1,
				"-K <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to kernel " + getKernel().getClass().getName() + ":"));

		Enumeration<Option> enke = ((OptionHandler) getKernel()).listOptions();
		while (enke.hasMoreElements()) {
			result.addElement(enke.nextElement());
		}

		Enumeration<Option> enu = super.listOptions();
		while (enu.hasMoreElements()) {
			result.addElement(enu.nextElement());
		}
		return result.elements();
	}

	@Override
	public String[] getOptions() {
		int i;
		Vector<String> result;
		String[] options;

		result = new Vector<String>();
		options = super.getOptions();
		for (i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		result.add("-K");
		result.add("" + getKernel().getClass().getName() + " " + Utils.joinOptions(getKernel().getOptions()));

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String kernelString = Utils.getOption('K', options);
		String[] kernelOptions = Utils.splitOptions(kernelString);
		if (kernelOptions.length != 0) {
			kernelString = kernelOptions[0];
			kernelOptions[0] = "";
			setKernel(Kernel.forName(kernelString, kernelOptions));
		}

		super.setOptions(options);
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter gui
	 */
	public String kernelTipText() {
		return "The kernel to use.";
	}

	/**
	 * sets the kernel to use
	 * 
	 * @param value
	 *            the kernel to use
	 */
	public void setKernel(Kernel value) {
		this.kernel = value;
	}

	/**
	 * Returns the kernel to use
	 * 
	 * @return the current kernel
	 */
	public Kernel getKernel() {
		return this.kernel;
	}

	/**
	 * Return i's label on the fly. Slower than storing each label.
	 * 
	 * @param i
	 * @return
	 */
	private int testGetLable(int i) {
		return (this.data.instance(i).classValue() <= 0) ? -1 : 1;
	}

	public static void main(String[] args) throws Exception {
		// Benchmark that shows that one should recognize the data first.

		DualForm d = new DualForm();
		Reader r = new FileReader("data/weka/iris2.arff");
		Instances i = new Instances(r);
		i.setClassIndex(4);
		d.prepare(i);

		for (int j = 0; j < 1; j++) {
			long tStart = System.currentTimeMillis();
			d.recognize(i);
			long t = System.currentTimeMillis() - tStart;
			System.out.println(t);
		}

		int dummy = 0;
		for (int j = 0; j < 10000000; j++) {
			dummy = d.testGetLable(1);
			dummy = d.classLableGet(1);
		}
		System.out.println(dummy);

		int sum = 0;
		long tStart = System.currentTimeMillis();
		for (int j = 0; j < 1000000000; j++) {
			sum += d.testGetLable(1);
		}
		long t = System.currentTimeMillis() - tStart;
		System.out.println(sum);
		System.out.println(t);

		sum = 0;
		tStart = System.currentTimeMillis();
		for (int j = 0; j < 1000000000; j++) {
			sum += d.classLableGet(1);
		}
		t = System.currentTimeMillis() - tStart;
		System.out.println(sum);
		System.out.println(t);

		sum = 0;
		tStart = System.currentTimeMillis();
		for (int j = 0; j < 1000000000; j++) {
			sum += d.testGetLable(1);
		}
		t = System.currentTimeMillis() - tStart;
		System.out.println(sum);
		System.out.println(t);
	}
}
