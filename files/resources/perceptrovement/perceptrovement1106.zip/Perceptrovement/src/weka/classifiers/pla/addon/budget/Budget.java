package weka.classifiers.pla.addon.budget;

import java.util.Enumeration;
import java.util.Vector;

import weka.classifiers.pla.addon.Addon;
import weka.core.Option;
import weka.core.Utils;

public abstract class Budget extends Addon {

	private static final long serialVersionUID = -5538967494378000878L;

	/** Maximum number of SVs allowed */
	private int budget = Integer.MAX_VALUE;

	/**
	 * Get rid of SVs one by one until the budget is maintained.
	 * 
	 * @throws Exception
	 */
	public final void budgetMaintenance() throws Exception {
		int numberOfSV = getWeight().getCountSV();
		for (int i = 0; i < numberOfSV - getBudget(); i++) {
			assert getWeight().getCountSV() > getBudget();
			getRidOfOneSV();
		}
		assert getWeight().getCountSV() <= getBudget();
	}

	/**
	 * Get rid of one SV in getWeight() by some heuristic.
	 * 
	 * @throws Exception
	 */
	protected abstract void getRidOfOneSV() throws Exception;

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tBudget on SVs.\n" + "\t(default Integer.MAX_VALUE)", "B", 1, "-B <num>"));

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-B");
		result.add("" + getBudget());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('B', options);
		if (tmp.length() != 0) {
			setBudget(Integer.parseInt(tmp));
		}
		else {
			setBudget(Integer.MAX_VALUE);
		}
	}

	/**
	 * Creates a new instance of a Budget given its class name and (optional) arguments to pass to its setOptions
	 * method.
	 * 
	 * @param budgetName
	 *            the fully qualified class name of the Budget
	 * @param options
	 *            an array of options suitable for passing to setOptions. May be null.
	 * @return the newly created Budget, ready for use.
	 * @throws Exception
	 *             if the Budget name is invalid, or the options supplied are not acceptable to the Budget
	 */
	public static Budget forName(String budgetName, String[] options) throws Exception {

		return (Budget) Utils.forName(Budget.class, budgetName, options);
	}

	/**
	 * @return
	 */
	public String budgetTipText() {
		return "Budget on SVs.";
	}

	/**
	 * @param budget
	 *            the budget to set
	 */
	public void setBudget(int budget) {
		this.budget = budget;
	}

	/**
	 * @return the budget
	 */
	public int getBudget() {
		return this.budget;
	}

}
