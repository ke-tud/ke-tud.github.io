package weka.classifiers.pla.weight;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import weka.classifiers.functions.supportVector.Kernel;
import weka.classifiers.functions.supportVector.PolyKernel;
import weka.classifiers.pla.addon.augment.Augment;
import weka.classifiers.pla.addon.augment.RealNumber;
import weka.classifiers.pla.addon.budget.Budget;
import weka.classifiers.pla.addon.budget.JustRemove;
import weka.core.Capabilities;
import weka.core.CapabilitiesHandler;
import weka.core.Debug;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionHandler;
import weka.core.RevisionUtils;
import weka.core.Utils;

public abstract class PerceptronWeight implements Cloneable, Serializable, OptionHandler, RevisionHandler, CapabilitiesHandler {

	/** Serialisation ID */
	private static final long serialVersionUID = -3581808584068434312L;

	/** Training Instances (given to kernel) */
	protected Instances data;
	/** Training data for access */
	protected Instance[] train;
	/** Data accessible via the indices */
	protected ArrayList<Integer> trainIndices;
	/** Label: -1 or +1 */
	protected int[] classLable;

	/** Euclidean length */
	protected double euclideanLength;

	/** The kernel to use */
	protected Kernel kernel = new PolyKernel();
	/** Special kernel square cache */
	protected double[] kernelSquareCache;

	/** Lambda trick value */
	protected double lambda = 0;
	/** Augment a dimension to the data */
	private Augment augment = new RealNumber();
	/** Budget on #SVs */
	private Budget budget = new JustRemove();

	private Debug logger;

	@Override
	public PerceptronWeight clone() throws CloneNotSupportedException {
		// No deep clone, but also not purely shallow
		PerceptronWeight w = (PerceptronWeight) super.clone();
		return w;
	}

	@Override
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 1.0 $");
	}

	@Override
	public Capabilities getCapabilities() {
		Capabilities result = new Capabilities(this);
		result.enableAll();

		return result;
	}

	/**
	 * Initialise the weight with data to comprise.
	 * 
	 * @param data
	 *            The instances for training.
	 * @param attributes
	 *            Of the training data.
	 * @param spaceReq
	 *            How much data to expect for initialisation.
	 * @throws Exception
	 *             Data fails tests.
	 */
	public final void init(Instances data, Debug logger) throws Exception {
		this.logger = logger;
		prepare(data);
		recognize(data);
		initAddons(this);
	}

	/**
	 * Prepare this weight for the data to come.
	 * 
	 * @param data
	 *            Training instances.
	 * @param attributes
	 *            Their attributes.
	 * @param spaceReq
	 *            How many instances to expect.
	 */
	protected void prepare(Instances data) {
		setEuclideanLength(0);

		this.train = new Instance[data.numInstances()];
		this.trainIndices = new ArrayList<Integer>(data.numInstances());
		this.classLable = new int[data.numInstances()];
	}

	public boolean noModelYet() {
		return this.data == null || this.train == null || this.trainIndices == null || this.classLable == null;
	}

	/**
	 * Recognise the data by adding each data-point one by one.
	 * 
	 * @param data
	 *            The training data.
	 * @throws Exception
	 */
	protected void recognize(Instances data) throws Exception {
		this.data = data;

		for (int i = 0; i < data.numInstances(); i++) {
			Instance instance = data.instance(i);
			this.train[i] = instance;

			int index;
			if (this.trainIndices.isEmpty()) {
				index = 0;
			}
			else {
				index = this.trainIndices.get(this.trainIndices.size() - 1) + 1;
			}
			this.trainIndices.add(index);

			if (instance.classValue() <= 0) {
				this.classLable[i] = (-1);
			}
			else {
				this.classLable[i] = (1);
			}
		}

		// Inform kernel about new data
		this.kernel.buildKernel(this.data);

		this.kernelSquareCache = new double[this.train.length];
		for (int i = 0; i < this.kernelSquareCache.length; i++) {
			this.kernelSquareCache[i] = this.kernel.eval(i, i, this.train[i]);
		}
	}

	/**
	 * Link my addons to a PerceptronWeight.
	 * 
	 * @param p
	 *            To be linked.
	 * @throws Exception
	 */
	protected void initAddons(PerceptronWeight p) throws Exception {
		getAugment().init(p, getLogger());
		getBudget().init(p, getLogger());
	}

	/**
	 * @return The max square of the training-data.
	 * @throws Exception
	 *             If a dot-product fails.
	 */
	public double maxSquare() throws Exception {
		double max = 0;
		double cur = 0;

		for (int i = 0; i < numInstances(); i++) {
			cur = this.dotProduct(i, i);
			if (cur > max) {
				max = cur;
			}
		}

		return max;
	}

	/**
	 * @return The average square of the training-data.
	 * @throws Exception
	 *             If a dot-product fails.
	 */
	public double averageSquare() throws Exception {
		double sum = 0;

		for (int i = 0; i < numInstances(); i++) {
			sum += this.dotProduct(i, i);
		}

		return sum / numInstances();
	}

	/**
	 * @return A short description of the implementation of this class.
	 */
	public abstract String globalInfo();

	/**
	 * Wrap dotProduct(int i1, int i2, Instance inst1) for training data only.
	 * 
	 * @param i1
	 * @param i2
	 * @return
	 * @throws Exception
	 */
	public double dotProduct(int id1, int id2) throws Exception {
		return this.dotProduct(id1, id2, this.train[id1]);
	}

	/**
	 * Wrap any dot product with augmentation and lambda-trick.
	 * 
	 * @param i1
	 *            Index of first instance.
	 * @param i2
	 *            Index of second instance.
	 * @param inst1
	 *            To be used, if i1 is -1.
	 * @return Dot product of i1 and i2.
	 * @throws Exception
	 */
	public abstract double dotProduct(int i1, int i2, Instance inst1) throws Exception;

	/**
	 * Wrap perceptronOutput(Instance inst, int instIndex) for training data only.
	 * 
	 * @param instIndex
	 * @return
	 * @throws Exception
	 */
	public double perceptronOutput(int instIndex) throws Exception {
		return this.perceptronOutput(this.train[instIndex], instIndex);
	}

	/**
	 * @param inst
	 *            Instance to be fed into the perceptron.
	 * @param instIndex
	 *            Training index, -1 if unknown example.
	 * @return Output of this perceptron weight given inst and its index.
	 * @throws Exception
	 */
	public abstract double perceptronOutput(Instance inst, int instIndex) throws Exception;

	/**
	 * Override to maybe get fast output by looking at "similar" oldWeight and its oldOutput for inst i.
	 * 
	 * @param inst
	 * @param i
	 * @param oldWeight
	 * @param oldOutput
	 * @return
	 * @throws Exception
	 */
	public double perceptronDiffOutput(Instance inst, int i, PerceptronWeight oldWeight, double oldOutput) throws Exception {
		return perceptronOutput(inst, i);
	}

	/**
	 * Update this weight due to a misclassification during the learning process. It has to do budget maintenance and
	 * stick to the alpha-bound. It has to keep track of the updates made so far. Maintains SV indices.
	 * 
	 * @param j
	 *            Index of data-point in training set to added.
	 * @param factor
	 *            Add data-point j times factor to this weight.
	 * @param outputJ
	 *            Has to be perceptronOutput(j) immediately before this update to efficiently calculate the new
	 *            Euclidean length of this weight.
	 * @return True iff. the weight got changed.
	 * @throws Exception
	 */
	public abstract boolean updateWeight(int j, double factor, double outputJ) throws Exception;

	/**
	 * Scale this weight vector by a scalar. Maintains SV indices.
	 * 
	 * @param factor
	 *            Scalar to scale this weight by.
	 * @return True iff. scaling actually changed the weight.
	 * @throws Exception
	 */
	public abstract boolean scale(double factor) throws Exception;

	/**
	 * Add the training instance with index i times factor to this weight. Not in the sense of updating during learning
	 * because of a "misclassification". It's safe, because it updates the Euclidean length of this weight. Maintains SV
	 * indices.
	 * 
	 * @param i
	 *            Training data index.
	 * @param factor
	 *            Scalar to multiply Instance i by before adding.
	 * @throws Exception
	 */
	public abstract void safeAdd(int i, double factor) throws Exception;

	/**
	 * @param instIndex
	 *            Index of the added training data point.
	 * @return How much the training data point with Index instIndex was added to this weight.
	 */
	public abstract double added(int instIndex);

	/**
	 * @return The number of support vectors that span this weight vector.
	 */
	public abstract int getCountSV();

	/**
	 * @return The linear representation of this weight.
	 */
	public abstract double[] getLinearWeight();

	/**
	 * Recalculate and internally save this weight's Euclidean length.
	 * 
	 * @return The recalculated length.
	 * @throws Exception
	 */
	public abstract double calcEuclideanLength() throws Exception;

	/**
	 * The indices of SVs should be stored in an extra, size-variable data-structure. This function maps their indices
	 * in this special data-structure to their index in the training data-set.
	 * 
	 * @param indirectIndex
	 *            Index of an SV in the special SV set.
	 * @return The training data index of an SV in the special SV index set.
	 */
	public abstract int indexSVGet(int indirectIndex);

	/**
	 * Remove added data-point x with index instIndex from this weight.
	 * 
	 * @param instIndex
	 *            Index of x in trainingInstances
	 * @throws Exception
	 */
	public abstract void remove(int instIndex) throws Exception;

	/**
	 * Similar as in Kernel. Call when training is over and eventually cached data is not needed anymore.
	 */
	public void clean() {
		this.kernel.clean();
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tLambda trick value. Negative -> absolute scale.\n" + "\t(default 0)", "M", 1, "-M <num>"));

		result.addElement(new Option("\tThe augmented dimension.\n" + "\t(default: weka.classifiers.pla.addon.augment.RealNumber)", "T", 1,
				"-T <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to augmentation " + getAugment().getClass().getName() + ":"));

		Enumeration<Option> enaug = getAugment().listOptions();
		while (enaug.hasMoreElements()) {
			result.addElement(enaug.nextElement());
		}

		result.addElement(new Option("\tThe budget on #SVs.\n" + "\t(default: weka.classifiers.pla.addon.budget.JustRemove)", "B", 1,
				"-B <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to budget " + getBudget().getClass().getName() + ":"));

		Enumeration<Option> enbud = getBudget().listOptions();
		while (enbud.hasMoreElements()) {
			result.addElement(enbud.nextElement());
		}

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;

		result = new Vector<String>();

		result.add("-M");
		result.add("" + getLambda());

		result.add("-T");
		result.add("" + getAugment().getClass().getName() + " " + Utils.joinOptions(getAugment().getOptions()));

		result.add("-B");
		result.add("" + getBudget().getClass().getName() + " " + Utils.joinOptions(getBudget().getOptions()));

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('M', options);
		if (tmp.length() != 0) {
			setLambda(Double.parseDouble(tmp));
		}
		else {
			setLambda(0);
		}

		String augmentString = Utils.getOption('T', options);
		String[] augmentOptions = Utils.splitOptions(augmentString);
		if (augmentOptions.length != 0) {
			augmentString = augmentOptions[0];
			augmentOptions[0] = "";
			setAugment(Augment.forName(augmentString, augmentOptions));
		}

		String budgetString = Utils.getOption('B', options);
		String[] budgetOptions = Utils.splitOptions(budgetString);
		if (budgetOptions.length != 0) {
			budgetString = budgetOptions[0];
			budgetOptions[0] = "";
			setBudget(Budget.forName(budgetString, budgetOptions));
		}
	}

	/**
	 * @return Help text for the augment addon.
	 */
	public String augmentTipText() {
		return "How to augment data by one dimension (\"after\" kernel).";
	}

	/**
	 * @param augment
	 *            the augment to set
	 */
	public void setAugment(Augment augment) {
		this.augment = augment;
	}

	/**
	 * @return the augment
	 */
	public Augment getAugment() {
		return this.augment;
	}

	/**
	 * @return
	 */
	public String budgetTipText() {
		return "Budget on the number of support vectors.";
	}

	/**
	 * @param budget
	 *            the budget to set
	 */
	public void setBudget(Budget budget) {
		this.budget = budget;
	}

	/**
	 * @return the budget
	 */
	public Budget getBudget() {
		return this.budget;
	}

	/**
	 * @return Help on lambda trick value.
	 */
	public String lambdaTipText() {
		return "Lambda-trick value. Negative -> |lambda| scaled by ||x_n||²";
	}

	/**
	 * @return the lambda
	 */
	public double getLambda() {
		return this.lambda;
	}

	/**
	 * @return the lambda to use
	 * @throws Exception
	 */
	protected double getLambdaToUse(int index) throws Exception {
		return Math.abs(this.lambda) * (this.lambda < 0 ? this.kernelSquareCache[index] : 1);
	}

	/**
	 * @param lambda
	 *            the lambda to set
	 */
	public void setLambda(double lambda) {
		this.lambda = lambda;
	}

	/**
	 * @return The current number of training instances.
	 */
	public int numInstances() {
		return this.data.numInstances();
	}

	/**
	 * @return the trainingIndices
	 */
	public ArrayList<Integer> getTrainIndices() {
		return this.trainIndices;
	}

	/**
	 * @param euclideanLength
	 *            the euclideanLength to set
	 */
	protected void setEuclideanLength(double euclideanLength) {
		this.euclideanLength = euclideanLength;
	}

	/**
	 * @return the euclideanLength
	 * @throws Exception
	 * @throws Exception
	 */
	public double getEuclideanLength() throws Exception {
		return this.euclideanLength;
	}

	/**
	 * @param j
	 *            Index of a training instance.
	 * @return The label of instance j from {-1, 1}.
	 */
	public int classLableGet(int j) {
		return this.classLable[j];
	}

	public static PerceptronWeight forName(String weightName, String[] options) throws Exception {

		return (PerceptronWeight) Utils.forName(PerceptronWeight.class, weightName, options);
	}

	protected Debug getLogger() {
		return this.logger;
	}

	/**
	 * @return Index array of SVs (should have no internal references -> array may be modified)
	 */
	public abstract ArrayList<Integer> getIndexSV();

}
