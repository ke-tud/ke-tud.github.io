package weka.classifiers.pla.addon.margin;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public class UnevenMargin extends Margin {

	private static final long serialVersionUID = 6753176791980664946L;

	/** Margin of negative class */
	private double negMargin = 1;
	/** Margin of positive class */
	private double posMargin = 1;
	/** Scale? */
	private boolean scale = false;

	/** Average kernel square to scale the margins */
	private double avgSquareScale = 1;

	@Override
	protected void init() throws Exception {
		if (getScale()) {
			this.avgSquareScale = getWeight().averageSquare();
		}
	}

	@Override
	public double getCurrentMargin(int n, int yN, int t) {
		return ((yN > 0) ? this.posMargin : this.negMargin) * this.avgSquareScale;
	}

	@Override
	public String globalInfo() {
		return "Uneven constant margin.";
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-N");
		result.add("" + getNegMargin());

		result.add("-P");
		result.add("" + getPosMargin());

		if (getScale()) {
			result.add("-S");
		}

		return result.toArray(new String[result.size()]);
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tMargin for negative instances.\n" + "\t(default 1)", "N", 1, "-N <num>"));
		result.addElement(new Option("\tMargin for positive instances.\n" + "\t(default 1)", "P", 1, "-P <num>"));
		result.addElement(new Option("\tScale by average kernel square.\n" + "\t(default false)", "S", 0, "-S"));

		return result.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('N', options);
		if (tmp.length() != 0) {
			setNegMargin(Double.parseDouble(tmp));
		}
		else {
			setNegMargin(1);
		}
		tmp = Utils.getOption('P', options);
		if (tmp.length() != 0) {
			setPosMargin(Double.parseDouble(tmp));
		}
		else {
			setPosMargin(1);
		}
		setScale(Utils.getFlag('S', options));
	}

	/**
	 * @return
	 */
	public String negMarginTipText() {
		return "Margin for negative instances.";
	}

	/**
	 * @param negMargin
	 *            the negMargin to set
	 */
	public void setNegMargin(double negMargin) {
		this.negMargin = negMargin;
	}

	/**
	 * @return the negMargin
	 */
	public double getNegMargin() {
		return this.negMargin;
	}

	/**
	 * @return
	 */
	public String posMarginTipText() {
		return "Margin for positive instances.";
	}

	/**
	 * @param posMargin
	 *            the posMargin to set
	 */
	public void setPosMargin(double posMargin) {
		this.posMargin = posMargin;
	}

	/**
	 * @return the posMargin
	 */
	public double getPosMargin() {
		return this.posMargin;
	}

	/**
	 * @return
	 */
	public String scaleTipText() {
		return "Whether to scale the respective margin by the average kernel square of all examples.";
	}

	public void setScale(boolean scale) {
		this.scale = scale;
	}

	public boolean getScale() {
		return this.scale;
	}

}
