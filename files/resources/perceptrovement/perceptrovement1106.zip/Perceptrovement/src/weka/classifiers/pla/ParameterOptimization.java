package weka.classifiers.pla;

import java.beans.PropertyDescriptor;
import java.util.Enumeration;
import java.util.Vector;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.RandomizableSingleClassifierEnhancer;
import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.PropertyPath;
import weka.core.RevisionUtils;
import weka.core.SelectedTag;
import weka.core.Utils;

public class ParameterOptimization extends RandomizableSingleClassifierEnhancer {

	public static final long serialVersionUID = -4356087502460814127L;

	protected boolean greedyOptimization = true;
	protected int numFolds = 10;
	protected Vector<String> cvParams = new Vector<String>();

	protected Instances trainData;
	protected Classifier optimized;

	public static Classifier makeOptionCopy(Classifier c) throws Exception {
		return Classifier.forName(c.getClass().getName(), c.getOptions().clone());
	}

	public Classifier[] makeOptionCopies(Classifier c, int n) throws Exception {
		String[] options = c.getOptions().clone();
		Classifier[] result = new Classifier[n];
		for (int i = 0; i < result.length; i++) {
			result[i] = Classifier.forName(c.getClass().getName(), options.clone());
		}
		return result;
	}

	@Override
	public void buildClassifier(Instances instances) throws Exception {
		// can classifier handle the data?
		getCapabilities().testWithFail(instances);

		// remove instances with missing class
		this.trainData = new Instances(instances);
		this.trainData.deleteWithMissingClass();

		if (!(getClassifier() instanceof OptionHandler)) {
			throw new IllegalArgumentException("Base classifier should be OptionHandler.");
		}
		this.optimized = makeOptionCopy(getClassifier());

		if (getGreedyOptimization()) {
			greedyOptimization();
		}
		else {
			fullOptimization();
		}

		this.optimized = makeOptionCopy(this.optimized);
		this.optimized.buildClassifier(instances);
	}

	private void greedyOptimization() throws Exception {
		for (String p : this.cvParams) {
			optimize(p);
		}
	}

	private double[] parseValues(String p) {
		String[] split = p.split(" ");
		double[] res = new double[split.length - 1];

		for (int i = 1; i < split.length; i++) {
			res[i - 1] = Double.parseDouble(split[i]);
		}

		return res;
	}

	private double getPerformance(Evaluation eval) {
		return eval.pctCorrect();
	}

	private void optimize(String p) throws Exception {
		String[] split = p.split(" ");
		String path = split[0];

		double[] paramValues = parseValues(p);
		Classifier[] cls = makeOptionCopies(this.optimized, paramValues.length);
		double bestPerformance = 0;
		for (int i = 0; i < paramValues.length; i++) {
			Classifier c = setValue(cls[i], path, paramValues[i]);
			if (getDebug()) {
				System.out.println(c.getClass().getName() + " " + Utils.joinOptions(c.getOptions()));
			}
			Evaluation eval = new Evaluation(this.trainData);
			eval.crossValidateModel(c, this.trainData, getNumFolds(), this.trainData.getRandomNumberGenerator(getSeed()));
			if (getPerformance(eval) > bestPerformance) {
				bestPerformance = getPerformance(eval);
				this.optimized = c;
			}
		}
	}

	/**
	 * tries to set the value as double, integer (just casts it to int!) or boolean (false if 0, otherwise true) in the
	 * object according to the specified path. float, char and long are also supported.
	 * 
	 * @param o
	 *            the object to modify
	 * @param path
	 *            the property path
	 * @param value
	 *            the value to set
	 * @throws Exception
	 *             if neither double nor int could be set
	 */
	protected Classifier setValue(Classifier o, String path, double value) throws Exception {
		PropertyDescriptor desc;
		Class<?> c;

		desc = PropertyPath.getPropertyDescriptor(o, path);
		c = desc.getPropertyType();

		// float
		if ((c == Float.class) || (c == Float.TYPE)) {
			PropertyPath.setValue(o, path, new Float((float) value));
		}
		else if ((c == Double.class) || (c == Double.TYPE)) {
			PropertyPath.setValue(o, path, new Double(value));
		}
		else if ((c == Character.class) || (c == Character.TYPE)) {
			PropertyPath.setValue(o, path, new Integer((char) value));
		}
		else if ((c == Integer.class) || (c == Integer.TYPE)) {
			PropertyPath.setValue(o, path, new Integer((int) value));
		}
		else if ((c == Long.class) || (c == Long.TYPE)) {
			PropertyPath.setValue(o, path, new Long((long) value));
		}
		else if ((c == Boolean.class) || (c == Boolean.TYPE)) {
			PropertyPath.setValue(o, path, (value == 0 ? new Boolean(false) : new Boolean(true)));
		}
		else if (c == SelectedTag.class) {
			SelectedTag st = (SelectedTag) PropertyPath.getValue(o, path);
			PropertyPath.setValue(o, path, new SelectedTag(new Integer((int) value), st.getTags()));
		}
		else {
			throw new Exception("Could neither set double nor integer nor boolean value for '" + path + "'!");
		}

		return o;
	}

	private void fullOptimization() {
		throw new UnsupportedOperationException("Full optimization not yet implemented!");
	}

	@Override
	public double[] distributionForInstance(Instance instance) throws Exception {
		return this.optimized.distributionForInstance(instance);
	}

	@Override
	public Capabilities getCapabilities() {
		return getClassifier().getCapabilities();
	}

	@SuppressWarnings("unchecked")
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tNumber of folds used for cross validation (default 10).", "X", 1, "-X <number of folds>"));
		result.addElement(new Option("\tGreedy optimization.\n" + "\t(default true)", "G", 0, "-G"));
		result.addElement(new Option("\tClassifier parameter options.\n" + "\teg: \"N 1 5 10\" Sets an optimisation parameter for the\n"
				+ "\tclassifier with name -N, with lower bound 1, upper bound\n" + "\t5, and 10 optimisation steps. The upper bound may be the\n"
				+ "\tcharacter 'A' or 'I' to substitute the number of\n" + "\tattributes or instances in the training data,\n"
				+ "\trespectively. This parameter may be supplied more than\n" + "\tonce to optimise over several classifier options\n" + "\tsimultaneously.",
				"P", 1, "-P <classifier parameter>"));

		Enumeration<Option> enu = super.listOptions();
		while (enu.hasMoreElements()) {
			result.addElement(enu.nextElement());
		}
		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		String[] options;

		result = new Vector<String>();

		result.add("-X");
		result.add("" + getNumFolds());

		if (getGreedyOptimization()) {
			result.add("-G");
		}

		Vector<String> pOptions = new Vector<String>();
		for (int i = 0; i < this.cvParams.size(); i++) {
			pOptions.add("-P");
			pOptions.add(getCVParameter(i));
		}
		result.addAll(pOptions);

		options = super.getOptions();
		for (int i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		setGreedyOptimization(Utils.getFlag('G', options));

		String foldsString = Utils.getOption('X', options);
		if (foldsString.length() != 0) {
			setNumFolds(Integer.parseInt(foldsString));
		}
		else {
			setNumFolds(10);
		}

		String cvParam;
		this.cvParams = new Vector<String>();
		do {
			cvParam = Utils.getOption('P', options);
			if (cvParam.length() != 0) {
				addCVParameter(cvParam);
			}
		} while (cvParam.length() != 0);

		super.setOptions(options);
	}

	/**
	 * Adds a scheme parameter to the list of parameters to be set by cross-validation
	 * 
	 * @param cvParam
	 *            the string representation of a scheme parameter. The format is: <br>
	 *            param_char lower_bound upper_bound number_of_steps <br>
	 *            eg to search a parameter -P from 1 to 10 by increments of 1: <br>
	 *            P 1 10 11 <br>
	 * @throws Exception
	 *             if the parameter specifier is of the wrong format
	 */
	public void addCVParameter(String cvParam) throws Exception {
		this.cvParams.addElement(cvParam);
	}

	/**
	 * Gets the scheme paramter with the given index.
	 * 
	 * @param index
	 *            the index for the parameter
	 * @return the scheme parameter
	 */
	public String getCVParameter(int index) {

		if (this.cvParams.size() <= index) {
			return "";
		}
		return this.cvParams.elementAt(index);
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter gui
	 */
	public String CVParametersTipText() {
		return "Sets the scheme parameters which are to be set " + "by cross-validation.\n" + "The format for each string should be:\n"
				+ "param_char lower_bound upper_bound number_of_steps\n" + "eg to search a parameter -P from 1 to 10 by increments of 1:\n"
				+ "    \"P 1 10 10\" ";
	}

	/**
	 * Get method for CVParameters.
	 * 
	 * @return the CVParameters
	 */
	public Object[] getCVParameters() {

		Object[] CVParams = this.cvParams.toArray();

		String params[] = new String[CVParams.length];

		for (int i = 0; i < CVParams.length; i++) {
			params[i] = CVParams[i].toString();
		}

		return params;

	}

	/**
	 * Set method for CVParameters.
	 * 
	 * @param params
	 *            the CVParameters to use
	 * @throws Exception
	 *             if the setting of the CVParameters fails
	 */
	public void setCVParameters(Object[] params) throws Exception {

		Vector<String> backup = this.cvParams;
		this.cvParams = new Vector<String>();

		for (int i = 0; i < params.length; i++) {
			try {
				addCVParameter((String) params[i]);
			}
			catch (Exception ex) {
				this.cvParams = backup;
				throw ex;
			}
		}
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter gui
	 */
	public String numFoldsTipText() {
		return "Get the number of folds used for cross-validation.";
	}

	/**
	 * Gets the number of folds for the cross-validation.
	 * 
	 * @return the number of folds for the cross-validation
	 */
	public int getNumFolds() {

		return this.numFolds;
	}

	/**
	 * Sets the number of folds for the cross-validation.
	 * 
	 * @param numFolds
	 *            the number of folds for the cross-validation
	 * @throws Exception
	 *             if parameter illegal
	 */
	public void setNumFolds(int numFolds) throws Exception {

		if (numFolds < 0) {
			throw new IllegalArgumentException("Stacking: Number of cross-validation " + "folds must be positive.");
		}
		this.numFolds = numFolds;
	}

	@Override
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 1.0 $");
	}

	@Override
	public String toString() {
		StringBuffer text = new StringBuffer();

		if (this.optimized == null) {
			text.append("Nothing optimized yet!\n");
		}
		else {
			text.append("Optimal parameters:\n" + this.optimized.getClass().getName() + " " + Utils.joinOptions(this.optimized.getOptions()) + "\n");
			text.append(this.optimized.toString());
		}

		return text.toString();
	}

	public String greedyOptimizationTipText() {
		return "Whether to optimize greedily.";
	}

	/**
	 * @param greedyOptimization
	 *            the greedyOptimization to set
	 */
	public void setGreedyOptimization(boolean greedyOptimization) {
		this.greedyOptimization = greedyOptimization;
	}

	/**
	 * @return the greedyOptimization
	 */
	public boolean getGreedyOptimization() {
		return this.greedyOptimization;
	}

}
