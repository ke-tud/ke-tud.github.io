package weka.classifiers.pla.addon.update;

import weka.classifiers.pla.addon.Addon;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public abstract class Update extends Addon {

	private static final long serialVersionUID = 6487232497916224486L;

	public boolean boundUpdateWeight(int alphaBound, int n, int yN, double lossN, double outputN, double margin, int uN, int t) throws Exception {
		if (uN < alphaBound) {
			return updateWeight(n, yN, lossN, outputN, margin, uN, t);
		}
		else {
			return false;
		}
	}

	/**
	 * Update the weight upon "mis-classification".
	 * 
	 * @param n
	 *            Index of x_n in training data.
	 * @param yN
	 *            Label of x_n (from {-1, 1}.
	 * @param lossN
	 *            Loss of x_n's classification.
	 * @param outputN
	 *            Old perceptron output of x_n.
	 * @param margin
	 *            Prediction-margin to be considered for updating.
	 * @return True iff. the weight changed.
	 * @throws Exception
	 */
	protected abstract boolean updateWeight(int n, int yN, double lossN, double outputN, double margin, int uN, int t) throws Exception;

	/**
	 * Creates a new instance of an update given its class name and (optional) arguments to pass to its setOptions
	 * method.
	 * 
	 * @param updateName
	 *            the fully qualified class name of the update
	 * @param options
	 *            an array of options suitable for passing to setOptions. May be null.
	 * @return the newly created update, ready for use.
	 * @throws Exception
	 *             if the update name is invalid, or the options supplied are not acceptable to the update
	 */
	public static Update forName(String updateName, String[] options) throws Exception {

		return (Update) Utils.forName(Update.class, updateName, options);
	}

}
