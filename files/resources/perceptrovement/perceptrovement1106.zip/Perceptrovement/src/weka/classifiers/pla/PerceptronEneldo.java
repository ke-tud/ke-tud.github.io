//$Id: Perceptron.java 112 2010-02-25 16:18:01Z DerEneldo $
/*
 * Created on 10.03.2005
 *
 */

package weka.classifiers.pla;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.UpdateableClassifier;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.UnassignedDatasetException;
import weka.core.UnsupportedAttributeTypeException;
import weka.core.UnsupportedClassTypeException;
import weka.core.Utils;

/**
 * @author eneldo
 * @version $Revision: 112 $
 */
public class PerceptronEneldo extends Classifier implements OptionHandler, UpdateableClassifier {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6067074929263904036L;

	/** Seed used for shuffling the dataset */
	private int m_seed = 1;

	private boolean datasetTestOK = false;

	private float[] m_perceptron = null;

	private float m_perceptronInit = 0.0001f;

	private float m_multiplizierer = 0.5f; // bei updatePerceptron

	private boolean m_normalisieren = false;

	private boolean m_randomizePerceptron = true;

	private int m_updateMethod = 0;

	private int numPosBsp = 0;
	private int numNegBsp = 0;

	// private float m_sumPosFactors = 0;
	// private float m_sumNegFactors = 0;

	private float m_threshold = 0.0f;

	public int numOps = 0; // anzahl der mutliplikationen
	public int numPredictions = 0;
	public int numUpdates = 0;

	// private Random randomGen;

	/**
	 * Builds the ensemble of perceptrons.
	 * 
	 * @exception Exception
	 *                if something goes wrong during building
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void buildClassifier(Instances insts) throws Exception {

		// Filter data wird in updateClassifier gemacht
		// jetzt garnicht mehr

		/** Randomize training data */
		// instances an updateClassifier weitergeben
		for (Enumeration<Instance> en = insts.enumerateInstances(); en.hasMoreElements();) {
			this.updateClassifier(en.nextElement());
		}
	}

	private void init(Instance instance) throws Exception {
		// Initialisierung, wird nur 1 Mal ausgef�hrt
		if (!this.datasetTestOK) {
			if (instance.dataset() != null) {
				// m_instsWork = new Instances(instance.dataset(), 1); // um die
				// Filteroperationen durchzuf�hren tests m�ssen gemacht werden,
				// da noch nie vorher geschehen
				// da filter nun weg sind, reicht eine Referenz auf das Dataset
				// aus, die spart Speicher
				Instances dataset = instance.dataset();
				if (dataset.checkForStringAttributes()) {
					throw new UnsupportedAttributeTypeException("Cannot handle string attributes!");
				}
				if (dataset.numClasses() > 2) {
					throw new Exception("Can only handle two-class datasets!");
				}
				if (dataset.classAttribute().isNumeric()) {
					throw new UnsupportedClassTypeException("Can't handle a numeric class!");
				}
				// perceptron wird initialisiert
				this.m_perceptron = new float[instance.numAttributes()];
				this.fillRandom(this.m_perceptron, this.m_perceptronInit, this.m_randomizePerceptron, this.m_seed);
				// randomGen=new Random(m_Seed);
				this.datasetTestOK = true;

			}
			else {
				// instsWork = new Instances("instsWork",,1)
				// wenn kein dataset existiert, kann man die attribute auch
				// nicht abfragen
				throw new UnassignedDatasetException("kein Dataset für Instance vorhanden");
			}

		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * weka.classifiers.UpdateableClassifier#updateClassifier(weka.core.Instance
	 * )
	 */
	public void updateClassifier(Instance instance) throws Exception {

		// Prediction und Perceptron aktualisieren
		if (!instance.classIsMissing()) {
			// distributionForInstance k�mmert sich initialisierung usw.
			this.init(instance);
			// double prediction = distributionForInstance(instance)[0];
			boolean istPosBsp = (instance.classValue() == 0.0);
			double factor = this.m_multiplizierer;
			if (this.m_updateMethod == 5) { // update immer vorher, führe dann ein
				// normales update durch
				factor = 1.0;
				if (istPosBsp) {
					// perceptron*instance>0 sein soll
					this.updateVector(this.m_perceptron, instance, factor); // m_perceptron=
					// m_perceptron
					// +
					// m_multiplizierer
					// *
					// instance;
				}
				else {
					// perceptron weg von Instanz
					this.updateVector(this.m_perceptron, instance, -factor); // m_perceptron=
					// m_perceptron
					// -
					// m_multiplizierer
					// *
					// instance;
				}
			}
			double prediction = this.makePrediction(instance);
			if (this.m_updateMethod == 3) {
				prediction += this.m_threshold; // so kann man denselben vgl für alle
			}
			// verwenden
			// System.out.println(toString(m_perceptron)+"*"+instance +
			// " "+instance.classValue()+" pred: "+distributionForInstance(instance)[0]+" "+classifyInstance(instance));
			// das unten funktioniert nicht, es ist festgelegt, bei bin�ren
			// problemen ist 0 pos und 1 neg.
			// boolean istPosBsp = m_classValuePositiveExamples.doubleValue() ==
			// instance.classValue();
			if (istPosBsp) {
				this.numPosBsp++;
			}
			else {
				this.numNegBsp++;
			}

			// xor aufgeschl�sselt:
			boolean update = false;
			// prediction=distributionForInstance(instance)[0];
			// if ((istPosBsp && prediction<0.5) || (!istPosBsp &&
			// prediction>=0.5))
			if ((istPosBsp ^ prediction >= 0.0) || this.m_updateMethod == 4) { // falsch
				// klassifiziert
				// oder
				// always-methode
				update = true;
				switch (this.m_updateMethod) {
				// case 0: //constant
				case 2: // ballseptron
					factor = 1.0;
					break;
				case 1: // consistent
					factor = Math.abs(this.m_multiplizierer * 2.0 * prediction / this.square(instance));
					break;
				case 3: // threshold
					// factor wurde schon richtig gesetzt
					this.m_threshold += istPosBsp ? 1 : -1;
					break;
				}
			}
			// Logger.getLogger().log("Distance to Hyperplane"+(update?"(u)":"")+": "+(istPosBsp?1:-1)*Math.sqrt(Math.abs(prediction))+" "+prediction,
			// this);
			// double tempD=0.0;
			// BigDecimal big1=new BigDecimal(m_perceptron[5]);
			// double d1=m_perceptron[5];
			// double d2=m_perceptron[5];
			// BigDecimal big2=new BigDecimal(m_perceptron[5]);
			// für ballseptron, falls kugel getroffen wird
			// double[] verifyPerceptron=new double[m_perceptron.length];
			if (this.m_updateMethod == 2 & !update) {
				double perLength = Math.sqrt(this.square(this.m_perceptron));
				double y = istPosBsp ? 1 : -1;
				if (y * prediction / perLength <= this.m_multiplizierer) { // prediction=w*x
					// for(int i=0;i<m_perceptron.length;i++){
					// verifyPerceptron[i]=m_perceptron[i];
					// if(i!=instance.classIndex())
					// verifyPerceptron[i]+=
					// y*(factor*instance.value(i)-(y*m_multiplizierer*m_perceptron[i]/perLength));
					// }
					// BigDecimal tempy=new BigDecimal(y);
					// big1=big1.multiply((new BigDecimal(1.0)).subtract((new
					// BigDecimal(m_multiplizierer)).divide(new
					// BigDecimal(perLength),100,BigDecimal.ROUND_HALF_EVEN))).add(tempy.multiply(new
					// BigDecimal(instance.value(5))));
					// d1=(1.0-m_multiplizierer/perLength)*d1+y*instance.value(5);
					// big2=big2.add(tempy.multiply((new
					// BigDecimal(instance.value(5))).subtract(tempy.multiply(new
					// BigDecimal(m_multiplizierer).multiply(big2.divide(new
					// BigDecimal(perLength),100,BigDecimal.ROUND_HALF_EVEN))))));
					// d2=d2+y*(instance.value(5)-y*m_multiplizierer*d2/perLength);

					double factortemp = (1.0 - (this.m_multiplizierer / perLength)); // entspricht
					// w-(r/|w|)w
					this.updateVectorMultWithFactor(this.m_perceptron, factortemp); // hier
					// wird
					// w=(1-(r/|w|))w
					// gemacht
					update = true;
					// Logger.getLogger().log("ball fault: "+(y*prediction/perLength)+"<"+m_multiplizierer+" ("+y+" "+prediction+" "+perLength+" "+factor+")",this);
				}
				// tempD=perLength;
			}

			if (update) {
				int tempNumOps = this.numOps; // da der z�hler in updateVector wieder
				// gel�scht wird
				if (istPosBsp) {
					// perceptron*instance>0 sein soll
					this.updateVector(this.m_perceptron, instance, factor); // m_perceptron=
					// m_perceptron
					// +
					// m_multiplizierer
					// *
					// instance;
				}
				else {
					// perceptron weg von Instanz
					this.updateVector(this.m_perceptron, instance, -factor); // m_perceptron=
				}
				// m_perceptron
				// -
				// m_multiplizierer
				// *
				// instance;
				this.numOps += tempNumOps;
				// Logger.getLogger().log("update Perceptron",this); //wird
				// zuviel datenm�ll
				// f�r constistent-debug:
				// System.out.println((prediction >= 0.0) + " " + istPosBsp +
				// " ; " + prediction+ " -> " + makePrediction(instance));
				// f�r balanced-debug:
				// System.out.println( istPosBsp + "\t" +
				// m_numPosBsp+"/"+m_numNegBsp+" "+m_sumPosFactors+"/"+m_sumNegFactors+" ; "
				// + factor);
				// if(m_updateMethod==2){
				// double distance=0;
				// String temp="";
				// for(int i=0;i<m_perceptron.length;i++){
				// if(i!=instance.classIndex()){
				// distance+=(m_perceptron[i]-verifyPerceptron[i])*(m_perceptron[i]-verifyPerceptron[i]);
				// temp+=m_perceptron[i]+" - "+verifyPerceptron[i]+",";
				// }
				// }
				// // if(distance>0.0000000001)
				// Logger.getLogger().log("Ballseptron: distance="+distance+"="+(d1-d2)+"/"+tempD+" ("+distance/tempD*100+") ",
				// this);
				// }
			}
			// switch(m_updateMethod){
			// case 2: //ballseptron
			// if(istPosBsp){
			// m_numPosBsp++;
			// }else{
			// m_numNegBsp++;
			// }
			// break;
			// }

			// System.out.println( istPosBsp + "\t" +
			// m_numPosBsp+"/"+m_numNegBsp+" ; ");
			// System.out.println(toString(m_perceptron)+"*"+instance +
			// " "+instance.classValue()+" pred: "+distributionForInstance(instance)[0]+" "+classifyInstance(instance)+"\n");

		}

	}

	/**
	 * Outputs the distribution for the given output. Pipes output of vector multiplication through sigmoid function.
	 * 
	 * @param inst
	 *            the instance for which distribution is to be computed
	 * @return the distribution
	 * @exception Exception
	 *                if something goes wrong
	 */
	@Override
	public double[] distributionForInstance(Instance instance) throws Exception {

		this.init(instance);

		/*
		 * //Der Filterkram (replaceMissingValues,NominalToBinary) wird nicht
		 * mehr getestet. bei nominalen oder missing values wird einfach hoffe
		 * ich irgendwie abgebrochen //(f�llt raus, da es jedesmal gemacht
		 * werden muss Instance inst = (Instance) instance.copy(); ... inst =
		 * m_NominalToBinary.output();
		 */

		// Get probabilities
		double prediction = this.makePrediction(instance);

		double[] result = new double[2];
		// sigmoid-funktion: sigmoid(x)=1/(1+exp(x))
		// sigmoid(-inf)=1, sigmoid(0)=0.5, sigmoid(+inf)=0
		// angewand auf -pred: sigmoid(-pred):
		// pred | sigmoid(-pred)=wkt klasse 0 = result[0]
		// -inf | 0.0
		// 0 | 0.5
		// +inf | 1.0
		result[0] = 1 / (1 + Math.exp(-prediction)); // Klasse pos Bsp. (bei
		// minus-werten ist die
		// wahrscheinlichkeit <0
		// , bei pos-werten >0)
		// simple variante:
		// if(prediction<0)
		// result[0] = 0;
		// else /*(prediction>0)*/
		// result[0] = 1;
		result[1] = 1 - result[0]; // Klasse neg Bsp.
		// System.out.println("\nINST "+inst+" PERC "+toString(m_perceptron)+"   "+prediction+"   "+result[1]);

		return result;
	}

	/**
	 * Compute a prediction from a perceptron
	 */
	private double makePrediction(Instance inst) throws Exception {
		this.numPredictions++;
		// Instance perceptron = new Instance(1.0, m_perceptron);
		double erg = this.innerProduct(inst, this.m_perceptron);

		return erg;

		/*
		 * if (result < 0) { return 0; } else { return 1; }
		 */
	}

	public void forceUpdateClassifier(Instance instance, double modifizierer) throws Exception {
		// Prediction und Perceptron aktualisieren
		if (!instance.classIsMissing()) {
			boolean istPosBsp = (instance.classValue() == 0.0);
			if (istPosBsp) {
				// perceptron*instance>0 sein soll
				this.updateVector(this.m_perceptron, instance, modifizierer); // m_perceptron=
				// m_perceptron
				// +
				// m_multiplizierer
				// *
				// instance;
			}
			else {
				// perceptron weg von Instanz
				this.updateVector(this.m_perceptron, instance, -modifizierer); // m_perceptron=
				// m_perceptron
				// -
				// m_multiplizierer
				// *
				// instance;
			}

		}

	}

	/**
	 * Initialisiert das �bergebene Array mit dem angegebenen Wert. Falls eine zuf�llige Initialisierung erw�nscht ist,
	 * wird das Array mit Werten von -initValue bis +initValue initialisiert
	 * 
	 * @param array
	 *            zu initialisieren
	 * @param initWert
	 *            F�llwert bzw. max Intervallgrenze bei Zufallsauff�llung
	 * @param Random
	 *            true oder false
	 * @param randomseed
	 */
	public void fillRandom(float[] array, float initValue, boolean random, int seed) {
		if (random) {
			Random randGen = new Random(this.m_seed);
			for (int i = 0; i < array.length; i++) {
				array[i] = (randGen.nextFloat() - 0.5f) * 2.0f * initValue;
			}
		}
		else {
			Arrays.fill(array, initValue);
		}
	}

	/**
	 * Computes the inner product of an instances with an Vector (Array of doubles)
	 */
	public double innerProduct(Instance i1, double[] i2) throws Exception {
		this.numOps = 0;
		// we can do a fast dot product
		double result = 0.0;
		double d1 = 0.0, d2 = 0.0; // f�rs Normalisieren
		double value1, value2;
		int numValues1 = i1.numValues(); // nicht menge der Attribute, sonder
		// nur menge der Werte (ungleich
		// null)
		int numValues2 = i2.length;
		int classAttrIndex = i1.classIndex();
		for (int valueIndex1 = 0, valueIndex2 = 0; valueIndex1 < numValues1 && valueIndex2 < numValues2;) {
			int attrIndex1 = i1.index(valueIndex1); // wegen sparsedInstance, da
			// hier attributindex !=
			// wertindex (nullwerte
			// werden nicht gespeichert)
			// index(valuenr/valueindex) liefert die position/index des
			// attributs
			if (attrIndex1 != classAttrIndex && valueIndex2 <= attrIndex1) { // classAttribut
				// wird
				// nicht
				// in
				// die
				// Multiplikation
				// miteinbezogen;
				// 2.Bedingung
				// stellt
				// ein
				// !IndexOutOfArray
				// sicher
				value1 = i1.valueSparse(valueIndex1); // valueSparse greift
				// direkt auf den Array,
				// in dem die Werte
				// gespeichert sind, zu.
				// D.h. f�r instance
				// gibt es den wert i
				// von attribut i
				// zur�ck, f�r
				// SparseInstance jedoch
				// wert i von Attribut
				// index(i) zur�ck
				value2 = i2[attrIndex1];
				result += value1 * value2;
				if (this.m_normalisieren) {
					d1 += value1 * value1;
				}
				// stats:
				this.numOps++;
			}
			valueIndex1++;
		}

		if (this.m_normalisieren) {
			for (int index2 = 0; index2 < i2.length; index2++) {
				if (index2 != classAttrIndex) {
					double value = i2[index2];
					d2 += value * value;
				}
			}
			double normFaktor = java.lang.Math.sqrt(d1 * d2);
			if (normFaktor == 0.0) {
				normFaktor = 1.0; // Wenn Nullvektoren
			}
			return result / normFaktor;
		}
		return result;
	}

	/**
	 * Computes the inner product of an instances with an Vector (Array of floates)
	 */
	public double innerProduct(Instance i1, float[] i2) throws Exception {
		this.numOps = 0;
		// we can do a fast dot product
		double result = 0.0;
		double d1 = 0.0, d2 = 0.0; // f�rs Normalisieren
		double value1, value2;
		int numValues1 = i1.numValues(); // nicht menge der Attribute, sonder
		// nur menge der Werte (ungleich
		// null)
		int numValues2 = i2.length;
		int classAttrIndex = i1.classIndex();
		for (int valueIndex1 = 0, valueIndex2 = 0; valueIndex1 < numValues1 && valueIndex2 < numValues2;) {
			int attrIndex1 = i1.index(valueIndex1); // wegen sparsedInstance, da
			// hier attributindex !=
			// wertindex (nullwerte
			// werden nicht gespeichert)
			// index(valuenr/valueindex) liefert die position/index des
			// attributs
			if (attrIndex1 != classAttrIndex && valueIndex2 <= attrIndex1) { // classAttribut
				// wird
				// nicht
				// in
				// die
				// Multiplikation
				// miteinbezogen;
				// 2.Bedingung
				// stellt
				// ein
				// !IndexOutOfArray
				// sicher
				value1 = i1.valueSparse(valueIndex1); // valueSparse greift
				// direkt auf den Array,
				// in dem die Werte
				// gespeichert sind, zu.
				// D.h. f�r instance
				// gibt es den wert i
				// von attribut i
				// zur�ck, f�r
				// SparseInstance jedoch
				// wert i von Attribut
				// index(i) zur�ck
				value2 = i2[attrIndex1];
				result += value1 * value2;
				if (this.m_normalisieren) {
					d1 += value1 * value1;
				}
				// stats:
				this.numOps++;
			}
			valueIndex1++;
		}
		if (this.m_normalisieren) {
			for (int index2 = 0; index2 < i2.length; index2++) {
				if (index2 != classAttrIndex) {
					float value = i2[index2];
					d2 += value * value;
				}
			}
			double normFaktor = java.lang.Math.sqrt(d1 * d2);
			if (normFaktor == 0.0) {
				normFaktor = 1.0; // Wenn Nullvektoren
			}
			return result / normFaktor;
		}
		return result;

	}

	public double innerProduct(Instance i1, Instance i2) {
		this.numOps = 0;
		// we can do a fast dot product
		double result = 0.0;
		double value1, value2;
		int numValues1 = i1.numValues(); // nicht menge der Attribute, sonder
		// nur menge der Werte (ungleich
		// null)
		int numValues2 = i2.numValues();
		int classAttrIndex = i1.classIndex();
		for (int valueIndex1 = 0, valueIndex2 = 0; valueIndex1 < numValues1 && valueIndex2 < numValues2;) {
			int attrIndex1 = i1.index(valueIndex1); // wegen sparsedInstance, da
			// hier attributindex !=
			// wertindex (nullwerte
			// werden nicht gespeichert)
			int attrIndex2 = i2.index(valueIndex2); // wegen sparsedInstance, da
			// hier attributindex !=
			// wertindex (nullwerte
			// werden nicht gespeichert)
			// index(valuenr/valueindex) liefert die position/index des
			// attributs
			if (attrIndex1 == attrIndex2) {
				if (attrIndex1 != classAttrIndex) {
					value1 = i1.valueSparse(valueIndex1); // valueSparse greift
					// direkt auf den
					// Array, in dem die
					// Werte gespeichert
					// sind, zu. D.h.
					// f�r instance gibt
					// es den wert i von
					// attribut i
					// zur�ck, f�r
					// SparseInstance
					// jedoch wert i von
					// Attribut index(i)
					// zur�ck
					value2 = i2.valueSparse(valueIndex2);
					result += value1 * value2;
					// stats:
					this.numOps++;
				}
				valueIndex1++;
				valueIndex2++;
			}
			else if (attrIndex1 > attrIndex2) {
				valueIndex2++;
			}
			else {
				valueIndex1++;
			}
		}
		return result;
	}

	private double square(Instance inst) throws Exception {
		this.numOps = 0;
		// we can do a fast dot product
		double result = 0;
		int numValues = inst.numValues();
		int classIndex = inst.classIndex();
		for (int valueIndex = 0; valueIndex < numValues; valueIndex++) {
			int attrIndex = inst.index(valueIndex);
			if (attrIndex != classIndex) {
				double temp = inst.valueSparse(valueIndex);
				result += temp * temp;
				this.numOps++;
			}
		}
		return result;
	}

	private double square(float[] inst) throws Exception {
		this.numOps = 0;
		// we can do a fast dot product
		double result = 0;
		int numValues = inst.length;
		// int classIndex = inst.classIndex();
		// classIndex wird ignoriert. es wird dann halt 0*0 berechnet. sonst
		// müßte der vergleich gemacht werden
		for (int valueIndex = 0; valueIndex < numValues; valueIndex++) {
			result += inst[valueIndex] * inst[valueIndex];
			this.numOps++;
		}
		return result;
	}

	/**
	 * Addiert dem Vector von Attributwerten einen anderen Vector von Attributwerten (in Form einer Instance),
	 * multipliziert um einen bestimmten Faktor. Arbeitet auf dem �bergebenen Array von doubles des Vectors
	 * 
	 * @param vector
	 *            v=v+instanceFactor*instance
	 * @param inst
	 *            Instance
	 * @param instanceFactor
	 */
	public void updateVector(double[] perceptron, Instance inst, double instanceFactor) {
		this.numOps = 0;
		this.numUpdates++;
		int numValues1 = inst.numValues(); // nicht menge der Attribute, sonder
		// nur menge der Werte (ungleich
		// null)
		int numValues2 = perceptron.length;
		int classAttrIndex = inst.classIndex();
		double value1;
		for (int valueIndex1 = 0, valueIndex2 = 0; valueIndex1 < numValues1 && valueIndex2 < numValues2;) {
			int attrIndex1 = inst.index(valueIndex1); // wegen sparsedInstance,
			// da hier attributindex
			// != wertindex
			// (nullwerte werden
			// nicht gespeichert)
			// index(valuenr/valueindex) liefert die position/index des
			// attributs
			if (attrIndex1 != classAttrIndex && valueIndex2 <= attrIndex1) { // classAttribut
				// wird
				// nicht
				// in
				// die
				// Multiplikation
				// miteinbezogen;
				// 2.Bedingung
				// stellt
				// ein
				// !IndexOutOfArray
				// sicher
				value1 = inst.valueSparse(valueIndex1); // valueSparse greift
				// direkt auf den Array,
				// in dem die Werte
				// gespeichert sind, zu.
				// D.h. f�r instance
				// gibt es den wert i
				// von attribut i
				// zur�ck, f�r
				// SparseInstance jedoch
				// wert i von Attribut
				// index(i) zur�ck
				// value2=m_perceptron[attrIndex1];
				perceptron[attrIndex1] += instanceFactor * value1;
				// stats:
				this.numOps++;
			}
			valueIndex1++;
		}

	}

	// TODO: only for testing purposes. please delete afterwards
	// float maxComponent = -Float.MIN_VALUE;
	// static float globalMaxComponent = -Float.MIN_VALUE;

	/**
	 * Addiert dem Vector von Attributwerten einen anderen Vector von Attributwerten (in Form einer Instance),
	 * multipliziert um einen bestimmten Faktor. Arbeitet auf dem �bergebenen Array von doubles des Vectors
	 * 
	 * @param vector
	 *            v=v+instanceFactor*instance
	 * @param inst
	 *            Instance
	 * @param instanceFactor
	 */
	public void updateVector(float[] perceptron, Instance inst, double instanceFactor) {
		this.numOps = 0;
		this.numUpdates++;
		int numValues1 = inst.numValues(); // nicht menge der Attribute, sonder
		// nur menge der Werte (ungleich
		// null)
		int numValues2 = perceptron.length;
		int classAttrIndex = inst.classIndex();
		double value1;
		for (int valueIndex1 = 0, valueIndex2 = 0; valueIndex1 < numValues1 && valueIndex2 < numValues2;) {
			int attrIndex1 = inst.index(valueIndex1); // wegen sparsedInstance,
			// da hier attributindex
			// != wertindex
			// (nullwerte werden
			// nicht gespeichert)
			// index(valuenr/valueindex) liefert die position/index des
			// attributs
			if (attrIndex1 != classAttrIndex && valueIndex2 <= attrIndex1) { // classAttribut
				// wird
				// nicht
				// in
				// die
				// Multiplikation
				// miteinbezogen;
				// 2.Bedingung
				// stellt
				// ein
				// !IndexOutOfArray
				// sicher
				value1 = inst.valueSparse(valueIndex1); // valueSparse greift
				// direkt auf den Array,
				// in dem die Werte
				// gespeichert sind, zu.
				// D.h. f�r instance
				// gibt es den wert i
				// von attribut i
				// zur�ck, f�r
				// SparseInstance jedoch
				// wert i von Attribut
				// index(i) zur�ck
				// value2=m_perceptron[attrIndex1];
				perceptron[attrIndex1] += instanceFactor * value1;
				// stats:
				this.numOps++;
			}
			valueIndex1++;
		}
		// if (false) {
		// double betrag = 0.0;
		// // int classAttrIndex = inst.classIndex();
		// int treffer = -1;
		// for (int i = 0; i < m_perceptron.length; i++) {
		// if (i != classAttrIndex) {
		// float wert = m_perceptron[i];
		// betrag += wert * wert;
		// if (wert > maxComponent) {
		// treffer = i;
		// maxComponent = wert;
		// }
		// if (maxComponent > globalMaxComponent) {
		// globalMaxComponent = maxComponent;
		// }
		// }
		// }
		// if (treffer != -1) {
		// Logger.getLogger().log(
		// "makePrediction(): max. component (" + treffer + "):"
		// + maxComponent + "/" + Math.sqrt(betrag) + "="
		// + (maxComponent / Math.sqrt(betrag))
		// + "; global max. Component="
		// + globalMaxComponent, this);
		// }
		// }
	}

	private void updateVectorMultWithFactor(float[] perceptron, double factor) {
		int max = perceptron.length;
		for (int i = 0; i < max; i++) {
			perceptron[i] *= factor;
		}
	}

	/**
	 * Main method.
	 */
	public static void main(String[] argv) {

		try {
			System.out.println(Evaluation.evaluateModel(new PerceptronEneldo(), argv));
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	/**
	 * @param m_perceptron2
	 * @return
	 */
	public String toString(double[] perceptron) {
		if (perceptron == null) {
			return "null";
		}
		String s = "";
		for (int i = 0; i < perceptron.length; i++) {
			s += perceptron[i] + ",";
		}
		return s;
	}

	public String toString(float[] perceptron) {
		if (perceptron == null) {
			return "null";
		}
		String s = "";
		for (int i = 0; i < perceptron.length; i++) {
			s += perceptron[i] + ",";
		}
		return s;
	}

	/**
	 * Returns textual description of classifier.
	 */
	@Override
	public String toString() {
		String erg = "Perceptron-Algorithm: Perceptron: [" + this.toString(this.m_perceptron) + "]+\n";
		String[] options = this.getOptions();
		erg += "Options: ";
		for (int i = 0; i < options.length; i++) {
			erg += options[i] + " ";
		}
		return erg;
	}

	/**
	 * Returns a string describing this classifier
	 * 
	 * @return a description of the classifier suitable for displaying in the explorer/experimenter gui
	 */
	public String globalInfo() {
		return "Perceptron-Algorithmus ";
	}

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> newVector = new Vector<Option>();

		newVector.addElement(new Option("\tThe number of iterations to be performed.\n" + "\t(default 1)", "I", 1, "-I <int>"));
		newVector.addElement(new Option("\tOb instances randomisiert werden oder nicht.\n" + "\t(default false)", "R", 1, "-R <boolean>"));
		newVector.addElement(new Option("\tOb der Perceptron mit Zufallswerten initialisert werden soll.\n" + "\t(default true)", "F", 1, "-F <boolean>"));
		newVector.addElement(new Option("\tWert, mit dem der Perceptron initialisert werden soll bzw. maxWert bei zuf�lliger Initialisierung.\n"
				+ "\t(default 0.0001)", "D", 1, "-D <float>"));
		newVector
				.addElement(new Option("\tnormalisiert den Perceptron. erzeugt saubere Wahrscheinlichkeiten.\n" + "\t(default false)", "N", 1, "-N <boolean>"));
		newVector.addElement(new Option("\tThe seed for the random number generation.\n" + "\t(default 1)", "S", 1, "-S <int>"));
		newVector.addElement(new Option("\tDer Multiplizierer/Modifikator/Faktor/Margin-Abstand (bei jeder update-Methode andere Funktion).\n"
				+ "\t(default 0.5)", "M", 1, "-M <int>"));
		newVector.addElement(new Option("\tDie zu verwendende Updatefunktion.\n" + "\t(default normal)", "U", 1,
				"-U <constant|consistent|ballseptron|threshold|always>"));

		return newVector.elements();
	}

	/**
	 * Parses a given list of options. Valid options are:
	 * <p>
	 * -I num <br>
	 * The number of iterations to be performed. (default 1)
	 * <p>
	 * -R bool <br>
	 * ob instances randomisiert wird oder nicht. (default false)
	 * <p>
	 * -S num <br>
	 * The seed for the random number generator. (default 1)
	 * <p>
	 * -M num <br>
	 * Der Multiplizierer f�r das Delta (kein Unterschied wenn bei allen Updates gleich). (default 1.0)
	 * <p>
	 * 
	 * @param options
	 *            the list of options as an array of strings
	 * @exception Exception
	 *                if an option is not supported
	 */
	@Override
	public void setOptions(String[] options) throws Exception {

		String multipliziererString = Utils.getOption('M', options);
		if (multipliziererString.length() != 0) {
			this.m_multiplizierer = (new Float(multipliziererString)).floatValue();
		}
		String tempString = Utils.getOption('D', options);
		if (tempString.length() != 0) {
			this.m_perceptronInit = (new Float(tempString)).floatValue();
		}
		String seedString = Utils.getOption('S', options);
		if (seedString.length() != 0) {
			this.m_seed = Integer.parseInt(seedString);
		}
		else {
			this.m_seed = 1;
		}
		tempString = Utils.getOption('F', options);
		if (tempString.length() != 0) {
			this.m_randomizePerceptron = Boolean.parseBoolean(tempString);
		}

		tempString = Utils.getOption('N', options);
		if (tempString.length() != 0) {
			this.m_normalisieren = Boolean.parseBoolean(tempString);
		}

		tempString = Utils.getOption('U', options);
		if (tempString.length() != 0) {
			this.setUpdateMethod(tempString);
		}
	}

	/**
	 * Gets the current settings of the classifier.
	 * 
	 * @return an array of strings suitable for passing to setOptions
	 */
	@Override
	public String[] getOptions() {

		String[] options = new String[22];
		int current = 0;

		options[current++] = "-M";
		options[current++] = "" + this.m_multiplizierer;
		options[current++] = "-S";
		options[current++] = "" + this.m_seed;
		options[current++] = "-D";
		options[current++] = "" + this.m_perceptronInit;
		options[current++] = "-F";
		options[current++] = "" + this.m_randomizePerceptron;
		options[current++] = "-N";
		options[current++] = "" + this.m_normalisieren;
		options[current++] = "-U";
		options[current++] = "" + this.getUpdateMethod();
		while (current < options.length) {
			options[current++] = "";
		}
		return options;
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter gui
	 */
	public String multipliziererTipText() {
		return "Multiplizierer des deltas";
	}

	/**
	 * Get the value of multiplizierer
	 * 
	 * @return Value of maxK.
	 */
	public float getMultiplizierer() {

		return this.m_multiplizierer;
	}

	/**
	 * Set the value of multiplizierer (obsolet)
	 * 
	 * @param v
	 *            Value to assign to multiplizierer.
	 */
	public void setMultiplizierer(float v) {

		this.m_multiplizierer = v;
	}

	public String normalisierenTipText() {
		return "Soll der Perceptron normalisiert werden?";
	}

	public boolean getNormalisieren() {

		return this.m_normalisieren;
	}

	public void setNormalisieren(boolean v) {

		this.m_normalisieren = v;
	}

	public boolean getRandomizePerceptron() {
		return this.m_randomizePerceptron;
	}

	public void setRandomizePerceptron(boolean perceptron) {
		this.m_randomizePerceptron = perceptron;
	}

	public float getPerceptronInit() {
		return this.m_perceptronInit;
	}

	public void setPerceptronInit(float init) {
		this.m_perceptronInit = init;
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter gui
	 */
	public String seedTipText() {
		return "Seed for the random number generator.";
	}

	/**
	 * Get the value of Seed.
	 * 
	 * @return Value of Seed.
	 */
	public int getSeed() {

		return this.m_seed;
	}

	/**
	 * Set the value of Seed.
	 * 
	 * @param v
	 *            Value to assign to Seed.
	 */
	public void setSeed(int v) {

		this.m_seed = v;
	}

	public String getUpdateMethod() {
		switch (this.m_updateMethod) {
		case -1:
		case 0:
			return "constant";
		case 1:
			return "consistent";
		case 2:
			return "ballseptron";
		case 3:
			return "threshold";
		case 4:
			return "always";
		case 5:
			return "always2";
		}
		// tritt nie ein, aber compiler hat gemeckert
		return "";
	}

	public void setUpdateMethod(String updateMethodString) {
		if (updateMethodString.equalsIgnoreCase("constant")) {
			this.m_updateMethod = 0;
		}
		else if (updateMethodString.equalsIgnoreCase("consistent")) {
			// oder doch consequent, reactionary ...
			// unterschied konsistenter update <-> konstistenter algorithmus
			// nur auf upgedatete instanz ist der klassif. konsistent <-> auf
			// alle bisher bekannten instanzen konsistent
			this.m_updateMethod = 1;
		}
		else if (updateMethodString.equalsIgnoreCase("ballseptron")) {
			this.m_updateMethod = 2;
		}
		else if (updateMethodString.equalsIgnoreCase("threshold")) {
			this.m_updateMethod = 3;
		}
		else if (updateMethodString.equalsIgnoreCase("always")) {
			this.m_updateMethod = 4;
		}
		else if (updateMethodString.equalsIgnoreCase("always2")) {
			this.m_updateMethod = 5;
		}

	}

	public int getNumPosExamples() {
		return this.numPosBsp;
	}

	public int getNumNegExamples() {
		return this.numNegBsp;
	}

}

/*
 * History: $Log: Perceptron.java,v $ Revision 1.3 2006/10/25 16:11:21 eneldo
 * war verschwunden
 * 
 * Revision 1.20 2005/11/30 01:11:23 eneldo bug Messung der Ops mod Umstellung
 * der Ops-Stats-Anzeige bei toString todo stats immer noch nicht perfekt
 * 
 * Revision 1.19 2005/08/03 00:22:33 eneldo mod umstellung von double auf float
 * f�r verringerung der zeit UND des speicherverbrauchs (um die h�lfte!)
 * 
 * Revision 1.18 2005/07/26 18:14:32 eneldo bak umstellen auf floats statt
 * double intern
 * 
 * Revision 1.17 2005/07/20 04:36:24 eneldo mod default-werte ge�ndert mod
 * init() ausgelagert add neue update-methode constant, consistent und balanced
 * 
 * Revision 1.16 2005/07/19 00:06:12 eneldo mod reorganisation/ordnung der
 * methoden im source code del entfernen der optionen randomizeInsts und
 * Iterationen, nur noch Updateable-optionen add set/getUpdateMethod (STUB!)
 * 
 * Revision 1.15 2005/07/18 01:52:48 eneldo bug setNormalisierenInsts setzte
 * randomizeInsts, nun setNormalisieren richtig add z�hlt anzahl der ops(mults)
 * bei vektormultiplikation und update
 * 
 * Revision 1.14 2005/06/22 05:15:40 eneldo add forceUpdateClassifier, update
 * kann von aussen kontrolliert werden, sonst ja nur wenn neg klassifikation
 * 
 * Revision 1.13 2005/06/19 15:22:57 eneldo mod unn�tige Imports gel�scht mod
 * weka-sourcen aus Projekt entfernt, werden jetzt nur noch von Eclipse
 * importiert
 * 
 * Revision 1.12 2005/06/13 05:59:02 eneldo mod unn�tige Referenz auf nicht
 * benutzte Variable entfernt, 4 byte gespart
 * 
 * Revision 1.11 2005/06/09 01:50:51 eneldo mod Beschreibung korrigiert mod
 * toString() Ausgabe jetzt mit �bergebenen Optionen bug perceptron wurde immer
 * random initilisiert
 * 
 * Revision 1.10 2005/05/19 03:48:52 eneldo add random init des peceptron.
 * sollte agglomeration der votes f�r die erste klasse bringen, hat es aber
 * nicht
 * 
 * Revision 1.9 2005/05/18 03:59:01 eneldo mod innerProduct() und
 * updatePerceptron()/updateVector() ver�ndert, damit auch von au�erhalb
 * sinnvoll nutzbar
 * 
 * Revision 1.8 2005/05/13 16:25:04 eneldo mod innerProduct klarer gestaltet mod
 * opt: Filter raus: NumericAttributs und MissingValues werden nicht mehr
 * gefiltert mod opt: einige Speicheroptimierungen
 * 
 * Revision 1.7 2005/05/10 19:19:23 eneldo mod angepasst an j2se 1.5 wegen enum
 * = keyword
 * 
 * Revision 1.6 2005/05/10 15:30:54 eneldo mod inner product angepasst
 * 
 * Revision 1.5 2005/05/05 04:26:36 eneldo add: normalisierung des
 * skalarprodukts f�r saubere Wahrscheinlichkeiten
 * 
 * Revision 1.4 2005/05/05 03:41:39 eneldo bug: falsche Zuweisung von positiven
 * Bsp. zu Klassennummer
 * 
 * Revision 1.3 2005/04/28 07:41:11 eneldo cvs tags eingef�gt
 */
