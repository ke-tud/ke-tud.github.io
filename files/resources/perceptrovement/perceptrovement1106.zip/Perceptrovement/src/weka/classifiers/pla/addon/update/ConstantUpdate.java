package weka.classifiers.pla.addon.update;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public class ConstantUpdate extends Update {

	private static final long serialVersionUID = 2058237308705337768L;

	/** Constant rate to use for updates on w */
	private double rate = 1;

	@Override
	protected void init() {
	}

	@Override
	public boolean updateWeight(int n, int yN, double lossN, double outputN, double margin, int uN, int t) throws Exception {
		double factor;

		if (yN * outputN <= margin) {
			factor = this.rate * yN;
		}
		else {
			factor = 0;
		}

		return getWeight().updateWeight(n, factor, outputN);
	}

	@Override
	public String globalInfo() {
		return "Constant update rate.";
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tLearning rate.\n" + "\t(default 1)", "L", 1, "-L <num>"));

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-L");
		result.add("" + getRate());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('L', options);
		if (tmp.length() != 0) {
			setRate(Double.parseDouble(tmp));
		}
		else {
			setRate(1);
		}
	}

	/**
	 * @return
	 */
	public String rateTipText() {
		return "Learning rate.";
	}

	/**
	 * @return the rate
	 */
	public double getRate() {
		return this.rate;
	}

	/**
	 * @param rate
	 *            the rate to set
	 */
	public void setRate(double rate) {
		this.rate = rate;
	}

}
