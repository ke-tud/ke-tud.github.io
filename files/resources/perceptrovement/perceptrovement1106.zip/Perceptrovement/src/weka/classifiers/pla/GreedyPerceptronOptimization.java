package weka.classifiers.pla;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.RandomizableClassifier;
import weka.classifiers.pla.addon.margin.Margin;
import weka.classifiers.pla.addon.margin.UnevenMargin;
import weka.classifiers.pla.addon.update.ConstantUpdate;
import weka.classifiers.pla.addon.update.Update;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.SelectedTag;
import weka.core.Utils;

public class GreedyPerceptronOptimization extends RandomizableClassifier {

	/**  */
	private static final long serialVersionUID = -673172533387025397L;

	/** Default variant */
	private int variant = Perceptrovement.VARIANT_CLASSICAL;

	/** Max. number of epochs */
	private int numIterations = 100;
	/** Number of "reduced epochs" (MICRA) */
	private int reducedIter = 0;

	/**  */
	private Update update = new ConstantUpdate();
	/**  */
	private Margin margin = new UnevenMargin();

	Perceptrovement p;

	public Classifier bestAccuracy(ArrayList<Classifier> cs, Instances data) throws Exception {
		double bestAcc = 0;
		Classifier bestC = null;
		for (Classifier c : cs) {
			Evaluation eval = new Evaluation(data);
			eval.crossValidateModel(c, data, 10, data.getRandomNumberGenerator(getSeed()));
			if (eval.pctCorrect() > bestAcc) {
				bestAcc = eval.pctCorrect();
				bestC = c;
			}
		}
		return bestC;
	}

	@Override
	public void buildClassifier(Instances data) throws Exception {
	}

	@Override
	public double[] distributionForInstance(Instance instance) throws Exception {
		return this.p.distributionForInstance(instance);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tMaximum number of iterations.\n" + "\t(default 100)", "I", 1, "-I <num>"));
		result.addElement(new Option("\tN (Reduced Epochen).\n" + "\t(default 0)", "N", 1, "-N <num>"));
		result.addElement(new Option("\tVariants: 0=Classic/1=Survivor/2=Voted.\n" + "\t(default 0)", "V", 1, "-V <num>"));

		result.addElement(new Option("\tThe Update to use.\n" + "\t(default: weka.classifiers.pla.addon.update.ConstantUpdate)", "U", 1,
				"-U <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to update " + getUpdate().getClass().getName() + ":"));

		Enumeration<Option> enup = getUpdate().listOptions();
		while (enup.hasMoreElements()) {
			result.addElement(enup.nextElement());
		}

		result.addElement(new Option("\tThe Margin to use.\n" + "\t(default: weka.classifiers.pla.addon.margin.UnevenConstantMargin)", "G", 1,
				"-G <classname and parameters>"));

		result.addElement(new Option("", "", 0, "\nOptions specific to margin " + getMargin().getClass().getName() + ":"));

		Enumeration<Option> enma = getMargin().listOptions();
		while (enma.hasMoreElements()) {
			result.addElement(enma.nextElement());
		}

		Enumeration<Option> enu = super.listOptions();
		while (enu.hasMoreElements()) {
			result.addElement(enu.nextElement());
		}
		return result.elements();
	}

	@Override
	public String[] getOptions() {
		int i;
		Vector<String> result;
		String[] options;

		result = new Vector<String>();
		options = super.getOptions();
		for (i = 0; i < options.length; i++) {
			result.add(options[i]);
		}

		result.add("-I");
		result.add("" + getIter());

		result.add("-N");
		result.add("" + getReducedIter());

		result.add("-V");
		result.add(getVariant().toString());

		result.add("-U");
		result.add("" + getUpdate().getClass().getName() + " " + Utils.joinOptions(getUpdate().getOptions()));

		result.add("-G");
		result.add("" + getMargin().getClass().getName() + " " + Utils.joinOptions(getMargin().getOptions()));

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('I', options);
		if (tmp.length() != 0) {
			setIter(Integer.parseInt(tmp));
		}
		else {
			setIter(100);
		}
		tmp = Utils.getOption('N', options);
		if (tmp.length() != 0) {
			setReducedIter(Integer.parseInt(tmp));
		}
		else {
			setReducedIter(0);
		}
		tmp = Utils.getOption('V', options);
		if (tmp.length() != 0) {
			setVariant(new SelectedTag(Integer.parseInt(tmp), Perceptrovement.TAGS_VARIANT));
		}
		else {
			setVariant(new SelectedTag(Perceptrovement.VARIANT_CLASSICAL, Perceptrovement.TAGS_VARIANT));
		}

		String updateString = Utils.getOption('U', options);
		String[] updateOptions = Utils.splitOptions(updateString);
		if (updateOptions.length != 0) {
			updateString = updateOptions[0];
			updateOptions[0] = "";
			setUpdate(Update.forName(updateString, updateOptions));
		}

		String marginString = Utils.getOption('G', options);
		String[] marginOptions = Utils.splitOptions(marginString);
		if (marginOptions.length != 0) {
			marginString = marginOptions[0];
			marginOptions[0] = "";
			setMargin(Margin.forName(marginString, marginOptions));
		}

		super.setOptions(options);
	}

	/**
	 * @return
	 */
	public String iterTipText() {
		return "Iterations.";
	}

	/**
	 * @return
	 */
	public int getIter() {
		return this.numIterations;
	}

	/**
	 * @param v
	 */
	public void setIter(int v) {
		this.numIterations = v;
	}

	/**
	 * @return
	 */
	public String reducedIterTipText() {
		return "Reduced epochs.";
	}

	/**
	 * @return the reducedIter
	 */
	public int getReducedIter() {
		return this.reducedIter;
	}

	/**
	 * @param reducedIter
	 *            the reducedIter to set
	 */
	public void setReducedIter(int reducedIter) {
		this.reducedIter = reducedIter;
	}

	/**
	 * @return
	 */
	public String variantTipText() {
		return "Variants: 0=Classic/1=Survivor/2=Voted.";
	}

	/**
	 * @return
	 */
	public SelectedTag getVariant() {
		return new SelectedTag(this.variant, Perceptrovement.TAGS_VARIANT);
	}

	/**
	 * @param variant
	 */
	public void setVariant(SelectedTag variant) {
		if (variant.getTags() == Perceptrovement.TAGS_VARIANT) {
			this.variant = variant.getSelectedTag().getID();
		}
	}

	/**
	 * @return
	 */
	public String marginTipText() {
		return "Margin type.";
	}

	/**
	 * @return the margin
	 */
	public Margin getMargin() {
		return this.margin;
	}

	/**
	 * @param margin
	 *            the margin to set
	 */
	public void setMargin(Margin margin) {
		this.margin = margin;
	}

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the explorer/experimenter GUI
	 */
	public String updateTipText() {
		return "The update method to use.";
	}

	/**
	 * @param update
	 *            the update to set
	 */
	public void setUpdate(Update update) {
		this.update = update;
	}

	/**
	 * @return the update
	 */
	public Update getUpdate() {
		return this.update;
	}

}
