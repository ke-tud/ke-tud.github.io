package weka.classifiers.pla.addon.margin;

import weka.classifiers.pla.addon.Addon;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public abstract class Margin extends Addon {

	private static final long serialVersionUID = -9114991906122376485L;

	@Override
	protected void init() throws Exception {
	}

	/**
	 * @param n
	 *            Index of the current training example.
	 * @param yN
	 *            Correct class of instIndex.
	 * @param t
	 *            Total update count.
	 * @return The margin when learning from data point with index instIndex.
	 * @throws Exception
	 */
	public abstract double getCurrentMargin(int n, int yN, int t) throws Exception;

	/**
	 * Creates a new instance of a margin given its class name and (optional) arguments to pass to its setOptions
	 * method.
	 * 
	 * @param marginName
	 *            the fully qualified class name of the margin
	 * @param options
	 *            an array of options suitable for passing to setOptions. May be null.
	 * @return the newly created margin, ready for use.
	 * @throws Exception
	 *             if the margin name is invalid, or the options supplied are not acceptable to the margin
	 */
	public static Margin forName(String marginName, String[] options) throws Exception {

		return (Margin) Utils.forName(Margin.class, marginName, options);
	}

}
