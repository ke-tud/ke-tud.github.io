package weka.classifiers.pla.addon.update;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.SelectedTag;
import weka.core.Tag;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public class PAUpdate extends Update {

	private static final long serialVersionUID = 7047247359111369908L;

	/**  */
	public static final int UPDATE_PA1 = 0;
	/**  */
	public static final int UPDATE_PA2 = 1;

	/**  */
	public static final Tag[] TAGS_UPDATE = { new Tag(UPDATE_PA1, "PA-I"), new Tag(UPDATE_PA2, "PA-II"), };

	/**  */
	private int update = UPDATE_PA1;

	/**  */
	private double aggressiveness = Double.POSITIVE_INFINITY;

	@Override
	protected void init() {
	}

	@Override
	public boolean updateWeight(int n, int yN, double lossN, double outputN, double margin, int uN, int temp) throws Exception {

		double taoT;
		double factor;

		// PA needs a positive loss to update, hence "passive-aggressive".
		if (lossN > 0.0) {
			if (this.update == UPDATE_PA1) {
				taoT = Math.min(this.aggressiveness, lossN / getWeight().dotProduct(n, n));
			}
			else if (this.update == UPDATE_PA2) {
				taoT = lossN / (getWeight().dotProduct(n, n) + 1 / (2 * this.aggressiveness));
			}
			else {
				throw new Exception("No valid update method chosen!");
			}
			factor = taoT * yN;
		}
		else {
			factor = 0;
		}

		return getWeight().updateWeight(n, factor, outputN);
	}

	@Override
	public String globalInfo() {
		return "Passive-aggressive update rate. PA is achieved by setting C to +inf.";
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tAggressiveness C.\n" + "\t(default +inf yields PA)", "C", 1, "-C <num>"));
		result.addElement(new Option("\tUpdates: 0=PA-I/1=PA-II. " + "(default 1)", "V", 1, "-V <num>"));

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-C");
		result.add("" + getAggressiveness());

		result.add("-V");
		result.add("" + this.update);

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('C', options);
		if (tmp.length() != 0) {
			setAggressiveness(Double.parseDouble(tmp));
		}
		else {
			setAggressiveness(Double.POSITIVE_INFINITY);
		}
		tmp = Utils.getOption('V', options);
		if (tmp.length() != 0) {
			setUpdate(new SelectedTag(Integer.parseInt(tmp), TAGS_UPDATE));
		}
		else {
			setUpdate(new SelectedTag(UPDATE_PA1, TAGS_UPDATE));
		}
	}

	/**
	 * @return
	 */
	public String updateTipText() {
		return "Updates: 0=PA-I/1=PA-II.";
	}

	/**
	 * @return
	 */
	public SelectedTag getUpdate() {
		return new SelectedTag(this.update, TAGS_UPDATE);
	}

	/**
	 * @param update
	 */
	public void setUpdate(SelectedTag update) {
		if (update.getTags() == TAGS_UPDATE) {
			this.update = update.getSelectedTag().getID();
		}
	}

	/**
	 * @return
	 */
	public String aggressivenessTipText() {
		return "Aggressiveness C.";
	}

	/**
	 * @return the aggressiveness
	 */
	public double getAggressiveness() {
		return this.aggressiveness;
	}

	/**
	 * @param aggressiveness
	 *            the aggressiveness to set
	 */
	public void setAggressiveness(double aggressiveness) {
		this.aggressiveness = aggressiveness;
	}

}
