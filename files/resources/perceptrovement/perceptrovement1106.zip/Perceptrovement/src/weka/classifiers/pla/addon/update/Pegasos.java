package weka.classifiers.pla.addon.update;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;

public class Pegasos extends Update {

	/**  */
	private static final long serialVersionUID = -3379320722006496910L;

	/** Lambda projection value */
	private double lambda = 0.0001;

	private int tPegasos;

	@Override
	protected void init() throws Exception {
		this.tPegasos = 0;
	}

	@Override
	public boolean updateWeight(int n, int yN, double lossN, double outputN, double margin, int uN, int t) throws Exception {

		final boolean[] weightChanged = { false, false };

		this.tPegasos++;
		final double etaT = 1.0 / (getLambda() * this.tPegasos);

		final double scale = 1.0 - 1.0 / this.tPegasos;
		weightChanged[0] = getWeight().scale(scale);
		weightChanged[0] = weightChanged[0] && scale == 0; // Scale factor might be 0 -> if ||w|| was > 0, it isn't now -> weight changed
		if (!weightChanged[0] && scale == 0) {
			assert this.tPegasos == 1 : "May happen only the first time this function gets called!";
			getLogger().log("Pegasos implicitly resets w = 0 in the first run");
		}

		outputN *= scale;

		// Same as PA: in the paper it needs a positive loss to update. But in the limit yN * outputN -> margin from above the loss function is still differentiable.
		if (yN * outputN <= margin) {
			final double factor = etaT * yN;
			weightChanged[1] = getWeight().updateWeight(n, factor, outputN);
		}

		double a = 1;
		double b = 1 / (Math.sqrt(getLambda()) * getWeight().getEuclideanLength());
		getWeight().scale(Math.min(a, b)); // Scale factor > 0 -> don't need to check for change

		return weightChanged[0] || weightChanged[1];
	}

	@Override
	public String globalInfo() {
		return "Primal Estimated sub-GrAdient SOlver for SVM.";
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tLambda projection value.\n" + "\t(default E-4)", "M", 1, "-M <num>"));

		return result.elements();
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;

		result = new Vector<String>();

		result.add("-M");
		result.add("" + getLambda());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('M', options);
		if (tmp.length() != 0) {
			setLambda(Double.parseDouble(tmp));
		}
		else {
			setLambda(0.0001);
		}
	}

	/**
	 * @return Help on lambda trick value.
	 */
	public final String lambdaTipText() {
		return "Lambda projection value.";
	}

	/**
	 * @return the lambda
	 */
	public final double getLambda() {
		return this.lambda;
	}

	/**
	 * @param lambda
	 *            the lambda to set
	 */
	public final void setLambda(double lambda) {
		this.lambda = lambda;
	}

}
