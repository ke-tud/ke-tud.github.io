package weka.classifiers.pla.addon.margin;

import java.util.Enumeration;
import java.util.Vector;

import weka.core.Option;
import weka.core.Utils;

/**
 * @author Tobias Krönke
 */
public class MICRAMargin extends Margin {

	private static final long serialVersionUID = -8673626157399816996L;

	/** */
	private double epsilon = 0.0625;
	/** */
	private double beta = 1;

	@Override
	public double getCurrentMargin(int n, int yN, int t) throws Exception {
		double margin = getBeta() * getWeight().getEuclideanLength() * Math.pow(t, -getEpsilon());
		return margin;
	}

	@Override
	public String globalInfo() {
		return "Mistake controlled margin.";
	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();

		result.add("-E");
		result.add("" + getEpsilon());

		result.add("-B");
		result.add("" + getBeta());

		return result.toArray(new String[result.size()]);
	}

	@Override
	public Enumeration<Option> listOptions() {

		Vector<Option> result = new Vector<Option>();

		result.addElement(new Option("\tEpsilon.\n" + "\t(default 0.0625)", "E", 1, "-E <num>"));
		result.addElement(new Option("\tBeta.\n" + "\t(default 1)", "B", 1, "-B <num>"));

		return result.elements();
	}

	@Override
	public void setOptions(String[] options) throws Exception {
		String tmp;

		tmp = Utils.getOption('E', options);
		if (tmp.length() != 0) {
			setEpsilon(Double.parseDouble(tmp));
		}
		else {
			setEpsilon(0.0625);
		}
		tmp = Utils.getOption('B', options);
		if (tmp.length() != 0) {
			setBeta(Double.parseDouble(tmp));
		}
		else {
			setBeta(1);
		}
	}

	/**
	 * @return
	 */
	public String epsilonTipText() {
		return "Epsilon: time degradation.";
	}

	/**
	 * @return the epsilon
	 */
	public double getEpsilon() {
		return this.epsilon;
	}

	/**
	 * @param epsilon
	 *            the epsilon to set
	 */
	public void setEpsilon(double epsilon) {
		this.epsilon = epsilon;
	}

	/**
	 * @return
	 */
	public String betaTipText() {
		return "Beta.";
	}

	/**
	 * @param beta
	 *            the beta to set
	 */
	public void setBeta(double beta) {
		this.beta = beta;
	}

	/**
	 * @return the beta
	 */
	public double getBeta() {
		return this.beta;
	}

}
