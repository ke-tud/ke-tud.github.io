package testing;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import weka.classifiers.Classifier;
import weka.classifiers.functions.supportVector.Kernel;
import weka.classifiers.functions.supportVector.PolyKernel;
import weka.classifiers.pla.Perceptrovement;
import weka.classifiers.pla.addon.augment.*;
import weka.classifiers.pla.addon.budget.*;
import weka.classifiers.pla.addon.margin.*;
import weka.classifiers.pla.addon.update.*;
import weka.classifiers.pla.weight.*;
import weka.classifiers.xml.XMLClassifier;
import weka.core.SelectedTag;
import weka.core.Tag;

public class PreTest {

	public static final ArrayList<Margin> margins() {
		ArrayList<Margin> result = new ArrayList<Margin>();

		//		final double[] NEG_MARGIN = { 0, 1 };
		//		final double[] POS_MARGIN = { 0, 1 };
		//
		//		for (double n : NEG_MARGIN) {
		//			for (double p : POS_MARGIN) {
		//				UnevenMargin m = new UnevenMargin();
		//
		//				m.setNegMargin(n);
		//				m.setPosMargin(p);
		//
		//				result.add(m);
		//			}
		//		}

		final double[] MARGIN = { 1 };
		final boolean[] SCALE = { false };

		for (double n : MARGIN) {
			for (boolean s : SCALE) {
				UnevenMargin m = new UnevenMargin();

				m.setNegMargin(n);
				m.setPosMargin(n);

				if (n != 0) {
					m.setScale(s);
				}

				result.add(m);
			}
		}

		final double[] BETA = { 1 };
		final double[] EPSILON = { 0.0625 };

		for (double b : BETA) {
			for (double e : EPSILON) {
				MICRAMargin m = new MICRAMargin();

				m.setBeta(b);
				m.setEpsilon(e);

				result.add(m);
			}
		}

		return result;
	}

	public static final ArrayList<Update> updates() {
		ArrayList<Update> result = new ArrayList<Update>();

		final double[] RATE = { 1 };

		for (double r : RATE) {
			ConstantUpdate u = new ConstantUpdate();

			u.setRate(r);

			result.add(u);
		}

		final double[] BETA = { 1 };
		final double[] DELTA = { 0 };
		final double[] ETA = { 2 };
		final double[] ZETA = { 0.875 };

		for (double b : BETA) {
			for (double d : DELTA) {
				for (double e : ETA) {
					for (double z : ZETA) {
						MICRAUpdate u = new MICRAUpdate();

						u.setBeta(b);
						u.setDelta(d);
						u.setEtaZero(e);
						u.setZeta(z);

						result.add(u);
					}
				}
			}
		}

		final double[] AGG = { 0.001 };

		PAUpdate pa = new PAUpdate();
		pa.setAggressiveness(Double.POSITIVE_INFINITY);
		result.add(pa);

		pa = new PAUpdate();
		pa.setAggressiveness(AGG[0]);
		result.add(pa);

		//		for (Tag v : PAUpdate.TAGS_UPDATE) {
		//			for (double a : AGG) {
		//				PAUpdate u = new PAUpdate();
		//
		//				u.setUpdate(new SelectedTag(v.getID(), PAUpdate.TAGS_UPDATE));
		//				u.setAggressiveness(a);
		//
		//				result.add(u);
		//			}
		//		}

		final double[] LAMBDA = { Math.pow(10, -4) };

		for (double l : LAMBDA) {
			Pegasos u = new Pegasos();

			u.setLambda(l);

			result.add(u);
		}

		return result;
	}

	private static ArrayList<Augment> augments() {
		ArrayList<Augment> result = new ArrayList<Augment>();

		final double[] AUGMENT_NUMBER = { 0 };

		for (double a : AUGMENT_NUMBER) {
			RealNumber r = new RealNumber();

			r.setNumber(a);

			result.add(r);
		}

		//		final Tag[] AUGMENT_VARIANTS = { FromData.TAGS_VARIANT[0] };
		//
		//		for (Tag variant : AUGMENT_VARIANTS) {
		//			FromData f = new FromData();
		//
		//			f.setVariant(new SelectedTag(variant.getID(), FromData.TAGS_VARIANT));
		//
		//			result.add(f);
		//		}

		return result;
	}

	private static ArrayList<Kernel> kernels() {
		ArrayList<Kernel> result = new ArrayList<Kernel>();

		PolyKernel k = new PolyKernel();
		k.setCacheSize(0);
		result.add(k);

		return result;
	}

	public static ArrayList<Budget> budgets() {
		ArrayList<Budget> result = new ArrayList<Budget>();

		final int[] BUDGET = { 50 };
		final Tag[] HEURISTICS = { HeuristicSelection.TAGS_HEURISTIC[0] };

		for (int b : BUDGET) {
			for (Tag heuristic : HEURISTICS) {
				JustRemove j = new JustRemove();

				j.setBudget(b);
				j.setHeuristic(new SelectedTag(heuristic.getID(), HeuristicSelection.TAGS_HEURISTIC));

				result.add(j);

				final double[] RIDGE = { 0.01 };
				final int[] SUB_BUDGET = { Integer.MAX_VALUE };

				for (double r : RIDGE) {
					for (int s : SUB_BUDGET) {
						LeastSquaresProjection l = new LeastSquaresProjection();

						l.setBudget(b);
						l.setNrRegressionSV(s);
						l.setHeuristic(new SelectedTag(heuristic.getID(), HeuristicSelection.TAGS_HEURISTIC));
						l.setRidge(r);

						result.add(l);
					}
				}
			}
		}

		return result;
	}

	public static final ArrayList<PerceptronWeight> perceptronWeights() {
		ArrayList<PerceptronWeight> result = new ArrayList<PerceptronWeight>();

		final double[] LAMBDA_TRICK = { 0, 1 };

		for (Augment a : augments()) {
			//			for (Budget b : budgets()) {
			for (Kernel k : kernels()) {
				for (double l : LAMBDA_TRICK) {
					DualForm d = new DualForm();

					d.setAugment(a);
					//					d.setBudget(b);
					d.setKernel(k);
					d.setLambda(l);

					result.add(d);
				}
			}
			//			}
		}

		return result;
	}

	public static final ArrayList<Classifier> classifiers(int iter, int r_iter, Tag variant) {
		ArrayList<Classifier> result = new ArrayList<Classifier>();
		final int[] ALPHA_BOUND = { 10, Integer.MAX_VALUE };

		int count = 0;

		for (Margin m : margins()) {
			for (Update u : updates()) {
				if (!(m instanceof MICRAMargin && u instanceof MICRAUpdate) || (((MICRAMargin) m).getBeta() == ((MICRAUpdate) u).getBeta())) {
					for (PerceptronWeight w : perceptronWeights()) {
						for (int ab : ALPHA_BOUND) {
							Perceptrovement p = new Perceptrovement();
							count++;

							p.setMargin(m);
							p.setUpdate(u);
							p.setWeight(w);
							p.setIter(iter);
							p.setReducedIter(r_iter);
							p.setVariant(new SelectedTag(variant.getID(), Perceptrovement.TAGS_VARIANT));
							p.setAlphaBound(ab);

							result.add(p);
						}
					}
				}
			}
		}

		System.out.println(count);

		return result;
	}

	public static String readFileAsString(String filePath) throws java.io.IOException {
		StringBuffer fileData = new StringBuffer(1000);
		BufferedReader reader = new BufferedReader(new FileReader(filePath));
		char[] buf = new char[1024];
		int numRead = 0;
		while ((numRead = reader.read(buf)) != -1) {
			fileData.append(buf, 0, numRead);
		}
		reader.close();
		return fileData.toString();
	}

	public static void writeStringAsFile(String strFilePath, String str) {
		try {
			//create FileOutputStream object
			FileOutputStream fos = new FileOutputStream(strFilePath);

			/*
			  * To create DataOutputStream object from FileOutputStream use,
			  * DataOutputStream(OutputStream os) constructor.
			  *
			  */

			DataOutputStream dos = new DataOutputStream(fos);

			/*
			  * To write a string as a sequence of bytes to a file, use
			  * void writeBytes(String str) method of Java DataOutputStream class.
			  *
			  * This method writes string as a sequence of bytes to underlying output
			  * stream (Each character's high eight bits are discarded first).
			  */

			dos.writeBytes(str);

			/*
			  * To close DataOutputStream use,
			  * void close() method.
			  *
			  */

			dos.close();

		}
		catch (IOException e) {
			System.err.println("IOException : " + e);
		}
	}

	public static String inty(int i, int w) {
		String res = Integer.toString(i);

		while (res.length() < w) {
			res = "0" + res;
		}

		return res;
	}

	public static void main(String[] args) throws Exception {
		//Experiment e = (Experiment) new XMLExperiment().read("/home/tobias/test.exp.xml");

		XMLClassifier x = new XMLClassifier();
		String before = readFileAsString("exp/before.xml");
		String after = readFileAsString("exp/after.xml");
		after = after.substring(0, after.length() - 1);
		String end = readFileAsString("exp/end.xml");
		String out;
		String ps;
		String exp = "";

		final int[] ITER = { 10, 100 };
		final int[] REDUCED_ITER = { 0, 10 };

		int wekaDB = 1;

		for (int iter : ITER) {
			for (int r_iter : REDUCED_ITER) {
				for (Tag variant : Perceptrovement.TAGS_VARIANT) {
					int id = 1;
					ArrayList<Classifier> cls = classifiers(iter, r_iter, variant);
					ps = "";
					for (Classifier c : cls) {
						out = x.toXML(c).toString().substring(420).trim();
						out = out.replaceFirst("__root__", "" + id++);
						out = out.replaceFirst(" version=\"3.6.3\"", "");

						ps = ps + "\n" + out;
					}
					exp = before + "\n" + ps + "\n" + after + inty(wekaDB, 2) + "\n" + end;
					writeStringAsFile("exp/crammer/db" + inty(wekaDB, 2) + "i" + inty(iter, 3) + "r" + inty(r_iter, 2) + "v" + variant.getID() + ".xml", exp);
					wekaDB++;
				}
			}
		}

		//		System.out.println(exp);

		//		WekaDemo w = new WekaDemo();
		//		w.setTraining("./data/weka/iris2.arff");
		//
		//		int i = 0;
		//			w.setClassifier(c);
		//			w.execute();
		//			i++;
		//			if (i % 100 == 0) {
		//				System.out.println("100 done");
		//				System.out.println(w);
		//			}
	}
}