package testing;

import java.util.ArrayList;

import weka.classifiers.functions.supportVector.Kernel;
import weka.classifiers.functions.supportVector.PolyKernel;
import weka.classifiers.pla.Perceptrovement;
import weka.classifiers.pla.addon.augment.Augment;
import weka.classifiers.pla.addon.augment.FromData;
import weka.classifiers.pla.addon.augment.RealNumber;
import weka.classifiers.pla.addon.budget.Budget;
import weka.classifiers.pla.addon.budget.HeuristicSelection;
import weka.classifiers.pla.addon.budget.JustRemove;
import weka.classifiers.pla.addon.budget.LeastSquaresProjection;
import weka.classifiers.pla.addon.margin.MICRAMargin;
import weka.classifiers.pla.addon.margin.Margin;
import weka.classifiers.pla.addon.margin.UnevenMargin;
import weka.classifiers.pla.addon.update.ConstantUpdate;
import weka.classifiers.pla.addon.update.MICRAUpdate;
import weka.classifiers.pla.addon.update.PAUpdate;
import weka.classifiers.pla.addon.update.Pegasos;
import weka.classifiers.pla.addon.update.Update;
import weka.classifiers.pla.weight.DualForm;
import weka.classifiers.pla.weight.PerceptronWeight;
import weka.core.SelectedTag;
import weka.core.Tag;

public class MainTest {

	// Base configuration parameters

	// Batch extensions
	static final Tag[] BATCH_VAR = Perceptrovement.TAGS_VARIANT;

	// Margins

	// Uneven Margin
	static final double[] NEG_MARGIN = { 1 };
	static final double[] POS_MARGIN = { 1 };
	static final boolean[] SCALE_MARGIN = { true };

	// MICRA Margin
	static final double[] MICRA_EPSILON = { 0.1 };

	// Updates

	// Constant
	static final double[] CONSTANT_RATE = { 1 };

	// MICRA
	static final double[] MICRA_BETA = { 1 };
	static final double[] MICRA_DELTA = { 0 };
	static final double[] MICRA_ETA = { 2 };
	static final double[] MICRA_ZETA = { 0.9 };

	// PA
	static final double[] PA_AGG = { 0.001 };
	static final Tag[] PA_VAR = PAUpdate.TAGS_UPDATE;

	// Pegasos
	static final double[] PEGASOS_LAMBDA = { Math.pow(10, -4) };

	// Misc. parameters

	// Augmentation
	static final double[] AUGMENT_NUMBER = { 1 };
	static final Tag[] AUGMENT_VARIANTS = { FromData.TAGS_VARIANT[0] };

	// Lambda trick
	static final double[] LAMBDA_TRICK = { 0, 1 };

	// Alpha bound
	static final int[] ALPHA_BOUND = { 10, Integer.MAX_VALUE };

	// Budget
	static final int[] BUDGET = { 50, Integer.MAX_VALUE };
	static final Tag[] HEURISTICS = { HeuristicSelection.TAGS_HEURISTIC[0] };
	static final double[] RIDGE = { 0.01 };
	static final int[] SUB_BUDGET = { Integer.MAX_VALUE };

	// Iterations
	static final int[] ITER = { 100 };
	static final int[] REDUCED_ITER = { 0 };

	public static final ArrayList<Margin> margins() {
		ArrayList<Margin> result = new ArrayList<Margin>();

		for (double n : NEG_MARGIN) {
			for (double p : POS_MARGIN) {
				for (boolean s : SCALE_MARGIN) {
					UnevenMargin m = new UnevenMargin();

					m.setNegMargin(n);
					m.setPosMargin(p);

					if (n != 0 || p != 0) {
						m.setScale(s);
					}

					result.add(m);
				}
			}
		}

		for (double b : MICRA_BETA) {
			for (double e : MICRA_EPSILON) {
				MICRAMargin m = new MICRAMargin();

				m.setBeta(b);
				m.setEpsilon(e);

				result.add(m);
			}
		}

		return result;
	}

	public static final ArrayList<Update> updates() {
		ArrayList<Update> result = new ArrayList<Update>();

		for (double r : CONSTANT_RATE) {
			ConstantUpdate u = new ConstantUpdate();

			u.setRate(r);

			result.add(u);
		}

		for (double b : MICRA_BETA) {
			for (double d : MICRA_DELTA) {
				for (double e : MICRA_ETA) {
					for (double z : MICRA_ZETA) {
						MICRAUpdate u = new MICRAUpdate();

						u.setBeta(b);
						u.setDelta(d);
						u.setEtaZero(e);
						u.setZeta(z);

						result.add(u);
					}
				}
			}
		}

		for (Tag v : PA_VAR) {
			for (double a : PA_AGG) {
				PAUpdate u = new PAUpdate();

				u.setUpdate(new SelectedTag(v.getID(), PAUpdate.TAGS_UPDATE));
				u.setAggressiveness(a);

				result.add(u);
			}
		}

		for (double l : PEGASOS_LAMBDA) {
			Pegasos u = new Pegasos();

			u.setLambda(l);

			result.add(u);
		}

		return result;
	}

	private static ArrayList<Augment> augments() {
		ArrayList<Augment> result = new ArrayList<Augment>();

		for (double a : AUGMENT_NUMBER) {
			RealNumber r = new RealNumber();

			r.setNumber(a);

			result.add(r);
		}

		for (Tag variant : AUGMENT_VARIANTS) {
			FromData f = new FromData();

			f.setVariant(new SelectedTag(variant.getID(), FromData.TAGS_VARIANT));

			result.add(f);
		}

		return result;
	}

	private static ArrayList<Kernel> kernels() {
		ArrayList<Kernel> result = new ArrayList<Kernel>();

		PolyKernel k = new PolyKernel();
		//k.setCacheSize(0);
		result.add(k);

		return result;
	}

	private static ArrayList<Budget> budgets() {
		ArrayList<Budget> result = new ArrayList<Budget>();

		for (int b : BUDGET) {
			for (Tag heuristic : HEURISTICS) {
				JustRemove j = new JustRemove();

				j.setBudget(b);
				j.setHeuristic(new SelectedTag(heuristic.getID(), HeuristicSelection.TAGS_HEURISTIC));

				result.add(j);

				for (double r : RIDGE) {
					for (int s : SUB_BUDGET) {
						LeastSquaresProjection l = new LeastSquaresProjection();

						l.setBudget(b);
						l.setNrRegressionSV(s);
						l.setHeuristic(new SelectedTag(heuristic.getID(), HeuristicSelection.TAGS_HEURISTIC));
						l.setRidge(r);

						result.add(l);
					}
				}
			}
		}

		return result;
	}

	public static final ArrayList<PerceptronWeight> perceptronWeights() {
		ArrayList<PerceptronWeight> result = new ArrayList<PerceptronWeight>();

		for (Augment a : augments()) {
			for (Budget b : budgets()) {
				for (Kernel k : kernels()) {
					for (double l : LAMBDA_TRICK) {
						DualForm d = new DualForm();

						d.setAugment(a);
						d.setBudget(b);
						d.setKernel(k);
						d.setLambda(l);

						result.add(d);
					}
				}
			}
		}

		return result;
	}

	public static final ArrayList<Perceptrovement> classifiers() {
		ArrayList<Perceptrovement> result = new ArrayList<Perceptrovement>();

		int count = 0;
		boolean keep;

		for (Margin m : margins()) {
			for (Update u : updates()) {
				keep = ((u instanceof ConstantUpdate && m instanceof UnevenMargin) || (u instanceof PAUpdate && m instanceof UnevenMargin)
						|| (u instanceof Pegasos && m instanceof MICRAMargin) || (u instanceof MICRAUpdate && m instanceof MICRAMargin));
				keep = keep && (!(m instanceof MICRAMargin && u instanceof MICRAUpdate) || (((MICRAMargin) m).getBeta() == ((MICRAUpdate) u).getBeta()));
				if (keep) {
					for (PerceptronWeight w : perceptronWeights()) {
						for (int iter : ITER) {
							for (int r_iter : REDUCED_ITER) {
								for (Tag batchVariant : BATCH_VAR) {
									for (int ab : ALPHA_BOUND) {

										// -----------------------------------------------------------------
										Perceptrovement p = new Perceptrovement();
										count++;

										p.setMargin(m);
										p.setUpdate(u);
										p.setWeight(w);
										p.setIter(iter);
										p.setReducedIter(r_iter);
										p.setVariant(new SelectedTag(batchVariant.getID(), Perceptrovement.TAGS_VARIANT));
										p.setIter(iter);
										p.setReducedIter(r_iter);
										p.setAlphaBound(ab);

										result.add(p);
										// -----------------------------------------------------------------

									}
								}
							}
						}
					}
				}
			}
		}

		return result;
	}

	public static void main(String[] args) {
		ArrayList<Perceptrovement> cls = classifiers();
		System.out.println(cls.size());
	}
}
