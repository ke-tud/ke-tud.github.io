package testing;

public class TicToc {

	private long savedTime;

	public String tic(String msg) {
		this.saveTime();

		return msg;
	}

	private void saveTime() {
		this.savedTime = System.currentTimeMillis();
	}

	public String toc() {
		long elapsedTime = System.currentTimeMillis() - this.savedTime;
		return elapsedTime + "ms";
	}
}
