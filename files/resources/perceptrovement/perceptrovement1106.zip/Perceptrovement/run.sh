#!/bin/bash
# -ea for assertions
# -Xmx2048m -server for "heavy" load
java -cp $CLASSPATH:lib/weka.jar:/usr/share/java/postgresql.jar:bin:lib/libsvm.jar weka.gui.GUIChooser
