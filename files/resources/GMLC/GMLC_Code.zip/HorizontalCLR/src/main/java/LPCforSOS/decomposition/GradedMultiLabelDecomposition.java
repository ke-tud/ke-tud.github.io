package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;

import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.evaluation.Configuration;

public class GradedMultiLabelDecomposition implements PairwiseDecomposition {

	private final PairwiseDecomposer decomposer;

	public GradedMultiLabelDecomposition(PairwiseDecomposer pairwiseDecomposer) {
		super();
		this.decomposer = pairwiseDecomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		int numOfCalibratedLabels = data.getNumberOfGrades() - 1;
		// int gradeLength =
		// Integer.toString(data.getNumberOfGrades()).length();

		List<String> classes = new ArrayList<String>(data.getClasses());
		List<String> calibrationLabels = new ArrayList<String>();
		Configuration.resetCaliLabels();
		for (int i = 0; i < numOfCalibratedLabels; i++) {
			String calibrationLabel = Configuration.getCalibrationLabel();
			calibrationLabels.add(calibrationLabel);
			Configuration.nextCaliLabel();
		}

		Set<String> shortenedClasses = new HashSet<String>();
		classes.addAll(calibrationLabels);
		for (String currentClassString : classes) {
			String currentClass = currentClassString;

			if (!calibrationLabels.contains(currentClassString)) {
				currentClass = parseClass(currentClassString);
			}

			shortenedClasses.add(currentClass);

			if (!this.decomposer.getClassToNumber().containsKey(currentClass)) {
				this.decomposer.getClassToNumber().put(currentClass,
						this.decomposer.getClassToNumber().size());
			}
		}

		for (int grade = 0; grade < numOfCalibratedLabels; grade++) {
			String calibrationLabel = Configuration.getCalibrationLabel(grade);

			int iter = 0;
			int counter = 0;
			List<String> shortenedClassesList = new ArrayList<String>(shortenedClasses);
			for (int i = 0; i < shortenedClassesList.size(); i++) {
				String label1 = shortenedClassesList.get(i);
				for (int j = i + 1; j < shortenedClassesList.size(); j++) {
					String label2 = shortenedClassesList.get(j);

					if (label1.equals(label2)) {
						continue;
					}

					FastVector attributeValues = new FastVector();
					attributeValues.addElement(label1);
					attributeValues.addElement(label2);

					FastVector attributes = (FastVector) data.get_Attributes()
							.copyElements();
					attributes.addElement(new Attribute("class",
							attributeValues));

					String sub_relation = data.relationName() + "_" + label1
							+ "_vs_" + label2 + "_calilabel_"
							+ calibrationLabel;
					Instances sub_Instances = new Instances(sub_relation,
							attributes, 100);
					// --->
					for (ExtInstance extInstance : data.get_Instances()) {
						int label = -1;

						if (label1.equals(calibrationLabel)
								&& !containsWithHigherGrade(
										extInstance.getM_Classes(), label2,
										grade, calibrationLabels)
								) {
							label = 0;
						} else if (label2.equals(calibrationLabel)
								&& !containsWithHigherGrade(
										extInstance.getM_Classes(), label1,
										grade, calibrationLabels)
								) {
							label = 1;
						} else if ((containsWithHigherGrade(
								extInstance.getM_Classes(), label1, grade, calibrationLabels) ^ containsWithHigherGrade(
								extInstance.getM_Classes(), label2, grade,calibrationLabels))) {
							label = (containsWithHigherGrade(
									extInstance.getM_Classes(), label1, grade, calibrationLabels)) ? 0
									: 1;
						}

						if (!(label < 0)) {
							ExtInstance instance = (ExtInstance) extInstance
									.copy();
							instance.setValue(extInstance.asWekaInstance()
									.numAttributes() - 1, label);

							// appends the new instance with new class value
							sub_Instances.add(instance);
							instance.asWekaInstance().setDataset(sub_Instances);
						}

						iter++;
					}

					sub_Instances
							.setClassIndex(sub_Instances.numAttributes() - 1);
					if (sub_Instances.numInstances() != 0) {
						this.decomposer.getDecomposedDatasets().add(
								sub_Instances);
						counter++;
					}

				}
			}
			//System.out.println(iter + " Iterationen, " + counter + " learner");

			Configuration.nextCaliLabel();
		}
		Configuration.resetCaliLabels();
	}

	private boolean hasCalibrationLabelWithHigherGrade(
			List<String> calibrationLabels, int grade, String calibrationLabel,
			String label1, String label2, ExtInstance extInstance) {
		return (calibrationLabels.contains(label1)
				&& parseGrade(label1) > grade && !containsWithHigherGrade(
					extInstance.getM_Classes(), label2, grade, calibrationLabels))
				^ (calibrationLabels.contains(label2)
						&& parseGrade(label2) > grade && !containsWithHigherGrade(
							extInstance.getM_Classes(), label1, grade, calibrationLabels));
	}

	private boolean containsWithHigherGrade(List<String> labels, String label,
			int grade, List<String> calibrationLabels) {
		if (calibrationLabels.contains(label)) {
			if(parseGrade(label)== grade){
				return false;
			}
			return parseGrade(label) > grade;
		} else {
			for (String currentLabel : labels) {
				if (parseClass(currentLabel).equals(label)
						&& parseGrade(currentLabel) > grade) {
					return true;
				}
			}
			return false;
		}
	}

	private String parseClass(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}

	private List<String> simplifyGrade(List<String> classes, List<String> grades) {
		List<String> simplifiedClasses = new ArrayList<String>(classes);
		for (int i = 0; i < classes.size(); i++) {
			String currentClass = classes.get(i);
			for (String grade : grades) {
				if (currentClass.endsWith(grade)) {
					simplifiedClasses.set(i, currentClass.replace(grade, ""));
				}
			}
		}
		return deleteDoublicates(simplifiedClasses);
	}

	private <T> List<T> deleteDoublicates(List<T> list) {
		Set<T> tmp = new HashSet<T>(list);
		return new ArrayList<T>(tmp);
	}

	private void updateDecomposer(PairwiseDecomposer gradeDecomposer) {
		// vereinige Datens�tze
		decomposer.getDecomposedDatasets().addAll(
				gradeDecomposer.getDecomposedDatasets());

		// f�ge zus�tzliche Label hinzu
		HashMap<String, Integer> gradeDecClassToNumber = gradeDecomposer
				.getClassToNumber();
		int caliLabelValue = Collections.max(gradeDecClassToNumber.values());

		int value;
		String caliLabelKey = null;
		HashMap<String, Integer> decClassToNumber = decomposer
				.getClassToNumber();
		for (Entry<String, Integer> entry : gradeDecClassToNumber.entrySet()) {
			value = entry.getValue();
			if (value == caliLabelValue) {
				caliLabelKey = entry.getKey();
				continue;
			}
			decClassToNumber.put(entry.getKey(), value);
		}
		decClassToNumber.put(caliLabelKey, decClassToNumber.size());
	}

	/**
	 * Returns true if a given set of ordinal labels contains only labels with a
	 * higher grade than the given label else false is returned
	 * 
	 * @param label
	 *            the label to compare
	 * @param highEnoughGrades
	 *            the set of labels
	 * @return if the label's grade is lower
	 */
	private boolean isNotInRange(String label, List<String> highEnoughGrades) {
		for (String curGrade : highEnoughGrades) {
			if (label.endsWith(curGrade))
				return false;
		}
		return true;
	}

	private List<String> getRange(int indexOfLowerBoundLabelGrade,
			ExtInstances data) {
		List<String> allLabelGrades = data.getLabelGrades();
		List<String> copyOfRange = allLabelGrades.subList(
				indexOfLowerBoundLabelGrade, allLabelGrades.size());
		return copyOfRange;
	}

	public void decomposeCalibratedLabelRanking(ExtInstances data) {
		int counter = 0;
		double value = 0.0;
		int iter = 0;

		int numOfClasses = data.getNumberOfClasses();
		int numOfClassesPlusCaliLabel = numOfClasses + 1;

		// Einf�gen des Calibrationlabels ans Ende der Liste aller Klassen
		List<String> classesPlusCaliLabel = new ArrayList<String>(
				data.getClasses());
		classesPlusCaliLabel.add(Configuration.getCalibrationLabel());

		// mapping string of class to number
		// Mit dem setzen in die classToNumber HashMap wird das Calibrationlabel
		// auch f�r den Lerner und Klassifizierer �bernommen.
		int classIndex = 0;
		for (String currentClassString : classesPlusCaliLabel) {
			String currentClass = parseClass(currentClassString);
			if (!this.decomposer.getClassToNumber().containsKey(currentClass)) {
				this.decomposer.getClassToNumber()
						.put(currentClass, classIndex);
				classIndex++;
			}
		}

		for (int i = 0; i < numOfClassesPlusCaliLabel; i++) {
			String label1 = classesPlusCaliLabel.get(i);

			// if asymmetric learner -> double round robin -> 1 vs. 2 unequal 2
			// vs. 1
			int startIdx = 0;
			if (this.decomposer.isSymmetric()) {
				startIdx = i + 1;
			}

			for (int j = startIdx; j < numOfClassesPlusCaliLabel; j++) {
				if (i == j) {
					continue;
				}

				String label2 = classesPlusCaliLabel.get(j);

				// new nominal attribute for class with the two classes
				FastVector attributeValues = new FastVector();
				attributeValues.addElement(label1);
				attributeValues.addElement(label2);

				FastVector attributes = (FastVector) data.get_Attributes()
						.copyElements();
				attributes.addElement(new Attribute("class", attributeValues));

				String sub_relation = data.relationName() + "_" + label1
						+ "_vs_" + label2;
				Instances sub_Instances = new Instances(sub_relation,
						attributes, 100);

				// naive approach
				for (ExtInstance extInstance : data.get_Instances()) {

					// weka coding of nominal attributes
					// -1 zeigt an das Instanz nicht zu gebrauchen ist.
					int label = -1;

					if (label1 == Configuration.getCalibrationLabel()
							&& !extInstance.getM_Classes().contains(label2)) {

						label = 0;
					} else if (label2 == Configuration.getCalibrationLabel()
							&& !extInstance.getM_Classes().contains(label1)) {

						label = 1;
					} else
					// only instance with one of the two classes, all other
					// records are omitted
					if (extInstance.getM_Classes().contains(label1)
							^ extInstance.getM_Classes().contains(label2)) {

						label = extInstance.getM_Classes().contains(label1) ? 0
								: 1;
					}

					if (!(label < 0)) {
						ExtInstance instance = (ExtInstance) extInstance.copy();
						instance.setValue(extInstance.asWekaInstance()
								.numAttributes() - 1, label);

						// appends the new instance with new class value
						sub_Instances.add(instance);
						instance.asWekaInstance().setDataset(sub_Instances);
					}
					iter++;
				}
				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				this.decomposer.getDecomposedDatasets().add(sub_Instances);
				value += sub_Instances.numInstances();
				counter++;
			}
		}
		System.out.println(iter + " Iterationen, " + counter + " learner");
	}

}
