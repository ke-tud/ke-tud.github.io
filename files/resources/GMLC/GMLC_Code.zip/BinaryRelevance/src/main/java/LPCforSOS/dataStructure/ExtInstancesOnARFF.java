package LPCforSOS.dataStructure;

import java.io.IOException;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.regex.Pattern;

import LPCforSOS.evaluation.Configuration;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;

/**
 * Dieser Untertyp �berschreibt die Methoden f�r das einlesen es Headers und der Testinstanzen aus einer Standard ARFF Datei.
 * Dies ist n�tig da der Obertyp so geschrieben ist dass der Parser auf bestimmte Zeichen im Text achtet.
 * Basis war der Code des Obertypen, es wurden keine Optimierungen vorgenommen.
 * 
 * @author George-P. C.F.
 */
public class ExtInstancesOnARFF extends ExtInstances {

	/**
	 * @param reader
	 * @throws IOException
	 */
	public ExtInstancesOnARFF(Reader reader) throws IOException {
		super(reader);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1538938077466440085L;

	/* (non-Javadoc)
	 * @see LPCforSOS.dataStructure.ExtInstances#getInstanceFull(java.io.StreamTokenizer, boolean)
	 */
	@Override
	protected boolean getInstanceFull(StreamTokenizer tokenizer, boolean flag)
			throws IOException {
		// additional column for single class in decomposed datasets
		double[] instance = new double[numAttributes() + 1];
		int index;

		// Get values for all attributes.
		for (int i = 0; i < numAttributes(); i++) {
			// Get next token
			if (i > 0) {
				getNextToken(tokenizer);
			}

			// Check if value is missing.
			if (tokenizer.ttype == '?') {
				instance[i] = Instance.missingValue();
			} else {
				// Check if token is valid.
				if (tokenizer.ttype != StreamTokenizer.TT_WORD) {
					errms(tokenizer, "not a valid value");
				}

				switch (attribute(i).type()) {
				case Attribute.NOMINAL:
					// Check if value appears in header.
					index = attribute(i).indexOfValue(tokenizer.sval);

					if (index == -1) {
						errms(tokenizer, "nominal value not declared in header");
					}

					instance[i] = index;

					break;

				case Attribute.NUMERIC:

					// Check if value is really a number.
					try {
						instance[i] = Double.valueOf(tokenizer.sval)
								.doubleValue();
					} catch (NumberFormatException e) {
						errms(tokenizer, "number expected");
					}

					break;

				case Attribute.STRING:
					instance[i] = attribute(i).addStringValue(tokenizer.sval);

					break;

				case Attribute.DATE:

					try {
						instance[i] = attribute(i).parseDate(tokenizer.sval);
					} catch (ParseException e) {
						errms(tokenizer, "unparseable date: " + tokenizer.sval);
					}

					break;

				default:
					errms(tokenizer, "unknown attribute type in column " + i);
				}
			}
		}
		
		// read last column with multilabel classes
		getNextToken(tokenizer);
		
		ArrayList<String> m_classes = new ArrayList<String>();

		m_classes.add(tokenizer.sval);

		if (flag) {
			getLastToken(tokenizer, true);
		}

		// Add instance to dataset
		ExtInstance tmp_extInstance = new ExtInstance(new Instance(1, instance), m_classes);
		add(tmp_extInstance);

		return true;
	}

	/* (non-Javadoc)
	 * @see LPCforSOS.dataStructure.ExtInstances#readHeader(java.io.StreamTokenizer)
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected void readHeader(StreamTokenizer tokenizer) throws IOException {
		String attributeName;
		FastVector attributeValues;
		classes = new ArrayList<String>();
		ext_Instances = new ArrayList<ExtInstance>();

		// Get name of relation.
		getFirstToken(tokenizer);

		if (tokenizer.ttype == StreamTokenizer.TT_EOF) {
			errms(tokenizer, "premature end of file");
		}

		if (ARFF_RELATION.equalsIgnoreCase(tokenizer.sval)) {
			getNextToken(tokenizer);
			m_RelationName = tokenizer.sval;
			getLastToken(tokenizer, false);
		} else {
			errms(tokenizer, "keyword " + ARFF_RELATION + " expected");
		}

		// Create vectors to hold information temporarily.
		// m_Attributes = new ArrayList<Attribute>();
		m_Attributes = new FastVector();

		// Get attribute declarations.
		getFirstToken(tokenizer);

		if (tokenizer.ttype == StreamTokenizer.TT_EOF) {
			errms(tokenizer, "premature end of file");
		}

		while (ARFF_ATTRIBUTE.equalsIgnoreCase(tokenizer.sval)) {
			// Get attribute name.
			getNextToken(tokenizer);
			attributeName = tokenizer.sval;
			getNextToken(tokenizer);

			// Check if attribute is nominal.
			if (tokenizer.ttype == StreamTokenizer.TT_WORD) {
				// Attribute is real, integer, or string.
				if (tokenizer.sval.equalsIgnoreCase(ARFF_ATTRIBUTE_REAL)
						|| tokenizer.sval
								.equalsIgnoreCase(ARFF_ATTRIBUTE_INTEGER)
						|| tokenizer.sval
								.equalsIgnoreCase(ARFF_ATTRIBUTE_NUMERIC)) {
					m_Attributes.addElement(new Attribute(attributeName));
					readTillEOL(tokenizer);
				} else if (tokenizer.sval
						.equalsIgnoreCase(ARFF_ATTRIBUTE_STRING)) {
					m_Attributes.addElement(new Attribute(attributeName));
					readTillEOL(tokenizer);
				} else if (tokenizer.sval.equalsIgnoreCase(ARFF_ATTRIBUTE_DATE)) {
					String format = null;

					if (tokenizer.nextToken() != StreamTokenizer.TT_EOL) {
						if ((tokenizer.ttype != StreamTokenizer.TT_WORD)
								&& (tokenizer.ttype != '\'')
								&& (tokenizer.ttype != '\"')) {
							errms(tokenizer, "not a valid date format");
						}

						format = tokenizer.sval;
						readTillEOL(tokenizer);
					} else {
						tokenizer.pushBack();
					}

					m_Attributes
							.addElement(new Attribute(attributeName, format));
				} else {
					errms(tokenizer, "no valid attribute type or invalid "
							+ "enumeration");
				}
			} else {
				// Attribute is nominal.
				attributeValues = new FastVector();
				tokenizer.pushBack();

				// Get values for nominal attribute.
				int token = tokenizer.nextToken();

				if (token == '{') {
					// Get values for nominal attribute
					while (tokenizer.nextToken() != '}') {
						if (tokenizer.ttype == StreamTokenizer.TT_EOL) {
							errms(tokenizer, "} expected at end of enumeration");
						} else {
							attributeValues.addElement(tokenizer.sval);
						}
					}

					if (attributeValues.size() == 0) {
						errms(tokenizer, "no nominal values found");
					}

					m_Attributes.addElement(new Attribute(attributeName,
							attributeValues));
				} else if (token == '[') {
					// read multi label classes
					classInformation = new ArrayList<String>();

					// classification type
					tokenizer.nextToken();
					type = Type.valueOf(tokenizer.sval);
					tokenizer.nextToken();
					
					// class informations
					while (tokenizer.nextToken() != '|') {
						if (tokenizer.ttype == StreamTokenizer.TT_EOL) {
							errms(tokenizer, "] expected at end of enumeration");
						} else {
							classInformation.add(tokenizer.sval);
							Pattern p = Pattern.compile("[<>!=]");
							String[] m_class = p.split(tokenizer.sval);
							for (String c : m_class) {
								if (!classes.contains(c)) {
									classes.add(c);
								}
							}
						}
					}

					// constraints
					tokenizer.nextToken();
					constraints = tokenizer.sval;

					tokenizer.nextToken();

					// insert additional attribute for class in the real
					// instance
					// m_Attributes.addElement(new Attribute("class"));
				} else {
					errms(tokenizer,
							"{ or [ expected at beginning of enumeration");
				}
			}

			getLastToken(tokenizer, false);
			getFirstToken(tokenizer);

			if (tokenizer.ttype == StreamTokenizer.TT_EOF) {
				errms(tokenizer, "premature end of file");
			}
		}

//		Es wird das letzte Attribut entnommen und als Klassenattribut verwendet
		if(m_Attributes.size() < 2){
			errms(tokenizer, "need minimum 2 attributes");
		}else{
			Attribute classAttribute = (Attribute)m_Attributes.lastElement();
			m_Attributes.removeElementAt(m_Attributes.size() - 1);
			
			// read multi label classes
			classInformation = new ArrayList<String>();

//			Es wird davon ausgegangen dass es sich immer um multiclassifikation handelt
			type = Type.Multiclass;
			
			for (Enumeration<String> enumer = classAttribute.enumerateValues(); enumer.hasMoreElements();) {
				String classValue = enumer.nextElement();
				if (!classes.contains(classValue)) {
					classes.add(classValue);
				}
			}

			// constraints
			constraints = Configuration.classAttributeConstraint;
		}
		
		// Check if data part follows. We can't easily check for EOL.
		if (!ARFF_DATA.equalsIgnoreCase(tokenizer.sval)) {
			errms(tokenizer, "keyword " + ARFF_DATA + " expected");
		}

		// Check if any attributes have been declared.
		if (m_Attributes.size() == 0) {
			errms(tokenizer, "no attributes declared");
		}

		// Allocate buffers in case sparse instances have to be read
		m_ValueBuffer = new double[numAttributes()];
		m_IndicesBuffer = new int[numAttributes()];
		// Make the last attribute be the class
		m_ClassIndex = numAttributes() - 1;
	}
}
