/**
 * 
 */
package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Calculate the precision. 
 * This is defined as<p>
 * <pre>
 * correctly classified positives
 * ------------------------------
 *  total predicted as positive
 * </pre>
 *
 * @author George-P. C.F.
 */
public class PrecisionLoss implements IConfusionMatrixBasedLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelCalibratedLabelRankingLossFunction#calculateLossFunction(LPCforSOS.evaluation.losses.TwoClassMultilabelCalibratedLabelRankingConfusionMatrix)
	 */
	@Override
	public double calculateLossFunction( TwoClassConfusionMatrix confusionMatrix) {
		return confusionMatrix.getPrecision();
	}
}
