/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.Comparator;

/**
 * @author Christian
 *
 */
public class LabelGradeComparator implements Comparator<String> {

	@Override
	public int compare(String label1, String label2) {
		return ((Integer)parseGrade(label1)).compareTo(parseGrade(label2));
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}
	
	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}

}
