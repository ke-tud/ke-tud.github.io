/**
 * 
 */
package LPCforSOS.dataStructure;

import java.util.ArrayList;

import weka.classifiers.evaluation.ConfusionMatrix;
import weka.classifiers.evaluation.TwoClassStats;
import weka.core.Matrix;

/**
 * @author George
 *
 */
@SuppressWarnings("deprecation")
public class ExtConfusionMatrix extends ConfusionMatrix {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5056545932934372569L;

	/**
	 * @param classNames
	 */
	public ExtConfusionMatrix(String[] classNames) {
		super(classNames);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Diese Methode summiert die �bergebenen Konfusionsmatizen auf.
	 * @return Konfusionsmatrix
	 */
	public static ConfusionMatrix getSumOfConfusionMatrices(ArrayList<ConfusionMatrix> confusionMatrixList){
		ConfusionMatrix tmpSumConfMatrix = null;
		Matrix tmpMatrix;
		if(!confusionMatrixList.isEmpty()){
			tmpMatrix = confusionMatrixList.get(0);
			for(int i = 1; i< confusionMatrixList.size();i++){
				tmpMatrix = tmpMatrix.add(confusionMatrixList.get(i));
			}
//			weka.Matrix kann man leider nicht automatisch auf ConfusionMatrix umschreiben
			String[] tmpMatrixLabels = new String[confusionMatrixList.get(0).numColumns()];
			for(int i=0; i<tmpMatrixLabels.length;i++){
				tmpMatrixLabels[i] = confusionMatrixList.get(0).className(i);
			}
			tmpSumConfMatrix = new ConfusionMatrix(tmpMatrixLabels);
			for(int j=0;j<tmpMatrix.getRow(0).length;j++){
				tmpSumConfMatrix.setRow(j, tmpMatrix.getRow(j));
			}
		}
		return tmpSumConfMatrix;
	}
	
	/**
	 * 
	 * @param confusionMatrix
	 * @return Eine 2x2 Confusionsmatrix
	 */
	public static ConfusionMatrix doMicroAveraging(ConfusionMatrix confusionMatrix)
	{
		ArrayList<ConfusionMatrix> twoClassStatsList = new ArrayList<ConfusionMatrix>();
		
		for(int i=0; i < confusionMatrix.numRows(); i++)
		{
//			F�r jede Klasse wird eine 2x2 Matrix errechnet
			TwoClassStats tmpTCS = confusionMatrix.getTwoClassStats(i);
			twoClassStatsList.add(tmpTCS.getConfusionMatrix());
		}
//		Die Matizen werden aufsummiert 
		ConfusionMatrix sumOfTwoClassStatsList = getSumOfConfusionMatrices(twoClassStatsList);
		return sumOfTwoClassStatsList;
	}
}
