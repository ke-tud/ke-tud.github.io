package LPCforSOS.evaluation.results;

import java.util.ArrayList;

import LPCforSOS.evaluation.losses.AUCLoss;
import LPCforSOS.evaluation.losses.ErrSetSizeLoss;
import LPCforSOS.evaluation.losses.IMultilabelRankingLossFunction;
import LPCforSOS.evaluation.losses.IsErrLoss;
import LPCforSOS.evaluation.losses.MarginLoss;

/**
 * @author George-P. C.F.
 * 
 */
public class MultiLabelFoldResult extends AFoldResult {

	private ArrayList<IMultilabelRankingLossFunction> losses;
	private ArrayList<ArrayList<String>> listOfdescendingRankingOfAllLabelsPerInstance;
	

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.AEvalResult#evaluateExtension()
	 */
	@Override
	protected void addLosses() {
		losses = new ArrayList<IMultilabelRankingLossFunction>();
		
		losses.add(new AUCLoss());
		losses.add(new ErrSetSizeLoss());
		losses.add(new IsErrLoss());
		losses.add(new MarginLoss());
	}

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.AEvalResult#evaluate()
	 */
	@Override
	public void evaluate() {
		listOfdescendingRankingOfAllLabelsPerInstance = new ArrayList<ArrayList<String>>();
		
//		Wir m�ssen die labels absteigend sortieren
		for(double[] vote : voteVector)
		{
			ArrayList<String> listOfDescendingSortedVote = new ArrayList<String>();
			double[] ascendingSortedVote = vote.clone();
			java.util.Arrays.sort(ascendingSortedVote);
			
//			In der openList werden die Indizes von allen Labels gespeichert die noch nicht gefunden wurden.
//			Diese Liste garantiert dass von 2 Labels mit dem gleichen Vote auch beide in die Liste 
//			aufgenommen werden, und nicht nur das erst gefundene. Au�erdem ist es schneller.
			ArrayList<Integer> openList = new ArrayList<Integer>();
			for(int j = 0; j < this.allLabels.size(); j++){
				openList.add(j);
			}
			
			for(int i = 0; i < ascendingSortedVote.length; i++){
				for(Integer j : openList){
					if(ascendingSortedVote[i] == vote[j]){
						listOfDescendingSortedVote.add(0, this.allLabels.get(j));
						openList.remove(j);
						break;
					}
				}
			}
			
			this.listOfdescendingRankingOfAllLabelsPerInstance.add(listOfDescendingSortedVote);
		}
		
		for(IMultilabelRankingLossFunction lossFunction : losses){
			String lossNamePlusPackage = lossFunction.getClass().getName();
			
			double sumOfLossResults = 0.00;
			
			for(int i = 0; i < numOfInstances; i++){
				sumOfLossResults += lossFunction.calculateLossFunction(this.relevantLabels.get(i), this.listOfdescendingRankingOfAllLabelsPerInstance.get(i));
			}
			
			double lossResult = sumOfLossResults / numOfInstances;
			this.lossResults.put(lossNamePlusPackage, lossResult);
		}
		
	}
	
	public String toString() {
		String result = "";

		result += super.toString();
		
		return result;
	}
}
