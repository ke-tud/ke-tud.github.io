package LPCforSOS.dataStructure;

import weka.core.FastVector;

/**
 * @author Jens Huehn (MR), Sandra Ebert (DA)
 *
 * @date  05.12.2007, 17:39:33
 */
public class ClassContainer {
  FastVector m_classes;
  
  public ClassContainer(){
    m_classes = new FastVector(2);
  }
  
  public void addClass(String classString){
    m_classes.addElement(classString);
  }
  
  public String getClassString(int i){
    return (String) m_classes.elementAt(i);
  }
  
  
}
