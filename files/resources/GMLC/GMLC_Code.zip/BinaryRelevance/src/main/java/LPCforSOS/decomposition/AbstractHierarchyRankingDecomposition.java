package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstances;

public abstract class AbstractHierarchyRankingDecomposition implements
		PairwiseDecomposition {

	protected final PairwiseDecomposer decomposer;

	public AbstractHierarchyRankingDecomposition(PairwiseDecomposer decomposer) {
		this.decomposer = decomposer;
	}

	protected ArrayList<ArrayList<Integer>> buildWay(ExtInstances data,
			HashMap<String, Integer> classToNumber) {
		ArrayList<ArrayList<Integer>> ways = new ArrayList<ArrayList<Integer>>();
		int[] parents = new int[classToNumber.size()];
		for (int i = 0; i < parents.length; i++)
			parents[i] = -1;

		ArrayList<String> classInformation = data.getClassInformation();

		for (String info : classInformation) {
			if (info.contains("<")) {
				String[] values = info.split("<");
				parents[classToNumber.get(values[1])] = classToNumber
						.get(values[0]);
			}
		}
		for (int i = 0; i < parents.length; i++) {
			ArrayList<Integer> way = new ArrayList<Integer>();
			way.add(i);
			int newItem = parents[i];
			while (newItem != -1) {
				way.add(newItem);
				newItem = parents[newItem];
			}
			ways.add(way);
		}
		return ways;
	}

	protected ArrayList<ArrayList<Integer>> buildCompareList(ExtInstances data,
			ArrayList<ArrayList<Integer>> ways,
			HashMap<Integer, String> numberToClass, boolean justLeaves) {
		ArrayList<ArrayList<Integer>> compareList = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < this.decomposer.getClassToNumber().size(); i++) {
			String class1 = numberToClass.get(i);
			ArrayList<Integer> newEntries = new ArrayList<Integer>();
			for (int j = 0; j < numberToClass.size(); j++) {
				String class2 = numberToClass.get(j);
				if (data.getClassInformation().contains(class1 + "!" + class2)
						|| data.getClassInformation().contains(
								class2 + "!" + class1)) {
					newEntries.add(0);
					continue;
				}

				if (justLeaves
						&& (this.isSuperNode(i, ways) || this.isSuperNode(j,
								ways))) {
					newEntries.add(0);
					continue;
				}
				// Schnittmenge bilden, Anahl verbliebende Elemente...
				ArrayList<Integer> cloneA = (ArrayList<Integer>) ways.get(i)
						.clone();
				ArrayList<Integer> cloneB = (ArrayList<Integer>) ways.get(j)
						.clone();
				cloneA.retainAll(cloneB);
				newEntries.add(cloneA.size());
			}
			compareList.add(newEntries);
		}
		return compareList;
	}

	protected void buildInstances(ExtInstances data,
			HashMap<Integer, String> numberToClass,
			ArrayList<ArrayList<Integer>> ways, boolean justLeaves) {
		List<String> theClasses = data.getClasses();
		for (int i = 0; i < theClasses.size() - 1; i++) {
			String class1 = numberToClass.get(i);
			for (int j = i + 1; j < theClasses.size(); j++) {
				String class2 = numberToClass.get(j);

				if (justLeaves
						&& (isSuperNode(i, ways) || isSuperNode(j, ways)))
					continue;

				if (data.getClassInformation().contains(class1 + "!" + class2)
						|| data.getClassInformation().contains(
								class2 + "!" + class1))
					continue;

				FastVector attributeValues = new FastVector();
				attributeValues.addElement(class1);
				attributeValues.addElement(class2);

				FastVector attributes = (FastVector) data.get_Attributes()
						.copyElements();
				attributes.addElement(new Attribute("class", attributeValues));
				String sub_relation = data.relationName() + "_" + class1
						+ "_vs_" + class2;
				Instances sub_Instances = new Instances(sub_relation,
						attributes, 100);
				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				this.decomposer.getDecomposedDatasets().add(sub_Instances);
			}
		}
	}

	private boolean isSuperNode(int index, ArrayList<ArrayList<Integer>> ways) {
		for (ArrayList<Integer> newWay : ways) {
			if (newWay.get(0) == index)
				continue;
			if (newWay.contains(index))
				return true;
		}
		return false;
	}
}
