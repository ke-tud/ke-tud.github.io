package LPCforSOS;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;

import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ClassContainer;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.decomposition.Decomposer;
import LPCforSOS.decomposition.PairwiseDecomposer;
import LPCforSOS.evaluation.StructuredEvaluation;
import LPCforSOS.structuredPrediction.StructuredPredictor;
import weka.classifiers.Evaluation;

/**
 * 29.01.10 : Diese Datei ist veraltet! 
 * @author Jens Huehn (MR), Sandra Ebert (DA)
 * 
 * @date 05.12.2007, 17:36:33
 */
public class LPCSOSFramework {
	ExtInstances m_data;
	ClassContainer m_classContainer;

	Decomposer m_dec;
	DecomposedDatasetLearner m_learner;
	StructuredPredictor m_pred;
	StructuredEvaluation m_eval;

	int m_seed;

	/**
	 * @param data
	 *            ExtInstances
	 * @param dec
	 *            Decomposer
	 * @param learner
	 *            DecomposedDatasetLearner
	 * @param pred
	 *            StructuredPredictor
	 * @param eval
	 *            StructuredEvaluation
	 */
	public LPCSOSFramework(ExtInstances data, Decomposer dec,
			DecomposedDatasetLearner learner, StructuredPredictor pred,
			StructuredEvaluation eval) {

		m_data = data;
		m_dec = dec;
		m_learner = learner;
		m_pred = pred;
		m_eval = eval;

	}

	/**
	 * @param data
	 */
	public LPCSOSFramework(ExtInstances data) {

		this.m_data = data;
	}

	/**
	 * TODO: Cross validation
	 * 
	 * @param folds
	 * @param loops
	 * @throws Exception
	 */
	public void crossValidate(int folds, int loops) throws Exception {
		Evaluation eval = new Evaluation(m_dec.getDecomposedDatasets().get(0));
		System.out.println();
	}

	/**
	 * TODO: Splits data into split% training and 1-split% testing data.
	 * Validation upon models build from the training data with the testing
	 * data.
	 * 
	 * @param split
	 * @param loops
	 */
	public void splitValidate(double split, int loops) {
	};

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Reader r = null;
//			r = new BufferedReader(new FileReader("src/LPCforSOS/yeast.earff"));
			r = new BufferedReader(new FileReader("datasets/yeast.earff"));

			ExtInstances data = new ExtInstances(r);
			// System.out.println(data.toSummaryString());

			LPCSOSFramework lpc = new LPCSOSFramework(data);
			PairwiseDecomposer m_dec = new PairwiseDecomposer();
			m_dec.buildDecomposedDatasets(data);

		} catch (Exception ex) {
			ex.printStackTrace();
			System.err.println(ex.getMessage());
		}
	}

}
