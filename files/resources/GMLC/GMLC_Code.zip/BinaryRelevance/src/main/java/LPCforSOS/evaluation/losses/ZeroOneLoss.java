/**
 * 
 */
package LPCforSOS.evaluation.losses;

import weka.classifiers.evaluation.ConfusionMatrix;

/**
 * @author Christian Brinker
 *
 */
public class ZeroOneLoss implements OMConfusionMatrixBasedLossFunction {
	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.OMConfusionMatrixBasedLossFunction#calculateLoss(weka.classifiers.evaluation.ConfusionMatrix, int)
	 */
	@Override
	@SuppressWarnings("deprecation")
	public double calculateLoss(ConfusionMatrix matrix, int numOfLabels){		
		double loss = 0.0D;
		int sum = 0;
		for (int i = 0; i < matrix.numRows(); i++) {
			for (int j = 0; j < matrix.numColumns(); j++) {
				double element = matrix.getElement(i, j);
				sum += element;
				if(i!=j) loss += element;
			}
		}
		return loss / sum;
	}
}
