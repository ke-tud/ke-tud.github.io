package LPCforSOS.evaluation.losses;

import java.util.List;
/**
 * Calculate the Margin-Measure. 
 * This is defined as<p>
 * <pre>
 * | (rank of first irrelevant label) - (rank of last relevant label) |
 * </pre>
 * 
 * @author George-P. C.F.
 *  
 */
public class MarginLoss implements IMultilabelRankingLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(List<String> realLabelsOfInstance,
			List<String> descendingRankingOfAllLabels) 
	{
		double result = 0.00;
		
		if(realLabelsOfInstance.isEmpty()) return result;
		
		int rankOfLastRelevantLabel = 0;
		for(int i = descendingRankingOfAllLabels.size() - 1; i > 0; i--){
			if(realLabelsOfInstance.contains(descendingRankingOfAllLabels.get(i))){
				rankOfLastRelevantLabel = i;
			}
		}
		
		int rankOfFirstIrrelevantLabel = 0;
		for(String rankedLabel : descendingRankingOfAllLabels){
			if(!realLabelsOfInstance.contains(rankedLabel)){
				rankOfFirstIrrelevantLabel = descendingRankingOfAllLabels.indexOf(rankedLabel);
			}
		}
		
		int margin = (rankOfFirstIrrelevantLabel - rankOfLastRelevantLabel);
		if(margin >= 0){
			return margin;
		}
			
		return result;
	}
}