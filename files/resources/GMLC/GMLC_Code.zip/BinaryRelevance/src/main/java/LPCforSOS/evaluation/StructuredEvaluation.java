package LPCforSOS.evaluation;

import weka.core.FastVector;

/**
 * @author Jens Huehn (MR)
 *
 * @date  05.12.2007, 17:38:56
 */
public abstract class StructuredEvaluation {

  /**
   * Compares a prediction with the original class (-structure). Returns a double value [0,1] reaching from false to true.
   * The FastVector classesValue should be given as a reference from the original FastVector such that it can be updated,
   * if the predicted classValue is not in the container with the known classes (ClassContainer).
   * @param prediction
   * @param correctClass
   * @param classesValues
   * @return The correctness of the prediction between [0,1]
   */
  public abstract double compare(String prediction, int correctClass, FastVector classesValues);
  
}
