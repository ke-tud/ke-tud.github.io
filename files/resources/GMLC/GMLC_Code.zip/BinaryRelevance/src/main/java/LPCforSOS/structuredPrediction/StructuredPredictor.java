package LPCforSOS.structuredPrediction;

import java.util.ArrayList;

import weka.core.Instances;
import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.evaluation.Result;

/**
 * @author Jens Huehn (MR)
 * 
 * @date 05.12.2007, 17:39:15
 */
public abstract class StructuredPredictor {

	protected Result results;
	protected ArrayList<double[]> voteVector;

	public void initialize() {
		voteVector = new ArrayList<double[]>();
	}

	/**
	 * @return the voteVector
	 */
	public ArrayList<double[]> getVoteVector() {
		return voteVector;
	}

	/**
	 * return the class of aggregation type
	 * 
	 * @param results
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * @throws ClassNotFoundException
	 */
	public static StructuredPredictor forName(Result results)
			throws InstantiationException, IllegalAccessException,
			ClassNotFoundException {

		String className = "LPCforSOS.structuredPrediction."
				+ results.getAggregationType().toString();

		Class<?> obj = Class.forName(className);
		StructuredPredictor pred = (StructuredPredictor) obj.newInstance();
		pred.results = results;

		return pred;
	}

	/**
	 * 
	 * @param test - The set of instances for classification
	 * @param learner - Holds the classifier
	 * @param trainingSet - The set of instances used for training the Classifier
	 */
	public abstract void classifyInstances(Instances test,
			DecomposedDatasetLearner learner,
			ExtInstances trainingSet) throws Exception;

	/**
	 * @return the results
	 */
	public Result getResults() {
		return results;
	}

	/**
	 * @param results
	 *            the results to set
	 */
	public void setResults(Result results) {
		this.results = results;
	}

	/**
	 * @param voting
	 * @return
	 */
	protected int maximum(double[] voting) {
		double max = 0;
		int realClass = 0;
		for (int i = 0; i < voting.length; i++) {
			if (voting[i] > max) {
				max = voting[i];
				realClass = i;
			}
		}
		return realClass + 1;
	}
}
