package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.List;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.evaluation.Configuration;

/**
 * 
 * @author Marian
 */
public class CalibratedLabelRanking implements PairwiseDecomposition {

	private PairwiseDecomposer decomposer;

	public CalibratedLabelRanking(PairwiseDecomposer decomposer) {
		this.decomposer = decomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		int counter = 0;
		double value = 0.0;
		int iter = 0;

		int numOfClasses = data.getNumberOfClasses();
		int numOfClassesPlusCaliLabel = numOfClasses + 1;

		// Einf�gen des Calibrationlabels ans Ende der Liste aller Klassen
		List<String> classesPlusCaliLabel = new ArrayList<String>(
				data.getClasses());
		classesPlusCaliLabel.add(Configuration.getCalibrationLabel());

		// mapping string of class to number
		// Mit dem setzen in die classToNumber HashMap wird das Calibrationlabel
		// auch f�r den Lerner und Klassifizierer �bernommen.
		for (int i = 0; i < numOfClassesPlusCaliLabel; i++) {
			this.decomposer.getClassToNumber().put(classesPlusCaliLabel.get(i),
					i);
		}

		for (int i = 0; i < numOfClassesPlusCaliLabel; i++) {
			String label1 = classesPlusCaliLabel.get(i);

			// if asymmetric learner -> double round robin -> 1 vs. 2 unequal 2
			// vs. 1
			int startIdx = 0;
			if (this.decomposer.isSymmetric()) {
				startIdx = i + 1;
			}

			for (int j = startIdx; j < numOfClassesPlusCaliLabel; j++) {
				if (i == j) {
					continue;
				}

				String label2 = classesPlusCaliLabel.get(j);

				// new nominal attribute for class with the two classes
				FastVector attributeValues = new FastVector();
				attributeValues.addElement(label1);
				attributeValues.addElement(label2);

				FastVector attributes = (FastVector) data.get_Attributes()
						.copyElements();
				attributes.addElement(new Attribute("class", attributeValues));

				String sub_relation = data.relationName() + "_" + label1
						+ "_vs_" + label2;
				Instances sub_Instances = new Instances(sub_relation,
						attributes, 100);

				// naive approach
				for (ExtInstance extInstance : data.get_Instances()) {

					// weka coding of nominal attributes
					// -1 zeigt an das Instanz nicht zu gebrauchen ist.
					int label = -1;

					if (label1 == Configuration.getCalibrationLabel()
							&& !extInstance.getM_Classes().contains(label2)) {

						label = 0;
					} else if (label2 == Configuration.getCalibrationLabel()
							&& !extInstance.getM_Classes().contains(label1)) {

						label = 1;
					} else
					// only instance with one of the two classes, all other
					// records are omitted
					if (extInstance.getM_Classes().contains(label1)
							^ extInstance.getM_Classes().contains(label2)) {

						label = extInstance.getM_Classes().contains(label1) ? 0
								: 1;
					}

					if (!(label < 0)) {
						ExtInstance instance = (ExtInstance) extInstance.copy();
						instance.setValue(extInstance.asWekaInstance()
								.numAttributes() - 1, label);

						// appends the new instance with new class value
						sub_Instances.add(instance);
						instance.asWekaInstance().setDataset(sub_Instances);
					}
					iter++;
				}
				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				this.decomposer.getDecomposedDatasets().add(sub_Instances);
				value += sub_Instances.numInstances();
				counter++;
			}
		}
		System.out.println(iter + " Iterationen, " + counter + " learner");
	}

	public void setDecomposer(PairwiseDecomposer decomposer) {
		this.decomposer = decomposer;
	}

}
