package LPCforSOS.evaluation.losses;

import weka.classifiers.evaluation.ConfusionMatrix;

public interface OMConfusionMatrixBasedLossFunction {

	@SuppressWarnings("deprecation")
	public abstract double calculateLoss(ConfusionMatrix matrix, int numOfLabels);

}