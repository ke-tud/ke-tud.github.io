package LPCforSOS.decomposition;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;

public class MultiLabelDecomposition implements PairwiseDecomposition {

	private final PairwiseDecomposer decomposer;

	public MultiLabelDecomposition(PairwiseDecomposer decomposer) {
		this.decomposer = decomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		int counter = 0;
		double value = 0.0;
		int iter = 0;

		// mapping class to integer
		for (int i = 0; i < data.getClasses().size(); i++) {
			this.decomposer.getClassToNumber().put(data.getClasses().get(i), i);
		}

		// ArrayList<ArrayList<Integer>> listOfClassIndices =
		// buildClassList(data.get_Instances());

		for (int i = 0; i < data.getNumberOfClasses(); i++) {
			String label1 = data.getClasses().get(i);

			// if asymmetric learner -> double round robin -> 1 vs. 2 unequal 2
			// vs. 1
			int startIdx = 0;
			if (this.decomposer.isSymmetric()) {
				startIdx = i + 1;
			}

			for (int j = startIdx; j < data.getNumberOfClasses(); j++) {
				if (i == j) {
					continue;
				}

				String label2 = data.getClasses().get(j);

				// new nominal attribute for class with the two classes
				FastVector attributeValues = new FastVector();
				attributeValues.addElement(label1);
				attributeValues.addElement(label2);

				FastVector attributes = (FastVector) data.get_Attributes()
						.copyElements();
				attributes.addElement(new Attribute("class", attributeValues));

				String sub_relation = data.relationName() + "_" + label1
						+ "_vs_" + label2;
				Instances sub_Instances = new Instances(sub_relation,
						attributes, 100);

				// naive approach
				for (ExtInstance extInstance : data.get_Instances()) {

					// only instance with one of the two classes, all other
					// records are omitted
					if (extInstance.getM_Classes().contains(label1)
							^ extInstance.getM_Classes().contains(label2)) {

						ExtInstance instance = (ExtInstance) extInstance.copy();

						// weka coding of nominal attributes
						int label = extInstance.getM_Classes().contains(label1) ? 0
								: 1;

						instance.setValue(extInstance.asWekaInstance()
								.numAttributes() - 1, label);

						// appends the new instance with new class value
						sub_Instances.add(instance);
						instance.asWekaInstance().setDataset(sub_Instances);
					}
					iter++;
				}
				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				this.decomposer.getDecomposedDatasets().add(sub_Instances);
				value += sub_Instances.numInstances();
				counter++;
			}
		}
		System.out.println(iter + " Iterationen, " + counter + " learner");
	}

}
