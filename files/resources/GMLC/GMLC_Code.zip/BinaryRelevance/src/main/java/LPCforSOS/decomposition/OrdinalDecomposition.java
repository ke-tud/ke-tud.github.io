package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;

public class OrdinalDecomposition implements PairwiseDecomposition {

	private final PairwiseDecomposer decomposer;

	public OrdinalDecomposition(PairwiseDecomposer decomposer) {
		this.decomposer = decomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		// PARK NOTES:
		// - Es wird vorausgesetzt, dass die Klassenaufzaehlung im Header
		// sortiert sind, aufsteigend oder absteigend
		// - in ranking werden alle Klassen abgespeichert
		// - ordinalStorage beeinhaltet spaeter alle decomposed Datensaetze

		// need to know internal the ranking of the different class values
		HashMap<String, Integer> ranking = new HashMap<String, Integer>();
		// retrieving the different classes by ordinal structure
		ArrayList<ArrayList<Instances>> ordinalStorage = new ArrayList<ArrayList<Instances>>();

		for (int i = 0; i < data.getClasses().size(); i++) {
			ranking.put(data.getClasses().get(i), i);
			ordinalStorage.add(new ArrayList<Instances>());
		}

		int toNumber = 0;
		List<String> theClasses = data.getClasses();
		// in der folgenden Schleife werden die Headerinformationen für die
		// decomposed Daten
		// erzeugt in ordinalStorage eingefuegt
		for (int i = 0; i < (theClasses.size() - 1); i++) {
			String lhs = theClasses.get(i);
			for (int j = i + 1; j < theClasses.size(); j++) {
				String rhs = theClasses.get(j);
				this.decomposer.getClassToNumber().put(lhs + "<" + rhs,
						toNumber);
				toNumber++;
				this.decomposer.getClassToNumber().put(rhs + "<" + lhs,
						toNumber);
				toNumber++;

				// new nominal attribute for class with the two classes
				FastVector attributeValues = new FastVector();
				attributeValues.addElement(lhs + "<" + rhs);
				attributeValues.addElement(rhs + "<" + lhs);

				FastVector attributes = (FastVector) data.get_Attributes()
						.copyElements();
				attributes.addElement(new Attribute("class", attributeValues));

				String sub_relation = data.relationName() + "_" + lhs + "_vs_"
						+ rhs;
				Instances sub_Instances = new Instances(sub_relation,
						attributes, 100);

				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				this.decomposer.getDecomposedDatasets().add(sub_Instances);

				int indexToInsert = ranking.get(rhs);
				ordinalStorage.get(indexToInsert).add(sub_Instances);
			}
		}
		// here, the actual decomposed datasets are generated
		for (ExtInstance ext_instance : data.get_Instances()) {
			String attrib = ext_instance.getM_Classes().get(0);
			int lastPosIndex = ranking.get(attrib);

			for (int i = 0; i < ordinalStorage.size(); i++) {
				for (int j = 0; j < ordinalStorage.get(i).size(); j++) {
					Instances instances = ordinalStorage.get(i).get(j);
					double[] attValue = ext_instance.getM_AttValues();
					// hier ist ein Fehler. Momentan besitzen alle paarweisen
					// Klassifizierer alle Instanzen
					// das gilt nicht immer. Beispiel: 2 vs 4, instanzen der
					// klasse 3 werden hierbei garnicht benutzt
					// momentan: falls instanz < lhs (oder so ähnlich) des
					// aktuell betrachteten Klassifizierers adde als positiv
					// ansonsten negativ
					int entryIndex = i < (lastPosIndex + 1) ? 0 : 1;

					ExtInstance instance = (ExtInstance) ext_instance.copy();
					instance.setValue(ext_instance.asWekaInstance()
							.numAttributes() - 1, entryIndex);
					instances.add(instance);
					instance.asWekaInstance().setDataset(instances);
				}
			}
		}
	}

}
