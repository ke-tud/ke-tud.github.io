/**
 * 
 */
package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Calculate the true positive rate. 
 * This is defined as<p>
 * <pre>
 * correctly classified positives
 * ------------------------------
 *       total positives
 * </pre>
 *
 * @author George-P. C.F.
 *
 */
public class TpRate implements IConfusionMatrixBasedLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelCalibratedLabelRankingLossFunction#calculateLossFunction(LPCforSOS.evaluation.losses.TwoClassConfusionMatrix)
	 */
	@Override
	public double calculateLossFunction(TwoClassConfusionMatrix confusionMatrix) {
		return confusionMatrix.getTruePositiveRate();
	}

}
