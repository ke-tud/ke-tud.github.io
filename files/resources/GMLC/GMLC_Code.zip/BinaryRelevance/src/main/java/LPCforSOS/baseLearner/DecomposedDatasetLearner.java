package LPCforSOS.baseLearner;

import java.util.ArrayList;
import java.util.HashMap;

import LPCforSOS.dataStructure.Models;
import weka.classifiers.Classifier;
import weka.core.Instances;

/**
 * @author Jens Huehn (MR)
 * 
 * @date 05.12.2007, 17:38:21
 */
public abstract class DecomposedDatasetLearner {

	protected ArrayList<Classifier> baseClassifier;
	protected HashMap<String, Integer> classToNumber;
	private ArrayList<Instances> decomposedDatasets;

	/**
	 * @param classifierName
	 * @param evaluateBaseClassifiers
	 * @throws Exception
	 */
	public abstract void buildClassifiers(String classifierName) throws Exception;

	/**
	 * saves the base classifiers
	 * 
	 * @param model
	 */
	public abstract void saveClassifiers(Models model);

	/**
	 * load the base classifiers
	 * 
	 * @param model
	 */
	public abstract void loadClassifiers(Models model);

	/**
	 * Creates a new instance of a base classifier given it's base learning
	 * environment (Weka, SeCo)
	 * 
	 * @param baseLearnerEnv
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * 
	 * @throws Exception
	 * 
	 */
	public static DecomposedDatasetLearner forName(
			BaseLearnerEnvironment baseLearnerEnv)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {

		String className = "LPCforSOS.baseLearner." + baseLearnerEnv.toString();

		Class<?> c = Class.forName(className);
		Object learner = c.newInstance();

		return (DecomposedDatasetLearner) learner;
	}

	/**
	 * @return the baseClassifier
	 */
	public ArrayList<Classifier> getBaseClassifier() {
		return baseClassifier;
	}

	/**
	 * @param baseClassifier
	 *            the baseClassifier to set
	 */
	public void setBaseClassifier(ArrayList<Classifier> baseClassifier) {
		this.baseClassifier = baseClassifier;
	}

	/**
	 * @param classToNumber
	 */
	public void setClassToNumber(HashMap<String, Integer> classToNumber) {
		this.classToNumber = classToNumber;
	}

	/**
	 * @return the classToNumber
	 */
	public HashMap<String, Integer> getClassToNumber() {
		return classToNumber;
	}

	/**
	 * @return the decomposedDatasets
	 */
	public ArrayList<Instances> getDecomposedDatasets() {
		return decomposedDatasets;
	}

	/**
	 * @param decomposedDatasets
	 *            the decomposedDatasets to set
	 */
	public void setDecomposedDatasets(ArrayList<Instances> decomposedDatasets) {
		this.decomposedDatasets = decomposedDatasets;
	}
}
