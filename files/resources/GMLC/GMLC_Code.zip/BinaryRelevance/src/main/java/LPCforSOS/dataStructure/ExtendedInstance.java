package LPCforSOS.dataStructure;

import java.util.ArrayList;
import java.util.List;

import weka.core.Copyable;
import weka.core.Instance;

public interface ExtendedInstance extends Copyable {
	public void setDataset(ExtInstances instances);
	public List<String> getM_Classes();
	public void setM_Classes(List<String> classes);
	
	/**
	 * Returns the array of attribute values for this instance. This method is
	 * deprecated and its use is discouraged because it is potentially expensive,
	 * e.g. a sparse instance has to create the array in the first place. An 
	 * implementation might also return a <b>copy</b> of the value array, which 
	 * might or might not be the desired result.
	 * @return array of attribute values for this instance
	 * @deprecated
	 */
	@Deprecated public double[] getM_AttValues();
	
	//TODO Find better method names
	public ArrayList<String> getLabelRankingTotalOrderOfLabels();
	public void setLabelRankingTotalOrderOfLabels(ArrayList<String> totalOrder);
	
	/**
	 * This method provides interface to Weka instance format. It is up to 
	 * the implementing class to either subclass <code>weka.core.Instance</code> or
	 * to have it as a (private) field. If the class doesn't offer an interface to Weka
	 * (e.g. because its data representation is incompatible), it should throw an 
	 * {@code UnsupportedOperationException}.
	 * @return an instance of {@link weka.core.Instance} (or a subclass) corresponding to 
	 * this instance
	 */
	public Instance asWekaInstance();
	public void setInnerInstance(Instance mInnerInstance);
	
	public double weight();
}
