package LPCforSOS.evaluation.results;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Diese Klasse beinhaltet alle Daten die zur Evaluation des einzelnen Folds
 * n�tig sind.
 * 
 * @author George-P. C.F.
 * 
 */
public abstract class AFoldResult {

	protected long foldTime = 0;
	protected List<String> allLabels = null;
	protected List<String> votedStrings = null;
	protected List<List<String>> relevantLabels = null;
	protected List<double[]> voteVector = null;
	protected int numOfInstances = 0;
	protected List<List<String>> totalOrderOfLabels = null;

	protected LinkedHashMap<String, Double> lossResults;

	/**
	 * Es wird die Methode addLosses() aufgerufen.
	 */
	public AFoldResult() {
		this.lossResults = new LinkedHashMap<String, Double>();

		addLosses();
	}

	/**
	 * In dieser Methode werden die Daten f�r die Losses ausgewertet. Die
	 * Methode configure() muss zuerst ausgef�hrt werden.
	 */
	public abstract void evaluate();

	/**
	 * Mit dieser Methode werden alle Daten auf das Objekt �bertragen. Es wird
	 * nichts ausgewertet, nur abgespeichert. Die Auswertung geschieht erst mit
	 * der Ausf�hrung der Methode evaluate().
	 * 
	 * @param allLabels
	 * @param votedStrings
	 * @param relevantLabels
	 * @param voteVector
	 * @param numOfInstances
	 * @param totalOrderOfLabels
	 */
	public void configure(List<String> allLabels,
			List<String> votedStrings,
			List<List<String>> relevantLabels,
			List<double[]> voteVector, int numOfInstances,
			List<List<String>> totalOrderOfLabels) {
		this.allLabels = allLabels;
		this.votedStrings = votedStrings;
		this.relevantLabels = relevantLabels;
		this.voteVector = voteVector;
		this.numOfInstances = numOfInstances;
		this.totalOrderOfLabels = totalOrderOfLabels;
	}

	/**
	 * Hier k�nnen die verschiedenen Metriken aus dem Package Losses
	 * hinzugef�gt werden. Die Methode wird von Standardkonstruktor aus
	 * aufgerufen.
	 */
	protected abstract void addLosses();

	/**
	 * Diese Methode gibt die Position des gr��ten Wertes im �bergebenen
	 * Array zur�ck. Beginnend bei Position 0.
	 * 
	 * @param voting
	 * @return
	 */
	protected static int maximum(double[] voting) {
		double max = 0;
		int realClass = 0;
		for (int i = 0; i < voting.length; i++) {
			if (voting[i] > max) {
				max = voting[i];
				realClass = i;
			}
		}
		return realClass;
	}

	/**
	 * Sortiert eine Liste von votes nach der H�ufigkeit ihres auftretens im
	 * einzelnen Array aufsteigend. Die Positionen der H�ufigkeiten in den
	 * �bergebenen Doublearrays m�ssen den Positionen der Labels in der
	 * �bergebenen Stringliste entsprechen.
	 * 
	 * @param votesToSort
	 * @return Eine nach der H�ufigkeit aufsteigend sortierte Liste von
	 *         Labels.
	 */
	protected static List<List<String>> sortVotesAscending(
			List<double[]> votesToSort, List<String> allLabels) {

		List<List<String>> listOfAscendingRankingOfAllLabelsPerInstance = new ArrayList<List<String>>();

		for (double[] vote : votesToSort) {
			ArrayList<String> listOfAscendingSortedVote = new ArrayList<String>();
			double[] ascendingSortedVote = vote.clone();
			java.util.Arrays.sort(ascendingSortedVote);

			// In der openList werden die Indizes von allen Labels gespeichert
			// die noch nicht gefunden wurden.
			// Diese Liste garantiert dass von 2 Labels mit dem gleichen Vote
			// auch beide in die Liste
			// aufgenommen werden, und nicht nur das erst gefundene. Au�erdem
			// ist es schneller.
			ArrayList<Integer> openList = new ArrayList<Integer>();
			for (int j = 0; j < allLabels.size(); j++) {
				openList.add(j);
			}

			for (int i = 0; i < ascendingSortedVote.length; i++) {
				for (Integer j : openList) {
					if (ascendingSortedVote[i] == vote[j]) {
						listOfAscendingSortedVote.add(allLabels.get(j));
						openList.remove(j);
						break;
					}
				}
			}

			listOfAscendingRankingOfAllLabelsPerInstance
					.add(listOfAscendingSortedVote);
		}
		return listOfAscendingRankingOfAllLabelsPerInstance;
	}

	/**
	 * @return the foldTime
	 */
	public long getFoldTime() {
		return foldTime;
	}

	/**
	 * @param foldTime
	 *            the foldTime to set
	 */
	public void setFoldTime(long foldTime) {
		this.foldTime = foldTime;
	}

	/**
	 * @return the lossResults
	 */
	public HashMap<String, Double> getLossResults() {
		return lossResults;
	}

	@Override
	public String toString() {
		String result = "";

		result += "Fold Computation Time: " + this.foldTime + " ms \n";
		;
		result += "Number of instances: " + this.numOfInstances + "\n";
		;

		result += "\n";
		result += "=== Losses: ================ \n";
		for (String lossNamePlusPackage : lossResults.keySet()) {
			String[] splittedLossName = lossNamePlusPackage.split("\\.");
			String lossName = lossNamePlusPackage;

			if (splittedLossName.length - 1 >= 0) {
				lossName = splittedLossName[splittedLossName.length - 1];
			}

			result += String.format("%-20.25s", lossName) + " = ";
			result += lossResults.get(lossNamePlusPackage) + "\n";
		}

		//
		// result += "==== Losses: ==== \n";
		// for(LossFunction lossFunction : losses){
		// double dResult = 0;
		// for(int i=0;i<voting.size();i++){
		// double[] vote = this.voting.get(i);
		// ArrayList<Integer> labels = new
		// ArrayList<Integer>(realInstanceLabels.get(i).size());
		// for(int j=0; j<realInstanceLabels.get(i).size();j++){
		// labels.add(allLabels.indexOf(realInstanceLabels.get(i).get(j)));
		// }
		// dResult += lossFunction.calcLoss(vote,
		// rank2classID_ascendingRelevance, labels,
		// this.relevanceBounds.get(i));
		// }
		// dResult = dResult / voting.size();
		// String lossNamePlusPackage = lossFunction.getClass().getName();
		// String[] splittedLossName = lossNamePlusPackage.split("\\.");
		// String lossName = lossNamePlusPackage;
		// if(splittedLossName.length-1>=0){
		// lossName = splittedLossName[splittedLossName.length-1];
		// }
		// result += lossName + " = " + dResult + "\n";
		// }
		// result += "\n";

		return result;
	}
}
