package LPCforSOS.decomposition;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;

import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstances;

/**
 * @author Jens Huehn (MR)
 * 
 * @date 05.12.2007, 17:39:48
 */
public abstract class Decomposer {

	protected ArrayList<Instances> dec_Instances;
	protected ArrayList<ArrayList<String>> realClasses;
	protected HashMap<String, Integer> classToNumber;
	protected boolean isSymmetric;

	/**
	 * Creates a new instance of a decomposer given it's decomposition type
	 * 
	 * @param decompositionType
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 * 
	 * @throws Exception
	 * 
	 */
	public static Decomposer forName(DecompositionType decompositionType)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {

		String className = "LPCforSOS.decomposition."
				+ decompositionType.toString();

		Class<?> c = Class.forName(className);
		Object dec = c.newInstance();

		return (Decomposer) dec;
	}

	public void initialize() {
		dec_Instances = new ArrayList<Instances>();
		realClasses = new ArrayList<ArrayList<String>>();
		classToNumber = new HashMap<String, Integer>();
	}

	/**
	 * Spaltet die Daten entsprechend dem Typ auf.
	 * 
	 * @param data
	 */
	public abstract void buildDecomposedDatasets(ExtInstances data);

	/**
	 * Gibt Liste mit allen aufgespaltenen Lernproblemen zur�ck
	 * 
	 * @return dec_Instances
	 */
	public ArrayList<Instances> getDecomposedDatasets() {
		return dec_Instances;
	}

	/**
	 * Speichert Liste der aufgespaltenen Lernprobleme in einzelnen Dateien ab,
	 * so dass sie direkt in Weka eingelesen werden k�nnen
	 */
	public void saveDecomposedDatasets() {

		/**
		 * TODO: man k�nnte noch einen extra Ordner anlegen, worin alle
		 * Teilprobleme gespeichert werden
		 */
		// File directory = new File( "." ) ;
		// directory.mkdir();
		// directory.renameTo(new File("blahDir"));
		for (Instances m_Instances : dec_Instances) {

			String filename = m_Instances.relationName() + ".arff";
			Writer writer = null;

			try {
				writer = new FileWriter(filename);
				writeHeader(m_Instances, writer);
				writeData(m_Instances, writer);
			} catch (IOException e) {
				System.err.println("Konnte Datei nicht erstellen");
			} finally {
				if (writer != null)
					try {
						writer.close();
					} catch (IOException e) {
						System.err.println("Fehler beim Speichern der Datei");
					}

			}
		}
	}

	/**
	 * @param instances
	 * @param writer
	 */
	private void writeHeader(Instances instances, Writer writer) {

		try {
			writer.write("@relation " + instances.relationName() + "\n\n");

			for (int i = 0; i < instances.numAttributes(); i++) {
				String line = instances.attribute(i).toString() + "\n";
				writer.append(line);
			}

			writer.append("\n");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * @param instances
	 * @param writer
	 */
	private void writeData(Instances instances, Writer writer) {

		try {
			writer.append("@data\n");

			for (int i = 0; i < instances.numInstances(); i++) {
				writer.append(instances.instance(i).toString() + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Load all sub datasets in a list
	 * 
	 * @param filenameList
	 * @return list with decomposed datasets
	 * @throws IOException
	 */
	public ArrayList<Instances> loadDecomposedDatasets(
			ArrayList<String> filenameList) throws IOException {

		Reader r;
		ArrayList<Instances> list = new ArrayList<Instances>();

		try {
			for (String file : filenameList) {
				r = new BufferedReader(new FileReader(file));
				Instances data = new Instances(r);
				list.add(data);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}

	/**
	 * @return the realClasses
	 */
	public ArrayList<ArrayList<String>> getRealClasses() {
		return realClasses;
	}

	/**
	 * @param realClasses
	 *            the realClasses to set
	 */
	public void setRealClasses(ArrayList<ArrayList<String>> realClasses) {
		this.realClasses = realClasses;
	}

	/**
	 * @return the classToNumber
	 */
	public HashMap<String, Integer> getClassToNumber() {
		return classToNumber;
	}

	/**
	 * @param classToNumber
	 *            the classToNumber to set
	 */
	public void setClassToNumber(HashMap<String, Integer> classToNumber) {
		this.classToNumber = classToNumber;
	}

	/**
	 * @return the isSymmetric
	 */
	public boolean isSymmetric() {
		return isSymmetric;
	}

	/**
	 * @param isSymmetric
	 *            the isSymmetric to set
	 */
	public void setSymmetric(boolean isSymmetric) {
		this.isSymmetric = isSymmetric;
	}
}
