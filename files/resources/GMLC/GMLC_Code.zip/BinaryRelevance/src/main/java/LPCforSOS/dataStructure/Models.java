/**
 */
package LPCforSOS.dataStructure;

/**
 * @author Sandra Ebert
 *
 * @date  28.06.2008, 13:00:12
 */
public class Models {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
