package LPCforSOS.evaluation.losses;

import java.util.HashMap;
import java.util.List;

import LPCforSOS.evaluation.Configuration;

public class HorizontalHammingLoss implements IOMLossFuntion {

	@Override
	public double calculateLossFunction(List<List<String>> relevantLabels,
			List<HashMap<String, List<String>>> predictions,
			int numberOfLabels, int numberOfGrades) {
		int error = 0;

		for (int instance = 0; instance < predictions.size(); instance++) {
			HashMap<String, List<String>> predictionOfInstance = predictions
					.get(instance);
			
			for (String relevantLabel : relevantLabels.get(instance)) {
				int calibrationLabelGrade = parseGrade(relevantLabel) - 1;
				String calibrationLabel = Configuration
						.getCalibrationLabel(calibrationLabelGrade);

				if (!predictionOfInstance.get(calibrationLabel)
						.contains(parseClass(relevantLabel))) {
					error++;
				}
			}

			for (String calibrationLabel : predictionOfInstance.keySet()) {
				for (String label : predictionOfInstance.get(calibrationLabel)) {
					int newError = 1;
					for (String relevantLabel : relevantLabels.get(instance)) {
						if(parseClass(relevantLabel).equals(label) && parseGrade(relevantLabel) == parseGrade(calibrationLabel)){
							newError = 0;
						}
					}
					error += newError;
				}
			}

//			for (int grade = 0; grade < numberOfGrades; grade++) {
//				List<String> relevantWithGrade = getRelevantLabelsWithGrade(
//						relevantLabels, grade);
//				for (String label : relevantWithGrade) {
//					if (predictions.get(instance).contains(label))
//						error++;
//				}
//
//				for (String label : predictions.get(instance)) {
//					if (relevantWithGrade.contains(label))
//						error++;
//				}
//			}
		}
		return error;
	}

	private String parseClass(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}
}
