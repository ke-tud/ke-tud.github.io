/**
 * 
 */
package LPCforSOS.evaluation.results;

/**
 * @author George-P. C.F.
 *
 */
public class LabelRankingSinglePreferenceFoldResult extends LabelRankingPairwisePreferenceFoldResult{

	public LabelRankingSinglePreferenceFoldResult() {
		super();
	}

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.results.AEvalResult#evaluate()
	 */
	@Override
	public void evaluate() {
		listOfAscendingRankingOfAllLabelsPerInstance = sortVotesAscending(this.voteVector, this.allLabels);
		
		calculateLossResults();
	}
}
