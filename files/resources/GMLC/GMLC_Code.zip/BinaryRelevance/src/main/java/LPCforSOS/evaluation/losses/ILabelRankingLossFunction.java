/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.List;

/**
 * Dieses Interface wird von allen Klassen implementiert 
 * die Loss Funktionen f�r LabelRanking Klassifikations Probleme
 * implementieren.
 * 
 * @author George-P. C.F.
 */
public interface ILabelRankingLossFunction {

	/**
	 * Gibt den Fehler im Ranking je nach Funktion zurueck. 
	 * @param predictedOrderOfLabels Die Ordung von allen Labels die vom Klassifizierer bestimmt wurde.
	 * @param totalOrderOfLabels Die Ordung von allen Labels die im originalen Datensatz angegeben wurde. 
	 * @return double
	 */
	public double calculateLossFunction(List<String> predictedOrderOfLabels, List<String> totalOrderOfLabels);
}
