package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Dieses Interface wird von allen Klassen implementiert 
 * die Loss Funktionen f�r Multilabel Klassifikations Probleme
 * implementieren.
 * 
 * @author George-P. C.F.
 */
public interface IConfusionMatrixBasedLossFunction {
	/**
	 * Berechnung der Losses auf Basis einer 2x2 Konfusionsmatrix.
	 * 
	 * @return double
	 */
	public double calculateLossFunction(TwoClassConfusionMatrix confusionMatrix);
}
