package LPCforSOS.decomposition;

import LPCforSOS.dataStructure.ExtInstances;

public interface PairwiseDecomposition {

	public void decompose(ExtInstances data);
}
