/**
 * 
 */
package LPCforSOS.evaluation.results;

import java.util.ArrayList;
import java.util.List;

import LPCforSOS.evaluation.losses.ILabelRankingLossFunction;
import LPCforSOS.evaluation.losses.KendallsTauLoss;
import LPCforSOS.evaluation.losses.MeanSquaredErrorLoss;
import LPCforSOS.evaluation.losses.SpearmanRankCorrelationLoss;

/**
 * @author George-P. C.F.
 *
 */
public class LabelRankingPairwisePreferenceFoldResult extends AFoldResult{

	protected List<ILabelRankingLossFunction> losses;
	protected List<List<String>> listOfAscendingRankingOfAllLabelsPerInstance;
	
	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.results.AEvalResult#addLosses()
	 */
	@Override
	protected void addLosses() {
		losses = new ArrayList<ILabelRankingLossFunction>();
		
		losses.add(new KendallsTauLoss());
		losses.add(new MeanSquaredErrorLoss());
		losses.add(new SpearmanRankCorrelationLoss());
	}

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.results.AEvalResult#evaluate()
	 */
	@Override
	public void evaluate() 
	{
		ArrayList<double[]> listOfVotesForLabelsPerInstance = new ArrayList<double[]>();
		
		for(double[] voteForInstance : this.voteVector)
		{
			double[] votesForLabelsPerInstance = new double[this.allLabels.size()];
			
			for(int i = 0; i < voteForInstance.length ; i++)
			{
				double voteForPreference = voteForInstance[i];
				int indexOfLabel = 0;
				
				String[] splittedPairwisePreference = votedStrings.get(i).split("<");
//				Es treten beide Preferencen auf < und > 
				if(splittedPairwisePreference.length > 1)
				{
					indexOfLabel = allLabels.indexOf(splittedPairwisePreference[1]);
				} else	{
					splittedPairwisePreference = this.votedStrings.get(i).split(">");
					indexOfLabel = allLabels.indexOf(splittedPairwisePreference[0]);
				}
				votesForLabelsPerInstance[indexOfLabel] += voteForPreference;
			}
			listOfVotesForLabelsPerInstance.add(votesForLabelsPerInstance);
		}
		
		listOfAscendingRankingOfAllLabelsPerInstance = sortVotesAscending(listOfVotesForLabelsPerInstance, allLabels);
		
		calculateLossResults();
	}

	protected void calculateLossResults(){
		for(ILabelRankingLossFunction lossFunction : losses){
			String lossNamePlusPackage = lossFunction.getClass().getName();
			
			double sumOfLossResults = 0.00;
			
			for(int i = 0; i < numOfInstances; i++){
				sumOfLossResults += lossFunction.calculateLossFunction(listOfAscendingRankingOfAllLabelsPerInstance.get(i), this.totalOrderOfLabels.get(i));
			}
			
			double lossResult = sumOfLossResults / numOfInstances;
			this.lossResults.put(lossNamePlusPackage, lossResult);
		}
	}
	public String toString(){
		String result = "";
		
		result += super.toString();
		result += "\n";
		
		result += "=== Vote vs. Total Order ===";
		result += "\n";
		for(int i = 0; i < numOfInstances; i++){
			result += String.format("%-17.18s", "Instance Nr." + i);
			result += ": Ascending sorted vote: ";
			result += listOfAscendingRankingOfAllLabelsPerInstance.get(i);
			result += "\n";
			result += String.format("%42s", "Total order: "); 
			result += this.totalOrderOfLabels.get(i);
			result += "\n";
		}
		
		return result;
	}
}
