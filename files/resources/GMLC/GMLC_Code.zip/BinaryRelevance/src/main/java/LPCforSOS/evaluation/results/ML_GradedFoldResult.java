package LPCforSOS.evaluation.results;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import weka.classifiers.evaluation.ConfusionMatrix;
import LPCforSOS.dataStructure.ExtConfusionMatrix;
import LPCforSOS.dataStructure.TwoClassConfusionMatrix;
import LPCforSOS.evaluation.Configuration;
import LPCforSOS.evaluation.losses.AccuracyLoss;
import LPCforSOS.evaluation.losses.CIndex;
import LPCforSOS.evaluation.losses.F1Loss;
import LPCforSOS.evaluation.losses.FalloutLoss;
import LPCforSOS.evaluation.losses.FpRate;
import LPCforSOS.evaluation.losses.IConfusionMatrixBasedLossFunction;
import LPCforSOS.evaluation.losses.OMConfusionMatrixBasedLossFunction;
import LPCforSOS.evaluation.losses.OneErrorLoss;
import LPCforSOS.evaluation.losses.PrecisionLoss;
import LPCforSOS.evaluation.losses.RankLoss;
import LPCforSOS.evaluation.losses.RecallLoss;
import LPCforSOS.evaluation.losses.TpRate;
import LPCforSOS.evaluation.losses.VerticalHammingDistanceLoss;
import LPCforSOS.evaluation.losses.ZeroOneLoss;

public class ML_GradedFoldResult extends AFoldResult {

	private List<IConfusionMatrixBasedLossFunction> twoClassConfusionMatrixBasedlosses;
	private List<OMConfusionMatrixBasedLossFunction> confusionMatrixBasedLosses;
	private List<RankLoss> rankLosses;
	
	ConfusionMatrix sumOfConfusionMatricesOfAllInstances;
	private final List<HashMap<String, List<String>>> predictions = new ArrayList<HashMap<String, List<String>>>();

	private ConfusionMatrix microAveragedConfusionMatrix;

	@SuppressWarnings("deprecation")
	@Override
	public void evaluate() {
		int numberOfLevelCuts = 3;
		
		// throw 'z' away
		List<double[]> tmpVector = new ArrayList<double[]>();
		for (double[] vector : this.voteVector) {
			tmpVector.add(Arrays.copyOfRange(vector, 0, vector.length - 1));
		}
		this.voteVector = tmpVector;
		this.votedStrings = this.votedStrings.subList(0, this.votedStrings.size() - 1);
		
		Set<String> tmp = new HashSet<String>();
		for (String labelplusGrade : this.allLabels) {
			tmp.add(parseLabel(labelplusGrade));
		}
		List<String> labelsWithoutGrade = new ArrayList<String>(tmp);
		
		
		Map<String, int[]> labelToVotePositions = new HashMap<String,int[]>();
		for (String label : labelsWithoutGrade) {
			labelToVotePositions.put(label, new int[numberOfLevelCuts]);
		}
		for (int i = 0; i < this.votedStrings.size(); i++) {
			String labelPlusGrade = votedStrings.get(i);
			int pos = parseGrade(labelPlusGrade) - 1;
			int[] js = labelToVotePositions.get(parseLabel(labelPlusGrade));
			js[pos] = i; 
		}
		

		ConfusionMatrix confusionMatrix = new ConfusionMatrix(
				this.allLabels.toArray(new String[this.allLabels.size()]));

		List<double[]> flattedPredictions = new ArrayList<double[]>();
		for (int i = 0; i < voteVector.size(); i++) {
			flattedPredictions.add(new double[labelsWithoutGrade.size()]);

			double[] votesOfInstance = voteVector.get(i);

			HashMap<String, List<String>> predictionForInstance = new HashMap<String, List<String>>();
			

			for (int j = 0; j < votesOfInstance.length; j++) {
				for (int levelCut = 1; levelCut <= numberOfLevelCuts; levelCut++) {
					List<String> predictionOfCaliLabel = predictionForInstance
							.get(levelCut);
					if (predictionOfCaliLabel == null) {
						predictionOfCaliLabel = new ArrayList<String>();
						predictionForInstance.put(Integer.toString(levelCut),
								predictionOfCaliLabel);
					}

				}
				
				for (String label : labelsWithoutGrade) {
					int predictedGrade = 0;
					int[] votePositions = labelToVotePositions.get(label);
					for (int k = 0; k < votePositions.length; k++) {
						int position = votePositions[k];
						if(votesOfInstance[position] > 0){
							predictedGrade = k + 1; 
						}
					}
					flattedPredictions.get(i)[labelsWithoutGrade.indexOf(label)] = predictedGrade;
					
					List<String> list = predictionForInstance.get(Integer.toString(predictedGrade));
					if(list != null){
						list.add(label);
					}
				}
			}

			this.predictions.add(predictionForInstance);

			for (String label : labelsWithoutGrade) {
				int realGrade;
				String realLabel = "";
				for (String currentLabel : relevantLabels.get(i)) {
					if (parseLabel(currentLabel).equals(label)) {
						realGrade = parseGrade(currentLabel);
						realLabel = currentLabel;
					}
				}

				int predictedGrade = 0;
				for (String calibrationLabel : predictionForInstance.keySet()) {
					if (predictionForInstance.get(calibrationLabel).contains(
							label)) {
						predictedGrade = Integer.parseInt(calibrationLabel);
					}
				}

				int posOfRealLabel = allLabels.indexOf(realLabel);
				int posOfPredictedLabel = allLabels.indexOf(label
						+ predictedGrade);

				double elementValue = confusionMatrix.getElement(
						posOfRealLabel, posOfPredictedLabel) + 1;
				confusionMatrix.setElement(posOfRealLabel, posOfPredictedLabel,
						elementValue);
			}
		}
		microAveragedConfusionMatrix = ExtConfusionMatrix
				.doMicroAveraging(confusionMatrix);
		TwoClassConfusionMatrix microAveragedTwoClassConfusionMatrix = new TwoClassConfusionMatrix(
				microAveragedConfusionMatrix);

		for(IConfusionMatrixBasedLossFunction lossFunction : twoClassConfusionMatrixBasedlosses)
		{
			double lossResult = lossFunction.calculateLossFunction(microAveragedTwoClassConfusionMatrix);
			String lossNamePlusPackage = lossFunction.getClass().getName();
			this.lossResults.put(lossNamePlusPackage, lossResult);
		}
		
		for (OMConfusionMatrixBasedLossFunction lossFunction : confusionMatrixBasedLosses) {
			this.lossResults.put(lossFunction.getClass().getName(), lossFunction.calculateLoss(confusionMatrix, labelsWithoutGrade.size()));
		}
		
		for (RankLoss lossFunction : rankLosses) {
			this.lossResults.put(lossFunction.getClass().getName(), lossFunction.calculateLoss(relevantLabels, flattedPredictions, labelsWithoutGrade));
		}
	}

	private boolean isRealLabel(int i, String classIDLabel) {
		return this.relevantLabels.get(i).contains(classIDLabel);
	}

	private boolean isPredicted(
			HashMap<String, List<String>> predictionForInstance, int realGrade,
			String realClass) {
		if (realGrade == 0) {
			for (String calibrationLabel : predictionForInstance.keySet()) {
				if (predictionForInstance.get(calibrationLabel).contains(
						realClass)) {
					return false;
				}
			}
			return true;
		}
		List<String> predictionForCalibrationLabel = predictionForInstance
				.get(getCaliLabelForGrade(realGrade));
		return predictionForCalibrationLabel.contains(realClass);
	}

	private String parseLabel(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}

	private String getCaliLabelForGrade(int grade) {
		String calibrationLabel = Configuration.getCalibrationLabel(grade - 1);
		return calibrationLabel;
	}

	private HashMap<String, Double> filterVotesOfCalibrationLabels(
			double[] votesOfInstance,
			HashMap<String, Integer> caliLabelPositions) {
		HashMap<String, Double> votesForCalibrationLabels = new HashMap<String, Double>();
		for (String calibrationLabel : caliLabelPositions.keySet()) {
			votesForCalibrationLabels.put(calibrationLabel,
					votesOfInstance[caliLabelPositions.get(calibrationLabel)]);
		}
		return votesForCalibrationLabels;
	}

	private HashMap<String, Integer> getCaliLabelPositions() {
		Configuration.resetCaliLabels();
		HashMap<String, Integer> calibratedLabelPositions = new HashMap<String, Integer>();
		for (int i = 0; i < this.votedStrings.size(); i++) {
			String currentLabel = this.votedStrings.get(i);
			if (currentLabel.equals(Configuration.getCalibrationLabel())) {
				calibratedLabelPositions.put(currentLabel, i);
				Configuration.nextCaliLabel();
			}
		}
		return calibratedLabelPositions;
	}

	@Override
	protected void addLosses() {
		twoClassConfusionMatrixBasedlosses = new ArrayList<IConfusionMatrixBasedLossFunction>();
		
		this.twoClassConfusionMatrixBasedlosses.add(new AccuracyLoss());
		this.twoClassConfusionMatrixBasedlosses.add(new TpRate());
		this.twoClassConfusionMatrixBasedlosses.add(new FpRate());
		this.twoClassConfusionMatrixBasedlosses.add(new RecallLoss());
		this.twoClassConfusionMatrixBasedlosses.add(new PrecisionLoss());
		this.twoClassConfusionMatrixBasedlosses.add(new F1Loss());
		this.twoClassConfusionMatrixBasedlosses.add(new FalloutLoss());
		
		this.confusionMatrixBasedLosses = new ArrayList<OMConfusionMatrixBasedLossFunction>();
		
		this.confusionMatrixBasedLosses.add(new ZeroOneLoss());
		this.confusionMatrixBasedLosses.add(new VerticalHammingDistanceLoss());
		
		this.rankLosses = new ArrayList<RankLoss>();
		this.rankLosses.add(new CIndex());
		this.rankLosses.add(new OneErrorLoss());
	}

	@Override
	public String toString() {
		String result = "";

		result += super.toString();
		result += "\n";
		result += "relevant Labels: " + relevantLabels + "\n";
		result += "votes: " + this.predictions + "\n";
		result += microAveragedConfusionMatrix
				.toString("=== Micro Averaged Confusion Matrix ===") + "\n";
		return result;
	}
}
