/**
 */
package LPCforSOS.dataStructure;

/**
 * contains CV results, Label Ranking, Label Set, ...
 * 
 * @author Sandra Ebert
 * 
 * @date 09.04.2008, 15:46:49
 */
public class Results {

	double[][] confusionMatrix;
	String relationName;
	ExtInstances ext_instances;

	/**
	 * @param relationName
	 * @param confusionMatrix
	 */
	public Results(String relationName, double[][] confusionMatrix) {
		this.confusionMatrix = confusionMatrix;
		this.relationName = relationName;
	}

	/**
	 * @param data
	 */
	public Results(ExtInstances data) {
		this.ext_instances = data;
	}

	/**
	 * @return the confusionMatrix
	 */
	public double[][] getConfusionMatrix() {
		return confusionMatrix;
	}

	/**
	 * @param confusionMatrix
	 *            the confusionMatrix to set
	 */
	public void setConfusionMatrix(double[][] confusionMatrix) {
		this.confusionMatrix = confusionMatrix;
	}

	/**
	 * @return the relationName
	 */
	public String getRelationName() {
		return relationName;
	}

}
