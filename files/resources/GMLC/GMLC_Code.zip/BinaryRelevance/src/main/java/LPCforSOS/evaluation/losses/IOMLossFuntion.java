package LPCforSOS.evaluation.losses;

import java.util.HashMap;
import java.util.List;

public interface IOMLossFuntion {

	public double calculateLossFunction(
			List<List<String>> relevantLabels,
			List<HashMap<String, List<String>>> predictions, int numberOfLabels,
			int numberOfGrades);

}
