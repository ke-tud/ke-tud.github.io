/**
 */
package LPCforSOS.structuredPrediction;

import weka.classifiers.Classifier;
import weka.core.Instance;
import weka.core.Instances;
import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ExtInstances;

/**
 * Binary Classifiers that return class probabilities and predict the class that
 * receives the maximum number of votes: arg max sum(p(c_i|c_i v c_j))
 * 
 * @author Sandra Ebert
 * 
 * @date 08.04.2008, 17:04:17
 */
public class WeightedVoting extends StructuredPredictor {

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.structuredPrediction.StructuredPredictor#classifyInstances(weka.core.Instances,
	 *      LPCforSOS.baseLearner.DecomposedDatasetLearner, java.util.ArrayList)
	 */
	@Override
	public void classifyInstances(Instances test,
			DecomposedDatasetLearner learner,
			ExtInstances trainingSet) throws Exception {

		initialize();

		double[][] voting = new double[test.numInstances()][test.numClasses()];

		int numInstances = test.numInstances();
		for (int i = 0; i < numInstances; i++) {
			Instance instance = test.instance(i);
			int numBaseClassifier = learner.getBaseClassifier().size();
			for (int j = 0; j < numBaseClassifier; j++) {
				Classifier classifier = learner.getBaseClassifier().get(j);
				double[] distrib = classifier.distributionForInstance(instance);

				for (int c = 0; c < distrib.length; c++) {
					String realClass = learner.getDecomposedDatasets().get(j).classAttribute().value(c);
					voting[i][learner.getClassToNumber().get(realClass)] += distrib[c];
				}
			}
			voteVector.add(voting[i]);
		}
	}
}
