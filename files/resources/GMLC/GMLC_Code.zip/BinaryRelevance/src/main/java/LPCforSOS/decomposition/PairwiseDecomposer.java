/**
 */
package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.HashMap;

import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstances;

/**
 * @author Sandra Ebert
 * 
 * @date 17.12.2007, 17:26:52
 */
public class PairwiseDecomposer extends Decomposer {

	private ExtInstances data;

	// private ArrayList<ArrayList<String>>
	// listOfTotalPreferenceOrdersPerInstance;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * LPCforSOS.decomposition.Decomposer#buildDecomposedDatasets(LPCforSOS.
	 * dataStructure.ExtInstances)
	 */
	@Override
	public void buildDecomposedDatasets(ExtInstances data) {
		super.initialize();
		this.data = data;
		// this.listOfTotalPreferenceOrdersPerInstance = new
		// ArrayList<ArrayList<String>>();

		PairwiseDecomposition decomposer = null;
		switch (data.getType()) {
		case CalibratedLabelRanking:
			decomposer = new CalibratedLabelRanking(this);
			break;

		case MultiLabel:
			decomposer = new MultiLabelDecomposition(this);
			break;

		case Ordinal:
			decomposer = new OrdinalDecomposition(this);
			break;

		case Multiclass:
			decomposer = new MulticlassDecomposition(this);
			break;

		case Hierarchy:
			decomposer = new HierarchyRankingDecomposition(this, false);
			break;

		case HierarchyLeaves:
			decomposer = new HierarchyRankingDecomposition(this, true);
			break;

		case ML_Hierarchy:
			decomposer = new MLHierarchyRankingDecomposition(this, false);
			break;

		case ML_HierarchyLeaves:
			decomposer = new MLHierarchyRankingDecomposition(this, true);
			break;

		case ML_Graded:
			decomposer = new GradedMultiLabelDecomposition(this);
			break;

		case LabelRankingPairwisePreference:
			decomposer = new LabelRankingPairwiseDecomposition(this);
			break;

		case LabelRankingSinglePreference:
			decomposer = new MulticlassDecomposition(this);
			break;
		}
		// betterApproach(data);

		decomposer.decompose(this.data);
	}

	// /**
	// *
	// */
	// private void filteringOfTotalPreferenceOrders() {
	// this.data.get_Instances();
	// }

	/*
	 * private void MulticlassDecomposition() { int counter = 0; double value =
	 * 0.0; int iter = 0;
	 * 
	 * int numOfClasses = data.getNumberOfClasses();
	 * 
	 * ArrayList<String> allClasses = (ArrayList<String>) data.getClasses()
	 * .clone();
	 * 
	 * // mapping string of class to number for (int i = 0; i < numOfClasses;
	 * i++) { classToNumber.put(allClasses.get(i), i); }
	 * 
	 * for (int i = 0; i < numOfClasses; i++) {
	 * 
	 * String label1 = allClasses.get(i); int startIdx = i + 1;
	 * 
	 * for (int j = startIdx; j < numOfClasses; j++) { String label2 =
	 * allClasses.get(j);
	 * 
	 * // new nominal attribute for class with the two classes FastVector
	 * attributeValues = new FastVector(); attributeValues.addElement(label1);
	 * attributeValues.addElement(label2);
	 * 
	 * FastVector attributes = (FastVector) data.get_Attributes()
	 * .copyElements(); attributes.addElement(new Attribute("class",
	 * attributeValues));
	 * 
	 * String sub_relation = data.relationName() + "_" + label1 + "_vs_" +
	 * label2; Instances sub_Instances = new Instances(sub_relation, attributes,
	 * 100);
	 * 
	 * for (ExtInstance extInstance : data.get_Instances()) {
	 * 
	 * // weka coding of nominal attributes // -1 zeigt an das Instanz nicht zu
	 * gebrauchen ist. int label = -1;
	 * 
	 * if (extInstance.getM_Classes().contains(label1)) {
	 * 
	 * label = 0; } else if (extInstance.getM_Classes().contains(label2)) {
	 * 
	 * label = 1; }
	 * 
	 * if (!(label < 0)) { ExtInstance instance = (ExtInstance)
	 * extInstance.copy(); instance.setValue(extInstance.asWekaInstance()
	 * .numAttributes() - 1, label);
	 * 
	 * // appends the new instance with new class value
	 * sub_Instances.add(instance);
	 * instance.asWekaInstance().setDataset(sub_Instances); } iter++; }
	 * sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
	 * dec_Instances.add(sub_Instances); value += sub_Instances.numInstances();
	 * counter++; } } // System.out.println(iter + " Iterationen, " + counter +
	 * " learner"); } /*
	 */

	/*
	 * private void CalibratedLabelRanking() { int counter = 0; double value =
	 * 0.0; int iter = 0;
	 * 
	 * int numOfClasses = data.getNumberOfClasses(); int
	 * numOfClassesPlusCaliLabel = numOfClasses + 1;
	 * 
	 * // Einf�gen des Calibrationlabels ans Ende der Liste aller Klassen
	 * ArrayList<String> classesPlusCaliLabel = (ArrayList<String>) data
	 * .getClasses().clone();
	 * classesPlusCaliLabel.add(Configuration.calibrationLabel);
	 * 
	 * // mapping string of class to number // Mit dem setzen in die
	 * classToNumber HashMap wird das Calibrationlabel // auch f�r den Lerner
	 * und Klassifizierer �bernommen. for (int i = 0; i <
	 * numOfClassesPlusCaliLabel; i++) {
	 * classToNumber.put(classesPlusCaliLabel.get(i), i); }
	 * 
	 * for (int i = 0; i < numOfClassesPlusCaliLabel; i++) { String label1 =
	 * classesPlusCaliLabel.get(i);
	 * 
	 * // if asymmetric learner -> double round robin -> 1 vs. 2 unequal 2 //
	 * vs. 1 int startIdx = 0; if (this.isSymmetric) { startIdx = i + 1; }
	 * 
	 * for (int j = startIdx; j < numOfClassesPlusCaliLabel; j++) { if (i != j)
	 * { String label2 = classesPlusCaliLabel.get(j);
	 * 
	 * // new nominal attribute for class with the two classes FastVector
	 * attributeValues = new FastVector(); attributeValues.addElement(label1);
	 * attributeValues.addElement(label2);
	 * 
	 * FastVector attributes = (FastVector) data.get_Attributes()
	 * .copyElements(); attributes.addElement(new Attribute("class",
	 * attributeValues));
	 * 
	 * String sub_relation = data.relationName() + "_" + label1 + "_vs_" +
	 * label2; Instances sub_Instances = new Instances(sub_relation, attributes,
	 * 100);
	 * 
	 * // naive approach for (ExtInstance extInstance : data.get_Instances()) {
	 * 
	 * // weka coding of nominal attributes // -1 zeigt an das Instanz nicht zu
	 * gebrauchen ist. int label = -1;
	 * 
	 * if (label1 == Configuration.calibrationLabel &&
	 * !extInstance.getM_Classes().contains(label2)) {
	 * 
	 * label = 0; } else if (label2 == Configuration.calibrationLabel &&
	 * !extInstance.getM_Classes().contains(label1)) {
	 * 
	 * label = 1; } else // only instance with one of the two classes, all other
	 * // records are omitted if (extInstance.getM_Classes().contains(label1) ^
	 * extInstance.getM_Classes().contains(label2)) {
	 * 
	 * label = extInstance.getM_Classes().contains(label1) ? 0 : 1; }
	 * 
	 * if (!(label < 0)) { ExtInstance instance = (ExtInstance) extInstance
	 * .copy(); instance.setValue(extInstance.asWekaInstance() .numAttributes()
	 * - 1, label);
	 * 
	 * // appends the new instance with new class value
	 * sub_Instances.add(instance);
	 * instance.asWekaInstance().setDataset(sub_Instances); } iter++; }
	 * sub_Instances .setClassIndex(sub_Instances.numAttributes() - 1);
	 * dec_Instances.add(sub_Instances); value += sub_Instances.numInstances();
	 * counter++; } } } System.out.println(iter + " Iterationen, " + counter +
	 * " learner"); } /*
	 */

	/*
	 * private void LabelRankingPairwiseDecomposition() {
	 * 
	 * HashMap<String, Integer> learner = new HashMap<String, Integer>(); int
	 * newIndex = 0; int learnerCounter = 0;
	 * 
	 * for (ExtInstance ext_instance : data.get_Instances()) {
	 * 
	 * for (String attrib : ext_instance.getM_Classes()) { String[] labels =
	 * attrib.split("<"); int indexLhs = data.getClasses().indexOf(labels[0]);
	 * int indexRhs = data.getClasses().indexOf(labels[1]);
	 * 
	 * String checkString = null; boolean wrightOrder = true; if (indexLhs <
	 * indexRhs) checkString = labels[0] + "<" + labels[1]; else { checkString =
	 * labels[1] + "<" + labels[0]; wrightOrder = false; }
	 * 
	 * // insert new learner if (!learner.containsKey(checkString)) {
	 * learner.put(checkString, learnerCounter); learnerCounter++; if
	 * (wrightOrder) { classToNumber .put(labels[0] + "<" + labels[1],
	 * newIndex); newIndex++; classToNumber .put(labels[1] + "<" + labels[0],
	 * newIndex); newIndex++; } else { classToNumber .put(labels[1] + "<" +
	 * labels[0], newIndex); newIndex++; classToNumber .put(labels[0] + "<" +
	 * labels[1], newIndex); newIndex++; }
	 * 
	 * // new nominal attribute for class with the two classes FastVector
	 * attributeValues = new FastVector(); if (wrightOrder) {
	 * attributeValues.addElement(labels[0] + "<" + labels[1]);
	 * attributeValues.addElement(labels[1] + "<" + labels[0]); } else {
	 * attributeValues.addElement(labels[1] + "<" + labels[0]);
	 * attributeValues.addElement(labels[0] + "<" + labels[1]); }
	 * 
	 * FastVector attributes = (FastVector) data.get_Attributes()
	 * .copyElements(); attributes.addElement(new Attribute("class",
	 * attributeValues));
	 * 
	 * String sub_relation; if (wrightOrder) sub_relation = data.relationName()
	 * + "_" + labels[0] + "_vs_" + labels[1]; else sub_relation =
	 * data.relationName() + "_" + labels[1] + "_vs_" + labels[0];
	 * 
	 * Instances sub_Instances = new Instances(sub_relation, attributes, 100);
	 * 
	 * sub_Instances .setClassIndex(sub_Instances.numAttributes() - 1);
	 * dec_Instances.add(sub_Instances); }
	 * 
	 * Instances sub_Instances = dec_Instances.get(learner .get(checkString));
	 * 
	 * // weka coding of nominal attributes
	 * 
	 * ExtInstance instance = (ExtInstance) ext_instance.copy();
	 * instance.setValue( ext_instance.asWekaInstance().numAttributes() - 1,
	 * wrightOrder ? 0 : 1);
	 * 
	 * // appends the new instance with new class value
	 * sub_Instances.add(instance);
	 * instance.asWekaInstance().setDataset(sub_Instances); }
	 * 
	 * } } /*
	 */

	/*
	 * private void HierarchyRankingDecomposition(boolean justLeaves) {
	 * HashMap<Integer, String> numberToClass = new HashMap<Integer, String>();
	 * for (int i = 0; i < data.getNumberOfClasses(); i++) {
	 * classToNumber.put(data.getClasses().get(i), i); numberToClass.put(i,
	 * data.getClasses().get(i)); } ArrayList<ArrayList<Integer>> ways =
	 * buildWay(classToNumber); // need to know the leaves for creating the
	 * classification ArrayList<ArrayList<Integer>> compareList =
	 * buildCompareList(ways, numberToClass, justLeaves);
	 * buildInstances(numberToClass, ways, justLeaves);
	 * 
	 * // String[] testStrings = {"a","b","c","d","e"}; // HashMap<String,
	 * ArrayList<String>> pos = new HashMap<String, // ArrayList<String>>(); //
	 * HashMap<String, ArrayList<String>> neg = new HashMap<String, //
	 * ArrayList<String>>();
	 * 
	 * // for(String test : testStrings) for (ExtInstance extInstance :
	 * data.get_Instances()) { for (int i = 0; i < dec_Instances.size(); i++) {
	 * Instances sub_Instances = dec_Instances.get(i); String lhs =
	 * sub_Instances.classAttribute().value(0); String rhs =
	 * sub_Instances.classAttribute().value(1); String node =
	 * extInstance.getM_Classes().get(0); // String node = test; //
	 * ArrayList<String> negEntries = neg.get(lhs + "," + rhs); //
	 * ArrayList<String> posEntries = pos.get(lhs + "," + rhs); // if(posEntries
	 * == null) // { // posEntries = new ArrayList<String>(); // pos.put(lhs +
	 * "," + rhs, posEntries); // negEntries = new ArrayList<String>(); //
	 * neg.put(lhs + "," + rhs, negEntries); // }
	 * 
	 * int distLhs = compareList.get(classToNumber.get(lhs)).get(
	 * classToNumber.get(node)); // int distRhs =
	 * compareList.get(classToNumber.get(rhs)).get( classToNumber.get(node));
	 * 
	 * if (distLhs != distRhs) { int label = -1; if (distLhs > distRhs) { label
	 * = 0; // posEntries.add(test); } else if (distLhs < distRhs) { label = 1;
	 * // negEntries.add(test); } ExtInstance instance = (ExtInstance)
	 * extInstance.copy(); instance.setValue(extInstance.asWekaInstance()
	 * .numAttributes() - 1, label); // appends the new instance with new class
	 * value sub_Instances.add(instance);
	 * instance.asWekaInstance().setDataset(sub_Instances); } } } } /*
	 */

	/*
	 * private void MLHierarchyRankingDecomposition(boolean justLeaves) {
	 * HashMap<Integer, String> numberToClass = new HashMap<Integer, String>();
	 * for (int i = 0; i < data.getNumberOfClasses(); i++) {
	 * classToNumber.put(data.getClasses().get(i), i); numberToClass.put(i,
	 * data.getClasses().get(i)); } ArrayList<ArrayList<Integer>> ways =
	 * buildWay(classToNumber); // need to know the leaves for creating the
	 * classification ArrayList<ArrayList<Integer>> compareList =
	 * buildCompareList(ways, numberToClass, justLeaves);
	 * buildInstances(numberToClass, ways, justLeaves);
	 * 
	 * for (ExtInstance extInstance : data.get_Instances()) { for (int i = 0; i
	 * < dec_Instances.size(); i++) { Instances sub_Instances =
	 * dec_Instances.get(i); String lhs =
	 * sub_Instances.classAttribute().value(0); String rhs =
	 * sub_Instances.classAttribute().value(1);
	 * 
	 * int label = -1; for (String node : extInstance.getM_Classes()) { int
	 * distLhs = compareList.get(classToNumber.get(lhs)).get(
	 * classToNumber.get(node));
	 * 
	 * int distRhs = compareList.get(classToNumber.get(rhs)).get(
	 * classToNumber.get(node));
	 * 
	 * if (distLhs != distRhs) { if (distLhs > distRhs) { if (label == -1) label
	 * = 0; if (label == 1) break; } else if (distLhs < distRhs) { if (label ==
	 * -1) label = 1; if (label == 0) break; } } } if (label != -1) {
	 * ExtInstance instance = (ExtInstance) extInstance.copy();
	 * instance.setValue(extInstance.asWekaInstance() .numAttributes() - 1,
	 * label); // appends the new instance with new class value
	 * sub_Instances.add(instance);
	 * instance.asWekaInstance().setDataset(sub_Instances); } } } } /*
	 */

	/*
	 * private void buildInstances(HashMap<Integer, String> numberToClass,
	 * ArrayList<ArrayList<Integer>> ways, boolean justLeaves) {
	 * ArrayList<String> theClasses = data.getClasses(); for (int i = 0; i <
	 * theClasses.size() - 1; i++) { String class1 = numberToClass.get(i); for
	 * (int j = i + 1; j < theClasses.size(); j++) { String class2 =
	 * numberToClass.get(j);
	 * 
	 * if (justLeaves && (isSuperNode(i, ways) || isSuperNode(j, ways)))
	 * continue;
	 * 
	 * if (data.getClassInformation().contains(class1 + "!" + class2) ||
	 * data.getClassInformation().contains( class2 + "!" + class1)) continue;
	 * 
	 * FastVector attributeValues = new FastVector();
	 * attributeValues.addElement(class1); attributeValues.addElement(class2);
	 * 
	 * FastVector attributes = (FastVector) data.get_Attributes()
	 * .copyElements(); attributes.addElement(new Attribute("class",
	 * attributeValues)); String sub_relation = data.relationName() + "_" +
	 * class1 + "_vs_" + class2; Instances sub_Instances = new
	 * Instances(sub_relation, attributes, 100);
	 * sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
	 * dec_Instances.add(sub_Instances); } } } /*
	 */

	/*
	 * private ArrayList<ArrayList<Integer>> buildCompareList(
	 * ArrayList<ArrayList<Integer>> ways, HashMap<Integer, String>
	 * numberToClass, boolean justLeaves) { ArrayList<ArrayList<Integer>>
	 * compareList = new ArrayList<ArrayList<Integer>>(); for (int i = 0; i <
	 * classToNumber.size(); i++) { String class1 = numberToClass.get(i);
	 * ArrayList<Integer> newEntries = new ArrayList<Integer>(); for (int j = 0;
	 * j < classToNumber.size(); j++) { String class2 = numberToClass.get(j); if
	 * (data.getClassInformation().contains(class1 + "!" + class2) ||
	 * data.getClassInformation().contains( class2 + "!" + class1)) {
	 * newEntries.add(0); continue; }
	 * 
	 * if (justLeaves && (isSuperNode(i, ways) || isSuperNode(j, ways))) {
	 * newEntries.add(0); continue; } // Schnittmenge bilden, Anahl verbliebende
	 * Elemente... ArrayList<Integer> cloneA = (ArrayList<Integer>) ways.get(i)
	 * .clone(); ArrayList<Integer> cloneB = (ArrayList<Integer>) ways.get(j)
	 * .clone(); cloneA.retainAll(cloneB); newEntries.add(cloneA.size()); }
	 * compareList.add(newEntries); } return compareList; } /*
	 */

	/*
	 * private boolean isSuperNode(int index, ArrayList<ArrayList<Integer>>
	 * ways) { for (ArrayList<Integer> newWay : ways) { if (newWay.get(0) ==
	 * index) continue; if (newWay.contains(index)) return true; } return false;
	 * } /*
	 */

	/*
	 * private ArrayList<ArrayList<Integer>> buildWay( HashMap<String, Integer>
	 * classToNumber) { ArrayList<ArrayList<Integer>> ways = new
	 * ArrayList<ArrayList<Integer>>(); int[] parents = new
	 * int[classToNumber.size()]; for (int i = 0; i < parents.length; i++)
	 * parents[i] = -1;
	 * 
	 * ArrayList<String> classInformation = data.getClassInformation();
	 * 
	 * for (String info : classInformation) { if (info.contains("<")) { String[]
	 * values = info.split("<"); parents[classToNumber.get(values[1])] =
	 * classToNumber .get(values[0]); } } for (int i = 0; i < parents.length;
	 * i++) { ArrayList<Integer> way = new ArrayList<Integer>(); way.add(i); int
	 * newItem = parents[i]; while (newItem != -1) { way.add(newItem); newItem =
	 * parents[newItem]; } ways.add(way); } return ways; } /*
	 */

	/*
	 * private void OrdinalDecomposition() { // PARK NOTES: // - Es wird
	 * vorausgesetzt, dass die Klassenaufzaehlung im Header // sortiert sind,
	 * aufsteigend oder absteigend // - in ranking werden alle Klassen
	 * abgespeichert // - ordinalStorage beeinhaltet spaeter alle decomposed
	 * Datensaetze
	 * 
	 * // need to know internal the ranking of the different class values
	 * HashMap<String, Integer> ranking = new HashMap<String, Integer>(); //
	 * retrieving the different classes by ordinal structure
	 * ArrayList<ArrayList<Instances>> ordinalStorage = new
	 * ArrayList<ArrayList<Instances>>();
	 * 
	 * for (int i = 0; i < data.getClasses().size(); i++) {
	 * ranking.put(data.getClasses().get(i), i); ordinalStorage.add(new
	 * ArrayList<Instances>()); }
	 * 
	 * int toNumber = 0; ArrayList<String> theClasses = data.getClasses(); // in
	 * der folgenden Schleife werden die Headerinformationen für die //
	 * decomposed Daten // erzeugt in ordinalStorage eingefuegt for (int i = 0;
	 * i < (theClasses.size() - 1); i++) { String lhs = theClasses.get(i); for
	 * (int j = i + 1; j < theClasses.size(); j++) { String rhs =
	 * theClasses.get(j); classToNumber.put(lhs + "<" + rhs, toNumber);
	 * toNumber++; classToNumber.put(rhs + "<" + lhs, toNumber); toNumber++;
	 * 
	 * // new nominal attribute for class with the two classes FastVector
	 * attributeValues = new FastVector(); attributeValues.addElement(lhs + "<"
	 * + rhs); attributeValues.addElement(rhs + "<" + lhs);
	 * 
	 * FastVector attributes = (FastVector) data.get_Attributes()
	 * .copyElements(); attributes.addElement(new Attribute("class",
	 * attributeValues));
	 * 
	 * String sub_relation = data.relationName() + "_" + lhs + "_vs_" + rhs;
	 * Instances sub_Instances = new Instances(sub_relation, attributes, 100);
	 * 
	 * sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
	 * dec_Instances.add(sub_Instances);
	 * 
	 * int indexToInsert = ranking.get(rhs);
	 * ordinalStorage.get(indexToInsert).add(sub_Instances); } } // here, the
	 * actual decomposed datasets are generated for (ExtInstance ext_instance :
	 * data.get_Instances()) { String attrib =
	 * ext_instance.getM_Classes().get(0); int lastPosIndex =
	 * ranking.get(attrib);
	 * 
	 * for (int i = 0; i < ordinalStorage.size(); i++) { for (int j = 0; j <
	 * ordinalStorage.get(i).size(); j++) { Instances instances =
	 * ordinalStorage.get(i).get(j); double[] attValue =
	 * ext_instance.getM_AttValues(); // hier ist ein Fehler. Momentan besitzen
	 * alle paarweisen // Klassifizierer alle Instanzen // das gilt nicht immer.
	 * Beispiel: 2 vs 4, instanzen der // klasse 3 werden hierbei garnicht
	 * benutzt // momentan: falls instanz < lhs (oder so ähnlich) des //
	 * aktuell betrachteten Klassifizierers adde als positiv // ansonsten
	 * negativ int entryIndex = i < (lastPosIndex + 1) ? 0 : 1;
	 * 
	 * ExtInstance instance = (ExtInstance) ext_instance.copy();
	 * instance.setValue(ext_instance.asWekaInstance() .numAttributes() - 1,
	 * entryIndex); instances.add(instance);
	 * instance.asWekaInstance().setDataset(instances); } } } } /*
	 */

	/**
	 * theoretic better approach: for n classes and m data records O(n*m) +
	 * O(n^2*k) mit k << m
	 * 
	 * @param data
	 */
	// private void betterApproach(ExtInstances data) {
	// int counter = 0;
	// int value = 0;
	// int iter = 0;
	//
	// ArrayList<ArrayList<Integer>> listOfClasses = buildClassList(data);
	//
	// String[] classValues = new String[data.getClasses().size()];
	// for (int i = 0; i < data.getClasses().size(); i++) {
	// classValues[i] = data.getClasses().get(i);
	// }
	//
	// for (int i = 0; i < listOfClasses.size(); i++) {
	// for (int j = i + 1; j < listOfClasses.size(); j++) {
	//
	// ArrayList<Integer> firstList = copyList(listOfClasses.get(i),
	// listOfClasses.get(j));
	// ArrayList<Integer> secondList = copyList(listOfClasses.get(j),
	// listOfClasses.get(i));
	//
	// String label1 = classValues[i];
	// String label2 = classValues[j];
	//
	// // new nominal attribute for class with the two classes
	// FastVector attributeValues = new FastVector();
	// attributeValues.addElement(label1);
	// attributeValues.addElement(label2);
	//
	// FastVector attributes = data.get_Attributes();
	// attributes.addElement(new Attribute("class", attributeValues));
	//
	// String sub_relation = data.relationName() + "_" + label1
	// + "_vs_" + label2;
	// Instances sub_Instances = new Instances(sub_relation,
	// attributes, 100);
	//
	// for (int index : firstList) {
	// ExtInstance extInstance = data.get_Instances().get(index);
	//
	// ExtInstance instance = (ExtInstance) extInstance.copy();
	// instance.setValue(extInstance.asWekaInstance()
	// .numAttributes() - 1, 0);
	//
	// // appends the new instance with new class value
	// sub_Instances.add(instance);
	// instance.asWekaInstance().setDataset(sub_Instances);
	// iter++;
	// }
	//
	// for (int index : secondList) {
	// ExtInstance extInstance = data.get_Instances().get(index);
	//
	// ExtInstance instance = (ExtInstance) extInstance.copy();
	// instance.setValue(extInstance.asWekaInstance()
	// .numAttributes() - 1, 1);
	//
	// // appends the new instance with new class value
	// sub_Instances.add(instance);
	// instance.asWekaInstance().setDataset(sub_Instances);
	// iter++;
	// }
	// sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
	// dec_Instances.add(sub_Instances);
	// value += sub_Instances.numInstances();
	// counter++;
	// }
	// }
	//
	// System.out.println(iter + " Iterationen");
	// }

	/**
	 * @param arrayList
	 * @param arrayList2
	 * @return
	 */
	// private ArrayList<Integer> copyList(ArrayList<Integer> arrayList,
	// ArrayList<Integer> arrayList2) {
	// ArrayList<Integer> list = new ArrayList<Integer>();
	// for (int element : arrayList) {
	// list.add(element);
	// }
	// list.removeAll(arrayList2);
	// return list;
	// }

	/*
	 * naive approach: for n classes and m data records n(n-1)/2*m -> O(n^2*m)
	 * 
	 * @param data
	 * 
	 * private void MultiLabelDecomposition() { int counter = 0; double value =
	 * 0.0; int iter = 0;
	 * 
	 * // mapping class to integer for (int i = 0; i < data.getClasses().size();
	 * i++) { classToNumber.put(data.getClasses().get(i), i); }
	 * 
	 * // ArrayList<ArrayList<Integer>> listOfClassIndices = //
	 * buildClassList(data.get_Instances());
	 * 
	 * for (int i = 0; i < data.getNumberOfClasses(); i++) { String label1 =
	 * data.getClasses().get(i);
	 * 
	 * // if asymmetric learner -> double round robin -> 1 vs. 2 unequal 2 //
	 * vs. 1 int startIdx = 0; if (this.isSymmetric) { startIdx = i + 1; }
	 * 
	 * for (int j = startIdx; j < data.getNumberOfClasses(); j++) { if (i != j)
	 * { String label2 = data.getClasses().get(j);
	 * 
	 * // new nominal attribute for class with the two classes FastVector
	 * attributeValues = new FastVector(); attributeValues.addElement(label1);
	 * attributeValues.addElement(label2);
	 * 
	 * FastVector attributes = (FastVector) data.get_Attributes()
	 * .copyElements(); attributes.addElement(new Attribute("class",
	 * attributeValues));
	 * 
	 * String sub_relation = data.relationName() + "_" + label1 + "_vs_" +
	 * label2; Instances sub_Instances = new Instances(sub_relation, attributes,
	 * 100);
	 * 
	 * // naive approach for (ExtInstance extInstance : data.get_Instances()) {
	 * 
	 * // only instance with one of the two classes, all other // records are
	 * omitted if (extInstance.getM_Classes().contains(label1) ^
	 * extInstance.getM_Classes().contains(label2)) {
	 * 
	 * ExtInstance instance = (ExtInstance) extInstance .copy();
	 * 
	 * // weka coding of nominal attributes int label =
	 * extInstance.getM_Classes().contains( label1) ? 0 : 1;
	 * 
	 * instance.setValue(extInstance.asWekaInstance() .numAttributes() - 1,
	 * label);
	 * 
	 * // appends the new instance with new class value
	 * sub_Instances.add(instance);
	 * instance.asWekaInstance().setDataset(sub_Instances); } iter++; }
	 * sub_Instances .setClassIndex(sub_Instances.numAttributes() - 1);
	 * dec_Instances.add(sub_Instances); value += sub_Instances.numInstances();
	 * counter++; } } } System.out.println(iter + " Iterationen, " + counter +
	 * " learner"); } /*
	 */

	/**
	 * Generated for n class a list of the indices of all records (m), which
	 * contain the class: O(n*m)
	 * 
	 * @param data
	 * @return list for each class with indices
	 */
	// private ArrayList<ArrayList<Integer>> buildClassList(ExtInstances data) {
	// int iter = 0;
	//
	// ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>();
	//
	// for (int i = 0; i < data.getNumberOfClasses(); i++) {
	// ArrayList<Integer> single = new ArrayList<Integer>();
	// list.add(single);
	// }
	//
	// for (int i = 0; i < data.numInstances(); i++) {
	// ExtInstance inst = data.get_Instances().get(i);
	// for (int j = 0; j < inst.getM_Classes().size(); j++) {
	// int index = data.getClasses().indexOf(
	// inst.getM_Classes().get(j));
	// list.get(index).add(i);
	// iter++;
	// }
	// }
	// System.out.println(iter + " Iterationen");
	// return list;

	@Override
	public PairwiseDecomposer clone() {
		try {
			PairwiseDecomposer dec = (PairwiseDecomposer) Decomposer
					.forName(DecompositionType.PairwiseDecomposer);
			dec.data = new ExtInstances(this.data);
			(dec.classToNumber = new HashMap<String, Integer>())
					.putAll(this.classToNumber);
			(dec.dec_Instances = new ArrayList<Instances>())
					.addAll(this.dec_Instances);
			(dec.realClasses = new ArrayList<ArrayList<String>>())
					.addAll(this.realClasses);
			dec.isSymmetric = this.isSymmetric;

			return dec;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
