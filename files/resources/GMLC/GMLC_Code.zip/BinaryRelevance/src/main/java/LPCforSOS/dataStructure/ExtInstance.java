package LPCforSOS.dataStructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import weka.core.Instance;
import weka.core.SparseInstance;

/**
 * 
 * @author Jens Huehn (MR), Sandra Ebert (DA), George-P. C.F.
 * 
 * @date 05.12.2007, 17:36:33
 */
public class ExtInstance extends Instance implements ExtendedInstance {

	private static final long serialVersionUID = -3012666279689145992L;
	protected ExtInstances m_ExtDataset;
	protected List<String> m_Classes;
	private Instance m_InnerInstance;
	
	protected Map<Integer, Double> changeSet;

	/**
	 * Not null when multi label ranking with total order of labels given.
	 */
	protected ArrayList<String> labelRankingTotalOrderOfLabels;

	/**
	 * Constructor
	 * 
	 * @param weight
	 * @param attValues
	 * @param classes
	 */
	public ExtInstance(Instance inner, ArrayList<String> classes) {
		setInnerInstance(inner);
		m_Classes = classes;
		m_ExtDataset = null;
	}

	/**
	 * Constructor that copies the attribute values and the weight from the
	 * given instance. Reference to the dataset is set to null. (ie. the
	 * instance doesn't have access to information about the attribute types)
	 * 
	 * @param instance
	 *            the instance from which the attribute values and the weight
	 *            are to be copied
	 */
	// @ ensures m_Dataset == null;
	protected ExtInstance(/* @non_null@ */ExtInstance instance) {
		setInnerInstance(instance.m_InnerInstance); //(Instance) instance.asWekaInstance().copy();
		changeSet.putAll(instance.changeSet);
		
		m_Classes = instance.m_Classes;
		m_ExtDataset = null;
		labelRankingTotalOrderOfLabels = instance.labelRankingTotalOrderOfLabels;
	}

	/**
	 * Sets the reference to the dataset. Does not check if the instance is
	 * compatible with the dataset. Note: the dataset does not know about this
	 * instance. If the structure of the dataset's header gets changed, this
	 * instance will not be adjusted automatically.
	 * 
	 * @param instances
	 *            the reference to the dataset
	 */
	public final void setDataset(ExtInstances instances) {
		m_ExtDataset = instances;
		m_Dataset = instances;
		m_InnerInstance.setDataset(instances);
	}

	public/* @pure@ */Object copy() {
		ExtInstance result = new ExtInstance(this);
		result.m_ExtDataset = m_ExtDataset;
		
		return result;
	}

	/**
	 * @return the m_Classes
	 */
	public List<String> getM_Classes() {
		return m_Classes;
	}

	/**
	 * @param classes
	 *            the m_Classes to set
	 */
	public void setM_Classes(List<String> classes) {
		m_Classes = classes;
	}

	/**
	 * @return the m_AttValues
	 */
	public double[] getM_AttValues() {
		return m_InnerInstance.toDoubleArray();
	}

	/**
	 * @return the multiLabelRankingTotalOrderOfLabels
	 */
	public ArrayList<String> getLabelRankingTotalOrderOfLabels() {
		return labelRankingTotalOrderOfLabels;
	}

	/**
	 * @param multiLabelRankingTotalOrderOfLabels the multiLabelRankingTotalOrderOfLabels to set
	 */
	public void setLabelRankingTotalOrderOfLabels(
			ArrayList<String> multiLabelRankingTotalOrderOfLabels) {
		this.labelRankingTotalOrderOfLabels = multiLabelRankingTotalOrderOfLabels;
	}

	public Instance asWekaInstance() {
		return m_InnerInstance;
	}

	public void setInnerInstance(Instance mInnerInstance) {
		m_InnerInstance = mInnerInstance;
		
		changeSet = new TreeMap<Integer, Double>();
		m_Dataset = m_InnerInstance.dataset();
		m_Weight = m_InnerInstance.weight();
		
	}
	
	@Override
	public boolean isMissing(int attIndex) {
		return Double.isNaN(this.value(attIndex));
	}
	
	
	
	@Override
	public int index(int position) {
		return m_InnerInstance.index(position);
	}
	
	
	@Override
	public int numAttributes() {
		return m_InnerInstance.numAttributes();
	}
	@Override
	public int numValues() {
		return m_InnerInstance.numValues();
	}
	
	
	
	@Override
	public void setValue(int attIndex, double value) {
		changeSet.put(attIndex, value);
	}
	
	
	@Override
	public void setValueSparse(int indexOfIndex, double value) {
		this.setValue(indexOfIndex, value);
	}
	
	
	@Override
	public double[] toDoubleArray() {
		double [] result = m_InnerInstance.toDoubleArray();
		for (Map.Entry<Integer, Double> entry : changeSet.entrySet()) {
			result[entry.getKey()] = entry.getValue();
		}
		return result;
	}
	
	@Override
	public double value(int attIndex) {
		Double val = changeSet.get(attIndex);
		return val != null ? val : m_InnerInstance.value(attIndex);
	}
	
	@Override
	public double valueSparse(int indexOfIndex) {
		if(m_InnerInstance instanceof SparseInstance){
			int attIndex = ((SparseInstance)m_InnerInstance).index(indexOfIndex); //get AttributeIndex to indexOfIndex
			Double val = changeSet.get(attIndex);
			return val != null ? val : ((SparseInstance)m_InnerInstance).valueSparse(indexOfIndex); //does the same as m_InnerInstance.value(attIndex), but for clearness that we pass an indexOfIndex 
		}
		return value(indexOfIndex); //normal behaviour, indexOfIndex is attIndex
	}
}
