/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.List;

/**
 * Calculate the Kendall's Tau Measure. 
 * This is defined as<p>
 * <pre>
 * Number of discordant pairs of labels
 * </pre>
 *
 * @author George-P. C.F.
 *  
 */
public class KendallsTauLoss implements ILabelRankingLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.ILabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(
			List<String> predictedOrderOfLabels,
			List<String> totalOrderOfLabels) {
		int numberOfDiscordantPairs = 0;
		for(int i = 0; i < totalOrderOfLabels.size(); i++){
			for(int j = i+1; j < totalOrderOfLabels.size(); j++){
				String lowLabel = totalOrderOfLabels.get(i);
				String highLabel = totalOrderOfLabels.get(j);
				int positionOfLowLabelInPrediction = predictedOrderOfLabels.indexOf(lowLabel);
				int positionOfHighLabelInPrediction = predictedOrderOfLabels.indexOf(highLabel);
				if (positionOfLowLabelInPrediction > positionOfHighLabelInPrediction){
					numberOfDiscordantPairs++;
				}
			}
		}
		return numberOfDiscordantPairs;
	}

}
