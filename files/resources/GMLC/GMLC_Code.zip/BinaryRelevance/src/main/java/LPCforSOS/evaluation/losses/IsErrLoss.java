package LPCforSOS.evaluation.losses;

import java.util.List;
/**
 * Calculate the IsErrLoss-Measure. 
 *
 * return 1; If a irrelevant label is ranked higher than a relevant label 
 * return 0; If no irrelevant label is ranked higher than a relevant label
 * 
 * @author George-P. C.F.
 *  
 */
public class IsErrLoss implements IMultilabelRankingLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(List<String> realLabelsOfInstance,
			List<String> descendingRankingOfAllLabels) 
	{
		double result = 0.00;
		
		if(realLabelsOfInstance.isEmpty()) return result;
		
		for(int i = 0, j = 0; i < descendingRankingOfAllLabels.size() && j < realLabelsOfInstance.size(); i++){
			if(!realLabelsOfInstance.contains(descendingRankingOfAllLabels.get(i))){
				return 1.00;
			}
			j++;
		}
		return 0.00;
	}
}