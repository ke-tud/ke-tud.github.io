/**
 */
package LPCforSOS.baseLearner;

/**
 * @author Sandra Ebert
 * 
 * @date 18.07.2008, 11:43:36
 */
public enum BaseLearnerEnvironment {
	WekaBaseLearner,

	SeCoBaseLearner
}
