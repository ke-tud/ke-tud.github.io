package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.HashMap;

import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;

public class MLHierarchyRankingDecomposition extends
		AbstractHierarchyRankingDecomposition {

	private final boolean justLeaves;

	public MLHierarchyRankingDecomposition(PairwiseDecomposer decomposer,
			boolean justLeaves) {
		super(decomposer);
		this.justLeaves = justLeaves;
	}

	@Override
	public void decompose(ExtInstances data) {
		HashMap<Integer, String> numberToClass = new HashMap<Integer, String>();
		for (int i = 0; i < data.getNumberOfClasses(); i++) {
			super.decomposer.getClassToNumber()
					.put(data.getClasses().get(i), i);
			numberToClass.put(i, data.getClasses().get(i));
		}
		ArrayList<ArrayList<Integer>> ways = super.buildWay(data,
				super.decomposer.getClassToNumber());
		// need to know the leaves for creating the classification
		ArrayList<ArrayList<Integer>> compareList = super.buildCompareList(
				data, ways, numberToClass, justLeaves);
		super.buildInstances(data, numberToClass, ways, justLeaves);

		for (ExtInstance extInstance : data.get_Instances()) {
			for (int i = 0; i < super.decomposer.getDecomposedDatasets().size(); i++) {
				Instances sub_Instances = super.decomposer
						.getDecomposedDatasets().get(i);
				String lhs = sub_Instances.classAttribute().value(0);
				String rhs = sub_Instances.classAttribute().value(1);

				int label = -1;
				for (String node : extInstance.getM_Classes()) {
					int distLhs = compareList.get(
							super.decomposer.getClassToNumber().get(lhs)).get(
							super.decomposer.getClassToNumber().get(node));

					int distRhs = compareList.get(
							super.decomposer.getClassToNumber().get(rhs)).get(
							super.decomposer.getClassToNumber().get(node));

					if (distLhs != distRhs) {
						if (distLhs > distRhs) {
							if (label == -1)
								label = 0;
							if (label == 1)
								break;
						} else if (distLhs < distRhs) {
							if (label == -1)
								label = 1;
							if (label == 0)
								break;
						}
					}
				}
				if (label != -1) {
					ExtInstance instance = (ExtInstance) extInstance.copy();
					instance.setValue(extInstance.asWekaInstance()
							.numAttributes() - 1, label);
					// appends the new instance with new class value
					sub_Instances.add(instance);
					instance.asWekaInstance().setDataset(sub_Instances);
				}
			}
		}
	}
}
