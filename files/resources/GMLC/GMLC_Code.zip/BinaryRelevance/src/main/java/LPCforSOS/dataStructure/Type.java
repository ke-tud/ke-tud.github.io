/**
 */
package LPCforSOS.dataStructure;

/**
 * Klassifikationstypen
 * 
 * @author Sandra Ebert
 * 
 * @date 12.12.2007, 15:33:49
 */
public enum Type {
	/**
	 * Multiclass Classification
	 */
	Multiclass,
	/**
	 * Ordinal classification
	 */
	Ordinal,
	/**
	 * Label Ranking Classification with pairwise preferences ( {a<b, c<d} )
	 */
	LabelRankingPairwisePreference,
	/**
	 * Label Ranking Classification with a single preference ( {a} )
	 */
	LabelRankingSinglePreference,
	/**
	 * Multi Label Classification
	 */
	MultiLabel,
	/**
	 * Hierarchical Classification
	 */
	Hierarchy,
	/**
	 * Hierarchical Classification only the leaves
	 */
	HierarchyLeaves,
	/**
	 * Multi Label Hierarchical Classification
	 */
	ML_Hierarchy,
	/**
	 * Multi Label Hierarchical Classification only the leaves
	 */
	ML_HierarchyLeaves,
	/**
	 * Calibrated Label Ranking
	 */
	CalibratedLabelRanking,
	/**
	 * Multi Label Classification with ordinal labels
	 */
	ML_Graded
}
