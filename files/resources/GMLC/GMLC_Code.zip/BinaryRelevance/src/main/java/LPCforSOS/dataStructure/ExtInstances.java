package LPCforSOS.dataStructure;

import java.io.IOException;
import java.io.Reader;
import java.io.StreamTokenizer;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.SparseInstance;
import weka.core.UnassignedClassException;

/**
 * Extended Instances: override readHeader() and getInstanceFull()
 * 
 * @author Jens Huehn (MR), Sandra Ebert (DA), George-P. C.F.
 * 
 * @date 05.12.2007, 17:36:33
 */
public class ExtInstances extends Instances {

	// constants not visible in Intances()
	private static final long serialVersionUID = -6815577831543125376L;

	/** The keyword used to denote the start of an arff header */
	protected static String ARFF_RELATION = "@relation";

	/** The keyword used to denote the start of the arff data section */
	protected static String ARFF_DATA = "@data";

	/** The keyword used to denote the start of an arff attribute declaration */
	public final static String ARFF_ATTRIBUTE = "@attribute";

	/** A keyword used to denote a numeric attribute */
	public final static String ARFF_ATTRIBUTE_INTEGER = "integer";

	/** A keyword used to denote a numeric attribute */
	public final static String ARFF_ATTRIBUTE_REAL = "real";

	/** A keyword used to denote a numeric attribute */
	public final static String ARFF_ATTRIBUTE_NUMERIC = "numeric";

	/** The keyword used to denote a string attribute */
	public final static String ARFF_ATTRIBUTE_STRING = "string";

	/** The keyword used to denote a date attribute */
	public final static String ARFF_ATTRIBUTE_DATE = "date";

	/** Klassifikationstyp */
	protected Type type;

	/**
	 * Classes f�r the decomposition
	 * 
	 */
	protected List<String> classes;

	/**
	 * Grades for the decomposition used by MultiLabelOrdinal
	 */
	private List<String> grades;

	/**
	 * List of possible classes, and if available, then their relations with
	 * each other such as <, >, !, = and so on LabelRanking: a,b,c,.. Hierarchy:
	 * a<b, b<c, b!e,...
	 */
	protected ArrayList<String> classInformation;

	/**
	 * List of possible grades and their relations with each other such as <, >
	 * , !, = and only used in MultiLabelOrdinal: a < b < c
	 */
	private ArrayList<String> gradeInformation;

	/**
	 * List of side constraints, such as minimum cardinality of ML
	 */
	protected String constraints;

	protected/* @spec_public non_null@ */ArrayList<ExtInstance> ext_Instances;

	private List<List<String>> testSetClasses;

	/**
	 * When testset was build this list is filled with the total ordered labels
	 * of the test instances
	 */
	private List<List<String>> testSetTotalOrderOfClasses;

	private int classInfoIndex;

	/**
	 * Constructor
	 * 
	 * @param reader
	 * @throws IOException
	 */
	public ExtInstances(Reader reader) throws IOException {
		super(reader);
	}

	/**
	 * Constructor creating an empty set of instances. Copies references to the
	 * header information from the given set of instances. Sets the capacity of
	 * the set of instances to 0 if its negative.
	 * 
	 * @param dataset
	 *            the instances from which the header information is to be taken
	 * @param capacity
	 *            the capacity of the new dataset
	 */
	public ExtInstances(/* @non_null@ */ExtInstances dataset, int capacity) {
		super(dataset, capacity);
		initialize(dataset, capacity);
	}

	/**
	 * initializes with the header information of the given dataset and sets the
	 * capacity of the set of instances.
	 * 
	 * @param dataset
	 *            the dataset to use as template
	 * @param capacity
	 *            the number of rows to reserve
	 */
	protected void initialize(ExtInstances dataset, int capacity) {
		if (capacity < 0)
			capacity = 0;

		// Strings only have to be "shallow" copied because
		// they can't be modified.
		m_ClassIndex = dataset.numAttributes() - 1;
		m_RelationName = dataset.m_RelationName;
		m_Attributes = dataset.m_Attributes;
		classes = dataset.classes;
		grades = dataset.grades;
		constraints = dataset.constraints;
		type = dataset.type;
		ext_Instances = new ArrayList<ExtInstance>();
	}

	/**
	 * Reads the header, although last line with additional information is
	 * parsed separately
	 * 
	 * @param tokenizer
	 * @throws IOException
	 */
	@Override
	protected void readHeader(StreamTokenizer tokenizer) throws IOException {
		String attributeName;
		FastVector attributeValues;
		classes = new ArrayList<String>();
		ext_Instances = new ArrayList<ExtInstance>();

		// Get name of relation.
		getFirstToken(tokenizer);

		if (tokenizer.ttype == StreamTokenizer.TT_EOF) {
			errms(tokenizer, "premature end of file");
		}

		if (ARFF_RELATION.equalsIgnoreCase(tokenizer.sval)) {
			getNextToken(tokenizer);
			m_RelationName = tokenizer.sval;
			getLastToken(tokenizer, false);
		} else {
			errms(tokenizer, "keyword " + ARFF_RELATION + " expected");
		}

		// Create vectors to hold information temporarily.
		// m_Attributes = new ArrayList<Attribute>();
		m_Attributes = new FastVector();

		// Get attribute declarations.
		getFirstToken(tokenizer);

		if (tokenizer.ttype == StreamTokenizer.TT_EOF) {
			errms(tokenizer, "premature end of file");
		}

		while (ARFF_ATTRIBUTE.equalsIgnoreCase(tokenizer.sval)) {
			// Get attribute name.
			getNextToken(tokenizer);
			attributeName = tokenizer.sval;
			getNextToken(tokenizer);

			// Check if attribute is nominal.
			if (tokenizer.ttype == StreamTokenizer.TT_WORD) {
				// Attribute is real, integer, or string.
				if (tokenizer.sval.equalsIgnoreCase(ARFF_ATTRIBUTE_REAL)
						|| tokenizer.sval
								.equalsIgnoreCase(ARFF_ATTRIBUTE_INTEGER)
						|| tokenizer.sval
								.equalsIgnoreCase(ARFF_ATTRIBUTE_NUMERIC)) {
					m_Attributes.addElement(new Attribute(attributeName));
					readTillEOL(tokenizer);
				} else if (tokenizer.sval
						.equalsIgnoreCase(ARFF_ATTRIBUTE_STRING)) {
					m_Attributes.addElement(new Attribute(attributeName));
					readTillEOL(tokenizer);
				} else if (tokenizer.sval.equalsIgnoreCase(ARFF_ATTRIBUTE_DATE)) {
					String format = null;

					if (tokenizer.nextToken() != StreamTokenizer.TT_EOL) {
						if ((tokenizer.ttype != StreamTokenizer.TT_WORD)
								&& (tokenizer.ttype != '\'')
								&& (tokenizer.ttype != '\"')) {
							errms(tokenizer, "not a valid date format");
						}

						format = tokenizer.sval;
						readTillEOL(tokenizer);
					} else {
						tokenizer.pushBack();
					}

					m_Attributes
							.addElement(new Attribute(attributeName, format));
				} else {
					errms(tokenizer, "no valid attribute type or invalid "
							+ "enumeration");
				}
			} else {
				// Attribute is nominal.
				attributeValues = new FastVector();
				tokenizer.pushBack();

				// Get values for nominal attribute.
				int token = tokenizer.nextToken();

				if (token == '{') {
					// Get values for nominal attribute
					while (tokenizer.nextToken() != '}') {
						if (tokenizer.ttype == StreamTokenizer.TT_EOL) {
							errms(tokenizer, "} expected at end of enumeration");
						} else {
							attributeValues.addElement(tokenizer.sval);
						}
					}

					if (attributeValues.size() == 0) {
						errms(tokenizer, "no nominal values found");
					}

					m_Attributes.addElement(new Attribute(attributeName,
							attributeValues));
				} else if (token == '[') {
					classInfoIndex = m_Attributes.size();

					// read multi label classes
					classInformation = new ArrayList<String>();

					// classification type
					tokenizer.nextToken();
					type = Type.valueOf(tokenizer.sval);
					tokenizer.nextToken();

					// class informations
					int splitPoint = -1;
					while (tokenizer.nextToken() != '|') {
						if (tokenizer.ttype == StreamTokenizer.TT_EOL) {
							errms(tokenizer, "] expected at end of enumeration");
						} else if (tokenizer.sval.equals("�")) {
							splitPoint = this.classes.size();
						} else {
							classInformation.add(tokenizer.sval);
							Pattern p = Pattern.compile("[<>!=]");
							String[] m_class = p.split(tokenizer.sval);

							for (String c : m_class) {
								if (!classes.contains(c)) {
									classes.add(c);
								}
							}
						}
					}

					if (splitPoint >= 0) {
						ArrayList<String> tmp = new ArrayList<String>(classes);
						classes.clear();
						grades = tmp.subList(splitPoint, tmp.size());
						for (int i = splitPoint; i < tmp.size(); i++) {
							for (int j = 0; j < splitPoint; j++) {
								String classWithGrade = tmp.get(j) + tmp.get(i);
								if (!classes.contains(classWithGrade))
									classes.add(classWithGrade);
							}
						}
					}

					// constraints
					tokenizer.nextToken();
					constraints = tokenizer.sval;

					tokenizer.nextToken();

					// insert additional attribute for class in the real
					// instance
					// m_Attributes.addElement(new Attribute("class"));
				} else {
					errms(tokenizer,
							"{ or [ expected at beginning of enumeration");
				}
			}

			getLastToken(tokenizer, false);
			getFirstToken(tokenizer);

			if (tokenizer.ttype == StreamTokenizer.TT_EOF) {
				errms(tokenizer, "premature end of file");
			}
		}

		// Check if data part follows. We can't easily check for EOL.
		if (!ARFF_DATA.equalsIgnoreCase(tokenizer.sval)) {
			errms(tokenizer, "keyword " + ARFF_DATA + " expected");
		}

		// Check if any attributes have been declared.
		if (m_Attributes.size() == 0) {
			errms(tokenizer, "no attributes declared");
		}

		// Allocate buffers in case sparse instances have to be read
		m_ValueBuffer = new double[numAttributes() + 1];
		m_IndicesBuffer = new int[numAttributes() + 1];
		// Make the last attribute be the class
		m_ClassIndex = numAttributes() - 1;

		/** TODO: Klassenattribut m�sste eigentlich noch angef�gt werden */
		// m_Attributes.addElement(new Attribute("class"));
	}

	/**
	 * Initializes the StreamTokenizer used for reading the ARFF file.
	 * 
	 * @param tokenizer
	 *            the stream tokenizer
	 */
	@Override
	protected void initTokenizer(StreamTokenizer tokenizer) {
		tokenizer.resetSyntax();
		tokenizer.whitespaceChars(0, ' ');
		tokenizer.wordChars(' ' + 1, '\u00FF');
		tokenizer.whitespaceChars(',', ',');
		tokenizer.commentChar('%');
		tokenizer.quoteChar('"');
		tokenizer.quoteChar('\'');
		tokenizer.ordinaryChar('{');
		tokenizer.ordinaryChar('}');
		tokenizer.ordinaryChar('[');
		tokenizer.ordinaryChar(']');
		tokenizer.ordinaryChar('|');
		tokenizer.eolIsSignificant(true);

	}

	public List<String> getGrades() {
		return grades;
	}

	public void setGrades(List<String> grades) {
		this.grades = grades;
	}

	public void setClasses(List<String> classes) {
		this.classes = classes;
	}

	/**
	 * Reads a single instance using the tokenizer and appends it to the
	 * dataset. Automatically expands the dataset if it is not large enough to
	 * hold the instance.
	 * 
	 * @param tokenizer
	 *            the tokenizer to be used
	 * @param flag
	 *            if method should test for carriage return after each instance
	 * @return false if end of file has been reached
	 * @exception IOException
	 *                if the information is not read successfully
	 */
	@Override
	protected boolean getInstanceFull(StreamTokenizer tokenizer, boolean flag)
			throws IOException {
		// additional column for single class in decomposed datasets
		double[] instance = new double[numAttributes() + 1];
		int index;

		// Get values for all attributes.
		for (int i = 0; i < numAttributes(); i++) {
			// Get next token
			if (i > 0) {
				getNextToken(tokenizer);
			}

			// Check if value is missing.
			if (tokenizer.ttype == '?') {
				instance[i] = Instance.missingValue();
			} else {
				// Check if token is valid.
				if (tokenizer.ttype != StreamTokenizer.TT_WORD) {
					errms(tokenizer, "not a valid value");
				}

				switch (attribute(i).type()) {
				case Attribute.NOMINAL:
					// Check if value appears in header.
					index = attribute(i).indexOfValue(tokenizer.sval);

					if (index == -1) {
						errms(tokenizer, "nominal value not declared in header");
					}

					instance[i] = index;

					break;

				case Attribute.NUMERIC:

					// Check if value is really a number.
					try {
						instance[i] = Double.valueOf(tokenizer.sval)
								.doubleValue();
					} catch (NumberFormatException e) {
						errms(tokenizer, "number expected");
					}

					break;

				case Attribute.STRING:
					instance[i] = attribute(i).addStringValue(tokenizer.sval);

					break;

				case Attribute.DATE:

					try {
						instance[i] = attribute(i).parseDate(tokenizer.sval);
					} catch (ParseException e) {
						errms(tokenizer, "unparseable date: " + tokenizer.sval);
					}

					break;

				default:
					errms(tokenizer, "unknown attribute type in column " + i);
				}
			}
		}

		// read last column with multilabel classes
		getNextToken(tokenizer);

		// GPCF: MultiLabelRanking extracting total order of labels
		ArrayList<String> totalOrder = null;
		if (tokenizer.ttype == '[') {
			tokenizer.nextToken();
			totalOrder = getLabelRankingTotalOrderPreferences(tokenizer.sval);
			tokenizer.nextToken();
			tokenizer.nextToken();
		}
		// GPCF: End

		ArrayList<String> m_classes = new ArrayList<String>();

		while (tokenizer.nextToken() != '}') {
			if (tokenizer.sval == null)
				continue;
			Pattern p = Pattern.compile("[<>]");
			String[] classes = p.split(tokenizer.sval);
			for (String c : classes) {
				m_classes.add(c);
			}
		}

		if (flag) {
			getLastToken(tokenizer, true);
		}

		// Add instance to dataset
		ExtInstance tmp_extInstance = new ExtInstance(
				new Instance(1, instance), m_classes);
		tmp_extInstance.setLabelRankingTotalOrderOfLabels(totalOrder);
		add(tmp_extInstance);

		return true;
	}

	@Override
	protected boolean getInstanceSparse(StreamTokenizer tokenizer, boolean flag)
			throws IOException {

		int valIndex, numValues = 0, maxIndex = -1;
		ArrayList<String> m_classes = new ArrayList<String>();

		// Get values
		do {

			// Get index
			getIndex(tokenizer);
			if (tokenizer.ttype == '}') {
				break;
			}

			// Is index valid?
			try {
				m_IndicesBuffer[numValues] = Integer.valueOf(tokenizer.sval)
						.intValue();
			} catch (NumberFormatException e) {
				errms(tokenizer, "index number expected");
			}
			if (m_IndicesBuffer[numValues] <= maxIndex) {
				errms(tokenizer, "indices have to be ordered");
			}
			if ((m_IndicesBuffer[numValues] < 0)
					|| (m_IndicesBuffer[numValues] >= numAttributes() + 1)) {
				errms(tokenizer, "index out of bounds");
			}
			maxIndex = m_IndicesBuffer[numValues];

			if (m_IndicesBuffer[numValues] == classInfoIndex) {
				// TODO do some work here
				getNextToken(tokenizer);
				while (tokenizer.nextToken() != '}') {
					m_classes.add(tokenizer.sval);
				}
			} else {

				// Get value;
				getNextToken(tokenizer);

				// Check if value is missing.
				if (tokenizer.ttype == '?') {
					m_ValueBuffer[numValues] = Instance.missingValue();
				} else {

					// Check if token is valid.
					if (tokenizer.ttype != StreamTokenizer.TT_WORD) {
						errms(tokenizer, "not a valid value");
					}
					switch (attribute(m_IndicesBuffer[numValues]).type()) {
					case Attribute.NOMINAL:
						// Check if value appears in header.
						valIndex = attribute(m_IndicesBuffer[numValues])
								.indexOfValue(tokenizer.sval);
						if (valIndex == -1) {
							errms(tokenizer,
									"nominal value not declared in header");
						}
						m_ValueBuffer[numValues] = valIndex;
						break;
					case Attribute.NUMERIC:
						// Check if value is really a number.
						try {
							m_ValueBuffer[numValues] = Double.valueOf(
									tokenizer.sval).doubleValue();
						} catch (NumberFormatException e) {
							errms(tokenizer, "number expected");
						}
						break;
					case Attribute.STRING:
						m_ValueBuffer[numValues] = attribute(
								m_IndicesBuffer[numValues]).addStringValue(
								tokenizer.sval);
						break;
					case Attribute.DATE:
						try {
							m_ValueBuffer[numValues] = attribute(
									m_IndicesBuffer[numValues]).parseDate(
									tokenizer.sval);
						} catch (ParseException e) {
							errms(tokenizer, "unparseable date: "
									+ tokenizer.sval);
						}
						break;
					default:
						errms(tokenizer, "unknown attribute type in column "
								+ m_IndicesBuffer[numValues]);
					}
				}
			}
			numValues++;
		} while (true);

		// read last column with multilabel classes
		getNextToken(tokenizer);

		// GPCF: MultiLabelRanking extracting total order of labels
		ArrayList<String> totalOrder = null;
		if (tokenizer.ttype == '[') {
			tokenizer.nextToken();
			totalOrder = getLabelRankingTotalOrderPreferences(tokenizer.sval);
			tokenizer.nextToken();
			tokenizer.nextToken();
		}
		// GPCF: End

		m_classes = new ArrayList<String>();

		while (tokenizer.nextToken() != '}') {
			if (tokenizer.sval == null)
				continue;
			Pattern p = Pattern.compile("[<>]");
			String[] classes = p.split(tokenizer.sval);
			for (String c : classes) {
				if(c.equals("")){
					continue;
				}
				m_classes.add(c);
			}
		}

		if (flag) {
			getLastToken(tokenizer, true);
		}

		// Add instance to dataset
		double[] tempValues = new double[numValues];
		int[] tempIndices = new int[numValues];
		System.arraycopy(m_ValueBuffer, 0, tempValues, 0, numValues);
		System.arraycopy(m_IndicesBuffer, 0, tempIndices, 0, numValues);
		ExtInstance tmp_extInstance = new ExtInstance(new SparseInstance(1,
				tempValues, tempIndices, numAttributes() + 1), m_classes);
		// tmp_extInstance.setLabelRankingTotalOrderOfLabels(totalOrder);
		add(tmp_extInstance);
		return true;
	}

	/**
	 * @param sval
	 */
	protected ArrayList<String> getLabelRankingTotalOrderPreferences(String sval) {
		ArrayList<String> labelRankingTotalOrderOfLabels = new ArrayList<String>();
		String[] totalOrder = sval.split("<");
		for (int i = 0; i < totalOrder.length; i++) {
			labelRankingTotalOrderOfLabels.add(totalOrder[i]);
		}
		return labelRankingTotalOrderOfLabels;
	}

	/**
	 * Adds one instance to the end of the set. Shallow copies instance before
	 * it is added. Increases the size of the dataset if it is not large enough.
	 * Does not check if the instance is compatible with the dataset.
	 * 
	 * @param extInstance
	 *            the instance to be added
	 * 
	 */
	public void add( /* @non_null@ */
	ExtInstance extInstance) {
		ExtInstance newInstance = (ExtInstance) extInstance.copy();
		newInstance.setDataset(this);

		ext_Instances.add(newInstance);
		// m_Instances.addElement(newInstance);
	}

	/**
	 * Creates the training set for one fold of a cross-validation on the
	 * dataset.
	 * 
	 * @param numFolds
	 *            the number of folds in the cross-validation. Must be greater
	 *            than 1.
	 * @param numFold
	 *            0 for the first fold, 1 for the second, ...
	 * @return the training set
	 * @throws IllegalArgumentException
	 *             if the number of folds is less than 2 or greater than the
	 *             number of instances.
	 */
	// @ requires 2 <= numFolds && numFolds < numInstances();
	// @ requires 0 <= numFold && numFold < numFolds;
	@Override
	public ExtInstances trainCV(int numFolds, int numFold) {

		int numInstForFold, first, offset;
		ExtInstances train;

		if (numFolds < 2) {
			throw new IllegalArgumentException(
					"Number of folds must be at least 2!");
		}
		if (numFolds > numInstances()) {
			throw new IllegalArgumentException(
					"Can't have more folds than instances!");
		}
		numInstForFold = numInstances() / numFolds;
		if (numFold < numInstances() % numFolds) {
			numInstForFold++;
			offset = numFold;
		} else
			offset = numInstances() % numFolds;
		train = new ExtInstances(this, numInstances() - numInstForFold);
		first = numFold * (numInstances() / numFolds) + offset;
		copyInstances(0, train, first);
		copyInstances(first + numInstForFold, train, numInstances() - first
				- numInstForFold);

		train.classInformation = this.classInformation;
		return train;
	}

	/**
	 * Creates the training set for one fold of a cross-validation on the
	 * dataset. The data is subsequently randomized based on the given random
	 * number generator.
	 * 
	 * @param numFolds
	 *            the number of folds in the cross-validation. Must be greater
	 *            than 1.
	 * @param numFold
	 *            0 for the first fold, 1 for the second, ...
	 * @param random
	 *            the random number generator
	 * @return the training set
	 * @throws IllegalArgumentException
	 *             if the number of folds is less than 2 or greater than the
	 *             number of instances.
	 */
	// @ requires 2 <= numFolds && numFolds < numInstances();
	// @ requires 0 <= numFold && numFold < numFolds;
	@Override
	public ExtInstances trainCV(int numFolds, int numFold, Random random) {

		ExtInstances train = trainCV(numFolds, numFold);
		train.randomize(random);
		return train;
	}

	/**
	 * Constructor copying all instances and references to the header
	 * information from the given set of instances.
	 * 
	 * @param dataset
	 *            the set to be copied
	 */
	public ExtInstances(/* @non_null@ */ExtInstances dataset) {

		this(dataset, dataset.numInstances());

		dataset.copyInstances(0, this, dataset.numInstances());

		this.classInformation = dataset.classInformation;
		this.gradeInformation = dataset.gradeInformation;
	}

	/**
	 * Creates the test set for one fold of a cross-validation on the dataset.
	 * 
	 * @param numFolds
	 *            the number of folds in the cross-validation. Must be greater
	 *            than 1.
	 * @param numFold
	 *            0 for the first fold, 1 for the second, ...
	 * @param testClasses
	 *            to classify, if empty algorithm use classes from file
	 * @return the test set as a set of weighted instances
	 * @throws IllegalArgumentException
	 *             if the number of folds is less than 2 or greater than the
	 *             number of instances. // @ requires 2 <= numFolds && numFolds
	 *             < numInstances(); // @ requires 0 <= numFold && numFold <
	 *             numFolds;
	 * 
	 */
	public Instances testCV(int numFolds, int numFold, Set<String> testClasses) {

		testSetClasses = new ArrayList<List<String>>();
		testSetTotalOrderOfClasses = new ArrayList<List<String>>();

		int numInstForFold, first, offset;
		Instances test;

		if (numFolds < 2) {
			throw new IllegalArgumentException(
					"Number of folds must be at least 2!");
		}
		if (numFolds > numInstances()) {
			throw new IllegalArgumentException(
					"Can't have more folds than instances!");
		}
		numInstForFold = numInstances() / numFolds;
		if (numFold < numInstances() % numFolds) {
			numInstForFold++;
			offset = numFold;
		} else
			offset = numInstances() % numFolds;

		FastVector attributes = (FastVector) this.get_Attributes()
				.copyElements();
		FastVector labels = new FastVector();
		// use classes from file
		if (testClasses.size() == 0) {
			for (String item : classes) {
				labels.addElement(item);
			}
		} else {
			for (String item : testClasses) {
				labels.addElement(item);
			}
		}
		attributes.addElement(new Attribute("class", labels));

		String sub_relation = this.relationName() + "_test";
		test = new Instances(sub_relation, attributes, numInstForFold);

		first = numFold * (numInstances() / numFolds) + offset;
		copyInstances(first, test, numInstForFold);
		test.setClassIndex(this.numAttributes());
		return test;
	}

	/**
	 * Copies instances from one set to the end of another one.
	 * 
	 * @param from
	 *            the position of the first instance to be copied
	 * @param dest
	 *            the destination for the instances
	 * @param num
	 *            the number of instances to be copied
	 */
	// @ requires 0 <= from && from <= numInstances() - num;
	// @ requires 0 <= num;
	protected void copyInstances(int from, /* @non_null@ */ExtInstances dest,
			int num) {

		for (int i = 0; i < num; i++) {
			dest.add(extInstance(from + i));
		}
	}

	/**
	 * Copies instances from one set to the end of another one.
	 * 
	 * @param from
	 *            the position of the first instance to be copied
	 * @param dest
	 *            the destination for the instances
	 * @param num
	 *            the number of instances to be copied
	 */
	// @ requires 0 <= from && from <= numInstances() - num;
	// @ requires 0 <= num;
	@Override
	protected void copyInstances(int from, /* @non_null@ */Instances dest,
			int num) {

		for (int i = 0; i < num; i++) {
			dest.add(instance(from + i, dest));
		}

	}

	/**
	 * Returns the instance at the given position.
	 * 
	 * @param index
	 *            the instance's index (index starts with 0)
	 * @return the instance at the given position
	 */
	// @ requires 0 <= index;
	// @ requires index < numInstances();
	public/* @non_null pure@ */ExtInstance extInstance(int index) {

		return ext_Instances.get(index);
	}

	/**
	 * Returns the instance at the given position.
	 * 
	 * @param index
	 *            the instance's index (index starts with 0)
	 * @return the instance at the given position
	 */
	// @ requires 0 <= index;
	// @ requires index < numInstances();
	public/* @non_null pure@ */Instance instance(int index, Instances test) {
		double[] attValue = ext_Instances.get(index).getM_AttValues().clone();
		Instance instance = new Instance(1, attValue);
		instance.setDataset(test);
		instance.dataset().setClassIndex(instance.numAttributes() - 1);

		//
		testSetClasses.add(ext_Instances.get(index).getM_Classes());
		testSetTotalOrderOfClasses.add(ext_Instances.get(index)
				.getLabelRankingTotalOrderOfLabels());
		return instance;
	}

	/**
	 * Adds one instance to the end of the set. Shallow copies instance before
	 * it is added. Increases the size of the dataset if it is not large enough.
	 * Does not check if the instance is compatible with the dataset. Note:
	 * String or relational values are not transferred.
	 * 
	 * @param instance
	 *            the instance to be added
	 */
	@Override
	public void add(/* @non_null@ */Instance instance) {

		ExtInstance newInstance = (ExtInstance) instance.copy();

		newInstance.setDataset(this);
		ext_Instances.add(newInstance);
	}

	/**
	 * Returns the number of instances in the dataset.
	 * 
	 * @return the number of instances in the dataset as an integer
	 */
	// @ ensures \result == m_Instances.size();
	@Override
	public/* @pure@ */int numInstances() {

		return ext_Instances.size();
	}

	/**
	 * @return the type
	 */
	public Type getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(Type type) {
		this.type = type;
	}

	/**
	 * @return the classInformation
	 */
	public ArrayList<String> getClassInformation() {
		return classInformation;
	}

	/**
	 * @return the gradeInformation
	 */
	public ArrayList<String> getGradeInformation() {
		return gradeInformation;
	}

	/**
	 * @param classInformation
	 *            the classInformation to set
	 */
	public void setClassInformation(ArrayList<String> classInformation) {
		this.classInformation = classInformation;
	}

	/**
	 * @param gradeInformation
	 *            the new classInformation
	 */
	public void setGradeInformation(ArrayList<String> gradeInformation) {
		this.gradeInformation = gradeInformation;
	}

	/**
	 * @return the constraints
	 */
	public String getConstraints() {
		return constraints;
	}

	/**
	 * @param constraints
	 *            the constraints to set
	 */
	public void setConstraints(String constraints) {
		this.constraints = constraints;
	}

	/**
	 * @return number of classes
	 */
	public int getNumberOfClasses() {
		return this.classes.size();
	}

	/**
	 * @return the m_Attributes
	 */
	public FastVector get_Attributes() {
		return m_Attributes;
	}

	/**
	 * @return m_Instances
	 */
	public ArrayList<ExtInstance> get_Instances() {
		return ext_Instances;
	}

	/**
	 * @return the classes
	 */
	public List<String> getClasses() {
		return classes;
	}

	/**
	 * @return the testSetClasses
	 */
	public List<List<String>> getTestSetClasses() {
		return testSetClasses;
	}

	public List<List<String>> getTestSetTotalOrderOfClasses() {
		return this.testSetTotalOrderOfClasses;
	}
	
	public void setTestSetTotalOrderOfClasses(List<List<String>> testSetTotalOrderOfClasses) {
		this.testSetTotalOrderOfClasses = testSetTotalOrderOfClasses;
	}

	/**
	 * @param testSetClasses
	 *            the testSetClasses to set
	 */
	public void setTestSetClasses(List<List<String>> testSetClasses) {
		this.testSetClasses = testSetClasses;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see weka.core.Instances#stratify(int)
	 */
	@Override
	public void stratify(int numFolds) {
		if (numFolds <= 0) {
			throw new IllegalArgumentException(
					"Number of folds must be greater than 1");
		}
		if (m_ClassIndex < 0) {
			throw new UnassignedClassException(
					"Class index is negative (not set)!");
		}
		if (classAttribute().isNominal()) {
			// sort by class
			int index = 1;
			while (index < numInstances()) {
				ExtInstance instance1 = extInstance(index - 1);
				for (int j = index; j < numInstances(); j++) {
					ExtInstance instance2 = extInstance(j);
					// if ((instance1.classValue() == instance2.classValue()) ||
					// (instance1.classIsMissing() &&
					// instance2.classIsMissing())) {
					if (instance1.m_Classes.get(0).equals(
							instance2.m_Classes.get(0))) {
						swap(index, j);
						index++;
					}
				}
				index++;
			}
			stratStep(numFolds);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see weka.core.Instances#stratStep(int)
	 */
	@Override
	protected void stratStep(int numFolds) {
		ArrayList<ExtInstance> newVec = new ArrayList<ExtInstance>(
				ext_Instances.size());
		int start = 0, j;

		// create stratified batch
		while (newVec.size() < numInstances()) {
			j = start;
			while (j < numInstances()) {
				newVec.add(extInstance(j));
				j = j + numFolds;
			}
			start++;
		}
		ext_Instances = newVec;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see weka.core.Instances#swap(int, int)
	 */
	@Override
	public void swap(int i, int j) {
		ExtInstance ei = ext_Instances.get(i);
		ExtInstance ej = ext_Instances.get(j);
		ext_Instances.set(i, ej);
		ext_Instances.set(j, ei);
	}

	public List<String> getLabelGrades() {
		return this.grades;
	}

	public int getNumberOfGrades() {
		return this.grades.size();
	}

}
