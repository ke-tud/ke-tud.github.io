package LPCforSOS.dataStructure;


import weka.classifiers.evaluation.ConfusionMatrix;
import weka.classifiers.evaluation.TwoClassStats;

/**
 * Erweiterung nur wegen vereinfachtem Konstruktor.
 * Alle anderen Spezifikationen siehe Oberklasse TwoClassStats.
 * 
 * @author George-P. C.F.
 *  
 */
public class TwoClassConfusionMatrix extends TwoClassStats{
	
	public TwoClassConfusionMatrix(TwoClassStats confusionMatrix){
		super(confusionMatrix.getTruePositive(), confusionMatrix.getFalsePositive(), confusionMatrix.getTrueNegative(), confusionMatrix.getFalseNegative());
	}
	
	@SuppressWarnings("deprecation")
	public TwoClassConfusionMatrix(ConfusionMatrix confusionMatrix){
		super(confusionMatrix.getElement(1, 1), confusionMatrix.getElement(0, 1), confusionMatrix.getElement(0, 0), confusionMatrix.getElement(1, 0));
//		double TP = confusionMatrix.getElement(1, 1);
//		double FP = confusionMatrix.getElement(0, 1);
//		double FN = confusionMatrix.getElement(1, 0);
//		double TN = confusionMatrix.getElement(0, 0);
	}
	
	public TwoClassConfusionMatrix(double tp, double fp, double tn, double fn){
		super(tp,fp,tn,fn);
	}
	
//	/**
//	 * Berechnet die true positives, false positives, true negatives und false negatives.
//	 * @param relevantLabelsOfInstance Eine Liste von allen Labels die dieser Instanz zugeordnet sind.
//	 * @param preditionOfAllLabels Die Einzelwertung f�r jedes Label.
//	 * @param relevanceBounds Der Grenzwert f�r die Zuordung zu Menge der Vorhergesagten Labels.
//	 */
//	public void calculateConfusionMatrix(ArrayList<String> relevantLabelsOfInstance, HashMap<String, Double> preditionOfAllLabels, double relevanceBound)
//	{
//		double TP, FP, TN, FN;
//		TP = FP = TN = FN = 0;
//		
//		for(String rankedLabel : preditionOfAllLabels.keySet()){
//			boolean real = relevantLabelsOfInstance.contains(rankedLabel);
//			boolean predicted=(relevanceBound<=preditionOfAllLabels.get(rankedLabel));
//			
//			if(real && predicted) 
//				TP++;
//			else if(real && !predicted) 
//				FN++;
//			else if(!real && predicted) 
//				FP++;
//			else //if(!real && !predicted)
//				TN++;
//		}
//		this.setTruePositive(TP);
//		this.setFalseNegative(FN);
//		this.setFalsePositive(FP);
//		this.setTrueNegative(TN);
//	}
}
