package LPCforSOS.decomposition;

/**
 * @author Sandra Ebert
 * 
 * @date 04.03.2008, 15:54:51
 */
public enum DecompositionType {

	/**
	 * Two classes are combined in pairs. Examples of both classes or none of
	 * them will be omitted. c(c-1)/2 subproblems
	 */
	PairwiseDecomposer,

	/** Each class against all other classes: c subproblems */
	OneAgainstAllDecomposer,

	/** Ranking determines how important the respective classes for the example. */
	TopicRankingDecomposer,

	/**
	 * Reinforcement Learning: For each class, only the most important examples
	 * were selected.
	 */
	ReinforcementLearningDecomposer

}
