/**
 * 
 */
package LPCforSOS.evaluation.losses;

import weka.classifiers.evaluation.ConfusionMatrix;

/**
 * @author Christian Brinker
 *
 */
public class VerticalHammingDistanceLoss implements OMConfusionMatrixBasedLossFunction{ 
//	/* (non-Javadoc)
//	 * @see LPCforSOS.evaluation.losses.OMConfusionMatrixBasedLossFunction#calculateLoss(weka.classifiers.evaluation.ConfusionMatrix, int)
//	 */
//	@SuppressWarnings("deprecation")
//	public double calculateLoss(ConfusionMatrix matrix, int numOfLabels){
//		int numOfGrades = matrix.numRows() / numOfLabels;
//		double loss = 0.0D;
//		int sum = 0;
//		for (int i = 0; i < matrix.numRows(); i++) {
//			for (int j = 0; j < matrix.numColumns(); j++) {
//				double element = matrix.getElement(i, j);
//				sum += element;
//				
//				if(i!=j) loss += Math.abs(i-j)*element/numOfLabels;
//			}
//		}
//		return loss / (sum * numOfGrades);
//	}
	
	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.OMConfusionMatrixBasedLossFunction#calculateLoss(weka.classifiers.evaluation.ConfusionMatrix, int)
	 */
	@SuppressWarnings("deprecation")
	public double calculateLoss(ConfusionMatrix matrix, int numOfLabels){
		int numOfGrades = matrix.numRows() / numOfLabels;
		double loss = 0.0D;
		int sum = 0;
		for (int i = 0; i < matrix.numRows(); i++) {
			for (int j = 0; j < matrix.numColumns(); j++) {
				double element = matrix.getElement(i, j);
				sum += element;
				
				if(i!=j) loss += Math.abs(i-j)*element/((double)((numOfGrades - 1) * numOfLabels));
			}
		}
		return loss / sum;
	}
}
