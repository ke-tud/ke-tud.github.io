/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.List;

/**
 * Dieses Interface wird von allen Klassen implementiert 
 * die Loss Funktionen f�r Multilabel Klassifikations Probleme
 * implementieren, bei denen es explizit auf das Ranking ankommt.
 * 
 * @author George-P. C.F.
 */
public interface IMultilabelRankingLossFunction {
	/**
	 * Gibt den Fehler im Ranking je nach Funktion zurueck. 
	 * @param relevantLabelsOfInstance Eine Liste von allen Labels die dieser Instanz zugeordnet sind.
	 * @param descendingRankingOfAllLabels Eine ihrer Relevanz entsprechend absteigend sortierte Liste aller Labels
	 * @return double
	 */
	public double calculateLossFunction(List<String> relevantLabelsOfInstance, List<String> descendingRankingOfAllLabels);
}
