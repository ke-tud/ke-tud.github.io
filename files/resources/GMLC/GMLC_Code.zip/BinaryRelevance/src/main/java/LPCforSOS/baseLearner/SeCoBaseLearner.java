/**
 */
package LPCforSOS.baseLearner;

import LPCforSOS.dataStructure.Models;

/**
 * @author Sandra Ebert
 * 
 * @date 28.06.2008, 13:35:25
 */
public class SeCoBaseLearner extends DecomposedDatasetLearner {

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.baseLearner.DecomposedDatasetLearner#buildClassifiers(java.util.ArrayList,
	 *      java.lang.String, boolean)
	 */
	@Override
	public void buildClassifiers(String classifierName) throws Exception {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.baseLearner.DecomposedDatasetLearner#loadClassifiers(LPCforSOS.dataStructure.Models)
	 */
	@Override
	public void loadClassifiers(Models model) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.baseLearner.DecomposedDatasetLearner#saveClassifiers(LPCforSOS.dataStructure.Models)
	 */
	@Override
	public void saveClassifiers(Models model) {
		// TODO Auto-generated method stub

	}

}
