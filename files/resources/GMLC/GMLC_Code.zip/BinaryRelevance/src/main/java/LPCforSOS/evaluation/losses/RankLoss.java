package LPCforSOS.evaluation.losses;

import java.util.List;

public interface RankLoss {

	double calculateLoss(List<List<String>> relevantLabels,
			List<double[]> voteVector, List<String> votedStrings);

}
