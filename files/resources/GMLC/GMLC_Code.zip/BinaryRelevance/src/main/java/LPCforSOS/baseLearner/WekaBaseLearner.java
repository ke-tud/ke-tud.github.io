/**
 */
package LPCforSOS.baseLearner;

import java.util.ArrayList;
import java.util.Random;

import LPCforSOS.dataStructure.Models;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.Instances;

/**
 * @author Sandra Ebert
 * 
 * @date 28.06.2008, 13:02:36
 */
public class WekaBaseLearner extends DecomposedDatasetLearner {

	@Override
	public void buildClassifiers(String classifierName) throws Exception {

		baseClassifier = new ArrayList<Classifier>();
		int numFolds = 10;

		for (Instances instances : this.getDecomposedDatasets()) {
			Classifier classifier = Classifier.forName(classifierName, null);
			classifier.buildClassifier(instances);

			/* spark 30.01.10 not needed
			if (evaluateBaseClassifiers) {
				Evaluation eval = new Evaluation(instances);
				Random rand = new Random();
				eval.crossValidateModel(classifier, instances, numFolds, rand);
				System.out.println("Wert f�r " + instances.relationName()
						+ ": " + eval.pctCorrect() + " ("
						+ instances.numInstances() + " Datens�tze!)");
			}*/

			baseClassifier.add(classifier);

		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.baseLearner.DecomposedDatasetLearner#loadClassifiers(LPCforSOS.dataStructure.Models)
	 */
	@Override
	public void loadClassifiers(Models model) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.baseLearner.DecomposedDatasetLearner#saveClassifiers(LPCforSOS.dataStructure.Models)
	 */
	@Override
	public void saveClassifiers(Models model) {
		// TODO Auto-generated method stub

	}

}
