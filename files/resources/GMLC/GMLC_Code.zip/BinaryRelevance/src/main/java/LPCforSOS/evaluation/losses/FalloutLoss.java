/**
 * 
 */
package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Calculate the fallout. 
 * This is defined as<p>
 * <pre>
 * incorrectly classified negatives
 * --------------------------------
 *   total predicted as positive
 * </pre>
 *
 * @author George-P. C.F.
 *
 */
public class FalloutLoss implements IConfusionMatrixBasedLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelCalibratedLabelRankingLossFunction#calculateLossFunction(LPCforSOS.evaluation.losses.TwoClassMultilabelCalibratedLabelRankingConfusionMatrix)
	 */
	@Override
	public double calculateLossFunction( TwoClassConfusionMatrix confusionMatrix) {
		return confusionMatrix.getFallout();
	}

}
