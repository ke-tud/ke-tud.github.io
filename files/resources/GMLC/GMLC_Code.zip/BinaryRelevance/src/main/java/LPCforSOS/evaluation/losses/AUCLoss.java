package LPCforSOS.evaluation.losses;

import java.util.List;
/**
 * Calculate the AUC-Measure. 
 * This is defined as<p>
 * <pre>
 * (Sum of rankings of relevant Labels) - (relevant * (relevant-1)) / 2
 * ----------------------
 *   relevant * irrelevant
 * </pre>
 *
 * @author George-P. C.F.
 *  
 */
public class AUCLoss implements IMultilabelRankingLossFunction{
	
	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(List<String> realLabelsOfInstance,
			List<String> descendingRankingOfAllLabels) 
	{
		double result = 0.00;
		
		if (realLabelsOfInstance.size()==0) return result;
		
		double sumOfRankingOfRealLabels = 0.00;
		int numberOfRealLabelsRemainedToFind = realLabelsOfInstance.size();
		
		for(String rankedLabel : descendingRankingOfAllLabels){
			if(realLabelsOfInstance.contains(rankedLabel)){
				sumOfRankingOfRealLabels += descendingRankingOfAllLabels.indexOf(rankedLabel) + 1;
				numberOfRealLabelsRemainedToFind++;
				if(numberOfRealLabelsRemainedToFind<=0){
					break;
				}
			}
		}
		double P = realLabelsOfInstance.size();
		double N = descendingRankingOfAllLabels.size() - P;
		
		result = (sumOfRankingOfRealLabels - (P * (P + 1)/2 )) / (P * N);
		
		return result; 
	}
}