package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;

import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.evaluation.Configuration;

public class GradedMultiLabelDecomposition implements PairwiseDecomposition {

	private final PairwiseDecomposer decomposer;
	private static final String zeroClass = "z";;

	public GradedMultiLabelDecomposition(PairwiseDecomposer pairwiseDecomposer) {
		super();
		this.decomposer = pairwiseDecomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		int numOfIterations = data.getNumberOfGrades() - 1;

		List<String> classes = new ArrayList<String>(data.getClasses());

		Set<String> shortenedClasses = new HashSet<String>();
		for (String currentClassString : classes) {
			shortenedClasses.add( parseClass(currentClassString));
		}
		
		int index = 0;
		for (int i = 0; i < numOfIterations; i++) {
			for (String currentClass : shortenedClasses) {
				int grade = i + 1;
				String extendedClass = currentClass + grade;
				
				this.decomposer.getClassToNumber().put(extendedClass,index);
				index++;
			}			
		}
		this.decomposer.getClassToNumber().put(zeroClass, index);

		for (int grade = 0; grade < numOfIterations; grade++) {

			int iter = 0;
			int counter = 0;
			for (String label : shortenedClasses) {
				String extendedLabel = label + (grade + 1);

				FastVector attributeValues = new FastVector();
				attributeValues.addElement(zeroClass);
				attributeValues.addElement(extendedLabel);

				FastVector attributes = (FastVector) data.get_Attributes()
						.copyElements();
				attributes.addElement(new Attribute("class", attributeValues));

				String sub_relation = data.relationName() + "_" + extendedLabel;
				Instances sub_Instances = new Instances(sub_relation,
						attributes, 100);
				// --->
				for (ExtInstance extInstance : data.get_Instances()) {
					int newLabel = 0;

					if (extInstance.getM_Classes().contains(extendedLabel)) {
						newLabel = 1;
					}

					ExtInstance instance = (ExtInstance) extInstance.copy();
					instance.setValue(extInstance.asWekaInstance()
							.numAttributes() - 1, newLabel);

					// appends the new instance with new class value
					sub_Instances.add(instance);
					instance.asWekaInstance().setDataset(sub_Instances);

					iter++;
				}

				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				if (sub_Instances.numInstances() != 0) {
					this.decomposer.getDecomposedDatasets().add(sub_Instances);
					counter++;
				}
				//System.out.println(iter + " Iterationen, " + counter + " learner");
			}
		}
	}

	private String parseClass(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}
}
