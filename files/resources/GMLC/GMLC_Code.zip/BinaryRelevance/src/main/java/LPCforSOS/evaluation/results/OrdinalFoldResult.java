/**
 * temporaer einfach multiclassfoldresult reingepastet 02.11.09
 */
package LPCforSOS.evaluation.results;

import java.util.ArrayList;

import LPCforSOS.dataStructure.ExtConfusionMatrix;
import LPCforSOS.dataStructure.TwoClassConfusionMatrix;
import LPCforSOS.evaluation.losses.AccuracyLoss;
import LPCforSOS.evaluation.losses.F1Loss;
import LPCforSOS.evaluation.losses.FalloutLoss;
import LPCforSOS.evaluation.losses.FpRate;
import LPCforSOS.evaluation.losses.IConfusionMatrixBasedLossFunction;
import LPCforSOS.evaluation.losses.PrecisionLoss;
import LPCforSOS.evaluation.losses.RecallLoss;
import LPCforSOS.evaluation.losses.TpRate;

import weka.classifiers.evaluation.ConfusionMatrix;

/**
 * @author Sang-Hyeun Park
 *
 */
public class OrdinalFoldResult extends AFoldResult {

	private ArrayList<IConfusionMatrixBasedLossFunction> losses;
	private ConfusionMatrix confusionMatrix;
	private ConfusionMatrix microAveragedConfusionMatrix;

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.AEvalResult#addLosses()
	 */
	@Override
	protected void addLosses() {
		losses = new ArrayList<IConfusionMatrixBasedLossFunction>();
		
		this.losses.add(new AccuracyLoss());
		this.losses.add(new TpRate());
		this.losses.add(new FpRate());
		this.losses.add(new RecallLoss());
		this.losses.add(new PrecisionLoss());
		this.losses.add(new F1Loss());
		this.losses.add(new FalloutLoss());
	}

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.AEvalResult#evaluate()
	 */
	@SuppressWarnings("deprecation")
	@Override
	public void evaluate() 
	{
		String[] labels = new String[this.allLabels.size()];
		labels = this.allLabels.toArray(labels);
		this.confusionMatrix = new ConfusionMatrix(labels);
		
		for(int i=0; i < voteVector.size(); i++)
		{
			int posOfPredictedClass = maximum(voteVector.get(i));
//			String predictedClass = labels[posOfPredictedClass];
			String realClass = this.relevantLabels.get(i).get(0);
			int posOfRealClass = this.allLabels.indexOf(realClass);
			double elementValue = confusionMatrix.getElement(posOfRealClass, posOfPredictedClass) + 1;
			confusionMatrix.setElement(posOfRealClass, posOfPredictedClass, elementValue);
		}
		microAveragedConfusionMatrix = ExtConfusionMatrix.doMicroAveraging(this.confusionMatrix);
		TwoClassConfusionMatrix microAveragedTwoClassConfusionMatrix = new TwoClassConfusionMatrix(microAveragedConfusionMatrix);
		
		for(IConfusionMatrixBasedLossFunction lossFunction : losses)
		{
			double lossResult = lossFunction.calculateLossFunction(microAveragedTwoClassConfusionMatrix);
			String lossNamePlusPackage = lossFunction.getClass().getName();
			this.lossResults.put(lossNamePlusPackage, lossResult);
		}
	}
	
	public String toString()
	{
		String result = "";
		
		result += super.toString();
		
		result += "\n";
		result += confusionMatrix + "\n";
		result += microAveragedConfusionMatrix.toString("=== Micro Averaged Confusion Matrix ===") + "\n";
		

		
//		String[] tmpString1 = "tp fn tn fp fp-Rate tp-Rate Precision Recall FMeasure Fallout".split("\\s");
//		String[] tmpString2 = cm.getTwoClassStats(0).toString().split("\\s");
//		String tmpStringResult1 = "";
//		String tmpStringResult2 = "";
//		for(int i=4;i<tmpString1.length;i++){
//			tmpStringResult1 += String.format("|%-10.9s", tmpString1[i]);
//			tmpStringResult2 += String.format("|%-10.9s", tmpString2[i]);
//		}
//		result += tmpStringResult1 + " \n";
//		result += tmpStringResult2 + " \n";
//		result += "\n";

		return result;
	}
}
