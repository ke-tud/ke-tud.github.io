package LPCforSOS.decomposition;

import java.util.ArrayList;
import java.util.HashMap;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;

public class HierarchyRankingDecomposition extends
		AbstractHierarchyRankingDecomposition {

	private final boolean justLeaves;

	public HierarchyRankingDecomposition(PairwiseDecomposer decomposer,
			boolean justLeaves) {
		super(decomposer);
		this.justLeaves = justLeaves;
	}

	@Override
	public void decompose(ExtInstances data) {
		HashMap<Integer, String> numberToClass = new HashMap<Integer, String>();
		for (int i = 0; i < data.getNumberOfClasses(); i++) {
			super.decomposer.getClassToNumber()
					.put(data.getClasses().get(i), i);
			numberToClass.put(i, data.getClasses().get(i));
		}
		ArrayList<ArrayList<Integer>> ways = super.buildWay(data,
				super.decomposer.getClassToNumber());
		// need to know the leaves for creating the classification
		ArrayList<ArrayList<Integer>> compareList = super.buildCompareList(
				data, ways, numberToClass, this.justLeaves);
		super.buildInstances(data, numberToClass, ways, this.justLeaves);

		// String[] testStrings = {"a","b","c","d","e"};
		// HashMap<String, ArrayList<String>> pos = new HashMap<String,
		// ArrayList<String>>();
		// HashMap<String, ArrayList<String>> neg = new HashMap<String,
		// ArrayList<String>>();

		// for(String test : testStrings)
		for (ExtInstance extInstance : data.get_Instances()) {
			for (int i = 0; i < super.decomposer.getDecomposedDatasets().size(); i++) {
				Instances sub_Instances = super.decomposer
						.getDecomposedDatasets().get(i);
				String lhs = sub_Instances.classAttribute().value(0);
				String rhs = sub_Instances.classAttribute().value(1);
				String node = extInstance.getM_Classes().get(0);
				// String node = test;
				// ArrayList<String> negEntries = neg.get(lhs + "," + rhs);
				// ArrayList<String> posEntries = pos.get(lhs + "," + rhs);
				// if(posEntries == null)
				// {
				// posEntries = new ArrayList<String>();
				// pos.put(lhs + "," + rhs, posEntries);
				// negEntries = new ArrayList<String>();
				// neg.put(lhs + "," + rhs, negEntries);
				// }

				int distLhs = compareList.get(
						super.decomposer.getClassToNumber().get(lhs)).get(
						super.decomposer.getClassToNumber().get(node));
				//				
				int distRhs = compareList.get(
						super.decomposer.getClassToNumber().get(rhs)).get(
						super.decomposer.getClassToNumber().get(node));

				if (distLhs != distRhs) {
					int label = -1;
					if (distLhs > distRhs) {
						label = 0;
						// posEntries.add(test);
					} else if (distLhs < distRhs) {
						label = 1;
						// negEntries.add(test);
					}
					ExtInstance instance = (ExtInstance) extInstance.copy();
					instance.setValue(extInstance.asWekaInstance()
							.numAttributes() - 1, label);
					// appends the new instance with new class value
					sub_Instances.add(instance);
					instance.asWekaInstance().setDataset(sub_Instances);
				}
			}
		}
	}

}
