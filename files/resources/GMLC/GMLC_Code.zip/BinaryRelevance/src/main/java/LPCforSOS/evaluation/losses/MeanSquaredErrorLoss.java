package LPCforSOS.evaluation.losses;

import java.util.List;

/**
 * Calculate the MeanSquaredError-Measure. 
 * This is defined as<p>
 * <pre>
 * Sum over all squared distances between position of a label in total order and the position of the same label in the predicted order
 * </pre>
 *
 * @author George-P. C.F.
 *  
 */
public class MeanSquaredErrorLoss implements ILabelRankingLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.ILabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(
			List<String> predictedOrderOfLabels,
			List<String> totalOrderOfLabels) {
		double sumOfSquared = 0.00;
		for(String label : predictedOrderOfLabels){
			double distance = predictedOrderOfLabels.indexOf(label) - totalOrderOfLabels.indexOf(label);
			double squaredDistance = Math.pow(distance, 2);
			sumOfSquared+= squaredDistance;
		}
		return sumOfSquared;
	}
}
