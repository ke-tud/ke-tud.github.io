package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Calculate the HammingDistance-Measure. 
 * This is defined as<p>
 * <pre>
 * false negatives + false positives
 * ----------------------
 * false negatives + false positives + true negatives + true positives
 * </pre>
 *
 * @author George-P. C.F.
 */
public class HammingDistanceLoss implements IConfusionMatrixBasedLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelCalibratedLabelRankingLossFunction#calculateLossFunction(LPCforSOS.evaluation.losses.TwoClassMultilabelConfusionMatrix)
	 */
	@Override
	public double calculateLossFunction( TwoClassConfusionMatrix confusionMatrix) 
	{
		double TP = confusionMatrix.getTruePositive();
		double TN = confusionMatrix.getTrueNegative();
		double FP = confusionMatrix.getFalsePositive();
		double FN = confusionMatrix.getFalseNegative();
		
		if((TP + FP + TN + FN) > 0)
			return (FN + FP) / (TP + FP + TN + FN);
		return 0.00;
	}
}