package LPCforSOS.decomposition;

import java.util.ArrayList;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;

public class MulticlassDecomposition implements PairwiseDecomposition {

	private final Decomposer decomposer;
	private int iter;
	private int counter;

	public MulticlassDecomposition(Decomposer decomposer) {
		this.decomposer = decomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		double value = 0.0;
		this.counter = 0;
		this.iter = 0;

		int numOfClasses = data.getNumberOfClasses();

		ArrayList<String> allClasses = new ArrayList<String>(data.getClasses());

		// mapping string of class to number
		for (int i = 0; i < numOfClasses; i++) {
			this.decomposer.getClassToNumber().put(allClasses.get(i), i);
		}

		for (int i = 0; i < numOfClasses; i++) {

			String label1 = allClasses.get(i);
			int startIdx = i + 1;

			for (int j = startIdx; j < numOfClasses; j++) {
				String label2 = allClasses.get(j);

				Instances sub_Instances = this.createSubInstances(data, label1,
						label2);

				sub_Instances.setClassIndex(sub_Instances.numAttributes() - 1);
				this.decomposer.getDecomposedDatasets().add(sub_Instances);
				value += sub_Instances.numInstances();
				this.counter++;
			}
		}
		// System.out.println(iter + " Iterationen, " + counter + " learner");
	}

	private Instances createSubInstances(ExtInstances data, String label1,
			String label2) {
		// new nominal attribute for class with the two classes
		FastVector attributeValues = new FastVector();
		attributeValues.addElement(label1);
		attributeValues.addElement(label2);

		FastVector attributes = (FastVector) data.get_Attributes()
				.copyElements();
		attributes.addElement(new Attribute("class", attributeValues));

		String sub_relation = data.relationName() + "_" + label1 + "_vs_"
				+ label2;
		Instances sub_Instances = new Instances(sub_relation, attributes, 100);

		for (ExtInstance extInstance : data.get_Instances()) {

			// weka coding of nominal attributes
			// -1 zeigt an das Instanz nicht zu gebrauchen ist.
			int label = -1;

			if (extInstance.getM_Classes().contains(label1)) {

				label = 0;
			} else if (extInstance.getM_Classes().contains(label2)) {

				label = 1;
			}

			if (!(label < 0)) {
				ExtInstance instance = (ExtInstance) extInstance.copy();
				instance
						.setValue(
								extInstance.asWekaInstance().numAttributes() - 1,
								label);

				// appends the new instance with new class value
				sub_Instances.add(instance);
				instance.asWekaInstance().setDataset(sub_Instances);
			}
			this.iter++;
		}

		return sub_Instances;
	}
}
