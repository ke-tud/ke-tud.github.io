package LPCforSOS.decomposition;

import java.util.HashMap;

import weka.core.Attribute;
import weka.core.FastVector;
import weka.core.Instances;

import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;

public class LabelRankingPairwiseDecomposition implements PairwiseDecomposition {

	private final PairwiseDecomposer decomposer;

	public LabelRankingPairwiseDecomposition(PairwiseDecomposer decomposer) {
		this.decomposer = decomposer;
	}

	@Override
	public void decompose(ExtInstances data) {
		HashMap<String, Integer> learner = new HashMap<String, Integer>();
		int newIndex = 0;
		int learnerCounter = 0;

		for (ExtInstance ext_instance : data.get_Instances()) {

			for (String attrib : ext_instance.getM_Classes()) {
				String[] labels = attrib.split("<");
				int indexLhs = data.getClasses().indexOf(labels[0]);
				int indexRhs = data.getClasses().indexOf(labels[1]);

				String checkString = null;
				boolean wrightOrder = true;
				if (indexLhs < indexRhs)
					checkString = labels[0] + "<" + labels[1];
				else {
					checkString = labels[1] + "<" + labels[0];
					wrightOrder = false;
				}

				// insert new learner
				if (!learner.containsKey(checkString)) {
					learner.put(checkString, learnerCounter);
					learnerCounter++;
					if (wrightOrder) {
						this.decomposer.getClassToNumber().put(
								labels[0] + "<" + labels[1], newIndex);
						newIndex++;
						this.decomposer.getClassToNumber().put(
								labels[1] + "<" + labels[0], newIndex);
						newIndex++;
					} else {
						this.decomposer.getClassToNumber().put(
								labels[1] + "<" + labels[0], newIndex);
						newIndex++;
						this.decomposer.getClassToNumber().put(
								labels[0] + "<" + labels[1], newIndex);
						newIndex++;
					}

					// new nominal attribute for class with the two classes
					FastVector attributeValues = new FastVector();
					if (wrightOrder) {
						attributeValues.addElement(labels[0] + "<" + labels[1]);
						attributeValues.addElement(labels[1] + "<" + labels[0]);
					} else {
						attributeValues.addElement(labels[1] + "<" + labels[0]);
						attributeValues.addElement(labels[0] + "<" + labels[1]);
					}

					FastVector attributes = (FastVector) data.get_Attributes()
							.copyElements();
					attributes.addElement(new Attribute("class",
							attributeValues));

					String sub_relation;
					if (wrightOrder)
						sub_relation = data.relationName() + "_" + labels[0]
								+ "_vs_" + labels[1];
					else
						sub_relation = data.relationName() + "_" + labels[1]
								+ "_vs_" + labels[0];

					Instances sub_Instances = new Instances(sub_relation,
							attributes, 100);

					sub_Instances
							.setClassIndex(sub_Instances.numAttributes() - 1);
					this.decomposer.getDecomposedDatasets().add(sub_Instances);
				}

				Instances sub_Instances = this.decomposer
						.getDecomposedDatasets().get(learner.get(checkString));

				// weka coding of nominal attributes

				ExtInstance instance = (ExtInstance) ext_instance.copy();
				instance.setValue(
						ext_instance.asWekaInstance().numAttributes() - 1,
						wrightOrder ? 0 : 1);

				// appends the new instance with new class value
				sub_Instances.add(instance);
				instance.asWekaInstance().setDataset(sub_Instances);
			}

		}
	}

}
