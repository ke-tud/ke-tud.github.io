/**
 * 
 */
package LPCforSOS.evaluation.results;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

/**
 * @author George-P. C.F.
 *
 */
public class AverageOfFoldResults {

	private HashMap<String, Double> sumOfLossResults = new HashMap<String, Double>();

	public AverageOfFoldResults(LinkedHashMap<String, AFoldResult> linkedHashMap) {
		
		ArrayList<HashMap<String, Double>> evalResultsLossResults = new ArrayList<HashMap<String,Double>>();
		for(AFoldResult evalResult : linkedHashMap.values()){
			evalResultsLossResults.add(evalResult.lossResults);
//			cms.add(evalResult.confusionMatrixList.get(0));
		}
//		cm = AFoldResult.getSumOfConfusionMatrices(cms);
		
		HashMap<String, Double> sumOfLossResults = new HashMap<String, Double>();
		for(String lossName : evalResultsLossResults.get(0).keySet())
		{
			sumOfLossResults.put(lossName, 0.00);
		}
		
		for(HashMap<String, Double> lossResults : evalResultsLossResults)
		{
			for(String lossName : lossResults.keySet()){
				double sumOfLossResult = sumOfLossResults.get(lossName);
				sumOfLossResult += lossResults.get(lossName);
				sumOfLossResults.put(lossName, sumOfLossResult);
			}
		}
		for(String lossName : sumOfLossResults.keySet()){
			double sumOfLoss = sumOfLossResults.get(lossName);
			sumOfLoss /= linkedHashMap.keySet().size();
			sumOfLossResults.put(lossName, sumOfLoss);
		}
		this.sumOfLossResults = sumOfLossResults;
	}
	
	public String toString(){
		String result = "";
		
//		result += "=== Total Macro Average ===================================================== ";
//		result += "\n";
		
		for(String lossNamePlusPackage : this.sumOfLossResults.keySet()){
			String[] splittedLossName = lossNamePlusPackage.split("\\.");
			String lossName = lossNamePlusPackage;
			
			if(splittedLossName.length-1 >= 0){
				lossName = splittedLossName[splittedLossName.length-1];
			}
			
			result += String.format("%-25.25s", lossName) + " = \t";
			result += sumOfLossResults.get(lossNamePlusPackage) + "\t";
		}
		result += "\n";
		
		return result;
	}
}
