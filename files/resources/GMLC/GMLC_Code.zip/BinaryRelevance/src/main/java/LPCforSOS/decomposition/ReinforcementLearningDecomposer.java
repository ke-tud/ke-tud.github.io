/**
 */
package LPCforSOS.decomposition;

import LPCforSOS.dataStructure.ExtInstances;

/**
 * @author Sandra Ebert
 *
 * @date  22.07.2008, 12:12:25
 */
public class ReinforcementLearningDecomposer extends Decomposer {

	/* (non-Javadoc)
	 * @see LPCforSOS.decomposition.Decomposer#buildDecomposedDatasets(LPCforSOS.dataStructure.ExtInstances)
	 */
	@Override
	public void buildDecomposedDatasets(ExtInstances data) {
		// TODO Auto-generated method stub

	}

}
