package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Calculate the F-Measure. 
 * This is defined as<p>
 * <pre>
 * 2 * recall * precision
 * ----------------------
 *   recall + precision
 * </pre>
 *
 * @author George-P. C.F.
 *  
 */
public class F1Loss implements IConfusionMatrixBasedLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelCalibratedLabelRankingLossFunction#calculateLossFunction(LPCforSOS.evaluation.losses.TwoClassMultilabelCalibratedLabelRankingConfusionMatrix)
	 */
	@Override
	public double calculateLossFunction( TwoClassConfusionMatrix confusionMatrix) 
	{
		return confusionMatrix.getFMeasure();
	}
}