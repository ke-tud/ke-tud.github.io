/**
 * 
 */
package LPCforSOS.dataStructure;

import weka.classifiers.evaluation.TwoClassStats;

/**
 * Encapsulates performance functions for multilabel problems.
 * 
 * @author George
 *
 */
public class MultilabelStats extends TwoClassStats {

  /**
   * Creates the MultilabelStats with the given initial performance values.
   *
   * @param tp the number of correctly classified positives
   * @param fp the number of incorrectly classified negatives
   * @param tn the number of correctly classified negatives
   * @param fn the number of incorrectly classified positives
   */
	public MultilabelStats(double tp, double fp, double tn, double fn) {
		super(tp, fp, tn, fn);
	}
	
	/**
	 * Calculate the Hamming Loss. 
	 * This is defined as<p>
	 * <pre>
	 * incorrectly classified negatives + incorrectly classified positives
	 * --------------------------------
	 *   total classes
	 * </pre>
	 *
	 * @return the Hamming Loss
	 */
	public double getHammingLoss() { 
		double totalClasses = getFalseNegative() + getTrueNegative() + getFalsePositive() + getFalsePositive();
		if (0 == totalClasses) {
			return 0;
		} else {
			return (getFalseNegative() + getFalsePositive()) / (totalClasses); 
		}
	}
	
	/**
	   * Returns a string containing the performance measures of Superclass 
	   * and this Implementation of the Hamming Loss measure 
	   */
	  public String toString() {

	    StringBuffer res = new StringBuffer();
	    res.append(super.toString());
	    res.append(getHammingLoss()).append(' ');
	    return res.toString();
	  }
}
