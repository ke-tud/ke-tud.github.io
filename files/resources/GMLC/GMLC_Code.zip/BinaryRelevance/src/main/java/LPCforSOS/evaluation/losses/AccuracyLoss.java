/**
 * 
 */
package LPCforSOS.evaluation.losses;

import LPCforSOS.dataStructure.TwoClassConfusionMatrix;

/**
 * Calculate the accuracy. 
 * This is defined as<p>
 * <pre>
 * sum of correct predicted labels (TN + TP)
 * ------------------------------
 * total positive + total negative ( |E| )
 * </pre>
 * 
 * @author George CF
 *
 */
public class AccuracyLoss implements IConfusionMatrixBasedLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMulticlassLossFunction#calculateLossFunction(LPCforSOS.evaluation.losses.TwoClassConfusionMatrix)
	 */
	@Override
	public double calculateLossFunction(TwoClassConfusionMatrix confusionMatrix) {
		double TP = confusionMatrix.getTruePositive();
		double TN = confusionMatrix.getTrueNegative();
		double FP = confusionMatrix.getFalsePositive();
		double FN = confusionMatrix.getFalseNegative();
		
		if((TP + FP + TN + FN)>0)
			return (TP + TN) / (TP + FP + TN + FN);
		return 0.00;
	}
	
	// TODO: 28.01.10 spark Accuracy ist wrong bei multiclass

}
