package LPCforSOS.structuredPrediction;

import java.util.Random;

import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ExtInstance;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.evaluation.Configuration;
import weka.classifiers.Classifier;
import weka.core.Instance;
import weka.core.Instances;

/**
 * Paper:      Probability Estimates for Multi-class Classification by Pairwise Coupling
 * Abschnitt:  2.4 Method by Hastie and Tibshirani
 * 
 * @author George-P. C.F.
 *
 */
public class HastieTibshirani extends StructuredPredictor{

	/* (non-Javadoc)
	 * @see LPCforSOS.structuredPrediction.StructuredPredictor#classifyInstances(weka.core.Instances, LPCforSOS.baseLearner.DecomposedDatasetLearner, java.util.ArrayList)
	 */
	@Override
	public void classifyInstances(Instances test,
			DecomposedDatasetLearner learner,
			ExtInstances trainingSet) throws Exception {

		initialize();
		
		int numInstances = test.numInstances();
		int numOfClasses = test.numClasses();

/***	n_i_j */
//		Zaehlen der Anzahl an Testinstanzen die den einzelnen Klasse angehoeren
		int[] numOfInstancesPerClass = new int[numOfClasses];
		for(ExtInstance instance : trainingSet.get_Instances()){
			numOfInstancesPerClass[learner.getClassToNumber().get(instance.getM_Classes().get(0))]++;
		}

//		Ausrechnen der Summen da sonst in unteren Schleifen Berechung redundant
		int[][] n = new int[numOfClasses][numOfClasses];
		for(int i=0; i<numOfClasses; i++){
			for(int j=i+1; j<numOfClasses; j++){
				n[i][j] = numOfInstancesPerClass[i] + numOfInstancesPerClass[j];
				n[j][i] = n[i][j];
			}
		}
/***	/
		
/***	F�r alle Instanzen einmal */
		for (int i = 0; i < numInstances; i++)
		{
			Instance instance = test.instance(i);
			
/****** 	Initialisierung
			Berechnung der initialen Wahrscheinlichkeiten der Klassen */
			
			Random random = new Random(Configuration.seedForEvaluation);		
			double[] probabilities = new double[numOfClasses];
			double[][] my = new double[numOfClasses][numOfClasses];
			
//			F�r alle 0 <= p_i <= 1 gew�hrleistet durch Methode nextDouble()
			double sumOfProbabilities = 0;
			for(int j=0; j<numOfClasses; j++)
			{
				probabilities[j] = random.nextDouble();
				sumOfProbabilities += probabilities[j];
			}
			
//			Normalisierung: Summe aller p_i = 1
			for(int j=0; j<probabilities.length; j++)
			{
				probabilities[j] = probabilities[j]/sumOfProbabilities;
			}
			
//			Berechnung der my_i_j = p_i / (p_i + p_j)
			for(int j=0; j<my.length; j++)
			{
				for(int k=j+1; k<my.length; k++)
				{
					double tmpSum = probabilities[j] + probabilities[k];
					my[j][k] = probabilities[j] / tmpSum;
					my[k][j] = 1 - my[j][k];
				}
			}
			
/******		*/
			
//			r kommt von den Klassifizierern und speichert das Verh�ltnis zweier Klassen zueinander. 
			double[][] r = new double[numOfClasses][numOfClasses];
			int numBaseClassifier = learner.getBaseClassifier().size();
			for (int j = 0; j < numBaseClassifier; j++) 
			{
				Classifier classifier = learner.getBaseClassifier().get(j);
				double[] distrib = classifier.distributionForInstance(instance);

				String realClass1 = learner.getDecomposedDatasets().get(j).classAttribute().value(0);
				String realClass2 = learner.getDecomposedDatasets().get(j).classAttribute().value(1);
				int indexOfClass1 = learner.getClassToNumber().get(realClass1);
				int indexOfClass2 = learner.getClassToNumber().get(realClass2);
				r[indexOfClass1][indexOfClass2] = distrib[0];
				r[indexOfClass2][indexOfClass1] = distrib[1];
			}
			
			double[] alpha = new double[numOfClasses];

//			Laufindex f�r erste Klasse
			int c_i = 0;
			
//			TODO Zweites Abbruchkriterium maximale Anzahl an Schleifendurchl�ufen?
			while(true)
			{
				double sumOfnAndr = 0;
				double sumOfnAndmy = 0;
				for(int c_j=0; c_j<numOfClasses; c_j++){
					if(c_i != c_j)
					{
						sumOfnAndr += r[c_i][c_j] * n[c_i][c_j];
						sumOfnAndmy += my[c_i][c_j] * n[c_i][c_j];
					}
				}
				alpha[c_i] = sumOfnAndr / sumOfnAndmy;
				
				for(int c_j=0; c_j<numOfClasses; c_j++){
					if(c_i != c_j)
					{
						double alphaMy = alpha[c_i] * my[c_i][c_j];
						double sumOfMy = alphaMy + my[c_j][c_i];
						my[c_i][c_j] = alphaMy / sumOfMy;
						my[c_j][c_i] = 1 - my[c_i][c_j];
					}
				}
				probabilities[c_i] = alpha[c_i] * probabilities[c_i];

//				f�r alle alpha gilt 1-alpha < epsilon  -->  break;
				if(checkBreakCondition(alpha)){
					break;
				}
				
				c_i++;
//				Schleife einmal durchgelaufen, wieder von vorne
				if(c_i >= numOfClasses)
				{
					c_i = 0;
				}
			}
//			Normalisierung der p_i 
			sumOfProbabilities = 0;
			for(double p_i : probabilities){
				sumOfProbabilities += p_i;
			}
			for(int j=0; j<probabilities.length; j++){
				probabilities[j] = probabilities[j] / sumOfProbabilities;
			}
			
			voteVector.add(probabilities);
		}
	}

	/**
	 * Checks break-condition
	 * @param alpha
	 * @return true if all 1-alpha < epsilon
	 */
	private boolean checkBreakCondition(double[] alpha) {
		double epsilon = Configuration.HTepsilon;
		for(double a : alpha){
			if(1-a > epsilon){
				return false;
			}
		}
		return true;
	}
}
