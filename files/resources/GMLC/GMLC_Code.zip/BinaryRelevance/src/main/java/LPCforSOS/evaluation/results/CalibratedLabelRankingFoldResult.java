/**
 */
package LPCforSOS.evaluation.results;

import java.util.ArrayList;

import LPCforSOS.dataStructure.ExtConfusionMatrix;
import LPCforSOS.dataStructure.TwoClassConfusionMatrix;
import LPCforSOS.evaluation.losses.AccuracyLoss;
import LPCforSOS.evaluation.losses.F1Loss;
import LPCforSOS.evaluation.losses.FalloutLoss;
import LPCforSOS.evaluation.losses.HammingDistanceLoss;
import LPCforSOS.evaluation.losses.IConfusionMatrixBasedLossFunction;
import LPCforSOS.evaluation.losses.PrecisionLoss;
import LPCforSOS.evaluation.losses.RecallLoss;

import weka.classifiers.evaluation.ConfusionMatrix;
import weka.classifiers.evaluation.TwoClassStats;


/**
 * @author Sandra Ebert, George-P. C.F.
 * 
 * @date 30.11.2008, 22:15:21
 */
public class CalibratedLabelRankingFoldResult extends AFoldResult {

	private ArrayList<IConfusionMatrixBasedLossFunction> losses;
	ConfusionMatrix sumOfConfusionMatricesOfAllInstances;

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.AEvalResult#addLosses()
	 */
	@Override
	protected void addLosses() {
		losses = new ArrayList<IConfusionMatrixBasedLossFunction>();
		
		this.losses.add(new RecallLoss());
		this.losses.add(new PrecisionLoss());
		this.losses.add(new F1Loss());
		this.losses.add(new FalloutLoss());
		this.losses.add(new HammingDistanceLoss());
		this.losses.add(new AccuracyLoss());
	}

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.AEvalResult#evaluate()
	 */
	@Override
	public void evaluate() 
	{
		int posOfCalibrationLabel = this.votedStrings.size() -1;
		ArrayList<ConfusionMatrix> listOfConfusionMatrices = new ArrayList<ConfusionMatrix>();
		
//		F�r jede Instanz wird eine 2x2 Konfusionsmatrix errechnet
		for(int i = 0; i < voteVector.size(); i++)
		{
			double[] vote = voteVector.get(i);
			double voteForCalibrationLabel = vote[posOfCalibrationLabel];
//			relevanceBounds.add(voteForCalibrationLabel);
			
			ArrayList<String> predictionForInstance = new ArrayList<String>();
			
			for(int j = 0; j < vote.length; j++){
//				Wert muss gr��er sein da sonst calibrationlabel mit in die Prediction kommt(oder for-schleife verkleinern).
				if(vote[j] > voteForCalibrationLabel){
					String predictedLabel = allLabels.get(j);
					predictionForInstance.add(predictedLabel);
				}
			}
//			prediction.add(predictionForInstance);

			int TP, FP, TN, FN;
			TP = FP = TN = FN = 0;
			for(int classID=0;classID<allLabels.size();classID++)
			{
				String classIDLabel = allLabels.get(classID);
				boolean real = this.relevantLabels.get(i).contains(classIDLabel);
				boolean predicted = (predictionForInstance.contains(classIDLabel));
				
				if(real && predicted) 
					TP++;
				else if(real && !predicted) 
					FN++;
				else if(!real && predicted) 
					FP++;
				else //if(!real && !predicted)
					TN++;
			}
			
			TwoClassStats tcs = new TwoClassStats(TP,FP,TN,FN);
			listOfConfusionMatrices.add(tcs.getConfusionMatrix());
		}
		
		this.sumOfConfusionMatricesOfAllInstances = ExtConfusionMatrix.getSumOfConfusionMatrices(listOfConfusionMatrices);
		TwoClassConfusionMatrix sum = new TwoClassConfusionMatrix(sumOfConfusionMatricesOfAllInstances);
		
		for(IConfusionMatrixBasedLossFunction lossFunction : losses)
		{
			String lossNamePlusPackage = lossFunction.getClass().getName();
			
			double lossResult = lossFunction.calculateLossFunction(sum);
			this.lossResults.put(lossNamePlusPackage, lossResult);
		}
	}
	public String toString(){
		String result = "";
		
		result += super.toString();
		result += "\n";
		result += sumOfConfusionMatricesOfAllInstances.toString("=== Micro Averaged Confusion Matrix ===") + "\n";
		
//		result += this.prediction.size() + " Testinstanzen in " + foldTime + " ms \n";
		
//		TwoClassStats sumOfTwoClassStats = getSumOfConfusionMatrices(this.confusionMatrixList).getTwoClassStats(0);
//		result += sumOfTwoClassStats.getConfusionMatrix();
//		
//		String[] tmpString1 = "tp fn tn fp fp-Rate tp-Rate Precision Recall FMeasure Fallout".split("\\s");
//		String[] tmpString2 = sumOfTwoClassStats.toString().split("\\s");
//		String tmpStringResult1 = "";
//		String tmpStringResult2 = "";
//		for(int i=4;i<tmpString1.length;i++){
//			tmpStringResult1 += String.format("|%-10.9s", tmpString1[i]);
//			tmpStringResult2 += String.format("|%-10.9s", tmpString2[i]);
//		}
//		result += tmpStringResult1 + " \n";
//		result += tmpStringResult2 + " \n\n";
//
//		result += super.toString();
		return result;
	}
}
