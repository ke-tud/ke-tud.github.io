package LPCforSOS.structuredPrediction;

import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.evaluation.Configuration;
import weka.classifiers.Classifier;
import weka.core.Instance;
import weka.core.Instances;

/**
 * Paper:      Probability Estimates for Multi-class Classification by Pairwise Coupling
 * Abschnitt:  4. Our Second Approach
 * Code:	   LIBSVM von Chang and Lin (2001)
 * 
 * @author George-P. C.-F.
 *
 */
public class WuLingWengLIBSVMVersion extends StructuredPredictor{

	/* (non-Javadoc)
	 * @see LPCforSOS.structuredPrediction.StructuredPredictor#classifyInstances(weka.core.Instances, LPCforSOS.baseLearner.DecomposedDatasetLearner, LPCforSOS.dataStructure.ExtInstances)
	 */
	@Override
	public void classifyInstances(Instances test,
			DecomposedDatasetLearner learner, ExtInstances trainingSet)
			throws Exception {

		initialize();
		
		int numInstances = test.numInstances();
		int numOfClasses = test.numClasses();
		
/***	F�r alle Instanzen einmal */
		for (int inst_i = 0; inst_i < numInstances; inst_i++)
		{
			Instance instance = test.instance(inst_i);

			double[] p = new double[numOfClasses];
			
//			r kommt von den Klassifizierern und speichert das Verh�ltnis zweier Klassen zueinander. 
			double[][] r = new double[numOfClasses][numOfClasses];
			int numBaseClassifier = learner.getBaseClassifier().size();
			
			for (int i = 0; i < numBaseClassifier; i++) 
			{
				Classifier classifier = learner.getBaseClassifier().get(i);
				double[] distrib = classifier.distributionForInstance(instance);

				String realClass1 = learner.getDecomposedDatasets().get(i).classAttribute().value(0);
				String realClass2 = learner.getDecomposedDatasets().get(i).classAttribute().value(1);
				int indexOfClass1 = learner.getClassToNumber().get(realClass1);
				int indexOfClass2 = learner.getClassToNumber().get(realClass2);
				r[indexOfClass1][indexOfClass2] = distrib[0];
				r[indexOfClass2][indexOfClass1] = distrib[1];
			}
			
			int t,j;
			int k = numOfClasses;
			int iter = 0;
//			Abbruchkriterium: Anzahl an Schleifendurchl�ufen
			int max_iter = Math.max(Configuration.WLWmaxIterations, k);
			
			double[][] Q=new double[k][k];
			double[] Qp= new double[k];
			double pQp;
//			Abbruchkriterium: Abstand zwischen Q*p_t und p*Q*p
			double eps= Configuration.WLWepsilon / k;
		
			for (t=0;t<k;t++)
			{
				p[t]=1.0/k;  // Valid if k = 1
				Q[t][t]=0;
				for (j=0;j<t;j++)
				{
					Q[t][t]+=r[j][t]*r[j][t];
					Q[t][j]=Q[j][t];
				}
				for (j=t+1;j<k;j++)
				{
					Q[t][t]+=r[j][t]*r[j][t];
					Q[t][j]=-r[j][t]*r[t][j];
				}
			}
			for (iter=0;iter<max_iter;iter++)
			{
//				Pr�fung des Abbruchkriteriums: Neuberechung von QP und pQP
				pQp=0;
				for (t=0;t<k;t++)
				{
					Qp[t]=0;
					for (j=0;j<k;j++)
						Qp[t]+=Q[t][j]*p[j];
					pQp+=p[t]*Qp[t];
				}
				double max_error=0;
				for (t=0;t<k;t++)
				{
					double error=Math.abs(Qp[t]-pQp);
					if (error>max_error)
						max_error=error;
				}
				if (max_error<eps) break;
			
				for (t=0;t<k;t++)
				{
					double diff=(-Qp[t]+pQp)/Q[t][t];
					p[t]+=diff;
					pQp=(pQp+diff*(diff*Q[t][t]+2*Qp[t]))/(1+diff)/(1+diff);
					for (j=0;j<k;j++)
					{
						Qp[j]=(Qp[j]+diff*Q[t][j])/(1+diff);
						p[j]/=(1+diff);
					}
				}
			}
			if (iter>=max_iter){
				throw new Exception("�berschreitung der maximalen Anzahl an Scheifendurchl�ufen");
			}
			voteVector.add(p);
		}
	}
}
