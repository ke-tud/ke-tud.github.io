/**
 */
package LPCforSOS.evaluation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import weka.core.Instances;

import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.dataStructure.ExtInstancesOnARFF;
import LPCforSOS.decomposition.Decomposer;
import LPCforSOS.structuredPrediction.AggregationType;
import LPCforSOS.structuredPrediction.StructuredPredictor;

/**
 * Evaluierung auf den Originaldaten (earff): Daten werden zunaechst in n folds
 * aufgeteilt und danach erst in paarweise Lernprobleme aufgespaltet.
 * 
 */
public class EvaluationMedical {

	private static String outputFilePath;
	private static String inputFilePath;
	Result results;

	/**
	 * @param results
	 */
	public EvaluationMedical(Result results) {
		this.results = results;
	}

	/**
	 * Crossvalidation
	 * 
	 * @throws Exception
	 */
	public void crossValidateModel() throws Exception {

		// Make a copy of the data we can reorder
		ExtInstances data = new ExtInstances(results.getExt_instances());
		data.randomize(results.getRandom());
		
		if (data.classAttribute().isNominal()) {
			data.stratify(results.getFolds());
		}

		results.initialize();
		
		// Do the folds
		for (int fold = 0; fold < results.getFolds(); fold++) {
			long time = System.currentTimeMillis();

			// decompose train set
			Decomposer decomposition = Decomposer.forName(results.getDecompositionType());
			decomposition.setSymmetric(results.isSymmetric());
			ExtInstances trainingSet = data.trainCV(results.getFolds(), fold);
			decomposition.buildDecomposedDatasets(trainingSet);

			// build the base classifiers for decomposed datasets
			DecomposedDatasetLearner models = DecomposedDatasetLearner.forName(results.getEnvironment());
			models.setDecomposedDatasets(decomposition.getDecomposedDatasets());
			models.buildClassifiers(results.getClassifierName());   //spark: thats strange, remodel that
			models.setClassToNumber(decomposition.getClassToNumber());

			// decompose test set
			Instances test = data.testCV(results.getFolds(), fold, decomposition.getClassToNumber().keySet());
			// Structured Prediction with base classifiers
			StructuredPredictor pred = StructuredPredictor.forName(results);
			pred.classifyInstances(test, models, trainingSet);

			// record the time
			results.addFoldTime(System.currentTimeMillis() - time);
			
/********** Datenerfassung fuer die Auswertung */

			
			String[] allLabelsArray = new String[models.getClassToNumber().size()];
//			Hier werden die Zeichenketten gespeichert fuer die gevoted wurden. Sind z.B beim labelRanking Relationen (a<b).
			ArrayList<String> votedStrings = new ArrayList<String>(models.getClassToNumber().size());
			for(String label : models.getClassToNumber().keySet())
			{
				allLabelsArray[models.getClassToNumber().get(label)] = label;
			}
			for(int i=0;i<allLabelsArray.length;i++)
			{
				votedStrings.add(allLabelsArray[i]);
			}
			
//			Hier werden alle existierenden Labels gespeichert.
			List<String> allLabels = data.getClasses();
			
//			Enthaelt alle votes die jede der Zeichenketten pro Instanz bekommen hat.
			ArrayList<double[]> listOfVotesPerInstance = pred.getVoteVector();
			
//			Enthaelt alle relevanten Labels pro Instanz.
			List<List<String>> relevantLabels = data.getTestSetClasses();
			
//			Bei LabelRanking ist hier die Totale Ordung der Labels gespeichert.
			List<List<String>> labelRankingTotalOrder = data.getTestSetTotalOrderOfClasses();
			
/********** Ende Datenerfassung */
			
			results.addFoldResult("Fold " + (fold+1), allLabels, votedStrings, relevantLabels, listOfVotesPerInstance, labelRankingTotalOrder);
//			results.getFoldResults().get("Fold 0").evaluate();
		}
		
//		Ausfuehrung der Evaluation f�r die einzelnen Fold Ergebnisse
		for(String s : results.getFoldResults().keySet()){
			results.getFoldResults().get(s).evaluate();
		}
		
//		Ausgabe der Ergebnisse
		System.out.println(results);
		Writer w = new BufferedWriter(new FileWriter(outputFilePath,true));
		w.write(results.toString());
		w.flush();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String mode = args[0];
		if("v".equals(mode)){
			Configuration.aggregationType = AggregationType.Voting;
		}else if("t".equals(mode)){
			throw new IllegalArgumentException("not implemented yet");
		} else if("w".equals(mode)) {
			throw new IllegalArgumentException("not implemented yet");
		} else {
			throw new IllegalArgumentException("use 'v' for voting, 'w' for weighted voting and 't' for tie breaking with weighted voting");
		}
		
		inputFilePath = args[1];
		outputFilePath = args[2];
		
		for(int i = 0; i < 
				 1
				; i++){
			Configuration.positionOfEARFFFile = inputFilePath 
					+"medical.earff"; 
			System.out.println((i+1)+"\n");
			try {
				Reader r = null;
				r = new BufferedReader(new FileReader(Configuration.positionOfEARFFFile));
	
				ExtInstances data = null;
	//			Abfrage ob weka arff Datei.
				if(Configuration.positionOfEARFFFile.contains(".arff")){
					data = new ExtInstancesOnARFF(r); 
				}else{
					data = new ExtInstances(r);
				}
	
	//********  TODO Nutzlos den zu setzen da in earff Datei geschrieben
				// Classification Attribute Type
	//			Type type = Type.LabelRanking;
	
				// Result Objekt fuer die entsprechende Klassifikation
				Result results = new Result(data); // Result.forName(type);
	//			results.setClassificationAttributeType(type);
				
	//			Von welchem Typ ist das Klassen Attribut.
	//			results.setClassAttributeType(data.classAttribute().type());
				
				// symmetric classifier; false if asymmetric -> double round robin
				results.setSymmetric(Configuration.isSymmetricClassifier);
	
				// Decomposition
				results.setDecompositionType(Configuration.decompositionType);
	
				// Aggregation
				results.setAggregationType(Configuration.aggregationType);
	
				// Classifier Environment
				results.setBaseLearnerEnvironment(Configuration.baseLearnerEnvironment);
	
				// Classifier
				results.setClassifier(Configuration.positionOfClassifier);
	
				//// Crossvalidate the base classifiers
				//results.setEvaluateBaseClassifiers(Configuration.evaluateBaseClassifiers);
	
				// Seed for evaluation
				results.setRandom(Configuration.seedForEvaluation);
	
				// Number of folds
				results.setFolds(Configuration.numberOfFolds);
	
				// Crossvalidation method
				EvaluationMedical eval = new EvaluationMedical(results);
				eval.crossValidateModel();
	
			} catch (Exception ex) {
				ex.printStackTrace();
				System.err.println(ex.getMessage());
			}
		}

	}

	/**
	 * Validierungsset wird zufaellig ausgewaehlt. (Weka Cross Validation)
	 * 
	 * @param numfolds
	 *            gibt Groesse des Validierungssets an
	 */
	public void getHoldoutValidationSet(int numfolds) {

	}
}
