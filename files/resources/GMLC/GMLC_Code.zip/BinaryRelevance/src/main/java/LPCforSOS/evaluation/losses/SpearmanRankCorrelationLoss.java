/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.List;

/**
 * Calculate the SpearmanRankCorrelation-Measure. 
 * This is defined as<p>
 * <pre>
 *        6 * MSE()
 * 1 -	--------------------
 *        m * ( pow( m, 2) - 1)
 *        
 * m   : number of labels 
 * MSE : MeanSquaredError lossfunction
 * pow : exponentiation function
 * </pre>
 *
 * @author George-P. C.F.
 *  
 */
public class SpearmanRankCorrelationLoss implements ILabelRankingLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.ILabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(
			List<String> predictedOrderOfLabels,
			List<String> totalOrderOfLabels) {
		
		double mse = new MeanSquaredErrorLoss().calculateLossFunction(predictedOrderOfLabels, totalOrderOfLabels);
		double m = totalOrderOfLabels.size();
		double result = 1 - ((6 * mse) / (m * (Math.pow( m, 2) - 1)));
		
		return result;
	}

	
}
