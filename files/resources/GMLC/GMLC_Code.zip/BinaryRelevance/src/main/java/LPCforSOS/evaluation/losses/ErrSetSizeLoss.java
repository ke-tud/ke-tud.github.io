package LPCforSOS.evaluation.losses;

import java.util.List;
/**
 * Calculate the ErrSetSize-Measure. 
 * This is defined as<p>
 * <pre>
 * The set of pairs of relevant an irrelevant labels with a wrong ranking 
 * </pre>
 * 
 * @author George-P. C.F.
 *  
 */
public class ErrSetSizeLoss implements IMultilabelRankingLossFunction{

	/* (non-Javadoc)
	 * @see LPCforSOS.evaluation.losses.IMultilabelRankingLossFunction#calculateLossFunction(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double calculateLossFunction(
			List<String> relevantLabelsOfInstance,
			List<String> descendingRankingOfAllLabels) 
	{
		double result = 0.00;
		
		if(relevantLabelsOfInstance.isEmpty()) return result;
		
		int numberOfIrrelevantLabelsAboveRelevant = 0;
		int numberOfFoundRelevantLabels = 0;
		
		for(String rankedLabel : descendingRankingOfAllLabels){
			if(relevantLabelsOfInstance.contains(rankedLabel)){
				numberOfFoundRelevantLabels ++;
				result += numberOfIrrelevantLabelsAboveRelevant;
			}else{
				numberOfIrrelevantLabelsAboveRelevant++;
			}
		}
		
		return result;
	}
}