package LPCforSOS.structuredPrediction;

/**
 * @author Sandra Ebert
 * 
 * @date 14.05.2008, 08:26:47
 */
public enum AggregationType {

	Voting,

	WeightedVoting,
	
	HastieTibshirani,
	
	WuLingWeng,
	
	WuLingWengLIBSVMVersion,
	
	WeightedAndUnweightedVoting

}
