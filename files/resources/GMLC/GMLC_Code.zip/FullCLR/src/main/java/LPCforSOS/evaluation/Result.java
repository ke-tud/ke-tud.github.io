/**
 */
package LPCforSOS.evaluation;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import LPCforSOS.baseLearner.BaseLearnerEnvironment;
import LPCforSOS.dataStructure.ExtInstances;
import LPCforSOS.dataStructure.Type;
import LPCforSOS.decomposition.DecompositionType;
import LPCforSOS.evaluation.results.AFoldResult;
import LPCforSOS.evaluation.results.AverageOfFoldResults;
import LPCforSOS.structuredPrediction.AggregationType;

/**
 * Diese Klasse speichert die Konfiguration der Evaluation eines Datensatzes.
 * Zudem h�lt sie die Referenzen auf die Fold-Ergebnisse.
 * 
 * @author Sandra Ebert, George-P. C.F.
 * 
 * @date 11.05.2008, 17:16:12
 */
public class Result {

	// Fields for Evaluation
	protected ArrayList<Long> foldTime;
	private LinkedHashMap<String, AFoldResult> foldResults;

	private ExtInstances ext_instances;
	// private int[] foldAssignments;
	private DecompositionType decompositionType;
	private AggregationType aggregationType;
	private int classAttributeType;
	private BaseLearnerEnvironment environment;

	private String classifierName;
	private boolean isSymmetric;
	private final Random random;
	private int folds;

	private Date evaluationDate;

	public Result() {
		this.random = new Random();
	}
	
	/**
	 * @param data
	 */
	public Result(ExtInstances data) {
		this.ext_instances = data;
		this.random = new Random();
		initialize();
	}

	/**
	 * @return the evalResults
	 */
	public LinkedHashMap<String, AFoldResult> getFoldResults() {
		return foldResults;
	}

	// /**
	// * @param crossValidationSets
	// */
	// public void setCrossValidationSets(int[] crossValidationSets) {
	// this.foldAssignments = crossValidationSets;
	// }

	/**
	 * @param dec
	 */
	public void setDecompositionType(DecompositionType dec) {
		this.decompositionType = dec;
	}

	/**
	 * @param agg
	 */
	public void setAggregationType(AggregationType agg) {
		this.aggregationType = agg;
	}

	/**
	 * @param classifierName
	 */
	public void setClassifier(String classifierName) {
		this.classifierName = classifierName;
	}

	/**
	 * @param seed
	 */
	public void setRandom(long seed) {
		random.setSeed(seed);

	}

	/**
	 * @param folds
	 */
	public void setFolds(int folds) {
		this.folds = folds;
	}

	/**
	 * @return the ext_instances
	 */
	public ExtInstances getExt_instances() {
		return ext_instances;
	}

	/**
	 * @param ext_instances
	 *            the ext_instances to set
	 */
	public void setExt_instances(ExtInstances ext_instances) {
		this.ext_instances = ext_instances;
	}

	/**
	 * @return the classifierName
	 */
	public String getClassifierName() {
		return classifierName;
	}

	/**
	 * @param classifierName
	 *            the classifierName to set
	 */
	public void setClassifierName(String classifierName) {
		this.classifierName = classifierName;
	}

	/**
	 * @return the decompositionType
	 */
	public DecompositionType getDecompositionType() {
		return decompositionType;
	}

	/**
	 * @return the aggregationType
	 */
	public AggregationType getAggregationType() {
		return aggregationType;
	}

	/**
	 * @return the random
	 */
	public Random getRandom() {
		return random;
	}

	/**
	 * @return the folds
	 */
	public int getFolds() {
		return folds;
	}

	/**
	 * @param time
	 */
	public void addFoldTime(long time) {
		foldTime.add(time);
	}

	/**
	 * @return the foldTime
	 */
	public long getFoldTime(int index) {
		return foldTime.get(index);
	}

	/**
	 * @param foldTime
	 *            the foldTime to set
	 */
	public void setFoldTime(long foldTime) {
		this.foldTime.add(foldTime);
	}

	/**
	 * 
	 */
	public void initialize() {
		foldTime = new ArrayList<Long>();
		foldResults = new LinkedHashMap<String, AFoldResult>();
		evaluationDate = new Date();
	}

	/**
	 * @return Summe �ber alle Fold Zeiten in Millisekunden.
	 */
	public double getTimeMs() {
		double temp = 0.0;
		for (long time : foldTime) {
			temp += time;
		}

		return Math.round(temp);
	}

	/**
	 * @return Summe �ber alle Fold Zeiten in Minuten.
	 */
	public double getTimeMin() {
		double temp = 0.0;
		for (long time : foldTime) {
			temp += time;
		}

		return Math.round((temp / 60) / 1000);
	}

	/**
	 * @param env
	 */
	public void setBaseLearnerEnvironment(BaseLearnerEnvironment env) {
		this.environment = env;

	}

	/**
	 * @return the environment
	 */
	public BaseLearnerEnvironment getEnvironment() {
		return environment;
	}

	/**
	 * @param environment
	 *            the environment to set
	 */
	public void setEnvironment(BaseLearnerEnvironment environment) {
		this.environment = environment;
	}

	/**
	 * @return the classAttributeType
	 */
	public int getClassAttributeType() {
		return classAttributeType;
	}

	/**
	 * @param classAttributeType
	 *            the classAttributeType to set
	 */
	public void setClassAttributeType(int classAttributeType) {
		this.classAttributeType = classAttributeType;
	}

	/**
	 * @return the isSymmetric
	 */
	public boolean isSymmetric() {
		return isSymmetric;
	}

	/**
	 * @param isSymmetric
	 */
	public void setSymmetric(boolean isSymmetric) {
		this.isSymmetric = isSymmetric;
	}

	/**
	 * @param type
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	public static AFoldResult forName(Type type) throws ClassNotFoundException,
			InstantiationException, IllegalAccessException {
		String className = "LPCforSOS.evaluation.results." + type.toString()
				+ "FoldResult";

		Class<?> c = Class.forName(className);
		Object result = c.newInstance();

		return (AFoldResult) result;
	}

	/**
	 * F�r die Auswertung der Daten wird eine klassifikationsspezifisches
	 * Objekt erzeugt und in einem Vektor dieser Klasse gespeichert.
	 * 
	 * @param name
	 * @param allLabels
	 * @param votedStrings
	 * @param relevantLabels
	 * @param voteVector
	 * @param totalOrderOfLabels
	 * @param listOfDistributionsPerInstance 
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public void addFoldResult(String name, List<String> allLabels,
			List<String> votedStrings,
			List<List<String>> relevantLabels,
			List<double[]> voteVector,
			List<List<String>> totalOrderOfLabels, List<double[]> listOfDistributionsPerInstance)
			throws ClassNotFoundException, InstantiationException,
			IllegalAccessException {
		// int numOfFoldInstances = ext_instances.numInstances()/getFolds();
		int numOfFoldInstances = voteVector.size();

		AFoldResult foldResult = null;
		try {
			foldResult = forName(ext_instances.getType());

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.err.println("Kein passendes Evaluierungsobjekt vorhanden!");
			System.exit(1);
		}

		foldResult.configure(allLabels, votedStrings, relevantLabels,
				voteVector, numOfFoldInstances, totalOrderOfLabels, listOfDistributionsPerInstance);
		foldResult.setFoldTime(this.foldTime.get(this.foldTime.size() - 1));

		this.foldResults.put(name, foldResult);
	}

	@Override
	public String toString() {
		String result = "";
//		result += String.format("%-25s", "Evaluation Date") + " : ";
//		result += evaluationDate + "\n";
//
//		result += String.format("%-25s", "DecompositionType") + " : ";
//		result += this.getDecompositionType() + "\n";
//
//		result += String.format("%-25s", "AggregationType") + " : ";
//		result += this.getAggregationType() + "\n";
//
//		result += String.format("%-25s", "BaseLearnerEnvironment") + " : ";
//		result += this.getEnvironment() + "\n";
//
//		result += String.format("%-25s", "Classifier") + " : ";
//		result += this.getClassifierName() + "\n";
//
//		result += String.format("%-25s", "Classification Type") + " : ";
//		result += this.ext_instances.getType() + "\n";
//
//		// result += String.format("%-25s", "Class Attribute") + " : ";
//		// result += this.classAttributeType + "\n";
//
//		result += String.format("%-25s", "Symetric") + " : ";
//		result += this.isSymmetric + "\n";
//
//		result += String.format("%-25s", "Number of Folds") + " : ";
//		result += this.getFolds() + "\n";
//
//		result += String.format("%-25s", "Number of Instances") + " : ";
//		result += this.ext_instances.numInstances() + "\n";
//
//		result += "\n";
//
//		for (String s : foldResults.keySet()) {
//			result += "=== "
//					+ s
//					+ " ===================================================== \n";
//			result += foldResults.get(s).toString() + "\n";
//		}

		// Durchschnitt �ber alle Folds
		result += new AverageOfFoldResults(this.getFoldResults());

//		result += "\n";
//		result += "Total Computation Time: " + this.getTimeMs() + " ms";

		return result;
	}
}
