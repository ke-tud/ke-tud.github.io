/**
 */
package LPCforSOS.structuredPrediction;

import weka.core.Instance;
import weka.core.Instances;
import LPCforSOS.baseLearner.DecomposedDatasetLearner;
import LPCforSOS.dataStructure.ExtInstances;
import weka.core.FastVector;
import weka.core.Attribute;

/**
 * @author Sandra Ebert
 * @author Sang-Hyeun Park
 * @date 19.01.2010
 */
public class Voting extends StructuredPredictor {

	/*
	 * (non-Javadoc)
	 * 
	 * @see LPCforSOS.structuredPrediction.StructuredPredictor#classifyInstances(LPCforSOS.dataStructure.ExtInstances)
	 */
	@Override
	public void classifyInstances(Instances test,
			DecomposedDatasetLearner learner,
			ExtInstances trainingSet) throws Exception {
		initialize();

		double probabilities[][] = new double[test.numInstances()][learner
				.getBaseClassifier().size()];
		double[][] voting = new double[test.numInstances()][test.numClasses()];

		// preprocess test instances to work correctly with decomposed base learners, e.g. set class headers for pairwise classifiers to 
		// positive and negative and so on, currently works only for pairwise multiclass and pairwise ordinal classification, complete later on. 
		// teilweise von weka
	    // construct a two-class header version of the dataset
	      Instances m_TwoClassDataset = new Instances(test, 0);
	      int classIndex = m_TwoClassDataset.classIndex();
	      m_TwoClassDataset.setClassIndex(-1);
	      m_TwoClassDataset.deleteAttributeAt(classIndex);
	      FastVector classLabels = new FastVector();
	      classLabels.addElement("class0");
	      classLabels.addElement("class1");
	      m_TwoClassDataset.insertAttributeAt(new Attribute("class", classLabels),
						  classIndex);
	      m_TwoClassDataset.setClassIndex(classIndex);		
	      
	      
		for (int i = 0; i < test.numInstances(); i++) {
			Instance instance = test.instance(i);
		    Instance tempInst = (Instance)instance.copy(); 
		    tempInst.setDataset(m_TwoClassDataset);
			for (int j = 0; j < learner.getBaseClassifier().size(); j++) {

				probabilities[i][j] = learner.getBaseClassifier().get(j)
						.classifyInstance(tempInst);
				

				String realClass = learner.getDecomposedDatasets().get(j)
						.classAttribute().value((int) probabilities[i][j]);
				voting[i][learner.getClassToNumber().get(realClass)]++;
			}
			voteVector.add(voting[i]);
		}
	}
}
