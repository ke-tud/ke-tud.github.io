package LPCforSOS.evaluation;

import java.util.ArrayList;

import LPCforSOS.baseLearner.BaseLearnerEnvironment;
import LPCforSOS.decomposition.DecompositionType;
import LPCforSOS.structuredPrediction.AggregationType;

/**
 * Hier kann das Framework durch Manipulation der Konstanten eingestellt werden.
 * 
 * @author George-P. C.F.
 */
public class Configuration {

	private static final String CALIBRATION_LABEL_PREFIX = "L";
	// meta-learner settings
	public static DecompositionType decompositionType = DecompositionType.PairwiseDecomposer;
	public static AggregationType aggregationType =
	// AggregationType.WeightedVoting;
	// AggregationType.WuLingWeng;
	// AggregationType.WuLingWengLIBSVMVersion;
	// AggregationType.HastieTibshirani;
	AggregationType.Voting;

	// evaluation
	public static String positionOfEARFFFile = "datasets/BeLaE_test.earff";
	public static int numberOfFolds = 10;
	public static long seedForEvaluation = 2;

	// base-learner settings
	public static BaseLearnerEnvironment baseLearnerEnvironment = BaseLearnerEnvironment.WekaBaseLearner;
	public static String positionOfClassifier = "weka.classifiers.meta.OrdinalClassClassifier"; // nearly
																				// all
																				// weka.classifiers
																				// possible
	public static boolean isSymmetricClassifier = true; // not really necessary,
														// better introduce a
														// new type, sth. like
														// DoublePairwiseDecomposer

	// spark 29.01.10 : what is its purpose
	// public static boolean evaluateBaseClassifiers = false;

	// calibrated label ranking specific, minor important
	// for debug purposes, pre-specification of calibrated label name is
	// possible
	private static int currentCaliLabelIndex = 0;
	private static ArrayList<String> caliLabels = new ArrayList<String>();
	static {
		caliLabels.add("L0");
	}

	public static String getCalibrationLabel() {
		return caliLabels.get(currentCaliLabelIndex);
	}
	
	public static String getCalibrationLabel(int grade) {
		grade = grade < 0 ? 0 : grade;
		return CALIBRATION_LABEL_PREFIX + grade;
	}

	public static void nextCaliLabel() {
		currentCaliLabelIndex++;
		String caliLabel = CALIBRATION_LABEL_PREFIX + currentCaliLabelIndex;
		if (!caliLabels.contains(caliLabel)) {
			caliLabels.add(caliLabel);
		}
	}
	
	public static int getNumberOfCalilabels(){
		return currentCaliLabelIndex + 1;
	}

	public static void resetCaliLabels() {
		currentCaliLabelIndex = 0;
	}

	// specific aggregation type parameters. Note: we have to handle it later in
	// another way. Here HastieTibshirani specific
	public static double HTepsilon = 0.005;

	// for Wu, Ling, Weng aggregation
	public static int WLWmaxIterations = 100;
	public static double WLWepsilon = 0.005;

	/********************* ARFF Dateien von Weka einlesen ********************************/
	/**
	 * Hier kann die Constraint f�r die Klassifikation angegeben werden.
	 */
	public static String classAttributeConstraint = "2";

	/********************* Ende ARFF *******************************************************/
}
