/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.List;

/**
 * @author Christian Brinker
 *
 */
public class OneErrorLoss  implements RankLoss{
	public double calculateLoss(List<List<String>> relevantLabels, List<Double[]> voteVectors, List<String> votedStrings, List<String> allLabels){
		double loss = 0.0D;
		int numberOfInstances = relevantLabels.size();
		
		if(numberOfInstances == 0) return 0;
		
		for (int instance = 0; instance < numberOfInstances; instance++) {
			
			Double[] voteVector = voteVectors.get(instance);
			int highestVoted = 0;
			for (int i = 0; i < voteVector.length; i++) {
				if(voteVector[highestVoted] < voteVector[i]){
					highestVoted = i;
				}
			}		
			String highestVotedLabel = votedStrings.get(highestVoted);
			
			List<String> relevantLabelsOfInstance = relevantLabels.get(instance);
	
			int maxGrade = 0, highestVotedRealGrade = 0;
			for (String labelPlusGrade : relevantLabelsOfInstance) {
				int currentGrade = parseGrade(labelPlusGrade);
				if(parseLabel(labelPlusGrade).equals(highestVotedLabel)){
					highestVotedRealGrade = currentGrade;
				}
				
				if(currentGrade > maxGrade){
					maxGrade = currentGrade;
				}
			}
			
			loss += (maxGrade - highestVotedRealGrade) / 4.0D;
		}
		
		return loss / (numberOfInstances);
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}

	private String parseLabel(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}
}
