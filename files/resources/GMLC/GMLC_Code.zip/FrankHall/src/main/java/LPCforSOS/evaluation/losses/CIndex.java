/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Christian Brinker
 *
 */
public class CIndex implements RankLoss{
	public double calculateLoss(List<List<String>> relevantLabels, List<Double[]> voteVector, List<String> votedStrings, List<String> allLabels){
		double cindex = 0.0D;
		for (int instance = 0; instance < relevantLabels.size(); instance++) {
			double cindexOfInstance = 0.0D;
			int numOfCombinations = 0;
			List<String> relevantLabelsOfInstance = relevantLabels.get(instance);
			 
			Collections.sort(relevantLabelsOfInstance, new LabelGradeComparator
					());
			
			List<List<String>> gradeSeparatedLabels = separateLabelsByGrade(relevantLabelsOfInstance);
			
			for (int i = 0; i < gradeSeparatedLabels.size(); i++) {
				for (int j = i+1; j < gradeSeparatedLabels.size(); j++) {
					for (String label1 : gradeSeparatedLabels.get(i)) {
						for (String label2 : gradeSeparatedLabels.get(j)) {
							numOfCombinations++;
							String label1WithoutGrade = parseLabel(label1);
							double votesLabel1 = voteVector.get(instance)[votedStrings.indexOf(label1WithoutGrade)];
							
							String label2WithoutGrade = parseLabel(label2);
							double votesLabel2 = voteVector.get(instance)[votedStrings.indexOf(label2WithoutGrade)];
							
							if(votesLabel1 > votesLabel2){
								cindexOfInstance++;
							}else if(votesLabel1 == votesLabel2){
								cindexOfInstance += 0.5;
							}
						}
					}
				}
			}
			if(numOfCombinations != 0){
				cindex += cindexOfInstance / numOfCombinations;
			}
		}
		if(relevantLabels.size() == 0) return 0;
		
		return cindex / relevantLabels.size();
	}

	private List<List<String>> separateLabelsByGrade(
			List<String> relevantLabelsOfInstance) {
		List<List<String>> separatedLabels = new ArrayList<List<String>>();
		int separationGrade = 0;
		separatedLabels.add(new ArrayList<String>());
		for (String label : relevantLabelsOfInstance) {
			int grade = parseGrade(label);
			if(grade > separationGrade){
				separationGrade = grade;
				separatedLabels.add(separatedLabels.size(), new ArrayList<String>());
			}
			
			separatedLabels.get(separatedLabels.size() -1).add(label);
		}
		return separatedLabels;
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}

	private String parseLabel(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}
}
