/**
 * 
 */
package LPCforSOS.evaluation.losses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import weka.classifiers.evaluation.ConfusionMatrix;

/**
 * @author Christian Brinker
 * 
 */
public class OptimalCalibrationHammingLoss implements RankLoss {
	private double realHammingLoss;

	public double calculateLoss(List<List<String>> relevantLabels,
			List<Double[]> voteVector, List<String> votedStrings, List<String> allLabels) {
		
		ConfusionMatrix confusionMatrix = new ConfusionMatrix(
				allLabels.toArray(new String[allLabels.size()]));
		
		for (int instance = 0; instance < relevantLabels.size(); instance++) {
			List<String> relevantLabelsOfInstance = relevantLabels
					.get(instance);

			Collections.sort(relevantLabelsOfInstance,
					new LabelGradeComparator());

			List<List<String>> gradeSeparatedLabels = separateLabelsByGrade(relevantLabelsOfInstance);

			ArrayList<String> sortedStrings = new ArrayList<String>(
					votedStrings);
			Collections.sort(sortedStrings,
					new VoteComparator(voteVector.get(instance),
							votedStrings));
			
			int lastSeen = 0;
			for (int i = 0; i < gradeSeparatedLabels.size(); i++) {
				int seenCount = 0;
				
				int labelPlusGradeCount = gradeSeparatedLabels.get(i).size();

				for (int j = 0; j < labelPlusGradeCount; j++) {
					seenCount++;
					
					String label = sortedStrings.get(lastSeen + j);
					String predictedLabelPlusGrade = label + i;
					
					String realLabelPlusGrade = null;
					for (String currentLabel : relevantLabelsOfInstance) {
						if(parseLabel(currentLabel).equals(label)){
							realLabelPlusGrade = currentLabel;
						}
					}
					
					int posOfRealLabel = allLabels.indexOf(realLabelPlusGrade);
					int posOfPredictedLabel = allLabels.indexOf(predictedLabelPlusGrade);

					double elementValue = confusionMatrix.getElement(
							posOfRealLabel, posOfPredictedLabel) + 1;
					confusionMatrix.setElement(posOfRealLabel, posOfPredictedLabel,
							elementValue);
				}
				
				lastSeen += seenCount;
			}
		}
		
		Set<String> labelsWithoutGrade = new HashSet<String>();
		for (String labelplusGrade : allLabels) {
			labelsWithoutGrade.add(parseLabel(labelplusGrade));
		}

		
		double calculatedLoss = new VerticalHammingDistanceLoss().calculateLoss(confusionMatrix, labelsWithoutGrade.size());

		return Math.abs(realHammingLoss - calculatedLoss);
	}

	private class VoteComparator implements Comparator<String> {

		private Double[] votes;
		private List<String> votedStrings;

		public VoteComparator(Double[] doubles, List<String> votedStrings) {
			this.votes = doubles;
			this.votedStrings = votedStrings;
		}

		@Override
		public int compare(String s1, String s2) {
			int o1 = votedStrings.indexOf(s1);
			int o2 = votedStrings.indexOf(s2);
			if (votes[o1] < votes[o2]) {
				return -1;
			} else if (votes[o1] == votes[o2]) {
				return 0;
			}
			return 1;
		}

	}

	private List<List<String>> separateLabelsByGrade(
			List<String> relevantLabelsOfInstance) {
		List<List<String>> separatedLabels = new ArrayList<List<String>>();
		for (int i = 0; i < 5; i++) {
			separatedLabels.add(new ArrayList<String>());
		}

		for (String label : relevantLabelsOfInstance) {
			int grade = parseGrade(label);

			separatedLabels.get(grade).add(parseLabel(label));
		}
		return separatedLabels;
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}

	private String parseLabel(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}

	public void setRealHammingLoss(double realHammingLoss) {
		this.realHammingLoss = realHammingLoss;
	}
}
