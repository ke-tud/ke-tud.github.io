package LPCforSOS.evaluation.losses;

import java.util.List;

public interface RankLoss {

	double calculateLoss(List<List<String>> relevantLabels,
			List<Double[]> votes, List<String> votedStrings, List<String> allLabels);

}
