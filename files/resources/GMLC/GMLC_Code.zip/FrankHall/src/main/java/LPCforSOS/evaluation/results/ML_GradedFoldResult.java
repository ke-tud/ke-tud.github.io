package LPCforSOS.evaluation.results;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;

import weka.classifiers.evaluation.ConfusionMatrix;
import LPCforSOS.dataStructure.ExtConfusionMatrix;
import LPCforSOS.dataStructure.TwoClassConfusionMatrix;
import LPCforSOS.evaluation.Configuration;
import LPCforSOS.evaluation.losses.AccuracyLoss;
import LPCforSOS.evaluation.losses.CIndex;
import LPCforSOS.evaluation.losses.F1Loss;
import LPCforSOS.evaluation.losses.FalloutLoss;
import LPCforSOS.evaluation.losses.FpRate;
import LPCforSOS.evaluation.losses.IConfusionMatrixBasedLossFunction;
import LPCforSOS.evaluation.losses.OMConfusionMatrixBasedLossFunction;
import LPCforSOS.evaluation.losses.OneErrorLoss;
import LPCforSOS.evaluation.losses.OptimalCalibrationHammingLoss;
import LPCforSOS.evaluation.losses.PrecisionLoss;
import LPCforSOS.evaluation.losses.RankLoss;
import LPCforSOS.evaluation.losses.RecallLoss;
import LPCforSOS.evaluation.losses.TpRate;
import LPCforSOS.evaluation.losses.VerticalHammingDistanceLoss;
import LPCforSOS.evaluation.losses.ZeroOneLoss;

public class ML_GradedFoldResult extends AFoldResult {

	private List<IConfusionMatrixBasedLossFunction> twoClassConfusionMatrixBasedlosses;
	private List<OMConfusionMatrixBasedLossFunction> confusionMatrixBasedLosses;
	private List<RankLoss> rankLosses;

	ConfusionMatrix sumOfConfusionMatricesOfAllInstances;
	private final List<HashMap<String, List<String>>> predictions = new ArrayList<HashMap<String, List<String>>>();

	private ConfusionMatrix microAveragedConfusionMatrix;

	@SuppressWarnings("deprecation")
	@Override
	public void evaluate() {
		Set<String> tmp = new HashSet<String>();
		for (String labelplusGrade : this.allLabels) {
			tmp.add(parseLabel(labelplusGrade));
		}
		List<String> labelsWithoutGrade = new ArrayList<String>(tmp);

		ConfusionMatrix confusionMatrix = new ConfusionMatrix(
				this.allLabels.toArray(new String[this.allLabels.size()]));
		
		for (int instance = 0; instance < this.voteVector.size(); instance++) {
			
			
			
			for (int i = 0; i < this.votedStrings.size(); i++) {
				
				String realLabel = this.votedStrings.get(i);
				int realGrade = 0;
				for (String currentLabel : relevantLabels.get(instance)) {
					if (parseLabel(currentLabel).equals(realLabel)) {
						realGrade = parseGrade(currentLabel);
					}
				}

				int predictedGrade = (int) this.voteVector.get(instance)[i];

				int posOfRealLabel = allLabels.indexOf(realLabel+realGrade);
				int posOfPredictedLabel = allLabels.indexOf(realLabel
						+ predictedGrade);

				double elementValue = confusionMatrix.getElement(
						posOfRealLabel, posOfPredictedLabel) + 1;
				confusionMatrix.setElement(posOfRealLabel, posOfPredictedLabel,
						elementValue);
			}
		}
		
		microAveragedConfusionMatrix = ExtConfusionMatrix
				.doMicroAveraging(confusionMatrix);
		TwoClassConfusionMatrix microAveragedTwoClassConfusionMatrix = new TwoClassConfusionMatrix(
				microAveragedConfusionMatrix);
		
		for (OMConfusionMatrixBasedLossFunction lossFunction : confusionMatrixBasedLosses) {
			this.lossResults.put(lossFunction.getClass().getName(), lossFunction.calculateLoss(confusionMatrix, votedStrings.size()));
		}
		
		ArrayList<Double[]> flattedPredictions = new ArrayList<Double[]>();
		for (int i = 0; i < voteVector.size(); i++) {
			double[] voteVectorOfInstance = voteVector.get(i);
			flattedPredictions.add(new Double[voteVectorOfInstance.length]);
			for (int j = 0; j < voteVectorOfInstance.length; j++) {
				flattedPredictions.get(i)[j] = voteVectorOfInstance[j];
			}
		}
		
		for (RankLoss lossFunction : rankLosses) {
			this.lossResults.put(lossFunction.getClass().getName(), lossFunction.calculateLoss(relevantLabels, flattedPredictions, votedStrings, allLabels));
		}
	}

	private int getSplitPoint(String classIDLabel) {
		int splitPoint = 0;
		for (int i = 1; i <= classIDLabel.length(); i++) {
			if (!Character.isDigit(classIDLabel.charAt(classIDLabel.length()
					- i))) {
				splitPoint = classIDLabel.length() - i + 1;
				break;
			}
		}
		return splitPoint;
	}
	
	private String parseLabel(String classIDLabel) {
		int splitPoint = getSplitPoint(classIDLabel);
		return classIDLabel.substring(0, splitPoint);
	}

	private int parseGrade(String label) {
		int splitPoint = getSplitPoint(label);
		return Integer.parseInt(label.substring(splitPoint));
	}

	@Override
	protected void addLosses() {

		this.confusionMatrixBasedLosses = new ArrayList<OMConfusionMatrixBasedLossFunction>();
		this.confusionMatrixBasedLosses.add(new ZeroOneLoss());
		this.confusionMatrixBasedLosses.add(new VerticalHammingDistanceLoss());
		
		this.rankLosses = new ArrayList<RankLoss>();
		this.rankLosses.add(new CIndex());
		this.rankLosses.add(new OneErrorLoss());
	}
	
	@Override
	public String toString() {
		String result = "";

		result += super.toString();
		result += "\n";
		result += "relevant Labels: " + relevantLabels + "\n";
		result += "votes: " + this.predictions + "\n";
		result += microAveragedConfusionMatrix
				.toString("=== Micro Averaged Confusion Matrix ===") + "\n";
		return result;
	}
}
// Set<String> labelsWithoutGrade = new HashSet<String>();
// for (String labelplusGrade : this.allLabels) {
// labelsWithoutGrade.add(parseLabel(labelplusGrade));
// }
//
// ConfusionMatrix confusionMatrix = new ConfusionMatrix(
// this.allLabels.toArray(new String[this.allLabels.size()]));
//
// for (int i = 0; i < voteVector.size(); i++) {
// double[] votesOfInstance = voteVector.get(i);
// HashMap<String, Integer> caliLabelPositions = getCaliLabelPositions();
// HashMap<String, Double> votesForCalibrationLabels =
// filterVotesOfCalibrationLabels(
// votesOfInstance, caliLabelPositions);
//
// HashMap<String, List<String>> predictionForInstance = new HashMap<String,
// List<String>>();
//
// for (int j = 0; j < votesOfInstance.length; j++) {
// Set<String> calibrationLabels = caliLabelPositions.keySet();
// for (String calibrationLabel : calibrationLabels) {
// List<String> predictionOfCaliLabel = predictionForInstance
// .get(calibrationLabel);
// if (predictionOfCaliLabel == null) {
// predictionOfCaliLabel = new ArrayList<String>();
// predictionForInstance.put(calibrationLabel,
// predictionOfCaliLabel);
// }
//
// // Wert muss groesser sein da sonst calibrationlabel mit in
// // die Prediction kommt(oder for-schleife verkleinern).
// if (votesOfInstance[j] > votesForCalibrationLabels
// .get(calibrationLabel)) {
// String predictedLabel = votedStrings.get(j);
// if (calibrationLabels.contains(predictedLabel)) {
// continue;
// }
// predictionOfCaliLabel.add(predictedLabel);
// }
// }
//
// for (String label1 : calibrationLabels) {
// for (String label2 : calibrationLabels) {
// if (parseGrade(label1) < parseGrade(label2)) {
// List<String> predictionForLabel1 = predictionForInstance
// .get(label1);
// List<String> predictionsForLabel2 = predictionForInstance
// .get(label2);
//
// if (predictionForLabel1 != null
// && predictionsForLabel2 != null) {
// predictionForLabel1
// .removeAll(predictionsForLabel2);
// }
// }
// }
// }
// }
//
// this.predictions.add(predictionForInstance);
//
// for (String label : labelsWithoutGrade) {
// int realGrade;
// String realLabel = "";
// for (String currentLabel : relevantLabels.get(i)) {
// if (parseLabel(currentLabel).equals(label)) {
// realGrade = parseGrade(currentLabel);
// realLabel = currentLabel;
// }
// }
//
// int predictedGrade = 0;
// for (String calibrationLabel : predictionForInstance.keySet()) {
// if (predictionForInstance.get(calibrationLabel).contains(
// label)) {
// predictedGrade = parseGrade(calibrationLabel) + 1;
// }
// }
//
// int posOfRealLabel = allLabels.indexOf(realLabel);
// int posOfPredictedLabel = allLabels.indexOf(label
// + predictedGrade);
//
// double elementValue = confusionMatrix.getElement(
// posOfRealLabel, posOfPredictedLabel) + 1;
// confusionMatrix.setElement(posOfRealLabel, posOfPredictedLabel,
// elementValue);
// }
// }
// microAveragedConfusionMatrix = ExtConfusionMatrix
// .doMicroAveraging(confusionMatrix);
// TwoClassConfusionMatrix microAveragedTwoClassConfusionMatrix = new
// TwoClassConfusionMatrix(
// microAveragedConfusionMatrix);
//
// for(IConfusionMatrixBasedLossFunction lossFunction :
// twoClassConfusionMatrixBasedlosses)
// {
// double lossResult =
// lossFunction.calculateLossFunction(microAveragedTwoClassConfusionMatrix);
// String lossNamePlusPackage = lossFunction.getClass().getName();
// this.lossResults.put(lossNamePlusPackage, lossResult);
// }
//
// double realHammingLoss = 0.0D;
// for (OMConfusionMatrixBasedLossFunction lossFunction :
// confusionMatrixBasedLosses) {
// double calculatedLoss = lossFunction.calculateLoss(confusionMatrix,
// labelsWithoutGrade.size());
// if(lossFunction instanceof VerticalHammingDistanceLoss){
// realHammingLoss = calculatedLoss;
// }
// this.lossResults.put(lossFunction.getClass().getName(), calculatedLoss);
// }
//
// List<String> labels = new ArrayList<String>();
// HashMap<String,Integer> caliLabelPositions = getCaliLabelPositions();
// for (String label : votedStrings) {
// if(!caliLabelPositions.containsKey(label)){
// labels.add(label);
// }
// }
// List<Integer> caliLabelPositionsList = new ArrayList<Integer>();
// for (Entry<String, Integer> entry : caliLabelPositions.entrySet()) {
// caliLabelPositionsList.add(entry.getValue());
// }
// List<Double[]> votes = new ArrayList<Double[]>();
// for(int i = 0; i < voteVector.size(); i++){
// double[] voteArray = voteVector.get(i);
// List<Double> tmp = new ArrayList<Double>();
// for (int j = 0; j < voteArray.length; j++) {
// if(!caliLabelPositionsList.contains(j)){
// tmp.add(voteArray[j]);
// }
// }
// votes.add(tmp.toArray(new Double[tmp.size()]));
// }
//
// for (RankLoss lossFunction : rankLosses) {
// if(lossFunction instanceof OptimalCalibrationHammingLoss){
// ((OptimalCalibrationHammingLoss)
// lossFunction).setRealHammingLoss(realHammingLoss );
// }
// this.lossResults.put(lossFunction.getClass().getName(),
// lossFunction.calculateLoss(relevantLabels, votes, labels, this.allLabels));
// }
// }
//
// private boolean isRealLabel(int i, String classIDLabel) {
// return this.relevantLabels.get(i).contains(classIDLabel);
// }
//
// private boolean isPredicted(
// HashMap<String, List<String>> predictionForInstance, int realGrade,
// String realClass) {
// if (realGrade == 0) {
// for (String calibrationLabel : predictionForInstance.keySet()) {
// if (predictionForInstance.get(calibrationLabel).contains(
// realClass)) {
// return false;
// }
// }
// return true;
// }
// List<String> predictionForCalibrationLabel = predictionForInstance
// .get(getCaliLabelForGrade(realGrade));
// return predictionForCalibrationLabel.contains(realClass);
// }
//
// private String parseLabel(String classIDLabel) {
// int splitPoint = getSplitPoint(classIDLabel);
// return classIDLabel.substring(0, splitPoint);
// }
//

//
// private String getCaliLabelForGrade(int grade) {
// String calibrationLabel = Configuration.getCalibrationLabel(grade - 1);
// return calibrationLabel;
// }
//
// private HashMap<String, Double> filterVotesOfCalibrationLabels(
// double[] votesOfInstance,
// HashMap<String, Integer> caliLabelPositions) {
// HashMap<String, Double> votesForCalibrationLabels = new HashMap<String,
// Double>();
// for (String calibrationLabel : caliLabelPositions.keySet()) {
// votesForCalibrationLabels.put(calibrationLabel,
// votesOfInstance[caliLabelPositions.get(calibrationLabel)]);
// }
// return votesForCalibrationLabels;
// }
//
// private HashMap<String, Integer> getCaliLabelPositions() {
// Configuration.resetCaliLabels();
// HashMap<String, Integer> calibratedLabelPositions = new HashMap<String,
// Integer>();
// for (int i = 0; i < this.votedStrings.size(); i++) {
// String currentLabel = this.votedStrings.get(i);
// if (currentLabel.equals(Configuration.getCalibrationLabel())) {
// calibratedLabelPositions.put(currentLabel, i);
// Configuration.nextCaliLabel();
// }
// }
// return calibratedLabelPositions;
// }
//
// @Override
// protected void addLosses() {
// twoClassConfusionMatrixBasedlosses = new
// ArrayList<IConfusionMatrixBasedLossFunction>();
//
// this.twoClassConfusionMatrixBasedlosses.add(new AccuracyLoss());
// this.twoClassConfusionMatrixBasedlosses.add(new TpRate());
// this.twoClassConfusionMatrixBasedlosses.add(new FpRate());
// this.twoClassConfusionMatrixBasedlosses.add(new RecallLoss());
// this.twoClassConfusionMatrixBasedlosses.add(new PrecisionLoss());
// this.twoClassConfusionMatrixBasedlosses.add(new F1Loss());
// this.twoClassConfusionMatrixBasedlosses.add(new FalloutLoss());
//
// this.confusionMatrixBasedLosses = new
// ArrayList<OMConfusionMatrixBasedLossFunction>();
//
// this.confusionMatrixBasedLosses.add(new ZeroOneLoss());
// this.confusionMatrixBasedLosses.add(new VerticalHammingDistanceLoss());
//
// this.rankLosses = new ArrayList<RankLoss>();
// this.rankLosses.add(new CIndex());
// this.rankLosses.add(new OneErrorLoss());
// this.rankLosses.add(new OptimalCalibrationHammingLoss());
// }
//
// @Override
// public String toString() {
// String result = "";
//
// result += super.toString();
// result += "\n";
// result += "relevant Labels: " + relevantLabels + "\n";
// result += "votes: " + this.predictions + "\n";
// result += microAveragedConfusionMatrix
// .toString("=== Micro Averaged Confusion Matrix ===") + "\n";
// return result;
// }
// }
