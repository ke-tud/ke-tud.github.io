**********************************************************************************
**********************************************************************************
**									        **
**      User Manual for Graded Multilabel Classification Experiments            **
**       more info at http://www.ke.tu-darmstadt.de/resources/GMLC              **
**									        **
**********************************************************************************
**********************************************************************************

           PLEASE READ THIS MANUAL BEFORE WORKING WITH THE CODE!


**********************************************************************************
**********************************************************************************

GENERAL INFORMATION:

In this archive file you will find the code for the various approaches from 

C. Brinker, E. Loza Menc�a and J. F�rnkranz, "Graded Multilabel Classification by 
Pairwise Comparisons", in Proceedings of the 14th International Conference on Data 
Mining(ICDM-2014), 2014

and the experiments described there. A more detailed description, especially of 
the experiments and datasets, can be found in

C. Brinker, E. Loza Menc�a and J. F�rnkranz, "Graded multilabel classification by 
pairwise comparisons", TU Darmstadt, Tech. Rep. TUD-KE-2014-01, 2014. [Online 
Available]: http://www.ke.tu-darmstadt.de/publications/reports/tud-ke-2014-01.pdf


The code uses an outdated version of the 
LPCforSOS framework ( http://lpcforsos.sourceforge.net/ ). This uses Java 1.6 and
Weka 3.7 ( http://www.cs.waikato.ac.nz/~ml/weka/ ). The code was developed using 
the Eclipse IDE ( http://eclipse.org/ ). Because of incompabillities between the 
different approaches in the usage of the framework, each of the approaches is 
developed in its own branch of the framework as separate eclipse project. Each 
represented as an own folder in this archive file:

- BinaryRelevance
- FrankHall
- FullCLR
- HorizontalCLR
- JoinedCLR

NOTE: We obtained the code of the IBLR-ML algorithm directly from the authors, so 
you may obtain it from there too or use the version contained in MULAN 
(http://mulan.sourceforge.net/doc/mulan/classifier/lazy/IBLR_ML.html).

EXPERIMENTS:

For the above referenced approaches four different kinds of experiments have been
done:

- 50 generated datasets from BeLaE with 5 labels
- 50 generated datasets from BeLaE with 10 labels
- medical dataset
- movie dataset

For each of the experiments there exists a separate main-class in each of the projects:

- EvaluationBeLaE5.java
- EvaluationBeLaE10.java
- EvaluationMedical.java
- EvaluationMovie.java

They can be found in each project under 
"<project-folder>/src/main/java/LPCforSOS/evaluation/".

Each of the main-methods in the classes consumes three arguments:

1. Prediction method: 'v' - voting, 'w' - weighted voting, 't' - voting with 
     weighted voting as tie breaking strategy
2. path of the directory containing the dataset(s)
2. path and name of the output file for the results (results will be appended)

NOTE: Weighted voting and tie breaking methods are actually not implemented for 
all of the approaches. In case of using them although not implemented the programm 
will terminate immediately.

NOTE: Some of the experiments will need their time. The code is not optimized for 
short runtimes and the experiments can take several hours. If you want to speed up 
please remark that the slowest part is the learning of the several base classifiers. 
This can be easily parallelized using threads and/or clusters.

The datasets are available online at http://www.ke.tu-darmstadt.de/resources/GMLC