This is the kea add-on.  It contains:

* A program (lib/main.js).
* A few tests.
* Some meager documentation.
