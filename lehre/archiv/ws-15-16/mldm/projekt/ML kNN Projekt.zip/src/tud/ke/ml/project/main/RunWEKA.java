package tud.ke.ml.project.main;

import weka.gui.GUIChooser;

public class RunWEKA {
	
	public static void main(String[] args) {
		GUIChooser.main(args);
	}

}
