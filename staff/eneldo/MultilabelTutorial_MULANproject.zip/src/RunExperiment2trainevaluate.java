import java.util.Arrays;

import weka.classifiers.trees.J48;
import weka.core.Instances;

import mulan.classifier.MultiLabelLearner;
import mulan.classifier.MultiLabelOutput;
import mulan.classifier.transformation.BinaryRelevance;
import mulan.data.MultiLabelInstances;
import mulan.evaluation.Evaluation;
import mulan.evaluation.Evaluator;
import mulan.evaluation.MultipleEvaluation;




public class RunExperiment2trainevaluate {

	public static void main(String[] args) throws Exception {

		String trainFile="data/emotions-train.arff";
		String testFile="data/emotions-test.arff";
		String xmlFile="data/emotions.xml";
		
	
		MultiLabelInstances trainInstances = new MultiLabelInstances(trainFile, xmlFile);
		MultiLabelInstances testInstances = new MultiLabelInstances(testFile, xmlFile);
		
		
		//set binary base learner and multilabel learner
		J48 baseLearner = new J48();
		MultiLabelLearner multilabelLearner = new BinaryRelevance(baseLearner);
		
		//train
		multilabelLearner.build(trainInstances);
		System.out.println(multilabelLearner);

		//make a single prediction
		MultiLabelOutput prediction = multilabelLearner.makePrediction(testInstances.getDataSet().instance(1));
		System.out.println(prediction);
		
		//testing and evaluating on test data
		Evaluator evaluator = new Evaluator();
		Evaluation results = evaluator.evaluate(multilabelLearner, testInstances, trainInstances ); //second parameter only for statistics
		System.out.println(results);

		//testing on training data
		results = evaluator.evaluate(multilabelLearner, trainInstances, trainInstances );
		System.out.println(results);

		//do cross validation
		trainFile="data/emotions.arff";
		trainInstances = new MultiLabelInstances(trainFile, xmlFile);

		MultipleEvaluation cvResults = evaluator.crossValidate(multilabelLearner, trainInstances, 10);
		System.out.println(cvResults);
		
	}
}
