import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import weka.classifiers.AbstractClassifier;
import weka.classifiers.Classifier;
import weka.classifiers.rules.JRip;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.TechnicalInformation;
import weka.core.Utils;
import mulan.classifier.InvalidDataException;
import mulan.classifier.MultiLabelLearnerBase;
import mulan.classifier.MultiLabelOutput;
import mulan.classifier.transformation.BinaryRelevance;
import mulan.data.MultiLabelInstances;


public class DBR2 extends MultiLabelLearnerBase {

	Classifier baseLearner;
	Classifier[] stackedBR;

	BinaryRelevance unstackedBR;

	
	public DBR2(Classifier baseLearner) {
		this.baseLearner = baseLearner;
	}

	
	@Override
	protected void buildInternal(MultiLabelInstances multilabelTrainingInstances)
			throws Exception {

		//for repeated access
		numLabels=multilabelTrainingInstances.getNumLabels();
		labelNames=multilabelTrainingInstances.getLabelNames();

		//build unstacked BR classifier for initialization of predictions
		unstackedBR=new BinaryRelevance(baseLearner);
		unstackedBR.build(multilabelTrainingInstances);
		
		
		//build stacked BR
		labelIndices=multilabelTrainingInstances.getLabelIndices();
		stackedBR=new Classifier[numLabels];
		for(int labelNo=0;labelNo<labelIndices.length;labelNo++){
			
			//take original weka instances object and just set the correct class index  
			int labelAttributeIndex=labelIndices[labelNo];
			Instances subProblemInstances = multilabelTrainingInstances.getDataSet();
			subProblemInstances.setClassIndex(labelAttributeIndex);  //TODO: this is not safe!!

			Classifier currentBaseLearner = AbstractClassifier.makeCopy(baseLearner);
			System.out.println("Bulding model " + (labelNo + 1) + "/" + numLabels);
			currentBaseLearner.buildClassifier(subProblemInstances);
			stackedBR[labelNo]=currentBaseLearner;
			
		}


	}

	@Override
	protected MultiLabelOutput makePredictionInternal(Instance instance)
			throws Exception, InvalidDataException {

		//in order to not change the given instance object
		Instances dataset=new Instances(instance.dataset(),0);
		Instance toPredict=(Instance) instance.copy();
		toPredict.setDataset(dataset);
		
		//make predictions for unstacked BR
		MultiLabelOutput pred = unstackedBR.makePrediction(instance);
		boolean[] biPartitions = pred.getBipartition();
		//not necessary
		double[] confidenceValues = pred.getConfidences();

		//put BR predictions into test instance
		for(int labelNo=0;labelNo<numLabels;labelNo++){
			int labelAttributeIndex=labelIndices[labelNo];
			if(biPartitions[labelNo]==true)
				toPredict.setValue(labelAttributeIndex, 1); //set positive
			else
				toPredict.setValue(labelAttributeIndex, 0); //set negative
		}
		
		//do predictions for stacked BR
		for(int labelNo=0;labelNo<numLabels;labelNo++){
				Classifier singleClassifier = stackedBR[labelNo];
				
				//set the correct label index
				int labelAttributeIndex=labelIndices[labelNo];
				dataset.setClassIndex(labelAttributeIndex);
				
				//use WEKA base learner predictions
				double[] distr = singleClassifier.distributionForInstance(toPredict);
				confidenceValues[labelNo]=distr[1]; //assume class 0 is negative and class 1 positive one
				if (confidenceValues[labelNo] > 0.5){ 
					biPartitions[labelNo]=true;
				}else{  //distr[1]<0.5
					biPartitions[labelNo]=false;
				}
			}

		//produce output -> final prediction
		return new MultiLabelOutput(biPartitions,confidenceValues);
//		return null;
	}

	public String toString(){
		String output="";
		output+="Dependent Binary Relevance with base learner "+baseLearner.getClass().getSimpleName();
		for(int labelNo=0;labelNo<numLabels;labelNo++){
			output+="\nUnstacked BR model "+(labelNo+1)+"/"+numLabels+" for label "+labelNames[labelNo]+":\n";
			output+=unstackedBR.getModel(labelNames[labelNo]);

			Classifier singleClassifier = stackedBR[labelNo];
			output+="\nStacked BR model "+(labelNo+1)+"/"+numLabels+" for label "+labelNames[labelNo]+":\n";
			output+=singleClassifier;
			
		}
		return output;
	}

	
	@Override
	public TechnicalInformation getTechnicalInformation() {
		// TODO Auto-generated method stub
		return null;
	}

}
