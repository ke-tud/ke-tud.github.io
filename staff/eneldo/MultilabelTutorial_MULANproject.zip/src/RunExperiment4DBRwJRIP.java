import java.util.Arrays;

import weka.classifiers.rules.JRip;
import weka.classifiers.trees.J48;
import weka.core.Instances;

import mulan.classifier.MultiLabelLearner;
import mulan.classifier.MultiLabelOutput;
import mulan.classifier.transformation.BinaryRelevance;
import mulan.data.MultiLabelInstances;
import mulan.evaluation.Evaluation;
import mulan.evaluation.Evaluator;




public class RunExperiment4DBRwJRIP {

	public static void main(String[] args) throws Exception {

//		String trainFile="data/emotions-train.arff";
//		String testFile="data/emotions-test.arff";
//		String xmlFile="data/emotions.xml";
		String trainFile="data/medical-train.arff";
		String testFile="data/medical-test.arff";
		String xmlFile="data/medical.xml";
//		String trainFile="data/enron-train.arff";
//		String testFile="data/enron-test.arff";
//		String xmlFile="data/enron.xml";
		
	
		MultiLabelInstances trainInstances = new MultiLabelInstances(trainFile, xmlFile);
		MultiLabelInstances testInstances = new MultiLabelInstances(testFile, xmlFile);
		
		//set binary base learner and multilabel learner
//		J48 baseLearner = new J48();
		JRip baseLearner = new JRip();
//		MultiLabelLearner multilabelLearner = new BinaryRelevance(baseLearner);
		MultiLabelLearner multilabelLearner = new DBR2(baseLearner);
		
		//train
		multilabelLearner.build(trainInstances);
		System.out.println(multilabelLearner);

		//make a single prediction
		MultiLabelOutput prediction = multilabelLearner.makePrediction(testInstances.getDataSet().instance(1));
		System.out.println(prediction);
		
		//testing and evaluating on test data
		Evaluator evaluator = new Evaluator();
		Evaluation results = evaluator.evaluate(multilabelLearner, testInstances, trainInstances ); //second parameter only for statistics
		System.out.println(results);


		
	}
}
