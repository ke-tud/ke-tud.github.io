import java.util.Arrays;

import weka.core.Instances;

import mulan.data.MultiLabelInstances;




public class RunExperiment1readdata {

	public static void main(String[] args) throws Exception {

		String trainFile="data/emotions-train.arff";
		String testFile="data/emotions-test.arff";
		String xmlFile="data/emotions.xml";
		
	
		MultiLabelInstances trainInstances = new MultiLabelInstances(trainFile, xmlFile);
		MultiLabelInstances testInstances = new MultiLabelInstances(testFile, xmlFile);
		
		System.out.println("numLabels: "+trainInstances.getNumLabels());
		System.out.println("labelNames: "+Arrays.toString(trainInstances.getLabelNames()));
		System.out.println("numTrainInstances: "+trainInstances.getNumInstances());
		System.out.println("numTestInstances: "+testInstances.getNumInstances());
//		System.out.println(testInstances.getDataSet());

		
		
		
		Instances empty = new Instances(testInstances.getDataSet(), 0);
		System.out.println(empty);
		System.out.println(testInstances.getDataSet().instance(1));
		
	}
}
